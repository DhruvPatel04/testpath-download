/**
 * Smart XPath Finder - Popup Script
 */

document.addEventListener('DOMContentLoaded', async () => {
  const btnInspect = document.getElementById('btnInspectPage');
  const statusAlert = document.getElementById('statusAlert');
  const btnReloadTab = document.getElementById('btnReloadTab');
  // --- Resizable Popup Engine ---
  const MIN_WIDTH = 320;
  const MAX_WIDTH = 800;
  const MIN_HEIGHT = 260;
  const MAX_HEIGHT = 600;
  const DEFAULT_WIDTH = 360;
  const DEFAULT_HEIGHT = 480;

  const STORAGE_KEY_WIDTH = '__xpath_popup_width__';
  const STORAGE_KEY_HEIGHT = '__xpath_popup_height__';
  const STORAGE_KEY_WIDE_LEGACY = '__xpath_popup_wide__';

  const btnSizeMenu = document.getElementById('btnSizeMenu');
  const sizePresetDropdown = document.getElementById('sizePresetDropdown');
  const btnResetSize = document.getElementById('btnResetSize');
  const presetOptions = document.querySelectorAll('.preset-opt[data-w]');
  const dimensionBadge = document.getElementById('resizeDimensionBadge');
  const resizerR = document.getElementById('popupResizerR');
  const resizerB = document.getElementById('popupResizerB');
  const resizerBr = document.getElementById('popupResizerBr');

  let badgeTimer = null;
  function showDimensionBadge(w, h) {
    if (!dimensionBadge) return;
    if (badgeTimer) clearTimeout(badgeTimer);
    dimensionBadge.textContent = `${Math.round(w)} × ${Math.round(h)} px`;
    dimensionBadge.classList.add('visible');
  }

  function hideDimensionBadge(delay = 900) {
    if (!dimensionBadge) return;
    if (badgeTimer) clearTimeout(badgeTimer);
    badgeTimer = setTimeout(() => {
      dimensionBadge.classList.remove('visible');
    }, delay);
  }

  function applyPopupSize(width, height, save = true, animate = false) {
    const clampedW = Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, Math.round(width)));
    const clampedH = Math.min(MAX_HEIGHT, Math.max(MIN_HEIGHT, Math.round(height)));

    if (animate) {
      document.body.classList.add('animating-size');
      setTimeout(() => {
        document.body.classList.remove('animating-size');
      }, 230);
    }

    document.documentElement.style.width = `${clampedW}px`;
    document.documentElement.style.height = `${clampedH}px`;
    document.body.style.width = `${clampedW}px`;
    document.body.style.height = `${clampedH}px`;

    // Highlight active preset button if matched
    if (presetOptions) {
      presetOptions.forEach((opt) => {
        const pw = parseInt(opt.getAttribute('data-w'), 10);
        const ph = parseInt(opt.getAttribute('data-h'), 10);
        if (Math.abs(pw - clampedW) <= 15 && Math.abs(ph - clampedH) <= 15) {
          opt.classList.add('active');
        } else {
          opt.classList.remove('active');
        }
      });
    }

    if (save) {
      try {
        localStorage.setItem(STORAGE_KEY_WIDTH, String(clampedW));
        localStorage.setItem(STORAGE_KEY_HEIGHT, String(clampedH));
      } catch (e) {}
    }

    return { width: clampedW, height: clampedH };
  }

  // Restore saved size or initialize default
  try {
    const savedW = localStorage.getItem(STORAGE_KEY_WIDTH);
    const savedH = localStorage.getItem(STORAGE_KEY_HEIGHT);
    const isWideLegacy = localStorage.getItem(STORAGE_KEY_WIDE_LEGACY) === 'true';

    if (savedW && savedH) {
      applyPopupSize(parseFloat(savedW), parseFloat(savedH), false, false);
    } else if (isWideLegacy) {
      applyPopupSize(480, 500, false, false);
    }
  } catch (e) {}

  // Drag-to-resize pointer handler
  function setupResizer(handle, direction) {
    if (!handle) return;

    handle.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 && e.pointerType === 'mouse') return;
      e.preventDefault();

      try {
        handle.setPointerCapture(e.pointerId);
      } catch (err) {}

      const startX = e.screenX;
      const startY = e.screenY;
      const startW = document.body.offsetWidth || DEFAULT_WIDTH;
      const startH = document.body.offsetHeight || DEFAULT_HEIGHT;

      document.body.classList.add('is-resizing');
      handle.classList.add('active');
      showDimensionBadge(startW, startH);

      function onPointerMove(ev) {
        if (ev.pointerId !== e.pointerId) return;

        const deltaX = ev.screenX - startX;
        const deltaY = ev.screenY - startY;

        let targetW = startW;
        let targetH = startH;

        if (direction.includes('r')) {
          targetW = startW + deltaX;
        }
        if (direction.includes('b')) {
          targetH = startH + deltaY;
        }

        const current = applyPopupSize(targetW, targetH, false, false);
        showDimensionBadge(current.width, current.height);
      }

      function onPointerUp(ev) {
        if (ev.pointerId !== e.pointerId) return;

        try {
          handle.releasePointerCapture(e.pointerId);
        } catch (err) {}

        handle.removeEventListener('pointermove', onPointerMove);
        handle.removeEventListener('pointerup', onPointerUp);
        handle.removeEventListener('pointercancel', onPointerUp);

        document.body.classList.remove('is-resizing');
        handle.classList.remove('active');

        const finalW = document.body.offsetWidth || targetW;
        const finalH = document.body.offsetHeight || targetH;
        applyPopupSize(finalW, finalH, true, false);

        hideDimensionBadge(1000);
      }

      handle.addEventListener('pointermove', onPointerMove);
      handle.addEventListener('pointerup', onPointerUp);
      handle.addEventListener('pointercancel', onPointerUp);
    });
  }

  setupResizer(resizerBr, 'rb');
  setupResizer(resizerR, 'r');
  setupResizer(resizerB, 'b');

  // Double click corner resizer to reset to default
  if (resizerBr) {
    resizerBr.addEventListener('dblclick', (e) => {
      e.preventDefault();
      applyPopupSize(DEFAULT_WIDTH, DEFAULT_HEIGHT, true, true);
      showDimensionBadge(DEFAULT_WIDTH, DEFAULT_HEIGHT);
      hideDimensionBadge(1200);
    });
  }

  // Size Presets Dropdown Menu
  if (btnSizeMenu && sizePresetDropdown) {
    btnSizeMenu.addEventListener('click', (e) => {
      e.stopPropagation();
      const isVisible = sizePresetDropdown.style.display === 'flex';
      sizePresetDropdown.style.display = isVisible ? 'none' : 'flex';
      btnSizeMenu.setAttribute('aria-expanded', String(!isVisible));
    });

    presetOptions.forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const targetW = parseInt(btn.getAttribute('data-w'), 10);
        const targetH = parseInt(btn.getAttribute('data-h'), 10);
        if (targetW && targetH) {
          applyPopupSize(targetW, targetH, true, true);
          showDimensionBadge(targetW, targetH);
          hideDimensionBadge(1000);
        }
        sizePresetDropdown.style.display = 'none';
        btnSizeMenu.setAttribute('aria-expanded', 'false');
      });
    });

    if (btnResetSize) {
      btnResetSize.addEventListener('click', (e) => {
        e.stopPropagation();
        applyPopupSize(DEFAULT_WIDTH, DEFAULT_HEIGHT, true, true);
        showDimensionBadge(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        hideDimensionBadge(1000);
        sizePresetDropdown.style.display = 'none';
        btnSizeMenu.setAttribute('aria-expanded', 'false');
      });
    }

    document.addEventListener('click', (e) => {
      if (!sizePresetDropdown.contains(e.target) && e.target !== btnSizeMenu) {
        sizePresetDropdown.style.display = 'none';
        btnSizeMenu.setAttribute('aria-expanded', 'false');
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && sizePresetDropdown.style.display === 'flex') {
        sizePresetDropdown.style.display = 'none';
        btnSizeMenu.setAttribute('aria-expanded', 'false');
      }
    });
  }

  function showAlert(message) {
    if (statusAlert) {
      statusAlert.textContent = message;
      statusAlert.style.display = 'block';
    }
  }

  function isRestrictedUrl(url) {
    if (typeof globalThis.isRestrictedUrl === 'function') {
      return globalThis.isRestrictedUrl(url);
    }
    if (!url) return false;
    return (
      url.startsWith('chrome://') ||
      url.startsWith('chrome-extension://') ||
      url.startsWith('edge://') ||
      url.startsWith('about:') ||
      url.startsWith('view-source:') ||
      url.startsWith('https://chrome.google.com/webstore')
    );
  }

  // Edge & Chrome compatible active tab getter
  async function getActiveTab() {
    try {
      const tabsCurrent = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabsCurrent && tabsCurrent.length > 0) return tabsCurrent[0];
      const tabsFocused = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tabsFocused && tabsFocused.length > 0) return tabsFocused[0];
      const allActive = await chrome.tabs.query({ active: true });
      return allActive && allActive.length > 0 ? allActive[0] : null;
    } catch (e) {
      return null;
    }
  }

  // Pre-check active tab
  try {
    const tab = await getActiveTab();
    if (tab && tab.url) {
      if (isRestrictedUrl(tab.url)) {
        btnInspect.disabled = true;
        btnInspect.style.opacity = '0.6';
        btnInspect.style.cursor = 'not-allowed';
        showAlert('⚠️ Extensions cannot inspect browser internal pages. Please switch to a regular website.');
      } else if (tab.url.startsWith('file://')) {
        if (chrome.extension && chrome.extension.isAllowedFileSchemeAccess) {
          chrome.extension.isAllowedFileSchemeAccess((isAllowed) => {
            if (!isAllowed) {
              showAlert('⚠️ Local file:/// page detected. Enable "Allow access to file URLs" in browser extension details.');
            }
          });
        }
      }
    }
  } catch (e) {}

  if (btnReloadTab) {
    btnReloadTab.addEventListener('click', async () => {
      const tab = await getActiveTab();
      if (tab && typeof tab.id === 'number' && tab.id >= 0) {
        chrome.tabs.reload(tab.id, {}, () => {
          window.close();
        });
      }
    });
  }

  btnInspect.addEventListener('click', async () => {
    try {
      const tab = await getActiveTab();
      if (!tab || typeof tab.id !== 'number' || tab.id < 0) {
        showAlert('No active web page found.');
        return;
      }

      if (isRestrictedUrl(tab.url)) {
        showAlert('⚠️ Extensions cannot inspect browser internal pages. Please navigate to any website first.');
        return;
      }

      const isFile = tab.url && tab.url.startsWith('file://');

      // Try sending message to active tab
      chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_INSPECT' }, () => {
        if (chrome.runtime.lastError) {
          // If content script was not yet injected, inject programmatically
          chrome.scripting.executeScript(
            {
              target: { tabId: tab.id },
              files: ['scripts/contentScript.js']
            },
            () => {
              if (chrome.runtime.lastError) {
                if (isFile) {
                  showAlert('⚠️ Local file access blocked. Enable "Allow access to file URLs" in extension details, then refresh this page (F5).');
                } else {
                  showAlert('⚠️ Page needs to be refreshed once to connect the extension.');
                  if (btnReloadTab) {
                    btnReloadTab.style.display = 'flex';
                  }
                }
                return;
              }
              setTimeout(() => {
                chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_INSPECT' }, () => {
                  window.close();
                });
              }, 120);
            }
          );
        } else {
          window.close();
        }
      });
    } catch (err) {
      console.error('Failed to trigger inspect mode:', err);
      showAlert('Error: ' + (err.message || 'Could not inspect page'));
    }
  });

  const btnFreezeInspect = document.getElementById('btnFreezeInspect');
  if (btnFreezeInspect) {
    btnFreezeInspect.addEventListener('click', async () => {
      try {
        const tab = await getActiveTab();
        if (!tab || typeof tab.id !== 'number' || tab.id < 0) {
          showAlert('No active web page found.');
          return;
        }

        if (isRestrictedUrl(tab.url)) {
          showAlert('⚠️ Extensions cannot inspect browser internal pages. Please navigate to any website first.');
          return;
        }

        chrome.tabs.sendMessage(tab.id, { action: 'START_FREEZE_INSPECT', delay: 3 }, () => {
          if (chrome.runtime.lastError) {
            chrome.scripting.executeScript(
              {
                target: { tabId: tab.id },
                files: ['scripts/contentScript.js']
              },
              () => {
                setTimeout(() => {
                  chrome.tabs.sendMessage(tab.id, { action: 'START_FREEZE_INSPECT', delay: 3 }, () => {
                    window.close();
                  });
                }, 120);
              }
            );
          } else {
            window.close();
          }
        });
      } catch (err) {
        console.error('Failed to trigger freeze inspect:', err);
      }
    });
  }

  const STORAGE_KEY_REC_STATE = '__xpath_pro_recording_state__';
  function updatePopupRecordButton(isRecording) {
    const btnRecText = document.getElementById('btnRecordFlowText');
    const btnRec = document.getElementById('btnRecordFlow');
    if (!btnRecText || !btnRec) return;
    if (isRecording) {
      btnRecText.textContent = '⏹ Stop Recording Flow (Alt+Shift+R)';
      btnRec.style.background = 'rgba(239, 68, 68, 0.28)';
      btnRec.style.borderColor = '#ef4444';
      btnRec.style.color = '#fee2e2';
    } else {
      btnRecText.textContent = '🔴 Record Test Flow (Alt+Shift+R)';
      btnRec.style.background = 'rgba(239, 68, 68, 0.1)';
      btnRec.style.borderColor = 'rgba(239, 68, 68, 0.35)';
      btnRec.style.color = '#f87171';
    }
  }

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get([STORAGE_KEY_REC_STATE], (res) => {
        const recState = res ? res[STORAGE_KEY_REC_STATE] : null;
        updatePopupRecordButton(Boolean(recState && recState.isRecording));
      });
      if (chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener((changes, area) => {
          if (area === 'local' && changes[STORAGE_KEY_REC_STATE]) {
            const newState = changes[STORAGE_KEY_REC_STATE].newValue;
            updatePopupRecordButton(Boolean(newState && newState.isRecording));
          }
        });
      }
    }
  } catch (e) {}

  const btnRecordFlow = document.getElementById('btnRecordFlow');
  if (btnRecordFlow) {
    btnRecordFlow.addEventListener('click', async () => {
      try {
        const tab = await getActiveTab();
        if (!tab || typeof tab.id !== 'number' || tab.id < 0) {
          showAlert('No active web page found.');
          return;
        }

        if (isRestrictedUrl(tab.url)) {
          showAlert('⚠️ Extensions cannot record on browser internal pages.');
          return;
        }

        chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_RECORD' }, () => {
          if (chrome.runtime.lastError) {
            chrome.scripting.executeScript(
              {
                target: { tabId: tab.id },
                files: ['scripts/contentScript.js']
              },
              () => {
                setTimeout(() => {
                  chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_RECORD' }, () => {
                    window.close();
                  });
                }, 120);
              }
            );
          } else {
            window.close();
          }
        });
      } catch (err) {
        console.error('Failed to trigger record flow:', err);
      }
    });
  }

  const btnToggleDock = document.getElementById('btnToggleDock');
  if (btnToggleDock) {
    btnToggleDock.addEventListener('click', async () => {
      try {
        const tab = await getActiveTab();
        if (!tab || typeof tab.id !== 'number' || tab.id < 0) {
          showAlert('No active web page found.');
          return;
        }

        if (isRestrictedUrl(tab.url)) {
          showAlert('⚠️ Extensions cannot inspect browser internal pages.');
          return;
        }

        chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_PANEL' }, () => {
          if (chrome.runtime.lastError) {
            chrome.scripting.executeScript(
              {
                target: { tabId: tab.id },
                files: ['scripts/contentScript.js']
              },
              () => {
                setTimeout(() => {
                  chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_PANEL' }, () => {
                    window.close();
                  });
                }, 120);
              }
            );
          } else {
            window.close();
          }
        });
      } catch (err) {
        console.error('Failed to toggle dock:', err);
      }
    });
  }

  // --- Popup Tabs Navigation & Saved Locators ---
  const STORAGE_KEY_SAVED = '__xpath_pro_saved_locators__';
  const STORAGE_KEY_DEL_AFTER = '__xpath_pro_del_after_download__';
  const STORAGE_KEY_PREF_FRAMEWORK = '__xpath_pref_framework__';

  const tabPopupLaunch = document.getElementById('tabPopupLaunch');
  const tabPopupSaved = document.getElementById('tabPopupSaved');
  const paneLaunch = document.getElementById('paneLaunch');
  const paneSaved = document.getElementById('paneSaved');
  const popupSavedCount = document.getElementById('popupSavedCount');
  const popupSavedList = document.getElementById('popupSavedList');
  const popupSearchInput = document.getElementById('popupSearchInput');
  const popupChkDeleteAfter = document.getElementById('popupChkDeleteAfter');
  const popupBtnExportJSON = document.getElementById('popupBtnExportJSON');
  const popupBtnExportCSV = document.getElementById('popupBtnExportCSV');
  const popupBtnExportScript = document.getElementById('popupBtnExportScript');
  const popupBtnClearSaved = document.getElementById('popupBtnClearSaved');
  const prefDefaultFramework = document.getElementById('prefDefaultFramework');
  const popupSavedFrameworkSelect = document.getElementById('popupSavedFrameworkSelect');
  const popupRecentList = document.getElementById('popupRecentList');
  const btnViewAllSaved = document.getElementById('btnViewAllSaved');

  // Load and persist default framework preference
  function loadFrameworkPreference() {
    try {
      if (chrome && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get([STORAGE_KEY_PREF_FRAMEWORK], (res) => {
          const val = res && res[STORAGE_KEY_PREF_FRAMEWORK] ? res[STORAGE_KEY_PREF_FRAMEWORK] : localStorage.getItem(STORAGE_KEY_PREF_FRAMEWORK);
          if (val) {
            if (prefDefaultFramework) prefDefaultFramework.value = val;
            if (popupSavedFrameworkSelect) popupSavedFrameworkSelect.value = val;
          }
        });
        return;
      }
    } catch (e) {}
    try {
      const val = localStorage.getItem(STORAGE_KEY_PREF_FRAMEWORK);
      if (val) {
        if (prefDefaultFramework) prefDefaultFramework.value = val;
        if (popupSavedFrameworkSelect) popupSavedFrameworkSelect.value = val;
      }
    } catch (e) {}
  }

  function handleFrameworkPrefChange(val) {
    if (!val) return;
    if (prefDefaultFramework && prefDefaultFramework.value !== val) prefDefaultFramework.value = val;
    if (popupSavedFrameworkSelect && popupSavedFrameworkSelect.value !== val) popupSavedFrameworkSelect.value = val;
    try {
      localStorage.setItem(STORAGE_KEY_PREF_FRAMEWORK, val);
    } catch (e) {}
    try {
      if (chrome && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ [STORAGE_KEY_PREF_FRAMEWORK]: val });
      }
    } catch (e) {}
    try {
      if (chrome && chrome.tabs && chrome.tabs.query) {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs && tabs[0] && tabs[0].id) {
            chrome.tabs.sendMessage(tabs[0].id, {
              action: 'SET_PREF_FRAMEWORK',
              framework: val
            }, () => {
              if (chrome.runtime.lastError) {}
            });
          }
        });
      }
    } catch (e) {}
  }

  loadFrameworkPreference();

  if (prefDefaultFramework) {
    prefDefaultFramework.addEventListener('change', () => {
      handleFrameworkPrefChange(prefDefaultFramework.value);
    });
  }

  if (popupSavedFrameworkSelect) {
    popupSavedFrameworkSelect.addEventListener('change', () => {
      handleFrameworkPrefChange(popupSavedFrameworkSelect.value);
    });
  }

  try {
    if (chrome && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes[STORAGE_KEY_PREF_FRAMEWORK]) {
          const val = changes[STORAGE_KEY_PREF_FRAMEWORK].newValue;
          if (val) {
            if (prefDefaultFramework && prefDefaultFramework.value !== val) prefDefaultFramework.value = val;
            if (popupSavedFrameworkSelect && popupSavedFrameworkSelect.value !== val) popupSavedFrameworkSelect.value = val;
          }
        }
      });
    }
  } catch (e) {}

  if (btnViewAllSaved) {
    btnViewAllSaved.addEventListener('click', (e) => {
      e.preventDefault();
      switchPopupTab('saved');
    });
  }

  function renderPopupRecentList() {
    if (!popupRecentList) return;
    getSavedLocatorsPopup((list) => {
      if (!list || list.length === 0) {
        popupRecentList.innerHTML = '<div class="popup-recent-empty">No saved locators yet. Inspect elements to save them!</div>';
        return;
      }
      // Show latest 3 (newest first)
      const recent = [...list].reverse().slice(0, 3);
      let html = '';
      recent.forEach((item) => {
        const tag = item.tagName ? `<${escapeHTMLPopup(item.tagName)}>` : '<element>';
        const textPreview = item.text ? escapeHTMLPopup(item.text) : (item.actionCode ? escapeHTMLPopup(item.actionCode) : escapeHTMLPopup(item.bestXPath));
        const copyTarget = item.actionCode || item.bestPlaywright || item.bestXPath;

        html += `
          <div class="popup-recent-item">
            <div class="popup-recent-meta">
              <span class="popup-recent-tag">${tag} ${item.action && item.action !== 'locator' ? '(' + escapeHTMLPopup(item.action) + ')' : ''}</span>
              <span class="popup-recent-code" title="${escapeHTMLPopup(copyTarget)}">${textPreview}</span>
            </div>
            <button class="popup-recent-copy-btn" data-copy="${escapeHTMLPopup(copyTarget)}" title="Copy code">Copy</button>
          </div>
        `;
      });
      popupRecentList.innerHTML = html;

      const cBtns = popupRecentList.querySelectorAll('.popup-recent-copy-btn');
      cBtns.forEach((btn) => {
        btn.addEventListener('click', () => {
          const text = btn.getAttribute('data-copy');
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(() => {
              btn.classList.add('copied');
              btn.textContent = '✓ Copied!';
              setTimeout(() => {
                btn.classList.remove('copied');
                btn.textContent = 'Copy';
              }, 1200);
            }).catch((err) => {
              console.warn('Clipboard write error:', err);
              btn.textContent = 'Failed';
              setTimeout(() => { btn.textContent = 'Copy'; }, 1200);
            });
          }
        });
      });
    });
  }

  function getSavedLocatorsPopup(callback) {
    try {
      if (chrome && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get([STORAGE_KEY_SAVED], (result) => {
          if (chrome.runtime && chrome.runtime.lastError) {
            fallbackGet();
            return;
          }
          const list = (result && Array.isArray(result[STORAGE_KEY_SAVED])) ? result[STORAGE_KEY_SAVED] : [];
          callback(list);
        });
        return;
      }
    } catch (e) {}
    fallbackGet();

    function fallbackGet() {
      try {
        const raw = localStorage.getItem(STORAGE_KEY_SAVED);
        const list = raw ? JSON.parse(raw) : [];
        callback(Array.isArray(list) ? list : []);
      } catch (e) {
        callback([]);
      }
    }
  }

  function setSavedLocatorsPopup(list, callback) {
    try {
      if (chrome && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ [STORAGE_KEY_SAVED]: list }, () => {
          if (callback) callback();
        });
        return;
      }
    } catch (e) {}
    try {
      localStorage.setItem(STORAGE_KEY_SAVED, JSON.stringify(list));
    } catch (e) {}
    if (callback) callback();
  }

  function updatePopupBadge() {
    if (!popupSavedCount) return;
    getSavedLocatorsPopup((list) => {
      const count = list ? list.length : 0;
      popupSavedCount.textContent = String(count);
      popupSavedCount.style.display = count > 0 ? 'inline-flex' : 'none';
    });
  }

  function switchPopupTab(tab) {
    if (tab === 'saved') {
      tabPopupLaunch.classList.remove('active');
      tabPopupSaved.classList.add('active');
      paneLaunch.style.display = 'none';
      paneSaved.style.display = 'flex';
      renderPopupSavedList(popupSearchInput ? popupSearchInput.value.trim() : '');
    } else {
      tabPopupSaved.classList.remove('active');
      tabPopupLaunch.classList.add('active');
      paneSaved.style.display = 'none';
      paneLaunch.style.display = 'block';
    }
  }

  if (tabPopupLaunch && tabPopupSaved) {
    tabPopupLaunch.addEventListener('click', () => switchPopupTab('launch'));
    tabPopupSaved.addEventListener('click', () => switchPopupTab('saved'));
  }

  if (popupChkDeleteAfter) {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_DEL_AFTER);
      if (saved === 'true') popupChkDeleteAfter.checked = true;
    } catch (e) {}
    popupChkDeleteAfter.addEventListener('change', () => {
      try {
        localStorage.setItem(STORAGE_KEY_DEL_AFTER, String(popupChkDeleteAfter.checked));
      } catch (e) {}
    });
  }

  if (popupSearchInput) {
    popupSearchInput.addEventListener('input', () => {
      renderPopupSavedList(popupSearchInput.value.trim());
    });
  }

  function triggerPopupDownload(url, filename, rawContent, mimeType) {
    mimeType = mimeType || 'application/octet-stream';

    // 1. Delegate to background service worker (safest, officially permitted, onDeterminingFilename guarantees exact filename extension)
    if (rawContent && typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
      try {
        chrome.runtime.sendMessage({
          action: 'DOWNLOAD_FILE',
          content: rawContent,
          filename: filename,
          mimeType: mimeType
        }, (res) => {
          if (!res || !res.success) {
            directPopupDownload(url, filename, rawContent, mimeType);
          } else {
            setTimeout(() => {
              try { URL.revokeObjectURL(url); } catch (e) {}
            }, 10000);
          }
        });
        return;
      } catch (err) {
        console.warn('sendMessage error, fallback to direct download:', err);
      }
    }

    directPopupDownload(url, filename, rawContent, mimeType);
  }

  function directPopupDownload(url, filename, rawContent, mimeType) {
    if (typeof chrome !== 'undefined' && chrome.downloads && typeof chrome.downloads.download === 'function') {
      try {
        let downloadUrl = url;
        if (rawContent) {
          try {
            const base64 = (typeof globalThis.utf8ToBase64 === 'function')
              ? globalThis.utf8ToBase64(rawContent)
              : btoa(unescape(encodeURIComponent(rawContent)));
            downloadUrl = `data:${mimeType || 'application/octet-stream'};charset=utf-8;base64,${base64}`;
          } catch (e) {}
        }
        chrome.downloads.download({
          url: downloadUrl,
          filename: filename,
          saveAs: false,
          conflictAction: 'uniquify'
        }, (downloadId) => {
          if (chrome.runtime.lastError) {
            console.warn('Direct popup download failed, using anchor:', chrome.runtime.lastError.message);
            fallbackAnchorDownload(url, filename);
          } else {
            setTimeout(() => {
              try { URL.revokeObjectURL(url); } catch (e) {}
            }, 10000);
          }
        });
        return;
      } catch (err) {
        console.warn('chrome.downloads exception:', err);
      }
    }

    fallbackAnchorDownload(url, filename);
  }

  function fallbackAnchorDownload(url, filename) {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      try {
        a.remove();
        URL.revokeObjectURL(url);
      } catch (e) {}
    }, 2000);
  }

  function handlePopupPostDownload() {
    if (popupChkDeleteAfter && popupChkDeleteAfter.checked) {
      setSavedLocatorsPopup([], () => {
        renderPopupSavedList();
        updatePopupBadge();
        showAlert('Exported & deleted saved locators! 🗑️');
      });
    } else {
      showAlert('Exported successfully! 📥');
    }
  }

  function getSortedAndFilteredSavedLocatorsPopup(list, query = '', sortOrder = 'step-asc') {
    let result = Array.isArray(list) ? [...list] : [];
    const getTs = (it) => (typeof globalThis.parseTimestamp === 'function' ? globalThis.parseTimestamp(it.timestamp) : (new Date(it.timestamp || 0).getTime() || 0));
    if (sortOrder === 'step-asc') {
      result.sort((a, b) => getTs(a) - getTs(b));
    } else if (sortOrder === 'newest-desc') {
      result.sort((a, b) => getTs(b) - getTs(a));
    }
    if (query) {
      const q = query.toLowerCase();
      result = result.filter(item => 
        (item.tagName && item.tagName.toLowerCase().includes(q)) ||
        (item.text && item.text.toLowerCase().includes(q)) ||
        (item.bestXPath && item.bestXPath.toLowerCase().includes(q)) ||
        (item.bestPlaywright && item.bestPlaywright.toLowerCase().includes(q)) ||
        (item.action && item.action.toLowerCase().includes(q)) ||
        (item.actionCode && item.actionCode.toLowerCase().includes(q)) ||
        (item.pageTitle && item.pageTitle.toLowerCase().includes(q)) ||
        (item.pageUrl && item.pageUrl.toLowerCase().includes(q))
      );
    }
    return result;
  }

  if (popupBtnExportJSON) {
    popupBtnExportJSON.addEventListener('click', () => {
      getSavedLocatorsPopup((list) => {
        if (!list || list.length === 0) {
          showAlert('No saved locators to export!');
          return;
        }
        const sortEl = document.getElementById('popupSavedSortSelect');
        const sortOrder = sortEl ? sortEl.value : 'step-asc';
        const query = popupSearchInput ? popupSearchInput.value.trim() : '';
        const itemsToExport = getSortedAndFilteredSavedLocatorsPopup(list, query, sortOrder);

        const jsonStr = JSON.stringify(itemsToExport, null, 2);
        const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const filename = `testpath-locators-${new Date().toISOString().slice(0, 10)}.json`;
        triggerPopupDownload(url, filename, jsonStr, 'application/json');
        handlePopupPostDownload();
      });
    });
  }

  if (popupBtnExportCSV) {
    popupBtnExportCSV.addEventListener('click', () => {
      getSavedLocatorsPopup((list) => {
        if (!list || list.length === 0) {
          showAlert('No saved locators to export!');
          return;
        }
        const sortEl = document.getElementById('popupSavedSortSelect');
        const sortOrder = sortEl ? sortEl.value : 'step-asc';
        const query = popupSearchInput ? popupSearchInput.value.trim() : '';
        const itemsToExport = getSortedAndFilteredSavedLocatorsPopup(list, query, sortOrder);

        const headers = ['Step', 'ID', 'Timestamp', 'Tag', 'Text / Label', 'Best XPath', 'Action', 'Action Code', 'Framework Format', 'Playwright Locator', 'CSS Selector', 'Relative XPath', 'Score', 'Page Title', 'Page URL'];
        const rows = itemsToExport.map((item, idx) => [
          idx + 1,
          item.id || '',
          item.timestamp || '',
          item.tagName || '',
          item.text || '',
          item.bestXPath || '',
          item.action || 'locator',
          item.actionCode || '',
          item.actionFormat || 'raw',
          item.bestPlaywright || '',
          item.cssSelector || '',
          item.bestRelative || '',
          String(item.score != null ? item.score : ''),
          item.pageTitle || '',
          item.pageUrl || ''
        ]);
        const csvContent = [headers, ...rows].map(row => 
          row.map(cell => '"' + String(cell).replace(/"/g, '""') + '"').join(',')
        ).join('\r\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const filename = `testpath-locators-${new Date().toISOString().slice(0, 10)}.csv`;
        triggerPopupDownload(url, filename, csvContent, 'text/csv');
        handlePopupPostDownload();
      });
    });
  }

  function getActiveTabUrl(callback) {
    if (typeof chrome !== 'undefined' && chrome.tabs && typeof chrome.tabs.query === 'function') {
      try {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs && tabs[0] && tabs[0].url && tabs[0].url.startsWith('http')) {
            callback(tabs[0].url);
          } else {
            callback(null);
          }
        });
        return;
      } catch (e) {
        console.warn('tabs.query exception:', e);
      }
    }
    callback(null);
  }

  function buildRunnableTestScript(steps, framework, pageUrl) {
    if (typeof globalThis.TestPathShared !== 'undefined' && typeof globalThis.TestPathShared.buildRunnableTestScript === 'function') {
      return globalThis.TestPathShared.buildRunnableTestScript(steps, framework, pageUrl);
    }
    if (typeof globalThis.buildRunnableTestScript === 'function' && globalThis.buildRunnableTestScript !== buildRunnableTestScript) {
      return globalThis.buildRunnableTestScript(steps, framework, pageUrl);
    }
    return '// Test script generation helper loaded from scripts/shared.js';
  }

  // Generate and export complete runnable Test Automation Script
  if (popupBtnExportScript) {
    popupBtnExportScript.addEventListener('click', () => {
      getSavedLocatorsPopup((list) => {
        if (!list || list.length === 0) {
          showAlert('No saved locators to generate script!');
          return;
        }

        const sortEl = document.getElementById('popupSavedSortSelect');
        const sortOrder = sortEl ? sortEl.value : 'step-asc';
        const sInput = document.getElementById('popupSearchInput');
        const query = sInput ? sInput.value.trim() : '';
        const items = getSortedAndFilteredSavedLocatorsPopup(list, query, sortOrder);

        const framework = (popupSavedFrameworkSelect && popupSavedFrameworkSelect.value) || 
                          (prefDefaultFramework && prefDefaultFramework.value) || 
                          'playwright';

        const steps = items.map((it) => ({
          action: it.action || 'click',
          target: it.text || it.name || it.tagName || it.tag || 'element',
          tagName: it.tagName || it.tag || 'element',
          tag: it.tagName || it.tag || 'element',
          bestXPath: it.bestXPath || it.xpath || it.locator || '//button',
          bestPlaywright: it.bestPlaywright || (it.locator && !it.locator.startsWith('//') ? it.locator : null),
          bestPlaywrightJava: it.bestPlaywrightJava || null,
          cssSelector: it.cssSelector || '',
          value: it.fillValue || it.value || '',
          pageUrl: it.pageUrl || it.url || null
        }));

        getActiveTabUrl((liveUrl) => {
          const scriptContent = buildRunnableTestScript(steps, framework, liveUrl);

          // Copy script to clipboard
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(scriptContent).catch((err) => {
              console.warn('Clipboard copy script warning:', err);
            });
          }

          // Pick filename extension based on framework
          const extMap = {
            'playwright': 'saved_locators.spec.js',
            'playwright-python': 'test_saved_locators.py',
            'playwright-java': 'SavedLocatorsTest.java',
            'playwright-csharp': 'SavedLocatorsTest.cs',
            'selenium-java': 'SavedLocatorsTest.java',
            'selenium-python': 'test_saved_locators.py',
            'selenium-javascript': 'saved_locators.js',
            'selenium-csharp': 'SavedLocatorsTest.cs',
            'cypress': 'saved_locators.cy.js',
            'robot': 'saved_locators.robot',
            'puppeteer': 'saved_locators.spec.js'
          };
          const filename = extMap[framework] || 'saved_locators.spec.js';

          // Using application/octet-stream ensures Chrome NEVER appends .txt to .java or .py
          const blob = new Blob([scriptContent], { type: 'application/octet-stream' });
          const url = URL.createObjectURL(blob);
          triggerPopupDownload(url, filename, scriptContent, 'application/octet-stream');
          handlePopupPostDownload();
          showAlert(`Test script (${extMap[framework] || framework}) copied & downloaded! ⚡`);
        });
      });
    });
  }

  if (popupBtnClearSaved) {
    popupBtnClearSaved.addEventListener('click', () => {
      getSavedLocatorsPopup((list) => {
        if (!list || list.length === 0) return;
        if (confirm('Are you sure you want to clear all ' + list.length + ' saved locators?')) {
          setSavedLocatorsPopup([], () => {
            renderPopupSavedList();
            updatePopupBadge();
            showAlert('All saved locators cleared');
          });
        }
      });
    });
  }

  const popupSavedSortSelect = document.getElementById('popupSavedSortSelect');
  if (popupSavedSortSelect) {
    popupSavedSortSelect.addEventListener('change', () => {
      renderPopupSavedList(popupSearchInput ? popupSearchInput.value.trim() : '');
    });
  }

  function escapeHTMLPopup(str) {
    if (typeof globalThis.escapeHTML === 'function') {
      return globalThis.escapeHTML(str);
    }
    if (!str && str !== 0) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function renderPopupSavedList(query = '') {
    if (!popupSavedList) return;
    const sortEl = document.getElementById('popupSavedSortSelect');
    const sortOrder = sortEl ? sortEl.value : 'step-asc';

    getSavedLocatorsPopup((list) => {
      const filtered = getSortedAndFilteredSavedLocatorsPopup(list, query, sortOrder);

      if (filtered.length === 0) {
        popupSavedList.innerHTML = `
          <div class="popup-empty-state">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
            </svg>
            <p>${query ? 'No locators match "' + escapeHTMLPopup(query) + '"' : 'No saved locators yet. Inspect elements and click ⭐ Save to store them.'}</p>
          </div>
        `;
        return;
      }

      let html = '';
      filtered.forEach((item, index) => {
        let domain = '';
        try {
          domain = new URL(item.pageUrl).hostname;
        } catch (e) {
          domain = item.pageTitle || '';
        }

        let actionBadgeHTML = '';
        if (item.action && item.action !== 'locator') {
          const actIcons = { click: '⚡', fill: '✏️', assertVisible: '👁️', waitFor: '⏳', getText: '📄' };
          const ico = actIcons[item.action] || '⚡';
          actionBadgeHTML = `<span class="popup-saved-action-tag popup-saved-action-${escapeHTMLPopup(item.action)}">${ico} ${escapeHTMLPopup(item.action.toUpperCase())}</span>`;
        } else if (item.action === 'locator') {
          actionBadgeHTML = `<span class="popup-saved-action-tag popup-saved-action-locator">🎯 LOCATOR</span>`;
        }

        html += `
          <div class="popup-saved-item" data-id="${escapeHTMLPopup(item.id)}">
            <div class="popup-saved-top">
              <span class="popup-saved-step-badge">#${index + 1}</span>
              <span class="popup-tag">&lt;${escapeHTMLPopup(item.tagName)}&gt;</span>
              ${actionBadgeHTML}
              <span class="popup-saved-title" title="${escapeHTMLPopup(item.text || item.tagName)}">${escapeHTMLPopup(item.text || item.tagName)}</span>
              <button class="popup-btn-del" data-del-id="${escapeHTMLPopup(item.id)}" title="Delete locator">✕</button>
            </div>

            ${item.actionCode ? `
              <div class="popup-code-row" style="border-color: rgba(245, 158, 11, 0.25); background: #14111d;">
                <span class="popup-code-badge" style="background: rgba(245, 158, 11, 0.2); color: #fbbf24;">ACT</span>
                <span style="flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #fde68a;" title="${escapeHTMLPopup(item.actionCode)}">${escapeHTMLPopup(item.actionCode)}</span>
                <button class="popup-btn-copy-mini" data-copy="${escapeHTMLPopup(item.actionCode)}" title="Copy Action Code">Copy</button>
              </div>
            ` : ''}

            <div class="popup-code-row">
              <span class="popup-code-badge">XP</span>
              <span style="flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${escapeHTMLPopup(item.bestXPath)}">${escapeHTMLPopup(item.bestXPath)}</span>
              <button class="popup-btn-copy-mini" data-copy="${escapeHTMLPopup(item.bestXPath)}">Copy</button>
            </div>

            ${item.bestPlaywright ? `
              <div class="popup-code-row">
                <span class="popup-code-badge pw">PW</span>
                <span style="flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${escapeHTMLPopup(item.bestPlaywright)}">${escapeHTMLPopup(item.bestPlaywright)}</span>
                <button class="popup-btn-copy-mini" data-copy="${escapeHTMLPopup(item.bestPlaywright)}">Copy</button>
              </div>
            ` : ''}

            <div class="popup-saved-bottom">
              <span>${escapeHTMLPopup(domain)}</span>
              <span>Score: ${item.score || 0}%</span>
            </div>
          </div>
        `;
      });

      popupSavedList.innerHTML = html;

      // Bind copy buttons
      const copyBtns = popupSavedList.querySelectorAll('.popup-btn-copy-mini');
      copyBtns.forEach((cb) => {
        cb.addEventListener('click', () => {
          const val = cb.getAttribute('data-copy');
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(val).then(() => {
              const prev = cb.textContent;
              cb.textContent = 'Copied!';
              setTimeout(() => { cb.textContent = prev; }, 1200);
            }).catch((err) => {
              console.warn('Clipboard copy error:', err);
              cb.textContent = 'Failed';
              setTimeout(() => { cb.textContent = 'Copy'; }, 1200);
            });
          }
        });
      });

      // Bind delete buttons
      const delBtns = popupSavedList.querySelectorAll('.popup-btn-del');
      delBtns.forEach((db) => {
        db.addEventListener('click', () => {
          const id = db.getAttribute('data-del-id');
          getSavedLocatorsPopup((fullList) => {
            const updated = fullList.filter(it => it.id !== id);
            setSavedLocatorsPopup(updated, () => {
              renderPopupSavedList(popupSearchInput ? popupSearchInput.value.trim() : '');
              updatePopupBadge();
            });
          });
        });
      });
    });
  }

  // Update badge and recent locators initially
  updatePopupBadge();
  renderPopupRecentList();

  // Cross-tab storage change listener
  try {
    if (chrome && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === 'local' && changes[STORAGE_KEY_SAVED]) {
          updatePopupBadge();
          renderPopupRecentList();
          if (paneSaved && paneSaved.style.display !== 'none') {
            renderPopupSavedList(popupSearchInput ? popupSearchInput.value.trim() : '');
          }
        }
      });
    }
  } catch (e) {}
});
