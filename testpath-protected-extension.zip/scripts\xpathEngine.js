/**
 * Smart XPath Finder - XPath Engine
 * Generates robust, reliable, and unique XPaths and CSS selectors.
 */

(function (global) {
  'use strict';

  const ELEMENT_NODE = typeof Node !== 'undefined' && Node.ELEMENT_NODE ? Node.ELEMENT_NODE : 1;

  function safeEscapeCSS(val) {
    if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') {
      return CSS.escape(val);
    }
    return String(val).replace(/["\\]/g, '\\$&');
  }

  function safeGetAttr(el, attr) {
    if (!el || el.nodeType !== ELEMENT_NODE) return null;
    try {
      if (typeof Element !== 'undefined' && Element.prototype && Element.prototype.getAttribute) {
        const v = Element.prototype.getAttribute.call(el, attr);
        return typeof v === 'string' ? v : (v !== null && v !== undefined ? String(v) : null);
      }
      if (typeof el.getAttribute === 'function') {
        const v = el.getAttribute(attr);
        return typeof v === 'string' ? v : (v !== null && v !== undefined ? String(v) : null);
      }
    } catch (e) { }
    return null;
  }

  function safeHasAttr(el, attr) {
    if (!el || el.nodeType !== ELEMENT_NODE) return false;
    try {
      if (typeof Element !== 'undefined' && Element.prototype && Element.prototype.hasAttribute) {
        return Boolean(Element.prototype.hasAttribute.call(el, attr));
      }
      if (typeof el.hasAttribute === 'function') {
        return Boolean(el.hasAttribute(attr));
      }
    } catch (e) { }
    return false;
  }

  function safeGetId(el) {
    const attrId = safeGetAttr(el, 'id');
    if (attrId && typeof attrId === 'string' && attrId.trim()) return attrId.trim();
    try {
      if (el && typeof el.id === 'string' && el.id.trim()) return el.id.trim();
    } catch (e) { }
    return null;
  }

  function safeGetTagName(el) {
    if (!el || el.nodeType !== ELEMENT_NODE) return '';
    try {
      if (typeof Element !== 'undefined' && Element.prototype) {
        const desc = Object.getOwnPropertyDescriptor(Element.prototype, 'tagName');
        if (desc && typeof desc.get === 'function') {
          const t = desc.get.call(el);
          if (typeof t === 'string') return t.toLowerCase();
        }
      }
      if (typeof el.tagName === 'string') return el.tagName.toLowerCase();
      if (typeof el.nodeName === 'string') return el.nodeName.toLowerCase();
    } catch (e) { }
    return '';
  }

  function safeGetText(el) {
    if (!el) return '';
    try {
      if (typeof el.innerText === 'string') return el.innerText;
      if (typeof el.textContent === 'string') return el.textContent;
    } catch (e) { }
    return '';
  }

  function safeGetChildren(el) {
    if (!el || el.nodeType !== ELEMENT_NODE) return [];
    try {
      if (typeof Element !== 'undefined' && Element.prototype) {
        const desc = Object.getOwnPropertyDescriptor(Element.prototype, 'children');
        if (desc && typeof desc.get === 'function') {
          const ch = desc.get.call(el);
          if (ch && typeof ch.length === 'number') return Array.from(ch);
        }
      }
      if (el.children && typeof el.children.length === 'number' && typeof el.children !== 'function') {
        return Array.from(el.children);
      }
    } catch (e) { }
    return [];
  }

  function safeGetParent(el) {
    if (!el) return null;
    try {
      if (typeof Node !== 'undefined' && Node.prototype) {
        const desc = Object.getOwnPropertyDescriptor(Node.prototype, 'parentElement');
        if (desc && typeof desc.get === 'function') {
          const p = desc.get.call(el);
          if (p && p.nodeType === ELEMENT_NODE) return p;
        }
      }
      if (el.parentElement && el.parentElement.nodeType === ELEMENT_NODE) return el.parentElement;
    } catch (e) { }
    return null;
  }

  function safeGetOwnerDocument(el) {
    if (!el) return (typeof document !== 'undefined' ? document : null);
    try {
      if (typeof Node !== 'undefined' && Node.prototype) {
        const desc = Object.getOwnPropertyDescriptor(Node.prototype, 'ownerDocument');
        if (desc && typeof desc.get === 'function') {
          const od = desc.get.call(el);
          if (od && od.nodeType === 9) return od;
        }
      }
      if (el.ownerDocument && el.ownerDocument.nodeType === 9) {
        return el.ownerDocument;
      }
    } catch (e) { }
    try {
      if (typeof el.getRootNode === 'function') {
        const root = el.getRootNode();
        if (root && root.nodeType === 9) return root;
      }
    } catch (e) { }
    return (typeof document !== 'undefined' ? document : null);
  }

  const DYNAMIC_ID_PATTERNS = [
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i, // UUID
    /^[0-9a-f]{10,}$/i, // Long hex hash
    /^[a-z_-]+[0-9]{3,}$/i, // Prefix with 3+ trailing digits e.g. gen-194, btn-10294
    /^(ember|mat-|cdk-|chakra|radix|mui|ng-|react-select|yui|headlessui|mantine|downshift|react-aria|rc-)[\w-]*\d+/i, // Framework IDs
    /^p[nvr]?[_-](id|[a-z]+)[_-]?\d+/i, // PrimeNG (pn_id_71_header), PrimeVue (pv_id_12), PrimeReact (pr_id_5), PrimeFaces
    /^(ui|ext)[_-](id|gen|element|comp)[_-]?\d+/i, // jQuery UI (ui-id-1), ExtJS (ext-gen12)
    /^[a-z0-9_-]+[_-]id[_-]\d+([_-].*)?$/i, // Generic component-id-number-part e.g. dialog_id_12_header
    /(^|:)r[0-9a-z]+:?$/i, // React 18 useId (:r1:)
    /^radix-.*$/i, // Radix UI
    /^\d+$/, // Pure numeric
    /__[a-z0-9_-]{5,}$/i // Hashed suffixes
  ];

  const TEST_ATTRIBUTES = [
    'data-testid',
    'data-test',
    'data-cy',
    'data-qa',
    'data-automation-id',
    'data-component-id',
    'data-id'
  ];

  const SEMANTIC_ATTRIBUTES = [
    'name',
    'placeholder',
    'aria-label',
    'role',
    'title',
    'alt',
    'type',
    'href',
    'value',
    'data-icon'
  ];

  const UTILITY_CLASS_PATTERNS = [
    /^(flex|grid|block|inline|hidden|relative|absolute|fixed|sticky)$/,
    /^(m|p|mt|mb|ml|mr|mx|my|pt|pb|pl|pr|px|py)-\w+/,
    /^(w|h|min-w|min-h|max-w|max-h)-\w+/,
    /^(text|bg|border|shadow|rounded|opacity|gap|z)-\w+/,
    /^(col|row|items|justify|self|content)-\w+/,
    /^[a-z0-9]{6,}$/i, // Short random CSS module hash
    /^css-[a-z0-9]+/i, // Emotion / styled-components
    /^sc-[a-z0-9]+/i,
    /^ng-/i, // Angular framework marker classes e.g. ng-star-inserted, ng-tns, ng-trigger
    /^_ng/i,
    /^cdk-/i,
    /^mat-(ripple|focus|elevation)/i,
    /^ant-/i
  ];

  const SVG_TAG_NAMES = [
    'svg', 'path', 'g', 'circle', 'rect', 'line', 'polyline', 'polygon',
    'ellipse', 'use', 'symbol', 'text', 'tspan', 'defs', 'clippath',
    'mask', 'pattern', 'marker', 'lineargradient', 'radialgradient', 'stop', 'foreignobject', 'image'
  ];

  class XPathEngine {
    /**
     * Test if a tag name belongs to the SVG specification
     */
    static isSVGTag(tag) {
      if (!tag || typeof tag !== 'string') return false;
      return SVG_TAG_NAMES.includes(tag.toLowerCase().trim());
    }

    /**
     * Test if an element is an SVG element or resides in the SVG XML namespace
     */
    static isSVGElement(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) return false;
      try {
        if (typeof SVGElement !== 'undefined' && element instanceof SVGElement) return true;
        if (element.namespaceURI === 'http://www.w3.org/2000/svg') return true;
        const tag = safeGetTagName(element);
        return XPathEngine.isSVGTag(tag);
      } catch (e) {
        return false;
      }
    }

    /**
     * Extract class string safely for both HTML and SVG elements (which use SVGAnimatedString)
     */
    static getElementClassString(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) return '';
      try {
        if (typeof element.className === 'string') return element.className;
        if (element.className && typeof element.className.baseVal === 'string') {
          return element.className.baseVal;
        }
        return safeGetAttr(element, 'class') || '';
      } catch (e) {
        return '';
      }
    }

    /**
     * Extract clean array of class tokens from element
     */
    static getElementClassList(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) return [];
      try {
        if (element.classList && typeof element.classList[Symbol.iterator] === 'function') {
          return Array.from(element.classList);
        }
      } catch (e) { }
      const str = XPathEngine.getElementClassString(element);
      return str ? str.trim().split(/\s+/).filter(Boolean) : [];
    }

    /**
     * Get the current or filled value of an interactive element (or 'Enter value' fallback)
     */
    static getElementFillValue(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) return 'Enter value';
      try {
        if (typeof element.value === 'string' && element.value.trim()) {
          return element.value.trim();
        }
      } catch (e) { }
      try {
        const attrVal = safeGetAttr(element, 'value');
        if (attrVal && typeof attrVal === 'string' && attrVal.trim()) {
          return attrVal.trim();
        }
      } catch (e) { }
      try {
        const isEditable = safeGetAttr(element, 'contenteditable');
        if (isEditable === 'true' || isEditable === '') {
          const txt = safeGetText(element).trim();
          if (txt) return txt;
        }
      } catch (e) { }
      return 'Enter value';
    }

    /**
     * Get robust XPath tag step (automatically converts SVG tags to namespace-agnostic *[local-name()='tag'])
     */
    static getXPathTagStep(element, tag = null) {
      const tagName = (tag || safeGetTagName(element) || '').toLowerCase();
      if (!tagName) return '*';
      if (XPathEngine.isSVGElement(element) || XPathEngine.isSVGTag(tagName)) {
        return `*[local-name()='${tagName}']`;
      }
      return tagName;
    }

    /**
     * Test if an ID is dynamic or generated
     */
    static isDynamicId(id) {
      if (!id || typeof id !== 'string') return true;
      const clean = id.trim();
      if (!clean) return true;
      return DYNAMIC_ID_PATTERNS.some((pattern) => pattern.test(clean));
    }

    /**
     * Escape strings for XPath expression
     */
    static escapeXPathString(str) {
      if (str === null || str === undefined) return "''";
      const s = String(str);
      if (!s.includes("'")) {
        return `'${s}'`;
      }
      if (!s.includes('"')) {
        return `"${s}"`;
      }
      // If it contains both single and double quotes, use concat()
      const parts = s.split("'").map((part) => `'${part}'`);
      return `concat(${parts.join(', "\'", ')})`;
    }

    /**
     * Evaluate an XPath in the context of the document
     * Returns array of matching DOM elements
     */
    static queryXPath(xpath, doc = (typeof document !== 'undefined' ? document : null)) {
      const results = [];
      if (!doc || typeof doc.evaluate !== 'function' || !xpath) {
        return results;
      }
      try {
        const snapshotType = (typeof XPathResult !== 'undefined' && XPathResult.ORDERED_NODE_SNAPSHOT_TYPE)
          ? XPathResult.ORDERED_NODE_SNAPSHOT_TYPE
          : 7;
        const query = doc.evaluate(
          xpath,
          doc,
          null,
          snapshotType,
          null
        );
        if (query) {
          for (let i = 0; i < query.snapshotLength; i++) {
            const item = query.snapshotItem(i);
            if (item) results.push(item);
          }
        }
      } catch (err) {
        // Invalid XPath syntax or context
      }
      return results;
    }

    /**
     * Check if an XPath uniquely identifies the given element
     */
    static isUnique(xpath, element, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!doc || typeof doc.evaluate !== 'function' || !xpath || !element) return false;
      try {
        // Fast early-exit iterator path: exits as soon as 2 nodes are evaluated
        if (typeof XPathResult !== 'undefined' && XPathResult.ORDERED_NODE_ITERATOR_TYPE) {
          const iter = doc.evaluate(xpath, doc, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
          if (iter && typeof iter.iterateNext === 'function') {
            const first = iter.iterateNext();
            if (!first || first !== element) return false;
            const second = iter.iterateNext();
            return second === null;
          }
        }
        // Direct snapshot evaluation avoiding array allocation
        const snapshotType = (typeof XPathResult !== 'undefined' && XPathResult.ORDERED_NODE_SNAPSHOT_TYPE)
          ? XPathResult.ORDERED_NODE_SNAPSHOT_TYPE
          : 7;
        const query = doc.evaluate(xpath, doc, null, snapshotType, null);
        if (query && typeof query.snapshotLength === 'number') {
          return query.snapshotLength === 1 && query.snapshotItem(0) === element;
        }
      } catch (err) { }

      // Fallback
      const matches = XPathEngine.queryXPath(xpath, doc);
      return matches.length === 1 && matches[0] === element;
    }

    /**
     * Evaluate CSS selector
     */
    static queryCSS(selector, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!doc || typeof doc.querySelectorAll !== 'function' || !selector) return [];
      try {
        return Array.from(doc.querySelectorAll(selector));
      } catch (e) {
        return [];
      }
    }

    static isUniqueCSS(selector, element, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!doc || typeof doc.querySelectorAll !== 'function' || !selector || !element) return false;
      try {
        const matches = doc.querySelectorAll(selector);
        return matches.length === 1 && matches[0] === element;
      } catch (e) {
        return false;
      }
    }

    /**
     * Generate all candidate XPaths and pick the best one
     */
    static analyzeElement(element, doc) {
      try {
        if (!element || element.nodeType !== ELEMENT_NODE) {
          return null;
        }
        const targetDoc = doc || safeGetOwnerDocument(element);
        const rawTag = safeGetTagName(element) || 'div';
        const tag = rawTag || 'div';
        const isSvg = XPathEngine.isSVGElement(element);
        const tagStep = isSvg ? `*[local-name()='${tag}']` : tag;
        const candidates = [];

        // Tier 1: Test IDs (data-testid, data-cy, etc.)
        for (const attr of TEST_ATTRIBUTES) {
          const val = safeGetAttr(element, attr);
          if (val && typeof val === 'string' && val.trim()) {
            const cleanVal = val.trim();
            const esc = XPathEngine.escapeXPathString(cleanVal);
            const xpTag = `//${tagStep}[@${attr}=${esc}]`;
            const xpAny = `//*[@${attr}=${esc}]`;

            if (XPathEngine.isUnique(xpAny, element, targetDoc)) {
              candidates.push({
                xpath: xpAny,
                type: 'test-id',
                score: 100,
                label: `Test ID (@${attr})`
              });
            } else if (XPathEngine.isUnique(xpTag, element, targetDoc) || (isSvg && XPathEngine.queryXPath(xpTag, targetDoc).length === 1)) {
              candidates.push({
                xpath: xpTag,
                type: isSvg ? 'svg-test-id' : 'test-id',
                score: 98,
                label: isSvg ? `SVG Namespace Test ID (@${attr})` : `Tag + Test ID (@${attr})`
              });
            }
          }
        }

        // Tier 2: Meaningful ID
        const id = safeGetId(element);
        if (id && !XPathEngine.isDynamicId(id)) {
          const cleanId = id.trim();
          const esc = XPathEngine.escapeXPathString(cleanId);
          const xpAny = `//*[@id=${esc}]`;
          const xpTag = `//${tagStep}[@id=${esc}]`;
          const pw = `page.locator('#${safeEscapeCSS(cleanId)}')`;
          const pwJava = `page.locator("#${safeEscapeCSS(cleanId)}");`;

          if (XPathEngine.isUnique(xpAny, element, targetDoc)) {
            candidates.push({
              xpath: xpAny,
              type: 'id',
              idValue: cleanId,
              playwright: pw,
              playwrightJava: pwJava,
              score: 95,
              label: 'Unique ID'
            });
          } else if (XPathEngine.isUnique(xpTag, element, targetDoc) || (isSvg && XPathEngine.queryXPath(xpTag, targetDoc).length === 1)) {
            candidates.push({
              xpath: xpTag,
              type: isSvg ? 'svg-id' : 'id',
              idValue: cleanId,
              playwright: pw,
              playwrightJava: pwJava,
              score: 94,
              label: isSvg ? 'SVG Namespace ID' : 'Tag + ID'
            });
          }
        }

        // Tier 2.5: SVG-Specific Robust Selectors (e.g. //*[local-name()='svg' and @data-icon='search'])
        if (isSvg) {
          const iconVal = safeGetAttr(element, 'data-icon');
          if (iconVal && typeof iconVal === 'string' && iconVal.trim()) {
            const cleanIcon = iconVal.trim();
            const escIcon = XPathEngine.escapeXPathString(cleanIcon);
            const xpSvgIcon = `//*[local-name()='${tag}' and @data-icon=${escIcon}]`;
            if (XPathEngine.isUnique(xpSvgIcon, element, targetDoc) || XPathEngine.queryXPath(xpSvgIcon, targetDoc).length === 1) {
              candidates.push({
                xpath: xpSvgIcon,
                type: 'svg-icon',
                score: 97,
                label: `SVG Namespace Locator (@data-icon='${cleanIcon}')`
              });
            }
          }
        }

        // Tier 3: Semantic Attributes (name, placeholder, aria-label, role, etc.)
        const semanticAttrs = isSvg
          ? ['data-icon', 'data-name', 'aria-label', 'role', 'title', 'name', 'viewBox']
          : SEMANTIC_ATTRIBUTES;

        for (const attr of semanticAttrs) {
          const val = safeGetAttr(element, attr);
          if (val && typeof val === 'string' && val.trim()) {
            const cleanVal = val.trim();
            if (cleanVal.length > 80) continue;
            const esc = XPathEngine.escapeXPathString(cleanVal);
            const xpTag = `//${tagStep}[@${attr}=${esc}]`;

            if (XPathEngine.isUnique(xpTag, element, targetDoc) || (isSvg && XPathEngine.queryXPath(xpTag, targetDoc).length === 1)) {
              candidates.push({
                xpath: xpTag,
                type: isSvg ? 'svg-attribute' : 'attribute',
                score: isSvg ? 92 : 88,
                label: isSvg ? `SVG Namespace (@${attr}='${cleanVal.substring(0, 16)}')` : `Attribute (@${attr})`
              });
            }

            // Combined attribute check for inputs e.g. //input[@type='email' and @name='user']
            if (attr === 'name' && safeHasAttr(element, 'type')) {
              const typeVal = safeGetAttr(element, 'type');
              if (typeVal) {
                const xpCombo = `//${tag}[@type='${typeVal}' and @name=${esc}]`;
                if (XPathEngine.isUnique(xpCombo, element, targetDoc)) {
                  candidates.push({
                    xpath: xpCombo,
                    type: 'attribute-combo',
                    score: 86,
                    label: `Type + Name`
                  });
                }
              }
            }
          }
        }

        // Tier 4: Exact Text & Normalized Text
        const rawText = safeGetText(element).trim();
        const cleanText = rawText.replace(/\s+/g, ' ');
        const childCount = safeGetChildren(element).length;
        if (cleanText && cleanText.length >= 1 && cleanText.length <= 60 && childCount <= 4) {
          const esc = XPathEngine.escapeXPathString(cleanText);
          const xpExact = `//${tagStep}[normalize-space()=${esc}]`;
          if (XPathEngine.isUnique(xpExact, element, targetDoc) || (isSvg && XPathEngine.queryXPath(xpExact, targetDoc).length === 1)) {
            candidates.push({
              xpath: xpExact,
              type: isSvg ? 'svg-text' : 'text',
              score: isSvg ? 87 : 85,
              label: isSvg ? `SVG Text (${cleanText.substring(0, 16)})` : 'Exact Text'
            });
          } else {
            const role = safeGetAttr(element, 'role');
            if (role) {
              const xpRoleText = `//${tagStep}[@role='${role}' and normalize-space()=${esc}]`;
              if (XPathEngine.isUnique(xpRoleText, element, targetDoc)) {
                candidates.push({
                  xpath: xpRoleText,
                  type: 'text-role',
                  score: 82,
                  label: 'Role + Text'
                });
              }
            }
          }
        }

        // Tier 5: Semantic CSS Classes
        const classList = XPathEngine.getElementClassList(element);
        if (classList.length > 0) {
          const classes = classList.filter((cls) => {
            return (
              typeof cls === 'string' &&
              cls.length > 2 &&
              cls.length < 35 &&
              !UTILITY_CLASS_PATTERNS.some((pat) => pat.test(cls))
            );
          });

          for (const cls of classes) {
            const esc = XPathEngine.escapeXPathString(cls);
            const xpClass = `//${tagStep}[contains(@class, ${esc})]`;
            if (XPathEngine.isUnique(xpClass, element, targetDoc) || (isSvg && XPathEngine.queryXPath(xpClass, targetDoc).length === 1)) {
              candidates.push({
                xpath: xpClass,
                type: isSvg ? 'svg-class' : 'class',
                score: isSvg ? 88 : 75,
                label: isSvg ? `SVG Namespace Class (.${cls})` : `Semantic Class (.${cls})`
              });
              break;
            }
          }
        }

        // Standalone SVG tag fallback
        if (isSvg) {
          const xpSvgOnly = `//*[local-name()='${tag}']`;
          if (XPathEngine.isUnique(xpSvgOnly, element, targetDoc) || XPathEngine.queryXPath(xpSvgOnly, targetDoc).length === 1) {
            candidates.push({
              xpath: xpSvgOnly,
              type: 'svg-tag',
              score: 80,
              label: `SVG Namespace Tag (*[local-name()='${tag}'])`
            });
          }
        }

        // Tier 6: Anchored Relative XPath
        try {
          const anchored = XPathEngine.generateAnchoredXPath(element, targetDoc);
          if (anchored && (XPathEngine.isUnique(anchored, element, targetDoc) || (isSvg && XPathEngine.queryXPath(anchored, targetDoc).length === 1))) {
            candidates.push({
              xpath: anchored,
              type: 'relative-anchor',
              score: 70,
              label: 'Relative to Anchor Ancestor'
            });
          }
        } catch (e) { }

        // Tier 7: Relative Axes Locators
        let relativeLocators = [];
        try {
          relativeLocators = XPathEngine.generateRelativeAxesLocators(element, targetDoc);
          for (const rel of relativeLocators) {
            candidates.push({
              xpath: rel.xpath,
              type: 'relative-axes',
              selenium4: rel.selenium4,
              score: rel.score,
              label: rel.label
            });
          }
        } catch (e) { }

        // Tier 8: Shortest Hierarchical Path
        try {
          const hier = XPathEngine.generateHierarchicalXPath(element, targetDoc);
          if (hier && (XPathEngine.isUnique(hier, element, targetDoc) || (isSvg && XPathEngine.queryXPath(hier, targetDoc).length === 1))) {
            candidates.push({
              xpath: hier,
              type: 'hierarchy',
              score: 60,
              label: 'Hierarchical Path'
            });
          }
        } catch (e) { }

        // Fallback: Full Absolute XPath
        try {
          const full = XPathEngine.generateAbsoluteXPath(element);
          if (full) {
            candidates.push({
              xpath: full,
              type: 'absolute',
              score: 20,
              label: 'Full Absolute XPath'
            });
          }
        } catch (e) { }

        // Deduplicate candidates by xpath string
        const uniqueCandidates = [];
        const seen = new Set();
        for (const cand of candidates) {
          if (cand && cand.xpath && !seen.has(cand.xpath)) {
            seen.add(cand.xpath);
            uniqueCandidates.push(cand);
          }
        }

        if (uniqueCandidates.length === 0) {
          uniqueCandidates.push({
            xpath: `//${tagStep}`,
            type: 'tag',
            score: 30,
            label: `Tag Locator (<${tag}>)`
          });
        }

        // Sort by score descending
        uniqueCandidates.sort((a, b) => b.score - a.score);

        const best = uniqueCandidates[0];
        let css = '';
        try {
          css = XPathEngine.generateBestCSS(element, targetDoc);
        } catch (e) { }

        let playwrightLocators = [];
        try {
          playwrightLocators = XPathEngine.generatePlaywrightLocators(element, targetDoc);
        } catch (e) { }

        const bestPlaywright = playwrightLocators.length > 0 ? playwrightLocators[0] : null;
        const bestIdCandidate = uniqueCandidates.find((c) => c.type === 'id');
        const bestId = bestIdCandidate ? bestIdCandidate.idValue : null;
        const bestPlaywrightJava = (bestPlaywright && bestPlaywright.codeJava)
          ? bestPlaywright.codeJava
          : (bestId ? `page.locator("#${bestId}");` : XPathEngine.toPlaywrightJava(bestPlaywright ? bestPlaywright.code : null, best.xpath));
        const bestRelative = relativeLocators.length > 0 ? relativeLocators[0] : null;
        const fillValue = XPathEngine.getElementFillValue(element);
        const iframeInfo = XPathEngine.detectIframe(element);

        return {
          best: best.xpath,
          bestType: best.type,
          bestLabel: best.label,
          score: best.score,
          alternatives: uniqueCandidates,
          cssSelector: css,
          playwrightLocators: playwrightLocators,
          bestPlaywright: bestPlaywright ? bestPlaywright.code : null,
          bestPlaywrightJava: bestPlaywrightJava,
          bestId: bestId,
          relativeLocators: relativeLocators,
          bestRelative: bestRelative,
          fillValue: fillValue,
          iframeInfo: iframeInfo,
          tagName: tag,
          isSvg: isSvg,
          elementInfo: {
            id: safeGetId(element),
            className: XPathEngine.getElementClassString(element) || null,
            innerText: safeGetText(element).substring(0, 100),
            nodeName: element.nodeName || tag
          }
        };
      } catch (err) {
        try {
          console.warn('XPathEngine: fallback analysis due to:', err);
        } catch (logErr) { }
        let fallbackTag = 'div';
        try {
          fallbackTag = safeGetTagName(element) || 'div';
        } catch (tErr) { }
        const isSvg = (typeof XPathEngine !== 'undefined' && XPathEngine.isSVGElement) ? XPathEngine.isSVGElement(element) : false;
        const fallbackXP = isSvg ? `//*[local-name()='${fallbackTag}']` : `//${fallbackTag}`;
        const fallbackIframe = (typeof XPathEngine !== 'undefined' && XPathEngine.detectIframe) ? XPathEngine.detectIframe(element) : null;
        return {
          best: fallbackXP,
          bestType: isSvg ? 'svg-tag' : 'fallback-tag',
          bestLabel: isSvg ? `SVG Namespace Tag (*[local-name()='${fallbackTag}'])` : `Tag (${fallbackTag})`,
          score: 30,
          alternatives: [{ xpath: fallbackXP, type: isSvg ? 'svg-tag' : 'fallback-tag', score: 30, label: isSvg ? `SVG Namespace Tag (*[local-name()='${fallbackTag}'])` : `Tag (${fallbackTag})` }],
          cssSelector: fallbackTag,
          playwrightLocators: [],
          bestPlaywright: null,
          bestPlaywrightJava: null,
          bestId: null,
          relativeLocators: [],
          bestRelative: null,
          fillValue: 'Enter value',
          iframeInfo: fallbackIframe,
          tagName: fallbackTag,
          isSvg: isSvg,
          elementInfo: {
            id: null,
            className: null,
            innerText: '',
            nodeName: fallbackTag
          }
        };
      }
    }

    /**
     * Find nearest ancestor with a stable ID or test-id and form a relative path
     */
    static generateAnchoredXPath(element, doc) {
      let curr = safeGetParent(element);
      const isTargetSvg = XPathEngine.isSVGElement(element);
      const targetTag = safeGetTagName(element) || '*';
      const targetStep = isTargetSvg ? `*[local-name()='${targetTag}']` : targetTag;
      const targetDoc = doc || safeGetOwnerDocument(element);

      while (curr && (!targetDoc || (curr !== targetDoc.body && curr !== targetDoc.documentElement))) {
        // Check test id
        for (const attr of TEST_ATTRIBUTES) {
          const val = safeGetAttr(curr, attr);
          if (val && val.trim()) {
            const esc = XPathEngine.escapeXPathString(val.trim());
            const anchor = `//*[@${attr}=${esc}]`;
            const path = `${anchor}//${targetStep}`;
            if (XPathEngine.isUnique(path, element, targetDoc) || (isTargetSvg && XPathEngine.queryXPath(path, targetDoc).length === 1)) {
              return path;
            }
            if (safeHasAttr(element, 'data-icon')) {
              const iconEsc = XPathEngine.escapeXPathString(safeGetAttr(element, 'data-icon') || '');
              const pathWithIcon = isTargetSvg
                ? `${anchor}//*[local-name()='${targetTag}' and @data-icon=${iconEsc}]`
                : `${anchor}//${targetTag}[@data-icon=${iconEsc}]`;
              if (XPathEngine.isUnique(pathWithIcon, element, targetDoc) || (isTargetSvg && XPathEngine.queryXPath(pathWithIcon, targetDoc).length === 1)) {
                return pathWithIcon;
              }
            }
            if (safeHasAttr(element, 'name')) {
              const nameEsc = XPathEngine.escapeXPathString(safeGetAttr(element, 'name') || '');
              const pathWithName = isTargetSvg
                ? `${anchor}//*[local-name()='${targetTag}' and @name=${nameEsc}]`
                : `${anchor}//${targetTag}[@name=${nameEsc}]`;
              if (XPathEngine.isUnique(pathWithName, element, targetDoc) || (isTargetSvg && XPathEngine.queryXPath(pathWithName, targetDoc).length === 1)) {
                return pathWithName;
              }
            }
          }
        }

        // Check stable ID
        const id = safeGetId(curr);
        if (id && !XPathEngine.isDynamicId(id)) {
          const esc = XPathEngine.escapeXPathString(id.trim());
          const anchor = `//*[@id=${esc}]`;
          const path = `${anchor}//${targetStep}`;
          if (XPathEngine.isUnique(path, element, targetDoc) || (isTargetSvg && XPathEngine.queryXPath(path, targetDoc).length === 1)) {
            return path;
          }
          if (safeHasAttr(element, 'data-icon')) {
            const iconEsc = XPathEngine.escapeXPathString(safeGetAttr(element, 'data-icon') || '');
            const pathWithIcon = isTargetSvg
              ? `${anchor}//*[local-name()='${targetTag}' and @data-icon=${iconEsc}]`
              : `${anchor}//${targetTag}[@data-icon=${iconEsc}]`;
            if (XPathEngine.isUnique(pathWithIcon, element, targetDoc) || (isTargetSvg && XPathEngine.queryXPath(pathWithIcon, targetDoc).length === 1)) {
              return pathWithIcon;
            }
          }
          if (safeHasAttr(element, 'name')) {
            const nameEsc = XPathEngine.escapeXPathString(safeGetAttr(element, 'name') || '');
            const pathWithName = isTargetSvg
              ? `${anchor}//*[local-name()='${targetTag}' and @name=${nameEsc}]`
              : `${anchor}//${targetTag}[@name=${nameEsc}]`;
            if (XPathEngine.isUnique(pathWithName, element, targetDoc) || (isTargetSvg && XPathEngine.queryXPath(pathWithName, targetDoc).length === 1)) {
              return pathWithName;
            }
          }
        }

        curr = safeGetParent(curr);
      }
      return null;
    }

    /**
     * Generate hierarchical relative XPath
     */
    static generateHierarchicalXPath(element, doc) {
      if (!element || element.nodeType !== ELEMENT_NODE) return '';
      let path = '';
      let curr = element;
      const targetDoc = doc || safeGetOwnerDocument(element);

      while (curr && curr.nodeType === ELEMENT_NODE && (!targetDoc || (curr !== targetDoc.documentElement && curr !== targetDoc.body))) {
        let rawTag = safeGetTagName(curr) || '*';
        const isSvg = XPathEngine.isSVGElement(curr);
        const tag = isSvg ? `*[local-name()='${rawTag}']` : rawTag;
        let index = 1;
        let sib = curr.previousElementSibling;

        while (sib) {
          if (safeGetTagName(sib) === rawTag) {
            index++;
          }
          sib = sib.previousElementSibling;
        }

        const step = index > 1 ? `${tag}[${index}]` : tag;
        path = path ? `${step}/${path}` : step;

        const candidate = `//${path}`;
        if (XPathEngine.isUnique(candidate, element, targetDoc) || (isSvg && XPathEngine.queryXPath(candidate, targetDoc).length === 1)) {
          return candidate;
        }

        curr = safeGetParent(curr);
      }

      return path ? `//${path}` : `//${safeGetTagName(element) || '*'}`;
    }

    /**
     * Generate Full Absolute XPath
     */
    static generateAbsoluteXPath(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) {
        return '';
      }
      const rawTag = safeGetTagName(element) || '*';
      if (rawTag === 'html') return '/html';
      if (rawTag === 'body') return '/html/body';

      let ix = 1;
      const parent = safeGetParent(element);
      let siblings = [];
      if (parent) {
        siblings = safeGetChildren(parent);
      }

      const isSvg = XPathEngine.isSVGElement(element);
      const tagStep = isSvg ? `*[local-name()='${rawTag}']` : rawTag;

      for (let i = 0; i < siblings.length; i++) {
        let sibling = siblings[i];
        if (sibling === element) {
          const parentPath = parent ? XPathEngine.generateAbsoluteXPath(parent) : '';
          return parentPath ? `${parentPath}/${tagStep}[${ix}]` : `/${tagStep}[${ix}]`;
        }
        if (sibling && sibling.nodeType === ELEMENT_NODE && safeGetTagName(sibling) === rawTag) {
          ix++;
        }
      }
      return `/${tagStep}`;
    }

    /**
     * Generate cleanest unique CSS Selector
     */
    static generateBestCSS(element, doc) {
      if (!element || element.nodeType !== ELEMENT_NODE) return '';

      const tag = safeGetTagName(element) || 'div';
      const isSvg = XPathEngine.isSVGElement(element);
      const targetDoc = doc || safeGetOwnerDocument(element);

      // Test ID
      for (const attr of TEST_ATTRIBUTES) {
        const val = safeGetAttr(element, attr);
        if (val) {
          const sel = `[${attr}="${safeEscapeCSS(val)}"]`;
          if (XPathEngine.isUniqueCSS(sel, element, targetDoc)) return sel;
          const selWithTag = `${tag}[${attr}="${safeEscapeCSS(val)}"]`;
          if (XPathEngine.isUniqueCSS(selWithTag, element, targetDoc)) return selWithTag;
        }
      }

      // Unique ID
      const elemId = safeGetId(element);
      if (elemId && !XPathEngine.isDynamicId(elemId)) {
        const sel = `#${safeEscapeCSS(elemId)}`;
        if (XPathEngine.isUniqueCSS(sel, element, targetDoc)) return sel;
      }

      // data-icon (for SVGs e.g. svg.icon-search or svg[data-icon="search"])
      const iconVal = safeGetAttr(element, 'data-icon');
      if (iconVal && typeof iconVal === 'string' && iconVal.trim()) {
        const cleanIcon = iconVal.trim();
        const selTag = `${tag}[data-icon="${safeEscapeCSS(cleanIcon)}"]`;
        if (XPathEngine.isUniqueCSS(selTag, element, targetDoc)) return selTag;
        const selIcon = `[data-icon="${safeEscapeCSS(cleanIcon)}"]`;
        if (XPathEngine.isUniqueCSS(selIcon, element, targetDoc)) return selIcon;
      }

      // Clean classes (e.g. svg.icon-search)
      const classList = XPathEngine.getElementClassList(element);
      if (classList.length > 0) {
        for (const cls of classList) {
          if (!UTILITY_CLASS_PATTERNS.some((p) => p.test(cls))) {
            const sel = `${tag}.${safeEscapeCSS(cls)}`;
            if (XPathEngine.isUniqueCSS(sel, element, targetDoc)) return sel;
            const selClassOnly = `.${safeEscapeCSS(cls)}`;
            if (XPathEngine.isUniqueCSS(selClassOnly, element, targetDoc)) return selClassOnly;
          }
        }
      }

      // Parent combination for SVG icons (e.g. button > svg.icon-search or button#search > svg)
      const parent = safeGetParent(element);
      if (isSvg && parent && (!targetDoc || parent !== targetDoc.body)) {
        const pTag = safeGetTagName(parent) || 'div';
        const pId = safeGetId(parent);
        if (pId && !XPathEngine.isDynamicId(pId)) {
          const pSel = `#${safeEscapeCSS(pId)} > ${tag}`;
          if (XPathEngine.isUniqueCSS(pSel, element, targetDoc)) return pSel;
        }
        const pClasses = XPathEngine.getElementClassList(parent).filter((c) => !UTILITY_CLASS_PATTERNS.some((pat) => pat.test(c)));
        if (pClasses.length > 0) {
          const pSel = `${pTag}.${safeEscapeCSS(pClasses[0])} > ${tag}`;
          if (XPathEngine.isUniqueCSS(pSel, element, targetDoc)) return pSel;
        }
      }

      // Name attribute
      const nameVal = safeGetAttr(element, 'name');
      if (nameVal) {
        const sel = `${tag}[name="${safeEscapeCSS(nameVal)}"]`;
        if (XPathEngine.isUniqueCSS(sel, element, targetDoc)) return sel;
      }

      // Placeholder
      const phVal = safeGetAttr(element, 'placeholder');
      if (phVal) {
        const sel = `${tag}[placeholder="${safeEscapeCSS(phVal)}"]`;
        if (XPathEngine.isUniqueCSS(sel, element, targetDoc)) return sel;
      }

      return `${tag}`;
    }

    /**
     * Escape strings for JavaScript / Playwright code literals
     */
    static escapeJSString(str) {
      return (str || '')
        .replace(/\\/g, '\\\\')
        .replace(/'/g, "\\'")
        .replace(/\r/g, '\\r')
        .replace(/\n/g, '\\n');
    }

    /**
     * Compute approximate accessible name for element according to W3C AccName spec
     */
    static getAccessibleName(element, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!element || element.nodeType !== ELEMENT_NODE) return '';
      const targetDoc = doc || safeGetOwnerDocument(element);

      // 1. aria-label
      const ariaLabel = safeGetAttr(element, 'aria-label');
      if (ariaLabel && ariaLabel.trim()) {
        return ariaLabel.trim();
      }

      // 2. aria-labelledby
      const ariaLabelledBy = safeGetAttr(element, 'aria-labelledby');
      if (ariaLabelledBy && ariaLabelledBy.trim() && targetDoc) {
        const ids = ariaLabelledBy.trim().split(/\s+/);
        const text = ids.map((id) => {
          const el = targetDoc.getElementById(id);
          return el ? safeGetText(el).trim() : '';
        }).filter(Boolean).join(' ');
        if (text) return text;
      }

      const tag = safeGetTagName(element);

      // 3. For input buttons
      if (tag === 'input') {
        const type = (safeGetAttr(element, 'type') || 'text').toLowerCase();
        if (['button', 'submit', 'reset'].includes(type) && safeHasAttr(element, 'value')) {
          return (safeGetAttr(element, 'value') || '').trim();
        }
      }

      // 4. Associated label for form elements
      if (['input', 'select', 'textarea'].includes(tag)) {
        const elemId = safeGetId(element);
        if (elemId && targetDoc) {
          try {
            const label = targetDoc.querySelector(`label[for="${safeEscapeCSS(elemId)}"]`);
            if (label) {
              const t = safeGetText(label).trim();
              if (t) return t.replace(/\s+/g, ' ');
            }
          } catch (e) { }
        }
        if (typeof element.closest === 'function') {
          try {
            const parentLabel = element.closest('label');
            if (parentLabel) {
              let labelText = '';
              const childNodes = parentLabel.childNodes;
              if (childNodes && childNodes.length > 0) {
                for (let i = 0; i < childNodes.length; i++) {
                  const n = childNodes[i];
                  if (n.nodeType === 3) {
                    labelText += n.nodeValue + ' ';
                  } else if (n.nodeType === ELEMENT_NODE) {
                    const chTag = safeGetTagName(n);
                    if (!['input', 'select', 'textarea'].includes(chTag)) {
                      labelText += safeGetText(n) + ' ';
                    }
                  }
                }
              } else {
                labelText = safeGetText(parentLabel);
              }
              const t = labelText.trim();
              if (t) return t.replace(/\s+/g, ' ');
            }
          } catch (e) { }
        }
      }

      // 5. Image alt
      if (tag === 'img' && safeHasAttr(element, 'alt')) {
        return (safeGetAttr(element, 'alt') || '').trim();
      }

      // 6. Direct / subtree text for buttons, links, headings, options, menuitems, etc.
      const explicitRole = (safeGetAttr(element, 'role') || '').toLowerCase();
      if (
        ['button', 'a', 'summary', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'th', 'option'].includes(tag) ||
        ['button', 'option', 'menuitem', 'tab', 'treeitem'].includes(explicitRole)
      ) {
        const text = safeGetText(element).trim();
        if (text) return text.replace(/\s+/g, ' ');
      }

      // 7. Title or placeholder
      const titleVal = safeGetAttr(element, 'title');
      if (titleVal && titleVal.trim()) {
        return titleVal.trim();
      }
      const phVal = safeGetAttr(element, 'placeholder');
      if (phVal && phVal.trim()) {
        return phVal.trim();
      }

      return '';
    }

    /**
     * Compute implicit or explicit ARIA role of element
     */
    static getImplicitOrExplicitRole(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) return null;
      const explicitRole = safeGetAttr(element, 'role');
      if (explicitRole && explicitRole.trim()) {
        return explicitRole.trim().toLowerCase();
      }

      const tag = safeGetTagName(element);
      switch (tag) {
        case 'button':
          return 'button';
        case 'a':
          return safeHasAttr(element, 'href') ? 'link' : null;
        case 'summary':
          return 'button';
        case 'select':
          return 'combobox';
        case 'textarea':
          return 'textbox';
        case 'dialog':
          return 'dialog';
        case 'nav':
          return 'navigation';
        case 'main':
          return 'main';
        case 'form':
          return 'form';
        case 'ul':
        case 'ol':
          return 'list';
        case 'li':
          return 'listitem';
        case 'table':
          return 'table';
        case 'tr':
          return 'row';
        case 'td':
          return 'cell';
        case 'th':
          return 'columnheader';
        case 'h1':
        case 'h2':
        case 'h3':
        case 'h4':
        case 'h5':
        case 'h6':
          return 'heading';
        case 'img':
          return 'img';
        case 'input': {
          const type = (safeGetAttr(element, 'type') || 'text').toLowerCase();
          if (['button', 'submit', 'reset'].includes(type)) return 'button';
          if (type === 'checkbox') return 'checkbox';
          if (type === 'radio') return 'radio';
          if (type === 'range') return 'slider';
          if (type === 'number') return 'spinbutton';
          if (type === 'search') return 'searchbox';
          return 'textbox';
        }
        default:
          return null;
      }
    }

    /**
     * Test if element matches selector safely
     */
    static elementMatches(el, selector) {
      if (!el || el.nodeType !== ELEMENT_NODE || !selector) return false;
      if (typeof el.matches === 'function') {
        try {
          return el.matches(selector);
        } catch (e) { }
      }
      const tag = safeGetTagName(el);
      const parts = selector.split(',').map((s) => s.trim().toLowerCase());
      return parts.some((p) => {
        if (p === tag) return true;
        if (p.startsWith('[role=')) {
          const expectedRole = p.replace(/^\[role=["']?/, '').replace(/["']?\]$/, '');
          return (safeGetAttr(el, 'role') || '').toLowerCase() === expectedRole;
        }
        return false;
      });
    }

    /**
     * Get a descriptive step and Selenium By for an interactive form control
     */
    static getControlDescriptor(ctrl) {
      if (!ctrl || ctrl.nodeType !== ELEMENT_NODE) {
        return { step: 'input', by: 'By.tagName("input")', tag: 'input', type: 'input' };
      }
      const tag = safeGetTagName(ctrl) || 'input';
      if (tag === 'input') {
        const type = (safeGetAttr(ctrl, 'type') || '').toLowerCase();
        if (type === 'checkbox') {
          return { step: "input[@type='checkbox']", by: 'By.xpath("//input[@type=\'checkbox\']")', tag: 'input', type: 'checkbox' };
        }
        if (type === 'radio') {
          return { step: "input[@type='radio']", by: 'By.xpath("//input[@type=\'radio\']")', tag: 'input', type: 'radio' };
        }
        const fcn = safeGetAttr(ctrl, 'formcontrolname');
        if (fcn && fcn.trim()) {
          const esc = XPathEngine.escapeXPathString(fcn.trim());
          return { step: `input[@formcontrolname=${esc}]`, by: `By.xpath("//input[@formcontrolname=${esc}]")`, tag: 'input', type: type || 'text' };
        }
        const name = safeGetAttr(ctrl, 'name');
        if (name && name.trim() && name.trim().length <= 30) {
          const cleanName = name.trim();
          const esc = XPathEngine.escapeXPathString(cleanName);
          return { step: `input[@name=${esc}]`, by: `By.name("${cleanName.replace(/"/g, '\\"')}")`, tag: 'input', type: type || 'text' };
        }
        const ph = safeGetAttr(ctrl, 'placeholder');
        if (ph && ph.trim() && ph.trim().length <= 30) {
          const cleanPh = ph.trim();
          const esc = XPathEngine.escapeXPathString(cleanPh);
          return { step: `input[@placeholder=${esc}]`, by: `By.xpath("//input[@placeholder=${esc}]")`, tag: 'input', type: type || 'text' };
        }
        if (type && type !== 'text') {
          return { step: `input[@type='${type}']`, by: `By.xpath("//input[@type='${type}']")`, tag: 'input', type };
        }
        return { step: 'input', by: 'By.tagName("input")', tag: 'input', type: 'text' };
      }
      if (tag === 'select') {
        const name = safeGetAttr(ctrl, 'name');
        if (name && name.trim()) {
          const cleanName = name.trim();
          return { step: `select[@name='${cleanName}']`, by: `By.name("${cleanName.replace(/"/g, '\\"')}")`, tag: 'select', type: 'select' };
        }
        return { step: 'select', by: 'By.tagName("select")', tag: 'select', type: 'select' };
      }
      if (tag === 'textarea') {
        const name = safeGetAttr(ctrl, 'name');
        if (name && name.trim()) {
          const cleanName = name.trim();
          return { step: `textarea[@name='${cleanName}']`, by: `By.name("${cleanName.replace(/"/g, '\\"')}")`, tag: 'textarea', type: 'textarea' };
        }
        return { step: 'textarea', by: 'By.tagName("textarea")', tag: 'textarea', type: 'textarea' };
      }
      if (tag === 'button') {
        const title = safeGetAttr(ctrl, 'title');
        if (title && title.trim() && title.trim().length <= 30) {
          const cleanTitle = title.trim();
          const esc = XPathEngine.escapeXPathString(cleanTitle);
          return { step: `button[@title=${esc}]`, by: `By.xpath("//button[@title=${esc}]")`, tag: 'button', type: 'button' };
        }
        return { step: 'button', by: 'By.tagName("button")', tag: 'button', type: 'button' };
      }
      const role = (safeGetAttr(ctrl, 'role') || '').toLowerCase();
      if (role) {
        return { step: `*[@role='${role}']`, by: `By.xpath("//*[@role='${role}']")`, tag, type: role };
      }
      return { step: tag, by: `By.tagName("${tag}")`, tag, type: tag };
    }

    /**
     * Get a robust, concise descriptor for an element when referenced in relative axes
     */
    static getTargetShortDescriptor(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) {
        return { tag: 'div', step: 'div', by: 'By.tagName("div")' };
      }
      const tag = safeGetTagName(element) || 'div';
      const isSvg = XPathEngine.isSVGElement(element);

      if (['input', 'select', 'textarea', 'button'].includes(tag) || safeHasAttr(element, 'role')) {
        return XPathEngine.getControlDescriptor(element);
      }

      // SVG specific descriptor
      if (isSvg) {
        const icon = safeGetAttr(element, 'data-icon');
        if (icon && icon.trim()) {
          const escIcon = XPathEngine.escapeXPathString(icon.trim());
          return {
            tag,
            step: `*[local-name()='${tag}' and @data-icon=${escIcon}]`,
            by: `By.xpath("//*[local-name()='${tag}' and @data-icon=${escIcon}]")`
          };
        }
        const svgClasses = XPathEngine.getElementClassList(element).filter((c) => !UTILITY_CLASS_PATTERNS.some((p) => p.test(c)));
        if (svgClasses.length > 0) {
          const escCls = XPathEngine.escapeXPathString(svgClasses[0]);
          return {
            tag,
            step: `*[local-name()='${tag}' and contains(@class, ${escCls})]`,
            by: `By.xpath("//*[local-name()='${tag}' and contains(@class, ${escCls})]")`
          };
        }
        const al = safeGetAttr(element, 'aria-label');
        if (al && al.trim()) {
          const escAl = XPathEngine.escapeXPathString(al.trim());
          return {
            tag,
            step: `*[local-name()='${tag}' and @aria-label=${escAl}]`,
            by: `By.xpath("//*[local-name()='${tag}' and @aria-label=${escAl}]")`
          };
        }
        return {
          tag,
          step: `*[local-name()='${tag}']`,
          by: `By.xpath("//*[local-name()='${tag}']")`
        };
      }

      // 1. Text on button or link or span
      if (['button', 'a', 'span', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'].includes(tag)) {
        const text = safeGetText(element).trim().replace(/\s+/g, ' ');
        if (text && text.length >= 1 && text.length <= 40) {
          const esc = XPathEngine.escapeXPathString(text);
          return {
            tag,
            step: `${tag}[normalize-space()=${esc}]`,
            by: `By.xpath("//${tag}[normalize-space()=${esc}]")`
          };
        }
      }

      // 2. Primary distinctive attributes (title, name, type, role, value)
      for (const attr of ['title', 'name', 'aria-label', 'placeholder', 'type', 'role', 'value']) {
        const val = safeGetAttr(element, attr);
        if (val && val.trim() && val.trim().length <= 40) {
          const esc = XPathEngine.escapeXPathString(val.trim());
          return {
            tag,
            step: `${tag}[@${attr}=${esc}]`,
            by: `By.xpath("//${tag}[@${attr}=${esc}]")`
          };
        }
      }

      // 3. Specific semantic classes
      const classList = XPathEngine.getElementClassList(element);
      if (classList.length > 0) {
        for (const cls of classList) {
          if (cls.length > 2 && cls.length < 25 && !UTILITY_CLASS_PATTERNS.some((p) => p.test(cls))) {
            const esc = XPathEngine.escapeXPathString(cls);
            return {
              tag,
              step: `${tag}[contains(@class, ${esc})]`,
              by: `By.xpath("//${tag}[contains(@class, ${esc})]")`
            };
          }
        }
      }

      // 4. Default to plain tag
      return {
        tag,
        step: tag,
        by: `By.tagName("${tag}")`
      };
    }

    /**
     * Generate Relative XPaths with Axes (Parent/Sibling Anchoring) and Selenium 4 Relative Locators
     */
    static generateRelativeAxesLocators(element, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!element || element.nodeType !== ELEMENT_NODE) return [];

      const results = [];
      const tag = safeGetTagName(element) || 'div';
      const targetDesc = XPathEngine.getTargetShortDescriptor(element);
      const CONTROL_SEL = 'input, select, textarea, button, [role="checkbox"], [role="combobox"], [role="listbox"], [role="textbox"], [contenteditable="true"]';
      const targetDoc = doc || safeGetOwnerDocument(element);

      // --- Category A: Table Row / Data Grid Sibling Traversals ---
      let currCell = element;
      while (currCell && (!targetDoc || (currCell !== targetDoc.body && currCell !== targetDoc.documentElement))) {
        const cTag = safeGetTagName(currCell);
        const cRole = safeGetAttr(currCell, 'role') || '';
        if (cTag === 'td' || cTag === 'th' || cRole === 'cell' || cRole === 'gridcell') {
          break;
        }
        currCell = safeGetParent(currCell);
      }

      if (currCell && (!targetDoc || (currCell !== targetDoc.body && currCell !== targetDoc.documentElement))) {
        let currRow = safeGetParent(currCell);
        while (currRow && (!targetDoc || (currRow !== targetDoc.body && currRow !== targetDoc.documentElement))) {
          const rTag = safeGetTagName(currRow);
          const rRole = safeGetAttr(currRow, 'role') || '';
          if (rTag === 'tr' || rRole === 'row') {
            break;
          }
          currRow = safeGetParent(currRow);
        }

        if (currRow) {
          const cells = safeGetChildren(currRow).filter((ch) => {
            const chTag = safeGetTagName(ch);
            const chRole = safeGetAttr(ch, 'role') || '';
            return chTag === 'td' || chTag === 'th' || chRole === 'cell' || chRole === 'gridcell';
          });

          const targetCellIndex = cells.indexOf(currCell);
          if (targetCellIndex !== -1) {
            for (let i = 0; i < cells.length; i++) {
              if (i === targetCellIndex) continue;
              const sibCell = cells[i];
              const sibText = safeGetText(sibCell).trim().replace(/\s+/g, ' ');

              if (sibText && sibText.length >= 2 && sibText.length <= 60 && !/^\d+$/.test(sibText)) {
                const escText = XPathEngine.escapeXPathString(sibText);
                const sibTag = safeGetTagName(sibCell) || 'td';
                const cellAnchorXP = `//${sibTag}[normalize-space()=${escText}]`;

                const isAnchorUnique = XPathEngine.queryXPath(cellAnchorXP, targetDoc).length === 1;
                const scoreBoost = isAnchorUnique ? 0 : -4;

                const isFollowing = i < targetCellIndex; // target comes after anchor
                const axis = isFollowing ? 'following-sibling' : 'preceding-sibling';
                const direction = isFollowing ? 'toRightOf' : 'toLeftOf';
                const cellTag = safeGetTagName(currCell) || 'td';

                let candidateXP = '';
                if (element === currCell) {
                  candidateXP = `${cellAnchorXP}/${axis}::${cellTag}`;
                } else {
                  candidateXP = `${cellAnchorXP}/${axis}::${cellTag}//${targetDesc.step}`;
                }

                if (XPathEngine.isUnique(candidateXP, element, targetDoc) || XPathEngine.queryXPath(candidateXP, targetDoc).length === 1) {
                  const sel4 = `RelativeLocator.with(${targetDesc.by}).${direction}(By.xpath("${cellAnchorXP.replace(/"/g, '\\"')}"))`;
                  results.push({
                    xpath: candidateXP,
                    selenium4: sel4,
                    type: 'relative-table-sibling',
                    anchorText: sibText,
                    score: 94 + scoreBoost,
                    label: `Table Sibling (${axis} from "${sibText.substring(0, 18)}")`
                  });
                }

                // Row Container Alternative: //tr[.//td[normalize-space()='...']]//button
                const rowXP = `//tr[.//${sibTag}[normalize-space()=${escText}]]//${targetDesc.step}`;
                if (XPathEngine.isUnique(rowXP, element, targetDoc) || XPathEngine.queryXPath(rowXP, targetDoc).length === 1) {
                  const sel4 = `RelativeLocator.with(${targetDesc.by}).near(By.xpath("${cellAnchorXP.replace(/"/g, '\\"')}"))`;
                  results.push({
                    xpath: rowXP,
                    selenium4: sel4,
                    type: 'relative-row-container',
                    anchorText: sibText,
                    score: 93 + scoreBoost,
                    label: `Table Row Container (Row with "${sibText.substring(0, 18)}")`
                  });
                }
              }
            }
          }
        }
      }

      // --- Category B: Form Controls & Sibling Label Anchoring ---
      const isTargetControl = XPathEngine.elementMatches(element, CONTROL_SEL);
      const parentControl = (!isTargetControl && typeof element.closest === 'function') ? element.closest(CONTROL_SEL) : null;
      const effectiveControl = isTargetControl ? element : (parentControl || element);
      const ctrlDesc = XPathEngine.getControlDescriptor(effectiveControl);

      let ancestor = effectiveControl;
      let depth = 0;
      while (ancestor && (!targetDoc || (ancestor !== targetDoc.body && ancestor !== targetDoc.documentElement)) && depth <= 3) {
        // Look at previous siblings of ancestor
        let pSib = ancestor.previousElementSibling;
        let pSteps = 1;
        while (pSib && pSteps <= 4) {
          const pTag = safeGetTagName(pSib) || '*';
          const pText = safeGetText(pSib).trim().replace(/\s+/g, ' ');

          if (pText && pText.length >= 2 && pText.length <= 60) {
            const escP = XPathEngine.escapeXPathString(pText);
            const anchorXP = `//${pTag}[normalize-space()=${escP}]`;

            const cands = [];
            if (ancestor === effectiveControl) {
              cands.push({ xp: `${anchorXP}/following-sibling::${ctrlDesc.step}`, wild: false });
            } else {
              const ancTag = safeGetTagName(ancestor) || '*';
              cands.push({ xp: `${anchorXP}/following-sibling::${ancTag}//${ctrlDesc.step}`, wild: false });
              cands.push({ xp: `${anchorXP}/following-sibling::*//${ctrlDesc.step}`, wild: true });
            }

            for (const cand of cands) {
              if (XPathEngine.isUnique(cand.xp, effectiveControl, targetDoc) || XPathEngine.queryXPath(cand.xp, targetDoc).length === 1) {
                const sel4 = `RelativeLocator.with(${ctrlDesc.by}).toRightOf(By.xpath("${anchorXP.replace(/"/g, '\\"')}"))`;
                results.push({
                  xpath: cand.xp,
                  selenium4: sel4,
                  type: 'relative-label-sibling',
                  anchorText: pText,
                  score: cand.wild ? 94 : 95,
                  label: `Form Control (<${ctrlDesc.step}> following <${pTag}> "${pText.substring(0, 16)}")`
                });
              }
            }
            break;
          }
          pSib = pSib.previousElementSibling;
          pSteps++;
        }

        // Look at following siblings of ancestor
        let nSib = ancestor.nextElementSibling;
        let nSteps = 1;
        while (nSib && nSteps <= 4) {
          const nTag = safeGetTagName(nSib) || '*';
          const nText = safeGetText(nSib).trim().replace(/\s+/g, ' ');

          if (nText && nText.length >= 2 && nText.length <= 60) {
            const escN = XPathEngine.escapeXPathString(nText);
            const anchorXP = `//${nTag}[normalize-space()=${escN}]`;

            const cands = [];
            if (ancestor === effectiveControl) {
              cands.push({ xp: `${anchorXP}/preceding-sibling::${ctrlDesc.step}`, wild: false });
            } else {
              const ancTag = safeGetTagName(ancestor) || '*';
              cands.push({ xp: `${anchorXP}/preceding-sibling::${ancTag}//${ctrlDesc.step}`, wild: false });
              cands.push({ xp: `${anchorXP}/preceding-sibling::*//${ctrlDesc.step}`, wild: true });
            }

            for (const cand of cands) {
              if (XPathEngine.isUnique(cand.xp, effectiveControl, targetDoc) || XPathEngine.queryXPath(cand.xp, targetDoc).length === 1) {
                const sel4 = `RelativeLocator.with(${ctrlDesc.by}).toLeftOf(By.xpath("${anchorXP.replace(/"/g, '\\"')}"))`;
                results.push({
                  xpath: cand.xp,
                  selenium4: sel4,
                  type: 'relative-label-sibling',
                  anchorText: nText,
                  score: cand.wild ? 94 : 95,
                  label: `Form Control (<${ctrlDesc.step}> preceding <${nTag}> "${nText.substring(0, 16)}")`
                });
              }
            }
            break;
          }
          nSib = nSib.nextElementSibling;
          nSteps++;
        }

        ancestor = safeGetParent(ancestor);
        depth++;
      }

      // Case B2: element is a wrapper container that CONTAINS form controls
      if (typeof element.querySelectorAll === 'function') {
        const childControls = Array.from(element.querySelectorAll(CONTROL_SEL)).slice(0, 3);
        if (childControls.length > 0) {
          let pSib = element.previousElementSibling;
          let pSteps = 1;
          while (pSib && pSteps <= 4) {
            const pTag = safeGetTagName(pSib) || '*';
            const pText = safeGetText(pSib).trim().replace(/\s+/g, ' ');

            if (pText && pText.length >= 2 && pText.length <= 60) {
              const escP = XPathEngine.escapeXPathString(pText);
              const anchorXP = `//${pTag}[normalize-space()=${escP}]`;

              for (const childCtrl of childControls) {
                const cDesc = XPathEngine.getControlDescriptor(childCtrl);
                const cand1 = `${anchorXP}/following-sibling::${tag}//${cDesc.step}`;
                const cand2 = `${anchorXP}/following-sibling::*//${cDesc.step}`;

                if (XPathEngine.queryXPath(cand1, targetDoc).length === 1) {
                  results.push({
                    xpath: cand1,
                    selenium4: `RelativeLocator.with(${cDesc.by}).toRightOf(By.xpath("${anchorXP.replace(/"/g, '\\"')}"))`,
                    type: 'relative-label-sibling',
                    anchorText: pText,
                    score: 95,
                    label: `Form Control inside Sibling (<${cDesc.step}> from "${pText.substring(0, 16)}")`
                  });
                }
                if (XPathEngine.queryXPath(cand2, targetDoc).length === 1 && cand2 !== cand1) {
                  results.push({
                    xpath: cand2,
                    selenium4: `RelativeLocator.with(${cDesc.by}).toRightOf(By.xpath("${anchorXP.replace(/"/g, '\\"')}"))`,
                    type: 'relative-label-sibling',
                    anchorText: pText,
                    score: 94,
                    label: `Wildcard Sibling Control (<${cDesc.step}> from "${pText.substring(0, 16)}")`
                  });
                }
              }
              break;
            }
            pSib = pSib.previousElementSibling;
            pSteps++;
          }
        }
      }

      // Case B3: element is the label or text element itself
      const elemText = safeGetText(element).trim().replace(/\s+/g, ' ');
      const isLabelLike = (
        tag === 'label' ||
        safeGetAttr(element, 'role') === 'label' ||
        (elemText.length >= 2 && elemText.length <= 60 && (!element.querySelectorAll || element.querySelectorAll(CONTROL_SEL).length === 0))
      );

      if (isLabelLike && elemText.length >= 2) {
        const escLabel = XPathEngine.escapeXPathString(elemText);
        const labelXP = `//${tag}[normalize-space()=${escLabel}]`;

        // 1. Sibling controls
        let sib = element.nextElementSibling;
        let sSteps = 1;
        while (sib && sSteps <= 4) {
          const sibCtrls = (XPathEngine.elementMatches(sib, CONTROL_SEL))
            ? [sib]
            : (sib.querySelectorAll ? Array.from(sib.querySelectorAll(CONTROL_SEL)).slice(0, 3) : []);

          for (const ctrl of sibCtrls) {
            const cDesc = XPathEngine.getControlDescriptor(ctrl);
            const sibTag = safeGetTagName(sib) || '*';
            const candXP = (sib === ctrl)
              ? `${labelXP}/following-sibling::${cDesc.step}`
              : `${labelXP}/following-sibling::${sibTag}//${cDesc.step}`;
            const candWild = (sib === ctrl) ? '' : `${labelXP}/following-sibling::*//${cDesc.step}`;

            if (XPathEngine.queryXPath(candXP, targetDoc).length === 1) {
              results.push({
                xpath: candXP,
                selenium4: `RelativeLocator.with(${cDesc.by}).toRightOf(By.xpath("${labelXP.replace(/"/g, '\\"')}"))`,
                type: 'relative-label-sibling',
                anchorText: elemText,
                score: 95,
                label: `Input for Label (<${cDesc.step}> from "${elemText.substring(0, 16)}")`
              });
            }
            if (candWild && XPathEngine.queryXPath(candWild, targetDoc).length === 1 && candWild !== candXP) {
              results.push({
                xpath: candWild,
                selenium4: `RelativeLocator.with(${cDesc.by}).toRightOf(By.xpath("${labelXP.replace(/"/g, '\\"')}"))`,
                type: 'relative-label-sibling',
                anchorText: elemText,
                score: 94,
                label: `Wildcard Input for Label (<${cDesc.step}> from "${elemText.substring(0, 16)}")`
              });
            }
          }
          sib = sib.nextElementSibling;
          sSteps++;
        }

        // 2. Parent's following siblings
        const parentElem = safeGetParent(element);
        if (parentElem && (!targetDoc || parentElem !== targetDoc.body)) {
          let parentSib = parentElem.nextElementSibling;
          let psSteps = 1;
          while (parentSib && psSteps <= 3) {
            const psCtrls = (XPathEngine.elementMatches(parentSib, CONTROL_SEL))
              ? [parentSib]
              : (parentSib.querySelectorAll ? Array.from(parentSib.querySelectorAll(CONTROL_SEL)).slice(0, 3) : []);

            for (const ctrl of psCtrls) {
              const cDesc = XPathEngine.getControlDescriptor(ctrl);
              const candXP = `${labelXP}/../following-sibling::*//${cDesc.step}`;
              if (XPathEngine.queryXPath(candXP, targetDoc).length === 1) {
                results.push({
                  xpath: candXP,
                  selenium4: `RelativeLocator.with(${cDesc.by}).toRightOf(By.xpath("${labelXP.replace(/"/g, '\\"')}"))`,
                  type: 'relative-label-sibling',
                  anchorText: elemText,
                  score: 94,
                  label: `Input in Next Column (<${cDesc.step}> from "${elemText.substring(0, 16)}")`
                });
              }
            }
            parentSib = parentSib.nextElementSibling;
            psSteps++;
          }
        }

        // 3. Preceding siblings
        let pSib = element.previousElementSibling;
        let psSteps = 1;
        while (pSib && psSteps <= 4) {
          const pCtrls = (XPathEngine.elementMatches(pSib, CONTROL_SEL))
            ? [pSib]
            : (pSib.querySelectorAll ? Array.from(pSib.querySelectorAll(CONTROL_SEL)).slice(0, 3) : []);

          for (const ctrl of pCtrls) {
            const cDesc = XPathEngine.getControlDescriptor(ctrl);
            const pTag = safeGetTagName(pSib) || '*';
            const candXP = (pSib === ctrl)
              ? `${labelXP}/preceding-sibling::${cDesc.step}`
              : `${labelXP}/preceding-sibling::${pTag}//${cDesc.step}`;

            if (XPathEngine.queryXPath(candXP, targetDoc).length === 1) {
              results.push({
                xpath: candXP,
                selenium4: `RelativeLocator.with(${cDesc.by}).toLeftOf(By.xpath("${labelXP.replace(/"/g, '\\"')}"))`,
                type: 'relative-label-sibling',
                anchorText: elemText,
                score: 95,
                label: `Input preceding Label (<${cDesc.step}> from "${elemText.substring(0, 16)}")`
              });
            }
          }
          pSib = pSib.previousElementSibling;
          psSteps++;
        }

        // 4. Common parent container wrapper
        if (parentElem && (!targetDoc || parentElem !== targetDoc.body)) {
          const groupCtrls = parentElem.querySelectorAll
            ? Array.from(parentElem.querySelectorAll(CONTROL_SEL)).filter((c) => c !== element && (!element.contains || !element.contains(c)))
            : [];
          for (const ctrl of groupCtrls.slice(0, 3)) {
            const cDesc = XPathEngine.getControlDescriptor(ctrl);
            const candXP = `${labelXP}/..//${cDesc.step}`;
            if (XPathEngine.queryXPath(candXP, targetDoc).length === 1) {
              results.push({
                xpath: candXP,
                selenium4: `RelativeLocator.with(${cDesc.by}).below(By.xpath("${labelXP.replace(/"/g, '\\"')}"))`,
                type: 'relative-form-group',
                anchorText: elemText,
                score: 93,
                label: `Form Group Input (<${cDesc.step}> from "${elemText.substring(0, 16)}")`
              });
            }
          }
        }
      }

      // Case B4: Direct fallback sibling anchor for non-control elements
      if (results.length === 0) {
        let prevSib = element.previousElementSibling;
        let prevSteps = 1;
        while (prevSib && prevSteps <= 3) {
          const pTag = safeGetTagName(prevSib) || '*';
          const pText = safeGetText(prevSib).trim().replace(/\s+/g, ' ');

          if (pText && pText.length >= 2 && pText.length <= 50) {
            const escP = XPathEngine.escapeXPathString(pText);
            const anchorXP = `//${pTag}[normalize-space()=${escP}]`;
            const fsXP = `${anchorXP}/following-sibling::${targetDesc.step}`;
            if (XPathEngine.isUnique(fsXP, element, targetDoc) || XPathEngine.queryXPath(fsXP, targetDoc).length === 1) {
              const sel4 = `RelativeLocator.with(${targetDesc.by}).toRightOf(By.xpath("${anchorXP.replace(/"/g, '\\"')}"))`;
              results.push({
                xpath: fsXP,
                selenium4: sel4,
                type: 'relative-label-sibling',
                anchorText: pText,
                score: 89,
                label: `Sibling Anchor (following-sibling from <${pTag}> "${pText.substring(0, 16)}")`
              });
              break;
            }
          }
          prevSib = prevSib.previousElementSibling;
          prevSteps++;
        }
      }

      // --- Category C: Parent Axis Traversal ---
      const elementChildren = safeGetChildren(element);
      if (elementChildren.length >= 1 && elementChildren.length <= 3) {
        for (const child of elementChildren) {
          const cTag = safeGetTagName(child) || '*';
          const isCSvg = XPathEngine.isSVGElement(child);
          const cText = safeGetText(child).trim().replace(/\s+/g, ' ');

          if (isCSvg) {
            let svgStep = `*[local-name()='${cTag}']`;
            let svgLabel = `SVG`;
            if (safeHasAttr(child, 'data-icon')) {
              const icon = (safeGetAttr(child, 'data-icon') || '').trim();
              if (icon) {
                svgStep = `*[local-name()='${cTag}' and @data-icon=${XPathEngine.escapeXPathString(icon)}]`;
                svgLabel = `SVG (${icon})`;
              }
            } else {
              const svgCls = XPathEngine.getElementClassList(child).filter((c) => !UTILITY_CLASS_PATTERNS.some((p) => p.test(c)));
              if (svgCls.length > 0) {
                svgStep = `*[local-name()='${cTag}' and contains(@class, ${XPathEngine.escapeXPathString(svgCls[0])})]`;
                svgLabel = `SVG (.${svgCls[0]})`;
              }
            }
            const parentXP = `//${svgStep}/parent::${tag}`;
            if (XPathEngine.isUnique(parentXP, element, targetDoc) || XPathEngine.queryXPath(parentXP, targetDoc).length === 1) {
              const sel4 = `RelativeLocator.with(${targetDesc.by}).near(By.xpath("//${svgStep}"))`;
              results.push({
                xpath: parentXP,
                selenium4: sel4,
                type: 'relative-parent-svg',
                anchorText: svgLabel,
                score: 92,
                label: `Parent Axis (parent::${tag} of ${svgLabel})`
              });
            }
          } else if (cText && cText.length >= 2 && cText.length <= 40) {
            const escC = XPathEngine.escapeXPathString(cText);
            const parentXP = `//${cTag}[normalize-space()=${escC}]/parent::${tag}`;
            if (XPathEngine.isUnique(parentXP, element, targetDoc) || XPathEngine.queryXPath(parentXP, targetDoc).length === 1) {
              const sel4 = `RelativeLocator.with(${targetDesc.by}).near(By.xpath("//${cTag}[normalize-space()=${escC.replace(/"/g, '\\"')}"]"))`;
              results.push({
                xpath: parentXP,
                selenium4: sel4,
                type: 'relative-parent',
                anchorText: cText,
                score: 91,
                label: `Parent Axis (parent::${tag} of "${cText.substring(0, 16)}")`
              });
            }
          }
        }
      }

      // If element is SVG itself and parent is a button or interactive container
      const parentNode = safeGetParent(element);
      if (XPathEngine.isSVGElement(element) && parentNode && (!targetDoc || parentNode !== targetDoc.body)) {
        const pTag = safeGetTagName(parentNode) || '*';
        if (['button', 'a', 'div', 'span'].includes(pTag)) {
          const parentXP = `//${targetDesc.step}/parent::${pTag}`;
          if (XPathEngine.queryXPath(parentXP, targetDoc).length === 1) {
            results.push({
              xpath: parentXP,
              selenium4: `RelativeLocator.with(By.tagName("${pTag}")).near(By.xpath("//${targetDesc.step}"))`,
              type: 'relative-parent-container',
              anchorText: targetDesc.step,
              score: 90,
              label: `Parent Container (parent::${pTag})`
            });
          }
        }
      }

      // Deduplicate by xpath
      const uniqueResults = [];
      const seen = new Set();
      for (const res of results) {
        if (!seen.has(res.xpath)) {
          seen.add(res.xpath);
          uniqueResults.push(res);
        }
      }

      // Boost locators targeting actual form controls over raw containers
      uniqueResults.sort((a, b) => {
        const aIsControl = a.xpath.includes('input') || a.xpath.includes('select') || a.xpath.includes('textarea') || a.xpath.includes('button');
        const bIsControl = b.xpath.includes('input') || b.xpath.includes('select') || b.xpath.includes('textarea') || b.xpath.includes('button');
        if (aIsControl && !bIsControl) return -1;
        if (!aIsControl && bIsControl) return 1;
        return b.score - a.score;
      });

      return uniqueResults;
    }

    /**
     * Map role string to Playwright Java AriaRole enum name
     */
    static getAriaRoleJavaEnum(role) {
      if (!role) return 'BUTTON';
      const clean = role.toLowerCase().trim();
      const map = {
        button: 'BUTTON',
        link: 'LINK',
        textbox: 'TEXTBOX',
        checkbox: 'CHECKBOX',
        radio: 'RADIO',
        combobox: 'COMBOBOX',
        heading: 'HEADING',
        dialog: 'DIALOG',
        navigation: 'NAVIGATION',
        main: 'MAIN',
        form: 'FORM',
        list: 'LIST',
        listitem: 'LISTITEM',
        table: 'TABLE',
        row: 'ROW',
        cell: 'CELL',
        columnheader: 'COLUMNHEADER',
        img: 'IMG',
        slider: 'SLIDER',
        spinbutton: 'SPINBUTTON',
        searchbox: 'SEARCHBOX',
        alert: 'ALERT',
        alertdialog: 'ALERTDIALOG',
        banner: 'BANNER',
        complementary: 'COMPLEMENTARY',
        contentinfo: 'CONTENTINFO',
        definition: 'DEFINITION',
        document: 'DOCUMENT',
        feed: 'FEED',
        figure: 'FIGURE',
        grid: 'GRID',
        gridcell: 'GRIDCELL',
        group: 'GROUP',
        log: 'LOG',
        marquee: 'MARQUEE',
        math: 'MATH',
        menu: 'MENU',
        menubar: 'MENUBAR',
        menuitem: 'MENUITEM',
        menuitemcheckbox: 'MENUITEMCHECKBOX',
        menuitemradio: 'MENUITEMRADIO',
        none: 'NONE',
        note: 'NOTE',
        option: 'OPTION',
        presentation: 'PRESENTATION',
        progressbar: 'PROGRESSBAR',
        radiogroup: 'RADIOGROUP',
        region: 'REGION',
        rowgroup: 'ROWGROUP',
        rowheader: 'ROWHEADER',
        scrollbar: 'SCROLLBAR',
        search: 'SEARCH',
        separator: 'SEPARATOR',
        status: 'STATUS',
        switch: 'SWITCH',
        tab: 'TAB',
        tablist: 'TABLIST',
        tabpanel: 'TABPANEL',
        term: 'TERM',
        timer: 'TIMER',
        toolbar: 'TOOLBAR',
        tooltip: 'TOOLTIP',
        tree: 'TREE',
        treegrid: 'TREEGRID',
        treeitem: 'TREEITEM'
      };
      return map[clean] || clean.toUpperCase().replace(/-/g, '_');
    }

    /**
     * Convert Playwright locator code (or XPath) into Playwright Modern Java syntax
     */
    static toPlaywrightJava(playwrightCode, xpath = null) {
      if (playwrightCode) {
        const clean = playwrightCode.trim().replace(/;$/, '');

        // 1. page.locator('#id') or page.locator("...")
        const locatorM = clean.match(/(?:page\.)?locator\(\s*['"](.*?)['"]\s*\)/i);
        if (locatorM) {
          return `page.locator("${locatorM[1].replace(/"/g, '\\"')}");`;
        }

        // 2. page.getByTestId('val')
        const testIdM = clean.match(/(?:page\.)?getByTestId\(\s*['"](.*?)['"]\s*\)/i);
        if (testIdM) {
          return `page.getByTestId("${testIdM[1].replace(/"/g, '\\"')}");`;
        }

        // 3. page.getByRole('role', { name: 'name', exact: true/false })
        const roleM = clean.match(/(?:page\.)?getByRole\(\s*['"]([a-z0-9_-]+)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (roleM) {
          const roleEnum = XPathEngine.getAriaRoleJavaEnum(roleM[1]);
          const optsRaw = roleM[2] || '';
          const nameM = optsRaw.match(/name:\s*['"](.*?)['"]/i);
          const exactM = optsRaw.match(/exact:\s*(true|false)/i);
          if (nameM) {
            const escName = nameM[1].replace(/"/g, '\\"');
            const exactPart = (exactM && exactM[1] === 'true') ? '.setExact(true)' : '';
            return `page.getByRole(AriaRole.${roleEnum}, new Page.GetByRoleOptions().setName("${escName}")${exactPart});`;
          }
          return `page.getByRole(AriaRole.${roleEnum});`;
        }

        // 4. page.getByLabel('val', { exact: true/false })
        const labelM = clean.match(/(?:page\.)?getByLabel\(\s*['"](.*?)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (labelM) {
          const escVal = labelM[1].replace(/"/g, '\\"');
          const exactM = (labelM[2] || '').match(/exact:\s*(true|false)/i);
          const exactPart = (exactM && exactM[1] === 'true') ? ', new Page.GetByLabelOptions().setExact(true)' : '';
          return `page.getByLabel("${escVal}"${exactPart});`;
        }

        // 5. page.getByPlaceholder('val')
        const phM = clean.match(/(?:page\.)?getByPlaceholder\(\s*['"](.*?)['"]\s*\)/i);
        if (phM) {
          const escVal = phM[1].replace(/"/g, '\\"');
          return `page.getByPlaceholder("${escVal}");`;
        }

        // 6. page.getByAltText('val')
        const altM = clean.match(/(?:page\.)?getByAltText\(\s*['"](.*?)['"]\s*\)/i);
        if (altM) {
          const escVal = altM[1].replace(/"/g, '\\"');
          return `page.getByAltText("${escVal}");`;
        }

        // 7. page.getByTitle('val')
        const titleM = clean.match(/(?:page\.)?getByTitle\(\s*['"](.*?)['"]\s*\)/i);
        if (titleM) {
          const escVal = titleM[1].replace(/"/g, '\\"');
          return `page.getByTitle("${escVal}");`;
        }

        // 8. page.getByText('val', { exact: true/false })
        const textM = clean.match(/(?:page\.)?getByText\(\s*['"](.*?)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (textM) {
          const escVal = textM[1].replace(/"/g, '\\"');
          const exactM = (textM[2] || '').match(/exact:\s*(true|false)/i);
          const exactPart = (exactM && exactM[1] === 'true') ? ', new Page.GetByTextOptions().setExact(true)' : '';
          return `page.getByText("${escVal}"${exactPart});`;
        }
      }

      // If raw XPath or ID XPath
      if (xpath) {
        const idMatch = xpath.match(/^\/\/[a-z0-9_-]*\[@id=['"]([^'"]+)['"]\]$/i);
        if (idMatch) {
          return `page.locator("#${safeEscapeCSS(idMatch[1])}");`;
        }
        return `page.locator("xpath=${xpath.replace(/"/g, '\\"')}");`;
      }

      return 'page.locator("");';
    }

    /**
     * Convert standard Playwright JS locator into Python Playwright syntax
     */
    static toPlaywrightPython(playwrightCode, xpath = null) {
      if (playwrightCode) {
        const clean = playwrightCode.trim().replace(/;$/, '');

        // 1. page.locator('#id') or page.locator("...")
        const locatorM = clean.match(/(?:page\.)?locator\(\s*['"](.*?)['"]\s*\)/i);
        if (locatorM) {
          return `page.locator("${locatorM[1].replace(/"/g, '\\"')}")`;
        }

        // 2. page.getByTestId('val')
        const testIdM = clean.match(/(?:page\.)?getByTestId\(\s*['"](.*?)['"]\s*\)/i);
        if (testIdM) {
          return `page.get_by_test_id("${testIdM[1].replace(/"/g, '\\"')}")`;
        }

        // 3. page.getByRole('role', { name: 'name', exact: true/false })
        const roleM = clean.match(/(?:page\.)?getByRole\(\s*['"]([a-z0-9_-]+)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (roleM) {
          const rawRole = roleM[1];
          const optsRaw = roleM[2] || '';
          const nameM = optsRaw.match(/name:\s*['"](.*?)['"]/i);
          const exactM = optsRaw.match(/exact:\s*(true|false)/i);
          const parts = [`"${rawRole}"`];
          if (nameM) {
            parts.push(`name="${nameM[1].replace(/"/g, '\\"')}"`);
          }
          if (exactM && exactM[1] === 'true') {
            parts.push('exact=True');
          }
          return `page.get_by_role(${parts.join(', ')})`;
        }

        // 4. page.getByLabel('val', { exact: true/false })
        const labelM = clean.match(/(?:page\.)?getByLabel\(\s*['"](.*?)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (labelM) {
          const escVal = labelM[1].replace(/"/g, '\\"');
          const exactM = (labelM[2] || '').match(/exact:\s*(true|false)/i);
          const exactPart = (exactM && exactM[1] === 'true') ? ', exact=True' : '';
          return `page.get_by_label("${escVal}"${exactPart})`;
        }

        // 5. page.getByPlaceholder('val')
        const phM = clean.match(/(?:page\.)?getByPlaceholder\(\s*['"](.*?)['"]\s*\)/i);
        if (phM) {
          return `page.get_by_placeholder("${phM[1].replace(/"/g, '\\"')}")`;
        }

        // 6. page.getByAltText('val')
        const altM = clean.match(/(?:page\.)?getByAltText\(\s*['"](.*?)['"]\s*\)/i);
        if (altM) {
          return `page.get_by_alt_text("${altM[1].replace(/"/g, '\\"')}")`;
        }

        // 7. page.getByTitle('val')
        const titleM = clean.match(/(?:page\.)?getByTitle\(\s*['"](.*?)['"]\s*\)/i);
        if (titleM) {
          return `page.get_by_title("${titleM[1].replace(/"/g, '\\"')}")`;
        }

        // 8. page.getByText('val', { exact: true/false })
        const textM = clean.match(/(?:page\.)?getByText\(\s*['"](.*?)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (textM) {
          const escVal = textM[1].replace(/"/g, '\\"');
          const exactM = (textM[2] || '').match(/exact:\s*(true|false)/i);
          const exactPart = (exactM && exactM[1] === 'true') ? ', exact=True' : '';
          return `page.get_by_text("${escVal}"${exactPart})`;
        }
      }

      if (xpath) {
        const idMatch = xpath.match(/^\/\/[a-z0-9_-]*\[@id=['"]([^'"]+)['"]\]$/i);
        if (idMatch) {
          return `page.locator("#${safeEscapeCSS(idMatch[1])}")`;
        }
        return `page.locator("xpath=${xpath.replace(/"/g, '\\"')}")`;
      }

      return 'page.locator("")';
    }

    /**
     * Convert standard Playwright JS locator into C# Playwright syntax
     */
    static toPlaywrightCSharp(playwrightCode, xpath = null) {
      if (playwrightCode) {
        const clean = playwrightCode.trim().replace(/;$/, '');

        // 1. page.locator('#id') or page.locator("...")
        const locatorM = clean.match(/(?:page\.)?locator\(\s*['"](.*?)['"]\s*\)/i);
        if (locatorM) {
          return `Page.Locator("${locatorM[1].replace(/"/g, '\\"')}")`;
        }

        // 2. page.getByTestId('val')
        const testIdM = clean.match(/(?:page\.)?getByTestId\(\s*['"](.*?)['"]\s*\)/i);
        if (testIdM) {
          return `Page.GetByTestId("${testIdM[1].replace(/"/g, '\\"')}")`;
        }

        // 3. page.getByRole('role', { name: 'name' })
        const roleM = clean.match(/(?:page\.)?getByRole\(\s*['"]([a-z0-9_-]+)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (roleM) {
          const roleEnum = XPathEngine.getAriaRoleJavaEnum(roleM[1]);
          const optsRaw = roleM[2] || '';
          const nameM = optsRaw.match(/name:\s*['"](.*?)['"]/i);
          if (nameM) {
            return `Page.GetByRole(AriaRole.${roleEnum}, new() { Name = "${nameM[1].replace(/"/g, '\\"')}" })`;
          }
          return `Page.GetByRole(AriaRole.${roleEnum})`;
        }

        // 4. page.getByLabel('val')
        const labelM = clean.match(/(?:page\.)?getByLabel\(\s*['"](.*?)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (labelM) {
          return `Page.GetByLabel("${labelM[1].replace(/"/g, '\\"')}")`;
        }

        // 5. page.getByPlaceholder('val')
        const phM = clean.match(/(?:page\.)?getByPlaceholder\(\s*['"](.*?)['"]\s*\)/i);
        if (phM) {
          return `Page.GetByPlaceholder("${phM[1].replace(/"/g, '\\"')}")`;
        }

        // 6. page.getByAltText('val')
        const altM = clean.match(/(?:page\.)?getByAltText\(\s*['"](.*?)['"]\s*\)/i);
        if (altM) {
          return `Page.GetByAltText("${altM[1].replace(/"/g, '\\"')}")`;
        }

        // 7. page.getByTitle('val')
        const titleM = clean.match(/(?:page\.)?getByTitle\(\s*['"](.*?)['"]\s*\)/i);
        if (titleM) {
          return `Page.GetByTitle("${titleM[1].replace(/"/g, '\\"')}")`;
        }

        // 8. page.getByText('val')
        const textM = clean.match(/(?:page\.)?getByText\(\s*['"](.*?)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (textM) {
          return `Page.GetByText("${textM[1].replace(/"/g, '\\"')}")`;
        }
      }

      if (xpath) {
        const idMatch = xpath.match(/^\/\/[a-z0-9_-]*\[@id=['"]([^'"]+)['"]\]$/i);
        if (idMatch) {
          return `Page.Locator("#${safeEscapeCSS(idMatch[1])}")`;
        }
        return `Page.Locator("xpath=${xpath.replace(/"/g, '\\"')}")`;
      }

      return 'Page.Locator("")';
    }

    /**
     * Detect if an element lives inside an iframe or nested frame
     * Returns iframe metadata or null if in top-level document
     */
    static detectIframe(element) {
      if (!element) return null;
      try {
        const ownerDoc = safeGetOwnerDocument(element) || (element && element.ownerDocument) || (typeof document !== 'undefined' ? document : null);
        if (!ownerDoc) return null;
        const win = ownerDoc.defaultView || (ownerDoc.parentWindow ? ownerDoc.parentWindow : null);
        if (!win) return null;

        // Check if current window is child frame
        let isChild = false;
        try {
          isChild = win !== win.top;
        } catch (crossErr) {
          isChild = true;
        }
        if (!isChild) return null;

        let frameEl = null;
        try {
          frameEl = win.frameElement;
        } catch (e) { }

        // Fallback: search parent frames for matching contentWindow if accessible
        if (!frameEl) {
          try {
            if (win.parent && win.parent.document) {
              const frames = Array.from(win.parent.document.querySelectorAll('iframe, frame'));
              for (const f of frames) {
                try {
                  if (f.contentWindow === win) {
                    frameEl = f;
                    break;
                  }
                } catch (fe) { }
              }
            }
          } catch (pe) { }
        }

        let id = null;
        let name = null;
        let title = null;
        let src = null;
        let selector = 'iframe';
        let xpath = '//iframe';
        let switchTarget = '0';

        if (frameEl) {
          id = safeGetAttr(frameEl, 'id') || (typeof frameEl.id === 'string' ? frameEl.id : (typeof frameEl.getAttribute === 'function' ? frameEl.getAttribute('id') : null));
          name = safeGetAttr(frameEl, 'name') || (typeof frameEl.name === 'string' ? frameEl.name : (typeof frameEl.getAttribute === 'function' ? frameEl.getAttribute('name') : null));
          title = safeGetAttr(frameEl, 'title') || (typeof frameEl.title === 'string' ? frameEl.title : (typeof frameEl.getAttribute === 'function' ? frameEl.getAttribute('title') : null));
          src = safeGetAttr(frameEl, 'src') || (typeof frameEl.src === 'string' ? frameEl.src : (typeof frameEl.getAttribute === 'function' ? frameEl.getAttribute('src') : null));

          if (id && !XPathEngine.isDynamicId(id)) {
            const safeId = id.split("'").join("\\'");
            const safeIdDouble = id.split('"').join('\\"');
            selector = `#${safeEscapeCSS(id)}`;
            xpath = `//iframe[@id='${safeId}']`;
            switchTarget = `"${safeIdDouble}"`;
          } else if (name) {
            const safeName = name.split("'").join("\\'");
            const safeNameDouble = name.split('"').join('\\"');
            selector = `iframe[name="${safeNameDouble}"]`;
            xpath = `//iframe[@name='${safeName}']`;
            switchTarget = `"${safeNameDouble}"`;
          } else if (title) {
            const safeTitle = title.split("'").join("\\'");
            const safeTitleDouble = title.split('"').join('\\"');
            selector = `iframe[title="${safeTitleDouble}"]`;
            xpath = `//iframe[@title='${safeTitle}']`;
            switchTarget = `"${safeTitleDouble}"`;
          } else if (src) {
            const shortSrc = src.split('?')[0].slice(-24);
            const safeShortSrc = shortSrc.split("'").join("\\'");
            const safeShortSrcDouble = shortSrc.split('"').join('\\"');
            selector = `iframe[src*="${safeShortSrcDouble}"]`;
            xpath = `//iframe[contains(@src, '${safeShortSrc}')]`;
            switchTarget = '0';
          }
        }

        return {
          isIframe: true,
          id: id || null,
          name: name || null,
          title: title || null,
          src: src || null,
          selector: selector || 'iframe',
          xpath: xpath || '//iframe',
          switchTarget: switchTarget || '0',
          displayName: id ? `#${id}` : (name ? `name="${name}"` : (title ? `title="${title}"` : 'iframe'))
        };
      } catch (err) {
        return null;
      }
    }

    /**
     * Generate modern Playwright user-facing locators
     */
    static generatePlaywrightLocators(element, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!element || element.nodeType !== ELEMENT_NODE) return [];

      const candidates = [];
      const tag = safeGetTagName(element) || 'div';
      const targetDoc = doc || safeGetOwnerDocument(element);

      // 1. getByTestId (data-testid, data-test, data-cy, data-qa)
      for (const attr of TEST_ATTRIBUTES) {
        const val = safeGetAttr(element, attr);
        if (val && val.trim()) {
          const cleanVal = val.trim();
          const code = `page.getByTestId('${XPathEngine.escapeJSString(cleanVal)}')`;
          const codeJava = `page.getByTestId("${cleanVal.replace(/"/g, '\\"')}");`;
          if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
            candidates.push({
              code,
              codeJava,
              type: 'getByTestId',
              score: 100,
              label: `Playwright Test ID (@${attr})`
            });
            break;
          }
        }
      }

      // 2. getByRole (with accessible name or standalone)
      const role = XPathEngine.getImplicitOrExplicitRole(element);
      if (role) {
        const roleEnum = XPathEngine.getAriaRoleJavaEnum(role);
        const accName = XPathEngine.getAccessibleName(element, targetDoc);
        if (accName && accName.length <= 80) {
          const code = `page.getByRole('${role}', { name: '${XPathEngine.escapeJSString(accName)}' })`;
          const codeJava = `page.getByRole(AriaRole.${roleEnum}, new Page.GetByRoleOptions().setName("${accName.replace(/"/g, '\\"')}"));`;
          if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
            candidates.push({
              code,
              codeJava,
              type: 'getByRole',
              score: 98,
              label: `Playwright Role (${role} "${accName.substring(0, 20)}")`
            });
          }
        }

        // Standalone getByRole if unique on page
        const standaloneRoleCode = `page.getByRole('${role}')`;
        const standaloneRoleJava = `page.getByRole(AriaRole.${roleEnum});`;
        if (XPathEngine.isUniquePlaywright(standaloneRoleCode, element, targetDoc)) {
          candidates.push({
            code: standaloneRoleCode,
            codeJava: standaloneRoleJava,
            type: 'getByRole',
            score: 95,
            label: `Playwright Role (${role})`
          });
        }
      }

      // 3. Unique ID (page.locator('#id'))
      const elemId = safeGetId(element);
      if (elemId && !XPathEngine.isDynamicId(elemId)) {
        const cleanId = elemId.trim();
        const escId = safeEscapeCSS(cleanId);
        const code = `page.locator('#${escId}')`;
        const codeJava = `page.locator("#${escId}");`;
        if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
          candidates.push({
            code,
            codeJava,
            type: 'id',
            score: 97,
            label: `Playwright ID (#${cleanId})`
          });
        }
      }

      // 4. getByLabel (for inputs, selects, textareas, or aria-label)
      if (['input', 'select', 'textarea'].includes(tag) || safeHasAttr(element, 'aria-label')) {
        let labelText = '';
        if (safeHasAttr(element, 'aria-label')) {
          labelText = (safeGetAttr(element, 'aria-label') || '').trim();
        } else if (elemId && targetDoc) {
          try {
            const lbl = targetDoc.querySelector(`label[for="${safeEscapeCSS(elemId)}"]`);
            if (lbl) labelText = safeGetText(lbl).trim();
          } catch (e) { }
        }
        if (!labelText && typeof element.closest === 'function') {
          try {
            const pLabel = element.closest('label');
            if (pLabel) {
              const clone = pLabel.cloneNode(true);
              clone.querySelectorAll('input, select, textarea').forEach((n) => n.remove());
              labelText = safeGetText(clone).trim();
            }
          } catch (e) { }
        }

        if (labelText && labelText.length <= 80) {
          const cleanLabel = labelText.replace(/\s+/g, ' ');
          const code = `page.getByLabel('${XPathEngine.escapeJSString(cleanLabel)}')`;
          const codeJava = `page.getByLabel("${cleanLabel.replace(/"/g, '\\"')}");`;
          if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
            candidates.push({
              code,
              codeJava,
              type: 'getByLabel',
              score: 96,
              label: `Playwright Label ("${cleanLabel.substring(0, 20)}")`
            });
          }
        }
      }

      // 5. getByPlaceholder
      if (safeHasAttr(element, 'placeholder')) {
        const ph = (safeGetAttr(element, 'placeholder') || '').trim();
        if (ph && ph.length <= 80) {
          const code = `page.getByPlaceholder('${XPathEngine.escapeJSString(ph)}')`;
          const codeJava = `page.getByPlaceholder("${ph.replace(/"/g, '\\"')}");`;
          if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
            candidates.push({
              code,
              codeJava,
              type: 'getByPlaceholder',
              score: 94,
              label: `Playwright Placeholder`
            });
          }
        }
      }

      // 6. getByAltText (images, areas)
      if ((tag === 'img' || tag === 'area' || (tag === 'input' && safeGetAttr(element, 'type') === 'image')) && safeHasAttr(element, 'alt')) {
        const alt = (safeGetAttr(element, 'alt') || '').trim();
        if (alt && alt.length <= 80) {
          const code = `page.getByAltText('${XPathEngine.escapeJSString(alt)}')`;
          const codeJava = `page.getByAltText("${alt.replace(/"/g, '\\"')}");`;
          if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
            candidates.push({
              code,
              codeJava,
              type: 'getByAltText',
              score: 93,
              label: `Playwright Alt Text`
            });
          }
        }
      }

      // 7. getByTitle
      if (safeHasAttr(element, 'title')) {
        const title = (safeGetAttr(element, 'title') || '').trim();
        if (title && title.length <= 80) {
          const code = `page.getByTitle('${XPathEngine.escapeJSString(title)}')`;
          const codeJava = `page.getByTitle("${title.replace(/"/g, '\\"')}");`;
          if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
            candidates.push({
              code,
              codeJava,
              type: 'getByTitle',
              score: 91,
              label: `Playwright Title`
            });
          }
        }
      }

      // 8. getByText (concise visible text on leaf or shallow elements)
      const text = safeGetText(element).trim();
      const childrenLen = safeGetChildren(element).length;
      if (text && text.length >= 2 && text.length <= 60 && childrenLen <= 2) {
        const cleanText = text.replace(/\s+/g, ' ');
        const codeExact = `page.getByText('${XPathEngine.escapeJSString(cleanText)}', { exact: true })`;
        const codeExactJava = `page.getByText("${cleanText.replace(/"/g, '\\"')}", new Page.GetByTextOptions().setExact(true));`;
        const codeGeneral = `page.getByText('${XPathEngine.escapeJSString(cleanText)}')`;
        const codeGeneralJava = `page.getByText("${cleanText.replace(/"/g, '\\"')}");`;

        if (XPathEngine.isUniquePlaywright(codeExact, element, targetDoc)) {
          candidates.push({
            code: codeExact,
            codeJava: codeExactJava,
            type: 'getByText',
            score: 89,
            label: `Playwright Exact Text`
          });
        } else if (XPathEngine.isUniquePlaywright(codeGeneral, element, targetDoc)) {
          candidates.push({
            code: codeGeneral,
            codeJava: codeGeneralJava,
            type: 'getByText',
            score: 87,
            label: `Playwright Text`
          });
        }
      }

      // Sort by score descending
      candidates.sort((a, b) => b.score - a.score);
      return candidates;
    }

    /**
     * Check if a Playwright locator uniquely identifies the element
     */
    static isUniquePlaywright(locatorCode, element, doc = (typeof document !== 'undefined' ? document : null)) {
      const matches = XPathEngine.queryPlaywright(locatorCode, doc);
      return matches.length === 1 && matches[0] === element;
    }

    /**
     * Parse and query a Playwright locator expression against the document
     * Supports: locator('#id'), getByRole, getByTestId, getByLabel, getByPlaceholder, getByText, getByAltText, getByTitle
     */
    static queryPlaywright(locatorCode, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!locatorCode || typeof locatorCode !== 'string' || !doc) return [];
      let clean = locatorCode.trim().replace(/;$/, '').trim();

      // 0. page.locator(...)
      const locatorMatch = clean.match(/(?:page\.)?locator\(\s*['"](.*?)['"]\s*\)/i);
      if (locatorMatch) {
        const sel = locatorMatch[1];
        if (sel.startsWith('xpath=')) {
          return XPathEngine.queryXPath(sel.substring(6), doc);
        }
        if (sel.startsWith('//') || sel.startsWith('(')) {
          return XPathEngine.queryXPath(sel, doc);
        }
        if (sel.startsWith('id=')) {
          const el = doc.getElementById(sel.substring(3));
          return el ? [el] : [];
        }
        try {
          return Array.from(doc.querySelectorAll(sel));
        } catch (e) {
          return [];
        }
      }

      // 1. getByTestId
      const testIdMatch = clean.match(/(?:page\.)?getByTestId\(\s*['"](.*?)['"]\s*\)/i);
      if (testIdMatch) {
        const val = testIdMatch[1];
        const sel = TEST_ATTRIBUTES.map((attr) => `[${attr}="${safeEscapeCSS(val)}"]`).join(', ');
        try {
          return Array.from(doc.querySelectorAll(sel));
        } catch (e) {
          return [];
        }
      }

      // 2. getByPlaceholder
      const phMatch = clean.match(/(?:page\.)?getByPlaceholder\(\s*['"](.*?)['"]\s*(?:,\s*\{\s*exact:\s*(true|false)\s*\}\s*)?\)/i);
      if (phMatch) {
        const val = phMatch[1];
        const exact = phMatch[2] === 'true';
        try {
          const els = Array.from(doc.querySelectorAll('[placeholder]'));
          return els.filter((el) => {
            const p = safeGetAttr(el, 'placeholder') || '';
            return exact ? p === val : p.toLowerCase().includes(val.toLowerCase());
          });
        } catch (e) {
          return [];
        }
      }

      // 3. getByTitle
      const titleMatch = clean.match(/(?:page\.)?getByTitle\(\s*['"](.*?)['"]\s*(?:,\s*\{\s*exact:\s*(true|false)\s*\}\s*)?\)/i);
      if (titleMatch) {
        const val = titleMatch[1];
        const exact = titleMatch[2] === 'true';
        try {
          const els = Array.from(doc.querySelectorAll('[title]'));
          return els.filter((el) => {
            const t = safeGetAttr(el, 'title') || '';
            return exact ? t === val : t.toLowerCase().includes(val.toLowerCase());
          });
        } catch (e) {
          return [];
        }
      }

      // 4. getByAltText
      const altMatch = clean.match(/(?:page\.)?getByAltText\(\s*['"](.*?)['"]\s*(?:,\s*\{\s*exact:\s*(true|false)\s*\}\s*)?\)/i);
      if (altMatch) {
        const val = altMatch[1];
        const exact = altMatch[2] === 'true';
        try {
          const els = Array.from(doc.querySelectorAll('[alt]'));
          return els.filter((el) => {
            const a = safeGetAttr(el, 'alt') || '';
            return exact ? a === val : a.toLowerCase().includes(val.toLowerCase());
          });
        } catch (e) {
          return [];
        }
      }

      // 5. getByLabel
      const labelMatch = clean.match(/(?:page\.)?getByLabel\(\s*['"](.*?)['"]\s*(?:,\s*(?:\{\s*exact:\s*(true|false)\s*\}|new\s+Page\.GetByLabelOptions\(\)\.setExact\((true|false)\))?\s*)?\)/i);
      if (labelMatch) {
        const val = labelMatch[1];
        const exact = (labelMatch[2] || labelMatch[3]) === 'true';
        const results = new Set();

        // Check aria-label
        try {
          const ariaEls = Array.from(doc.querySelectorAll('[aria-label]'));
          ariaEls.forEach((el) => {
            const al = safeGetAttr(el, 'aria-label') || '';
            if (exact ? al === val : al.toLowerCase().includes(val.toLowerCase())) {
              results.add(el);
            }
          });
        } catch (e) { }

        // Check HTML labels
        try {
          const labels = Array.from(doc.querySelectorAll('label'));
          labels.forEach((lbl) => {
            const txt = safeGetText(lbl).trim().replace(/\s+/g, ' ');
            if (exact ? txt === val : txt.toLowerCase().includes(val.toLowerCase())) {
              const forAttr = safeGetAttr(lbl, 'for');
              if (forAttr) {
                const target = doc.getElementById(forAttr);
                if (target) results.add(target);
              }
              const nestedInput = lbl.querySelector('input, select, textarea');
              if (nestedInput) results.add(nestedInput);
            }
          });
        } catch (e) { }

        return Array.from(results);
      }

      // 6. getByText
      const textMatch = clean.match(/(?:page\.)?getByText\(\s*['"](.*?)['"]\s*(?:,\s*(?:\{\s*exact:\s*(true|false)\s*\}|new\s+Page\.GetByTextOptions\(\)\.setExact\((true|false)\))?\s*)?\)/i);
      if (textMatch) {
        const val = textMatch[1];
        const exact = (textMatch[2] || textMatch[3]) === 'true';
        const root = doc.body || doc.documentElement;
        if (!root || !root.querySelectorAll) return [];
        const all = Array.from(root.querySelectorAll('*'));
        const lowerVal = val.toLowerCase();
        return all.filter((el) => {
          // Fast check: skip elements without any text
          if (!el.textContent && !el.innerText) return false;
          const raw = safeGetText(el);
          if (!raw) return false;
          if (exact ? !raw.includes(val) : !raw.toLowerCase().includes(lowerVal)) return false;

          const t = raw.trim().replace(/\s+/g, ' ');
          const matchesText = exact ? t === val : t.toLowerCase().includes(lowerVal);
          if (!matchesText) return false;

          const chList = safeGetChildren(el);
          for (let i = 0; i < chList.length; i++) {
            const chRaw = safeGetText(chList[i]);
            if (!chRaw) continue;
            const childText = chRaw.trim().replace(/\s+/g, ' ');
            if (exact ? childText === val : childText.toLowerCase().includes(lowerVal)) {
              return false;
            }
          }
          return true;
        });
      }

      // 7. getByRole (supports JS and Java AriaRole enum syntax)
      const roleMatch = clean.match(/(?:page\.)?getByRole\(\s*(?:AriaRole\.([a-z0-9_-]+)|['"]([a-z0-9_-]+)['"])\s*(?:,\s*([\s\S]*?))?\s*\)/i);
      if (roleMatch) {
        const rawRole = (roleMatch[1] || roleMatch[2]).toLowerCase();
        const optionsRaw = roleMatch[3] || '';
        let nameFilter = null;
        let exactName = false;

        const nameMatch = optionsRaw.match(/(?:name:\s*['"](.*?)['"]|\.setName\(\s*['"](.*?)['"]\s*\))/i);
        if (nameMatch) {
          nameFilter = nameMatch[1] !== undefined ? nameMatch[1] : nameMatch[2];
        }
        const exactMatch = optionsRaw.match(/(?:exact:\s*(true|false)|\.setExact\(\s*(true|false)\s*\))/i);
        if (exactMatch) {
          exactName = (exactMatch[1] || exactMatch[2]) === 'true';
        }

        const ROLE_SELECTOR_MAP = {
          button: 'button, input[type="button"], input[type="submit"], input[type="reset"], summary, [role="button"]',
          link: 'a[href], [role="link"]',
          textbox: 'input, textarea, [role="textbox"]',
          checkbox: 'input[type="checkbox"], [role="checkbox"]',
          radio: 'input[type="radio"], [role="radio"]',
          combobox: 'select, [role="combobox"]',
          heading: 'h1, h2, h3, h4, h5, h6, [role="heading"]',
          dialog: 'dialog, [role="dialog"], [role="alertdialog"]',
          list: 'ul, ol, [role="list"]',
          listitem: 'li, [role="listitem"]',
          table: 'table, [role="table"], [role="grid"]',
          row: 'tr, [role="row"]',
          cell: 'td, [role="cell"], [role="gridcell"]',
          columnheader: 'th, [role="columnheader"]',
          img: 'img, svg, [role="img"]',
          slider: 'input[type="range"], [role="slider"]',
          spinbutton: 'input[type="number"], [role="spinbutton"]',
          searchbox: 'input[type="search"], [role="searchbox"]',
          navigation: 'nav, [role="navigation"]',
          main: 'main, [role="main"]',
          form: 'form, [role="form"]'
        };

        let candidateNodes = [];
        if (ROLE_SELECTOR_MAP[rawRole]) {
          try {
            candidateNodes = Array.from(doc.querySelectorAll(ROLE_SELECTOR_MAP[rawRole]));
          } catch (e) {
            candidateNodes = [];
          }
        }
        if (candidateNodes.length === 0) {
          try {
            candidateNodes = Array.from(doc.querySelectorAll(`[role="${rawRole}"], ${rawRole}`));
          } catch (e) {
            candidateNodes = [];
          }
        }
        if (candidateNodes.length === 0) {
          const root = doc.body || doc.documentElement;
          if (!root || !root.querySelectorAll) return [];
          candidateNodes = Array.from(root.querySelectorAll('*'));
        }

        return candidateNodes.filter((el) => {
          const role = XPathEngine.getImplicitOrExplicitRole(el);
          if (role !== rawRole) return false;

          if (nameFilter !== null) {
            const accName = XPathEngine.getAccessibleName(el, doc);
            return exactName
              ? accName === nameFilter
              : accName.toLowerCase().includes(nameFilter.toLowerCase());
          }
          return true;
        });
      }

      return [];
    }

    /**
     * Export XPath to target test framework code template
     */
    static formatForFramework(xpath, framework = 'raw', bestPlaywright = null, bestPlaywrightJava = null, bestRelative = null, action = 'locator', sampleText = 'Enter value', iframeInfo = null, exactText = null) {
      if (action && action !== 'locator') {
        return XPathEngine.formatActionCode(xpath, framework, action, bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText);
      }

      const escapedDouble = (xpath || '').replace(/"/g, '\\"');
      const inFrame = iframeInfo && iframeInfo.isIframe;
      const frameSel = inFrame ? (iframeInfo.selector || 'iframe').replace(/'/g, "\\'") : '';
      const frameSelDouble = inFrame ? (iframeInfo.selector || 'iframe').replace(/"/g, '\\"') : '';

      switch (framework) {
        case 'playwright': {
          if (inFrame) {
            const basePw = bestPlaywright || `page.locator("xpath=${escapedDouble}");`;
            return basePw.startsWith('page.')
              ? basePw.replace(/^page\./, `page.frameLocator('${frameSel}').`)
              : `page.frameLocator('${frameSel}').locator("xpath=${escapedDouble}");`;
          }
          return bestPlaywright || `page.locator("xpath=${escapedDouble}");`;
        }
        case 'playwright-python': {
          const basePy = XPathEngine.toPlaywrightPython(bestPlaywright, xpath);
          if (inFrame) {
            return basePy.startsWith('page.')
              ? basePy.replace(/^page\./, `page.frame_locator('${frameSel}').`)
              : `page.frame_locator('${frameSel}').locator("xpath=${escapedDouble}")`;
          }
          return basePy;
        }
        case 'playwright-csharp': {
          const baseCs = XPathEngine.toPlaywrightCSharp(bestPlaywright, xpath);
          if (inFrame) {
            return (baseCs.startsWith('Page.')
              ? baseCs.replace(/^Page\./, `Page.FrameLocator("${frameSelDouble}").`)
              : `Page.FrameLocator("${frameSelDouble}").Locator("xpath=${escapedDouble}")`) + ';';
          }
          return baseCs + ';';
        }
        case 'playwright-java':
        case 'playwright-modern-java': {
          const baseJava = (bestPlaywrightJava || XPathEngine.toPlaywrightJava(bestPlaywright, xpath)).trim().replace(/;$/, '');
          if (inFrame) {
            return (baseJava.startsWith('page.')
              ? baseJava.replace(/^page\./, `page.frameLocator("${frameSelDouble}").`)
              : `page.frameLocator("${frameSelDouble}").locator("xpath=${escapedDouble}")`) + ';';
          }
          return baseJava + ';';
        }
        case 'playwright-xpath':
          return inFrame
            ? `page.frameLocator('${frameSel}').locator("xpath=${escapedDouble}");`
            : `page.locator("xpath=${escapedDouble}");`;
        case 'playwright-java-xpath':
          return inFrame
            ? `page.frameLocator("${frameSelDouble}").locator("xpath=${escapedDouble}");`
            : `page.locator("xpath=${escapedDouble}");`;
        case 'selenium4-relative': {
          const relBase = (bestRelative && bestRelative.selenium4)
            ? bestRelative.selenium4 + ';'
            : `RelativeLocator.with(By.xpath("${escapedDouble}")).near(By.xpath("..."));`;
          return inFrame
            ? `driver.switchTo().frame(${iframeInfo.switchTarget});\n${relBase}`
            : relBase;
        }
        case 'selenium-java':
          return inFrame
            ? `driver.switchTo().frame(${iframeInfo.switchTarget});\ndriver.findElement(By.xpath("${escapedDouble}"));`
            : `driver.findElement(By.xpath("${escapedDouble}"));`;
        case 'selenium-python':
          return inFrame
            ? `driver.switch_to.frame(${iframeInfo.switchTarget})\ndriver.find_element(By.XPATH, "${escapedDouble}")`
            : `driver.find_element(By.XPATH, "${escapedDouble}")`;
        case 'selenium-javascript':
          return inFrame
            ? `await driver.switchTo().frame(${iframeInfo.switchTarget});\nawait driver.findElement(By.xpath("${escapedDouble}"));`
            : `driver.findElement(By.xpath("${escapedDouble}"));`;
        case 'selenium-csharp':
          return inFrame
            ? `driver.SwitchTo().Frame(${iframeInfo.switchTarget});\ndriver.FindElement(By.XPath("${escapedDouble}"));`
            : `driver.FindElement(By.XPath("${escapedDouble}"));`;
        case 'cypress':
          return inFrame
            ? `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}");\n});`
            : `cy.xpath("${escapedDouble}");`;
        case 'robot':
          return inFrame
            ? `Select Frame    ${iframeInfo.xpath}\n# Locator: xpath=${xpath}`
            : `xpath=${xpath}`;
        case 'puppeteer':
          return inFrame
            ? `const frame = (await page.$("${frameSelDouble}")).contentFrame();\nawait frame.$x("${escapedDouble}");`
            : `await page.$x("${escapedDouble}");`;
        case 'raw':
        default:
          return xpath;
      }
    }

    /**
     * Generate complete executable action code for given locator, framework and action type
     * Actions: 'locator', 'click', 'fill', 'assertVisible', 'assertText', 'assertChecked', 'assertEnabled', 'waitFor', 'getText'
     */
    static formatActionCode(xpath, framework = 'raw', action = 'locator', bestPlaywright = null, bestPlaywrightJava = null, bestRelative = null, sampleText = 'Enter value', iframeInfo = null, exactText = null) {
      if (action === 'locator') {
        return XPathEngine.formatForFramework(xpath, framework, bestPlaywright, bestPlaywrightJava, bestRelative, 'locator', sampleText, iframeInfo, exactText);
      }

      const escapedDouble = (xpath || '').replace(/"/g, '\\"');
      const inFrame = iframeInfo && iframeInfo.isIframe;
      const frameSel = inFrame ? (iframeInfo.selector || 'iframe').replace(/'/g, "\\'") : '';
      const frameSelDouble = inFrame ? (iframeInfo.selector || 'iframe').replace(/"/g, '\\"') : '';

      const actualText = (sampleText && typeof sampleText === 'string' && sampleText.trim().length > 0)
        ? sampleText.trim()
        : 'Enter value';
      const escText = actualText.replace(/"/g, '\\"');

      const targetText = (exactText && typeof exactText === 'string' && exactText.trim().length > 0)
        ? exactText.trim()
        : actualText;
      const escTargetText = targetText.replace(/"/g, '\\"');

      // Resolved locators
      let cleanPlaywrightJS = (bestPlaywright || `page.locator("xpath=${escapedDouble}")`).trim().replace(/;$/, '');
      if (inFrame) {
        cleanPlaywrightJS = cleanPlaywrightJS.startsWith('page.')
          ? cleanPlaywrightJS.replace(/^page\./, `page.frameLocator('${frameSel}').`)
          : `page.frameLocator('${frameSel}').locator("xpath=${escapedDouble}")`;
      }

      let cleanPlaywrightJava = (bestPlaywrightJava || XPathEngine.toPlaywrightJava(bestPlaywright, xpath)).trim().replace(/;$/, '');
      if (inFrame) {
        cleanPlaywrightJava = cleanPlaywrightJava.startsWith('page.')
          ? cleanPlaywrightJava.replace(/^page\./, `page.frameLocator("${frameSelDouble}").`)
          : `page.frameLocator("${frameSelDouble}").locator("xpath=${escapedDouble}")`;
      }

      const selenium4Target = (bestRelative && bestRelative.selenium4)
        ? bestRelative.selenium4.trim().replace(/;$/, '')
        : `RelativeLocator.with(By.xpath("${escapedDouble}")).near(By.xpath("..."))`;

      switch (framework) {
        case 'playwright':
          if (action === 'click') return `await ${cleanPlaywrightJS}.click();`;
          if (action === 'fill') return `await ${cleanPlaywrightJS}.fill("${escText}");`;
          if (action === 'assertVisible') return `await expect(${cleanPlaywrightJS}).toBeVisible();`;
          if (action === 'assertText') return `await expect(${cleanPlaywrightJS}).toHaveText("${escTargetText}");`;
          if (action === 'assertChecked') return `await expect(${cleanPlaywrightJS}).toBeChecked();`;
          if (action === 'assertEnabled') return `await expect(${cleanPlaywrightJS}).toBeEnabled();`;
          if (action === 'waitFor') return `await ${cleanPlaywrightJS}.waitFor({ state: 'visible' });`;
          if (action === 'getText') return `const text = await ${cleanPlaywrightJS}.textContent();`;
          return `await ${cleanPlaywrightJS}.${action}();`;

        case 'playwright-python': {
          let cleanPlaywrightPy = XPathEngine.toPlaywrightPython(bestPlaywright, xpath).trim().replace(/;$/, '');
          if (inFrame) {
            cleanPlaywrightPy = cleanPlaywrightPy.startsWith('page.')
              ? cleanPlaywrightPy.replace(/^page\./, `page.frame_locator('${frameSel}').`)
              : `page.frame_locator('${frameSel}').locator("xpath=${escapedDouble}")`;
          }
          if (action === 'click') return `${cleanPlaywrightPy}.click()`;
          if (action === 'fill') return `${cleanPlaywrightPy}.fill("${escText}")`;
          if (action === 'assertVisible') return `expect(${cleanPlaywrightPy}).to_be_visible()`;
          if (action === 'assertText') return `expect(${cleanPlaywrightPy}).to_have_text("${escTargetText}")`;
          if (action === 'assertChecked') return `expect(${cleanPlaywrightPy}).to_be_checked()`;
          if (action === 'assertEnabled') return `expect(${cleanPlaywrightPy}).to_be_enabled()`;
          if (action === 'waitFor') return `${cleanPlaywrightPy}.wait_for(state="visible")`;
          if (action === 'getText') return `text = ${cleanPlaywrightPy}.text_content()`;
          return `${cleanPlaywrightPy}.${action}()`;
        }

        case 'playwright-csharp': {
          let cleanPlaywrightCs = XPathEngine.toPlaywrightCSharp(bestPlaywright, xpath).trim().replace(/;$/, '');
          if (inFrame) {
            cleanPlaywrightCs = cleanPlaywrightCs.startsWith('Page.')
              ? cleanPlaywrightCs.replace(/^Page\./, `Page.FrameLocator("${frameSelDouble}").`)
              : `Page.FrameLocator("${frameSelDouble}").Locator("xpath=${escapedDouble}")`;
          }
          if (action === 'click') return `await ${cleanPlaywrightCs}.ClickAsync();`;
          if (action === 'fill') return `await ${cleanPlaywrightCs}.FillAsync("${escText}");`;
          if (action === 'assertVisible') return `await Expect(${cleanPlaywrightCs}).ToBeVisibleAsync();`;
          if (action === 'assertText') return `await Expect(${cleanPlaywrightCs}).ToHaveTextAsync("${escTargetText}");`;
          if (action === 'assertChecked') return `await Expect(${cleanPlaywrightCs}).ToBeCheckedAsync();`;
          if (action === 'assertEnabled') return `await Expect(${cleanPlaywrightCs}).ToBeEnabledAsync();`;
          if (action === 'waitFor') return `await ${cleanPlaywrightCs}.WaitForAsync();`;
          if (action === 'getText') return `string text = await ${cleanPlaywrightCs}.TextContentAsync();`;
          return `await ${cleanPlaywrightCs}.${action}Async();`;
        }

        case 'playwright-xpath': {
          const pwXpTarget = inFrame
            ? `page.frameLocator('${frameSel}').locator("xpath=${escapedDouble}")`
            : `page.locator("xpath=${escapedDouble}")`;
          if (action === 'click') return `await ${pwXpTarget}.click();`;
          if (action === 'fill') return `await ${pwXpTarget}.fill("${escText}");`;
          if (action === 'assertVisible') return `await expect(${pwXpTarget}).toBeVisible();`;
          if (action === 'assertText') return `await expect(${pwXpTarget}).toHaveText("${escTargetText}");`;
          if (action === 'assertChecked') return `await expect(${pwXpTarget}).toBeChecked();`;
          if (action === 'assertEnabled') return `await expect(${pwXpTarget}).toBeEnabled();`;
          if (action === 'waitFor') return `await ${pwXpTarget}.waitFor();`;
          if (action === 'getText') return `const text = await ${pwXpTarget}.textContent();`;
          return `await ${pwXpTarget}.${action}();`;
        }

        case 'playwright-java':
        case 'playwright-modern-java':
          if (action === 'click') return `${cleanPlaywrightJava}.click();`;
          if (action === 'fill') return `${cleanPlaywrightJava}.fill("${escText}");`;
          if (action === 'assertVisible') return `assertThat(${cleanPlaywrightJava}).isVisible();`;
          if (action === 'assertText') return `assertThat(${cleanPlaywrightJava}).hasText("${escTargetText}");`;
          if (action === 'assertChecked') return `assertThat(${cleanPlaywrightJava}).isChecked();`;
          if (action === 'assertEnabled') return `assertThat(${cleanPlaywrightJava}).isEnabled();`;
          if (action === 'waitFor') return `${cleanPlaywrightJava}.waitFor();`;
          if (action === 'getText') return `String text = ${cleanPlaywrightJava}.textContent();`;
          return `${cleanPlaywrightJava}.${action}();`;

        case 'playwright-java-xpath': {
          const pwJavaXpTarget = inFrame
            ? `page.frameLocator("${frameSelDouble}").locator("xpath=${escapedDouble}")`
            : `page.locator("xpath=${escapedDouble}")`;
          if (action === 'click') return `${pwJavaXpTarget}.click();`;
          if (action === 'fill') return `${pwJavaXpTarget}.fill("${escText}");`;
          if (action === 'assertVisible') return `assertThat(${pwJavaXpTarget}).isVisible();`;
          if (action === 'assertText') return `assertThat(${pwJavaXpTarget}).hasText("${escTargetText}");`;
          if (action === 'assertChecked') return `assertThat(${pwJavaXpTarget}).isChecked();`;
          if (action === 'assertEnabled') return `assertThat(${pwJavaXpTarget}).isEnabled();`;
          if (action === 'waitFor') return `${pwJavaXpTarget}.waitFor();`;
          if (action === 'getText') return `String text = ${pwJavaXpTarget}.textContent();`;
          return `${pwJavaXpTarget}.${action}();`;
        }

        case 'selenium-java': {
          const framePrefix = inFrame ? `driver.switchTo().frame(${iframeInfo.switchTarget});\n` : '';
          if (action === 'click') return `${framePrefix}driver.findElement(By.xpath("${escapedDouble}")).click();`;
          if (action === 'fill') return `${framePrefix}driver.findElement(By.xpath("${escapedDouble}")).sendKeys("${escText}");`;
          if (action === 'assertVisible') return `${framePrefix}Assert.assertTrue(driver.findElement(By.xpath("${escapedDouble}")).isDisplayed());`;
          if (action === 'assertText') return `${framePrefix}Assert.assertEquals(driver.findElement(By.xpath("${escapedDouble}")).getText(), "${escTargetText}");`;
          if (action === 'assertChecked') return `${framePrefix}Assert.assertTrue(driver.findElement(By.xpath("${escapedDouble}")).isSelected());`;
          if (action === 'assertEnabled') return `${framePrefix}Assert.assertTrue(driver.findElement(By.xpath("${escapedDouble}")).isEnabled());`;
          if (action === 'waitFor') return `${framePrefix}new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("${escapedDouble}")));`;
          if (action === 'getText') return `${framePrefix}String text = driver.findElement(By.xpath("${escapedDouble}")).getText();`;
          return `${framePrefix}driver.findElement(By.xpath("${escapedDouble}")).${action}();`;
        }

        case 'selenium-python': {
          const framePrefix = inFrame ? `driver.switch_to.frame(${iframeInfo.switchTarget})\n` : '';
          if (action === 'click') return `${framePrefix}driver.find_element(By.XPATH, "${escapedDouble}").click()`;
          if (action === 'fill') return `${framePrefix}driver.find_element(By.XPATH, "${escapedDouble}").send_keys("${escText}")`;
          if (action === 'assertVisible') return `${framePrefix}assert driver.find_element(By.XPATH, "${escapedDouble}").is_displayed()`;
          if (action === 'assertText') return `${framePrefix}assert driver.find_element(By.XPATH, "${escapedDouble}").text == "${escTargetText}"`;
          if (action === 'assertChecked') return `${framePrefix}assert driver.find_element(By.XPATH, "${escapedDouble}").is_selected()`;
          if (action === 'assertEnabled') return `${framePrefix}assert driver.find_element(By.XPATH, "${escapedDouble}").is_enabled()`;
          if (action === 'waitFor') return `${framePrefix}WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, "${escapedDouble}")))`;
          if (action === 'getText') return `${framePrefix}text = driver.find_element(By.XPATH, "${escapedDouble}").text`;
          return `${framePrefix}driver.find_element(By.XPATH, "${escapedDouble}").${action}()`;
        }

        case 'selenium-javascript': {
          const framePrefix = inFrame ? `await driver.switchTo().frame(${iframeInfo.switchTarget});\n` : '';
          if (action === 'click') return `${framePrefix}await driver.findElement(By.xpath("${escapedDouble}")).click();`;
          if (action === 'fill') return `${framePrefix}await driver.findElement(By.xpath("${escapedDouble}")).sendKeys("${escText}");`;
          if (action === 'assertVisible') return `${framePrefix}await driver.findElement(By.xpath("${escapedDouble}")).isDisplayed();`;
          if (action === 'assertText') return `${framePrefix}const text = await driver.findElement(By.xpath("${escapedDouble}")).getText();\nexpect(text).toBe("${escTargetText}");`;
          if (action === 'assertChecked') return `${framePrefix}await driver.findElement(By.xpath("${escapedDouble}")).isSelected();`;
          if (action === 'assertEnabled') return `${framePrefix}await driver.findElement(By.xpath("${escapedDouble}")).isEnabled();`;
          if (action === 'waitFor') return `${framePrefix}await driver.wait(until.elementLocated(By.xpath("${escapedDouble}")), 10000);`;
          if (action === 'getText') return `${framePrefix}const text = await driver.findElement(By.xpath("${escapedDouble}")).getText();`;
          return `${framePrefix}await driver.findElement(By.xpath("${escapedDouble}")).${action}();`;
        }

        case 'selenium-csharp': {
          const framePrefix = inFrame ? `driver.SwitchTo().Frame(${iframeInfo.switchTarget});\n` : '';
          if (action === 'click') return `${framePrefix}driver.FindElement(By.XPath("${escapedDouble}")).Click();`;
          if (action === 'fill') return `${framePrefix}driver.FindElement(By.XPath("${escapedDouble}")).SendKeys("${escText}");`;
          if (action === 'assertVisible') return `${framePrefix}Assert.IsTrue(driver.FindElement(By.XPath("${escapedDouble}")).Displayed);`;
          if (action === 'assertText') return `${framePrefix}Assert.AreEqual("${escTargetText}", driver.FindElement(By.XPath("${escapedDouble}")).Text);`;
          if (action === 'assertChecked') return `${framePrefix}Assert.IsTrue(driver.FindElement(By.XPath("${escapedDouble}")).Selected);`;
          if (action === 'assertEnabled') return `${framePrefix}Assert.IsTrue(driver.FindElement(By.XPath("${escapedDouble}")).Enabled);`;
          if (action === 'waitFor') return `${framePrefix}new WebDriverWait(driver, TimeSpan.FromSeconds(10)).Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("${escapedDouble}")));`;
          if (action === 'getText') return `${framePrefix}string text = driver.FindElement(By.XPath("${escapedDouble}")).Text;`;
          return `${framePrefix}driver.FindElement(By.XPath("${escapedDouble}")).${action}();`;
        }

        case 'selenium4-relative': {
          const framePrefix = inFrame ? `driver.switchTo().frame(${iframeInfo.switchTarget});\n` : '';
          if (action === 'click') return `${framePrefix}driver.findElement(${selenium4Target}).click();`;
          if (action === 'fill') return `${framePrefix}driver.findElement(${selenium4Target}).sendKeys("${escText}");`;
          if (action === 'assertVisible') return `${framePrefix}Assert.assertTrue(driver.findElement(${selenium4Target}).isDisplayed());`;
          if (action === 'assertText') return `${framePrefix}Assert.assertEquals(driver.findElement(${selenium4Target}).getText(), "${escTargetText}");`;
          if (action === 'assertChecked') return `${framePrefix}Assert.assertTrue(driver.findElement(${selenium4Target}).isSelected());`;
          if (action === 'assertEnabled') return `${framePrefix}Assert.assertTrue(driver.findElement(${selenium4Target}).isEnabled());`;
          if (action === 'waitFor') return `${framePrefix}new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOf(driver.findElement(${selenium4Target})));`;
          if (action === 'getText') return `${framePrefix}String text = driver.findElement(${selenium4Target}).getText();`;
          return `${framePrefix}driver.findElement(${selenium4Target}).${action}();`;
        }

        case 'cypress':
          if (inFrame) {
            if (action === 'click') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").click();\n});`;
            if (action === 'fill') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").type("${escText}");\n});`;
            if (action === 'assertVisible') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").should('be.visible');\n});`;
            if (action === 'assertText') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").should('have.text', "${escTargetText}");\n});`;
            if (action === 'assertChecked') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").should('be.checked');\n});`;
            if (action === 'assertEnabled') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").should('be.enabled');\n});`;
            if (action === 'waitFor') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").should('exist');\n});`;
            if (action === 'getText') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").invoke('text').then((text) => {\n    console.log(text);\n  });\n});`;
            return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").${action}();\n});`;
          }
          if (action === 'click') return `cy.xpath("${escapedDouble}").click();`;
          if (action === 'fill') return `cy.xpath("${escapedDouble}").type("${escText}");`;
          if (action === 'assertVisible') return `cy.xpath("${escapedDouble}").should('be.visible');`;
          if (action === 'assertText') return `cy.xpath("${escapedDouble}").should('have.text', "${escTargetText}");`;
          if (action === 'assertChecked') return `cy.xpath("${escapedDouble}").should('be.checked');`;
          if (action === 'assertEnabled') return `cy.xpath("${escapedDouble}").should('be.enabled');`;
          if (action === 'waitFor') return `cy.xpath("${escapedDouble}").should('exist');`;
          if (action === 'getText') return `cy.xpath("${escapedDouble}").invoke('text').then((text) => {\n  console.log(text);\n});`;
          return `cy.xpath("${escapedDouble}").${action}();`;

        case 'robot': {
          const framePrefix = inFrame ? `Select Frame    ${iframeInfo.xpath}\n` : '';
          if (action === 'click') return `${framePrefix}Click Element    xpath=${xpath}`;
          if (action === 'fill') return `${framePrefix}Input Text    xpath=${xpath}    ${actualText}`;
          if (action === 'assertVisible') return `${framePrefix}Element Should Be Visible    xpath=${xpath}`;
          if (action === 'assertText') return `${framePrefix}Element Text Should Be    xpath=${xpath}    ${targetText}`;
          if (action === 'assertChecked') return `${framePrefix}Checkbox Should Be Selected    xpath=${xpath}`;
          if (action === 'assertEnabled') return `${framePrefix}Element Should Be Enabled    xpath=${xpath}`;
          if (action === 'waitFor') return `${framePrefix}Wait Until Element Is Visible    xpath=${xpath}`;
          if (action === 'getText') return `${framePrefix}\${text} =    Get Text    xpath=${xpath}`;
          return `${framePrefix}xpath=${xpath}`;
        }

        case 'puppeteer': {
          const pupFrame = inFrame ? `const frameHandle = await page.$("${frameSelDouble}");\nconst frame = await frameHandle.contentFrame();\n` : '';
          const rootTarget = inFrame ? 'frame' : 'page';
          if (action === 'click') return `${pupFrame}await ${rootTarget}.locator("xpath=${escapedDouble}").click();`;
          if (action === 'fill') return `${pupFrame}await ${rootTarget}.locator("xpath=${escapedDouble}").fill("${escText}");`;
          if (action === 'assertVisible') return `${pupFrame}await ${rootTarget}.waitForXPath("${escapedDouble}", { visible: true });`;
          if (action === 'assertText') return `${pupFrame}const el = (await ${rootTarget}.$x("${escapedDouble}"))[0];\nconst text = await (await el?.getProperty('textContent'))?.jsonValue();\nif (text !== "${escTargetText}") throw new Error('Text mismatch');`;
          if (action === 'assertChecked') return `${pupFrame}const isChecked = await (await (await ${rootTarget}.$x("${escapedDouble}"))[0]?.getProperty('checked'))?.jsonValue();`;
          if (action === 'assertEnabled') return `${pupFrame}const isDisabled = await (await (await ${rootTarget}.$x("${escapedDouble}"))[0]?.getProperty('disabled'))?.jsonValue();`;
          if (action === 'waitFor') return `${pupFrame}await ${rootTarget}.waitForSelector("xpath=${escapedDouble}");`;
          if (action === 'getText') return `${pupFrame}const text = await (await (await ${rootTarget}.$x("${escapedDouble}"))[0]?.getProperty('textContent'))?.jsonValue();`;
          return `${pupFrame}await ${rootTarget}.$x("${escapedDouble}");`;
        }

        case 'raw':
        default:
          return xpath;
      }
    }

    /**
     * Generate an action map with all ready-to-use action code snippets
     */
    static generateActionMap(xpath, framework = 'playwright', bestPlaywright = null, bestPlaywrightJava = null, bestRelative = null, sampleText = 'Enter value', iframeInfo = null, exactText = null) {
      return {
        locator: XPathEngine.formatActionCode(xpath, framework, 'locator', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        click: XPathEngine.formatActionCode(xpath, framework, 'click', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        fill: XPathEngine.formatActionCode(xpath, framework, 'fill', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        assertVisible: XPathEngine.formatActionCode(xpath, framework, 'assertVisible', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        assertText: XPathEngine.formatActionCode(xpath, framework, 'assertText', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        assertChecked: XPathEngine.formatActionCode(xpath, framework, 'assertChecked', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        assertEnabled: XPathEngine.formatActionCode(xpath, framework, 'assertEnabled', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        waitFor: XPathEngine.formatActionCode(xpath, framework, 'waitFor', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        getText: XPathEngine.formatActionCode(xpath, framework, 'getText', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText)
      };
    }
  }

  // Export helper functions on XPathEngine for unified safe access
  XPathEngine.safeEscapeCSS = safeEscapeCSS;
  XPathEngine.safeGetAttr = safeGetAttr;
  XPathEngine.safeHasAttr = safeHasAttr;
  XPathEngine.safeGetId = safeGetId;
  XPathEngine.safeGetTagName = safeGetTagName;
  XPathEngine.safeGetText = safeGetText;
  XPathEngine.safeGetChildren = safeGetChildren;
  XPathEngine.safeGetParent = safeGetParent;
  XPathEngine.safeGetOwnerDocument = safeGetOwnerDocument;
  XPathEngine.getElementFillValue = XPathEngine.getElementFillValue;

  // Export to window / global / module
  if (typeof window !== 'undefined') {
    window.XPathEngine = XPathEngine;
  }
  if (typeof globalThis !== 'undefined') {
    globalThis.XPathEngine = XPathEngine;
  }
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = XPathEngine;
  }
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));
