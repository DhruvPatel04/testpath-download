/**
 * TestPath DevTools Studio - Panel Controller Script
 * Manages DevTools inspection, element evaluation, multi-framework generation,
 * flow recording, and saved locators with real-time bi-directional synchronization.
 */

(function () {
  'use strict';

  // Global safety handler: prevent any panel script exception from bubbling to DevTools host
  window.addEventListener('error', function (e) {
    console.warn('TestPath Panel suppressed error:', e ? (e.message || e) : 'unknown');
  });

  // Storage Keys matching extension ecosystem
  const STORAGE_KEY_SAVED = '__xpath_pro_saved_locators__';
  const STORAGE_KEY_DEL_AFTER = '__xpath_pro_del_after_download__';
  const STORAGE_KEY_PREF_FRAMEWORK = '__xpath_pref_framework__';
  const STORAGE_KEY_REC_STATE = '__xpath_pro_recording_state__';
  const STORAGE_KEY_FLOW_STEPS = '__xpath_pro_recorded_flow__';

  // Safe Storage wrapper: works under chrome.storage.local, with localStorage and memory fallback
  const safeStorage = {
    get: function (keys, callback) {
      try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local && typeof chrome.storage.local.get === 'function') {
          chrome.storage.local.get(keys, function (res) {
            if (chrome.runtime && chrome.runtime.lastError) {
              // ignore
            }
            if (callback) callback(res || {});
          });
          return;
        }
      } catch (err) { }

      // Fallback
      var result = {};
      try {
        if (typeof localStorage !== 'undefined') {
          keys.forEach(function (k) {
            var raw = localStorage.getItem(k);
            if (raw !== null) {
              try {
                result[k] = JSON.parse(raw);
              } catch (e) {
                result[k] = raw;
              }
            }
          });
        }
      } catch (e) { }
      if (callback) callback(result);
    },

    set: function (items, callback) {
      try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local && typeof chrome.storage.local.set === 'function') {
          chrome.storage.local.set(items, function () {
            if (callback) callback();
          });
          return;
        }
      } catch (err) { }

      try {
        if (typeof localStorage !== 'undefined') {
          Object.keys(items).forEach(function (k) {
            localStorage.setItem(k, JSON.stringify(items[k]));
          });
        }
      } catch (e) { }
      if (callback) callback();
    }
  };

  /**
   * Standalone Automation Code Formatter
   * Generates production-ready locator and action statements across frameworks.
   */
  function formatForFramework(
    xpath,
    framework,
    bestPlaywright,
    bestPlaywrightJava,
    bestRelative,
    action,
    fillValue,
    iframeInfo,
    exactText
  ) {
    if (!xpath) return '';
    framework = framework || 'playwright';
    action = action || 'locator';
    fillValue = fillValue || 'Enter text';

    const escapedSingle = xpath.replace(/'/g, "\\'");
    const escapedDouble = xpath.replace(/"/g, '\\"');
    const escapedFill = String(fillValue).replace(/'/g, "\\'").replace(/"/g, '\\"');
    const escapedText = exactText ? String(exactText).replace(/'/g, "\\'").replace(/"/g, '\\"') : 'Sample Text';

    const pw = bestPlaywright || `page.locator('${escapedSingle}')`;
    const selJava = `driver.findElement(By.xpath("${escapedDouble}"))`;
    const selPy = `driver.find_element(By.XPATH, "${escapedDouble}")`;
    const selJs = `await driver.findElement(By.xpath('${escapedSingle}'))`;
    const selCs = `driver.FindElement(By.XPath("${escapedDouble}"))`;
    const cyp = `cy.xpath('${escapedSingle}')`;
    const rob = `Click Element    xpath=${xpath}`;
    const pup = `await page.$x('${escapedSingle}')`;

    switch (action) {
      case 'locator':
        if (framework === 'raw') return xpath;
        if (framework === 'css') return xpath.startsWith('/') ? xpath : xpath;
        if (framework === 'playwright') return pw;
        if (framework === 'playwright-python') return pw.replace(/page\.getByRole/g, 'page.get_by_role').replace(/page\.getByTestId/g, 'page.get_by_test_id').replace(/page\.getByText/g, 'page.get_by_text').replace(/page\.getByPlaceholder/g, 'page.get_by_placeholder').replace(/page\.getByLabel/g, 'page.get_by_label');
        if (framework === 'playwright-java') return bestPlaywrightJava || `page.locator("${escapedDouble}")`;
        if (framework === 'playwright-csharp') return pw.replace(/page\./g, 'Page.');
        if (framework === 'selenium-java') return `By.xpath("${escapedDouble}")`;
        if (framework === 'selenium-python') return `By.XPATH, "${escapedDouble}"`;
        if (framework === 'selenium-javascript') return `By.xpath('${escapedSingle}')`;
        if (framework === 'selenium-csharp') return `By.XPath("${escapedDouble}")`;
        if (framework === 'selenium4-relative') return bestRelative || `RelativeLocator.with(By.xpath("${escapedDouble}"))`;
        if (framework === 'cypress') return cyp;
        if (framework === 'robot') return `xpath=${xpath}`;
        if (framework === 'puppeteer') return pup;
        return xpath;

      case 'click':
        if (framework === 'raw') return `// Click: ${xpath}`;
        if (framework === 'css') return `document.querySelector('${escapedSingle}').click()`;
        if (framework === 'playwright') return `await ${pw}.click();`;
        if (framework === 'playwright-python') return `${pw.replace(/page\.getByRole/g, 'page.get_by_role').replace(/page\.getByTestId/g, 'page.get_by_test_id')}.click()`;
        if (framework === 'playwright-java') return `${bestPlaywrightJava || pw}.click();`;
        if (framework === 'playwright-csharp') return `await ${pw.replace(/page\./g, 'Page.')}.ClickAsync();`;
        if (framework === 'selenium-java') return `${selJava}.click();`;
        if (framework === 'selenium-python') return `${selPy}.click()`;
        if (framework === 'selenium-javascript') return `${selJs}.click();`;
        if (framework === 'selenium-csharp') return `${selCs}.Click();`;
        if (framework === 'cypress') return `${cyp}.click();`;
        if (framework === 'robot') return `Click Element    xpath=${xpath}`;
        if (framework === 'puppeteer') return `const [el] = ${pup}; if (el) await el.click();`;
        return `// Click: ${xpath}`;

      case 'fill':
        if (framework === 'raw') return `// Fill: ${xpath} -> "${escapedFill}"`;
        if (framework === 'playwright') return `await ${pw}.fill('${escapedFill}');`;
        if (framework === 'playwright-python') return `${pw.replace(/page\.getByRole/g, 'page.get_by_role').replace(/page\.getByTestId/g, 'page.get_by_test_id')}.fill("${escapedFill}")`;
        if (framework === 'playwright-java') return `${bestPlaywrightJava || pw}.fill("${escapedFill}");`;
        if (framework === 'playwright-csharp') return `await ${pw.replace(/page\./g, 'Page.')}.FillAsync("${escapedFill}");`;
        if (framework === 'selenium-java') return `${selJava}.sendKeys("${escapedFill}");`;
        if (framework === 'selenium-python') return `${selPy}.send_keys("${escapedFill}")`;
        if (framework === 'selenium-javascript') return `${selJs}.sendKeys('${escapedFill}');`;
        if (framework === 'selenium-csharp') return `${selCs}.SendKeys("${escapedFill}");`;
        if (framework === 'cypress') return `${cyp}.type('${escapedFill}');`;
        if (framework === 'robot') return `Input Text    xpath=${xpath}    ${escapedFill}`;
        if (framework === 'puppeteer') return `const [el] = ${pup}; if (el) await el.type('${escapedFill}');`;
        return `// Fill: ${xpath}`;

      case 'assertVisible':
        if (framework === 'playwright') return `await expect(${pw}).toBeVisible();`;
        if (framework === 'playwright-python') return `expect(${pw}).to_be_visible()`;
        if (framework === 'playwright-java') return `assertThat(${bestPlaywrightJava || pw}).isVisible();`;
        if (framework === 'selenium-java') return `assertTrue(${selJava}.isDisplayed());`;
        if (framework === 'selenium-python') return `assert ${selPy}.is_displayed()`;
        if (framework === 'cypress') return `${cyp}.should('be.visible');`;
        return `// Assert visible: ${xpath}`;

      case 'assertText':
        if (framework === 'playwright') return `await expect(${pw}).toHaveText('${escapedText}');`;
        if (framework === 'playwright-python') return `expect(${pw}).to_have_text("${escapedText}")`;
        if (framework === 'playwright-java') return `assertThat(${bestPlaywrightJava || pw}).hasText("${escapedText}");`;
        if (framework === 'selenium-java') return `assertEquals("${escapedText}", ${selJava}.getText());`;
        if (framework === 'selenium-python') return `assert ${selPy}.text == "${escapedText}"`;
        if (framework === 'cypress') return `${cyp}.should('have.text', '${escapedText}');`;
        return `// Assert text: ${xpath}`;

      case 'assertChecked':
        if (framework === 'playwright') return `await expect(${pw}).toBeChecked();`;
        if (framework === 'playwright-python') return `expect(${pw}).to_be_checked()`;
        if (framework === 'selenium-java') return `assertTrue(${selJava}.isSelected());`;
        if (framework === 'selenium-python') return `assert ${selPy}.is_selected()`;
        if (framework === 'cypress') return `${cyp}.should('be.checked');`;
        return `// Assert checked: ${xpath}`;

      case 'assertEnabled':
        if (framework === 'playwright') return `await expect(${pw}).toBeEnabled();`;
        if (framework === 'playwright-python') return `expect(${pw}).to_be_enabled()`;
        if (framework === 'selenium-java') return `assertTrue(${selJava}.isEnabled());`;
        if (framework === 'selenium-python') return `assert ${selPy}.is_enabled()`;
        if (framework === 'cypress') return `${cyp}.should('be.enabled');`;
        return `// Assert enabled: ${xpath}`;

      case 'waitFor':
        if (framework === 'playwright') return `await ${pw}.waitFor({ state: 'visible' });`;
        if (framework === 'playwright-python') return `${pw}.wait_for(state='visible')`;
        if (framework === 'playwright-java') return `${bestPlaywrightJava || pw}.waitFor();`;
        if (framework === 'selenium-java') return `wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("${escapedDouble}")));`;
        if (framework === 'selenium-python') return `wait.until(EC.visibility_of_element_located((By.XPATH, "${escapedDouble}")))`;
        if (framework === 'cypress') return `${cyp}.should('exist');`;
        return `// Wait for ${xpath}`;

      case 'getText':
        if (framework === 'playwright') return `const text = await ${pw}.textContent();`;
        if (framework === 'playwright-python') return `text = ${pw}.text_content()`;
        if (framework === 'playwright-java') return `String text = ${bestPlaywrightJava || pw}.textContent();`;
        if (framework === 'selenium-java') return `String text = ${selJava}.getText();`;
        if (framework === 'selenium-python') return `text = ${selPy}.text`;
        if (framework === 'cypress') return `${cyp}.invoke('text').then((text) => { /* use text */ });`;
        return `// Get text from ${xpath}`;

      default:
        return xpath;
    }
  }

  // State
  let currentAnalysis = null;
  let currentMatrixAttributes = [];
  let currentBreadcrumbs = [];
  let currentFramework = 'playwright';
  let currentAction = 'locator';
  let isRecording = false;
  let recordedSteps = [];
  let evalCurrentIndex = 0;
  let evalTotalMatches = 0;
  let evalDebounceTimer = null;
  let lastEvaluatedQuery = '';
  let lastEvaluatedTag = '';
  let lastEvaluatedText = '';
  let lastEvaluatedTotal = 0;

  // DOM Elements
  const devStatusPill = document.getElementById('devStatusPill');
  const devTargetUrl = document.getElementById('devTargetUrl');
  const btnDevInspect = document.getElementById('btnDevInspect');
  const btnDevFreeze = document.getElementById('btnDevFreeze');
  const btnDevRecord = document.getElementById('btnDevRecord');
  const devRecordBtnText = document.getElementById('devRecordBtnText');
  const btnDevToggleDock = document.getElementById('btnDevToggleDock');
  const btnDevHeaderSave = document.getElementById('btnDevHeaderSave');
  const devHeaderFrameworkSelect = document.getElementById('devHeaderFrameworkSelect');
  const devSettingFrameworkSelect = document.getElementById('devSettingFrameworkSelect');
  const devActionSelect = document.getElementById('devActionSelect');
  const devToast = document.getElementById('devToast');

  // Navigation Tabs & Panes
  const tabs = {
    paneInspect: document.getElementById('tabInspect'),
    paneRecorder: document.getElementById('tabRecorder'),
    paneSaved: document.getElementById('tabSaved'),
    paneSettings: document.getElementById('tabSettings')
  };
  const panes = {
    paneInspect: document.getElementById('paneInspect'),
    paneRecorder: document.getElementById('paneRecorder'),
    paneSaved: document.getElementById('paneSaved'),
    paneSettings: document.getElementById('paneSettings')
  };

  // Top Evaluator elements (integrated at top of paneInspect)
  const devTopEvaluatorCard = document.getElementById('devTopEvaluatorCard');
  const devEvalInput = document.getElementById('devEvalInput');
  const btnDevEvalClear = document.getElementById('btnDevEvalClear');
  const btnDevEvalExecute = document.getElementById('btnDevEvalExecute');
  const btnInspectCurrentMatch = document.getElementById('btnInspectCurrentMatch');
  const btnCopyEvalQuery = document.getElementById('btnCopyEvalQuery');
  const devEvalCountBadge = document.getElementById('devEvalCountBadge');
  const devEvalMatchNav = document.getElementById('devEvalMatchNav');
  const btnEvalPrev = document.getElementById('btnEvalPrev');
  const btnEvalNext = document.getElementById('btnEvalNext');
  const devEvalMatchIndex = document.getElementById('devEvalMatchIndex');
  const btnToggleCheat = document.getElementById('btnToggleCheat');
  const devCheatsheetInline = document.getElementById('devCheatsheetInline');
  const devEvalMatchPreview = document.getElementById('devEvalMatchPreview');
  const devEvalPreviewTag = document.getElementById('devEvalPreviewTag');
  const devEvalPreviewText = document.getElementById('devEvalPreviewText');

  // Breadcrumbs & Welcome State
  const devBreadcrumbsContainer = document.getElementById('devBreadcrumbsContainer');
  const devBreadcrumbPills = document.getElementById('devBreadcrumbPills');
  const devWelcomeState = document.getElementById('devWelcomeState');
  const devInspectorContent = document.getElementById('devInspectorContent');

  // Inspector Content Cards
  const devHeroTag = document.getElementById('devHeroTag');
  const devHeroUniqueness = document.getElementById('devHeroUniqueness');
  const devHeroScore = document.getElementById('devHeroScore');
  const devHeroCode = document.getElementById('devHeroCode');
  const btnCopyHeroCode = document.getElementById('btnCopyHeroCode');
  const btnSaveHeroLocator = document.getElementById('btnSaveHeroLocator');
  const btnTestInEvaluator = document.getElementById('btnTestInEvaluator');

  const devPlaywrightCard = document.getElementById('devPlaywrightCard');
  const devPlaywrightLocatorsList = document.getElementById('devPlaywrightLocatorsList');

  const devAttributeMatrixCard = document.getElementById('devAttributeMatrixCard');
  const devMatrixCountBadge = document.getElementById('devMatrixCountBadge');
  const btnDevMatrixReset = document.getElementById('btnDevMatrixReset');
  const btnDevMatrixClear = document.getElementById('btnDevMatrixClear');
  const devCustomXPathDisplay = document.getElementById('devCustomXPathDisplay');
  const devCustomMatchBadge = document.getElementById('devCustomMatchBadge');
  const btnCopyCustomXPath = document.getElementById('btnCopyCustomXPath');
  const devMatrixChipsGrid = document.getElementById('devMatrixChipsGrid');

  const devRelativeAxesCard = document.getElementById('devRelativeAxesCard');
  const devRelativeList = document.getElementById('devRelativeList');

  const devAlternativesCard = document.getElementById('devAlternativesCard');
  const devAlternativesList = document.getElementById('devAlternativesList');

  // Flow Recorder elements
  const devRecIndicator = document.getElementById('devRecIndicator');
  const devRecStatusTitle = document.getElementById('devRecStatusTitle');
  const devRecStatusSub = document.getElementById('devRecStatusSub');
  const btnDevRecStart = document.getElementById('btnDevRecStart');
  const btnDevRecPause = document.getElementById('btnDevRecPause');
  const btnDevRecStop = document.getElementById('btnDevRecStop');
  const btnDevRecClear = document.getElementById('btnDevRecClear');
  const devRecFrameworkSelect = document.getElementById('devRecFrameworkSelect');
  const btnDevCopyScript = document.getElementById('btnDevCopyScript');
  const btnDevDownloadRecScript = document.getElementById('btnDevDownloadRecScript');
  const btnDevExportJSON = document.getElementById('btnDevExportJSON');
  const btnDevExportCSV = document.getElementById('btnDevExportCSV');
  const devRecStepsList = document.getElementById('devRecStepsList');
  const devGeneratedScriptDisplay = document.getElementById('devGeneratedScriptDisplay');
  const devScriptLangBadge = document.getElementById('devScriptLangBadge');
  const recorderTabBadge = document.getElementById('recorderTabBadge');

  // Saved Locators elements
  const devSavedSearchInput = document.getElementById('devSavedSearchInput');
  const devChkDeleteAfter = document.getElementById('devChkDeleteAfter');
  const devSavedSortSelect = document.getElementById('devSavedSortSelect');
  const btnDevExportSavedScript = document.getElementById('btnDevExportSavedScript');
  const btnDevExportSavedJSON = document.getElementById('btnDevExportSavedJSON');
  const btnDevExportSavedCSV = document.getElementById('btnDevExportSavedCSV');
  const btnDevClearSaved = document.getElementById('btnDevClearSaved');
  const devSavedLocatorsList = document.getElementById('devSavedLocatorsList');
  const savedCountBadge = document.getElementById('savedCountBadge');

  // Helper to get inspected tab ID
  function getTabId() {
    return (typeof chrome !== 'undefined' && chrome && chrome.devtools && chrome.devtools.inspectedWindow)
      ? chrome.devtools.inspectedWindow.tabId
      : null;
  }

  // Send message to active inspected tab with automatic script injection fallback
  function sendTabMessage(message, callback) {
    const tabId = getTabId();
    if (!tabId || tabId < 0) {
      if (callback) callback({ success: false, error: 'No inspected tab' });
      return;
    }
    if (typeof chrome === 'undefined' || !chrome || !chrome.tabs || !chrome.tabs.sendMessage) {
      if (callback) callback({ success: false, error: 'chrome.tabs API unavailable' });
      return;
    }
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime && chrome.runtime.lastError) {
        // If content script wasn't loaded, try injecting it
        if (chrome.scripting && chrome.scripting.executeScript) {
          chrome.scripting.executeScript(
            {
              target: { tabId },
              files: ['scripts/contentScript.js']
            },
            () => {
              if (chrome.runtime && chrome.runtime.lastError) {
                if (callback) callback({ success: false, error: chrome.runtime.lastError.message });
                return;
              }
              setTimeout(() => {
                chrome.tabs.sendMessage(tabId, message, (retryRes) => {
                  if (callback) callback(retryRes || { success: true });
                });
              }, 150);
            }
          );
        } else {
          if (callback) callback({ success: false, error: chrome.runtime.lastError.message });
        }
      } else {
        if (callback) callback(response);
      }
    });
  }

  // Toast notification
  let toastTimer = null;
  function showToast(text, duration = 1800) {
    if (!devToast) return;
    if (toastTimer) clearTimeout(toastTimer);
    devToast.textContent = text;
    devToast.classList.add('visible');
    toastTimer = setTimeout(() => {
      devToast.classList.remove('visible');
    }, duration);
  }

  // Copy text helper with button feedback
  function copyText(text, btn, successLabel = '✓ Copied!') {
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => {
      showToast(successLabel);
      if (btn) {
        const orig = btn.innerHTML;
        btn.classList.add('copied');
        btn.innerHTML = `✓ <span>${successLabel}</span>`;
        setTimeout(() => {
          btn.classList.remove('copied');
          btn.innerHTML = orig;
        }, 1500);
      }
    }).catch(() => {
      // Safe Fallback
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
        showToast(successLabel);
      } catch (err) {
        console.warn('Clipboard fallback copy error:', err);
      }
    });
  }

  // Update URL displayed in header
  function updateInspectedUrl() {
    if (!devTargetUrl) return;
    if (typeof chrome !== 'undefined' && chrome && chrome.devtools && chrome.devtools.inspectedWindow && chrome.devtools.inspectedWindow.eval) {
      chrome.devtools.inspectedWindow.eval('window.location.href', (result, isException) => {
        if (!isException && result) {
          try {
            const urlObj = new URL(result);
            devTargetUrl.textContent = urlObj.hostname || result.slice(0, 35);
            devTargetUrl.title = result;
          } catch (e) {
            devTargetUrl.textContent = result.slice(0, 35);
          }
        } else {
          devTargetUrl.textContent = 'Connected';
        }
      });
    } else {
      devTargetUrl.textContent = 'Ready';
    }
  }

  // ==========================================================================
  // Navigation Tabs Switching
  // ==========================================================================
  const allTabs = document.querySelectorAll('.dev-tab');
  const allPanes = document.querySelectorAll('.dev-pane');

  allTabs.forEach((tabBtn) => {
    tabBtn.addEventListener('click', () => {
      const targetPaneId = tabBtn.getAttribute('data-target');
      if (!targetPaneId) return;

      allTabs.forEach((t) => t.classList.remove('active'));
      allPanes.forEach((p) => {
        p.classList.remove('active');
        p.style.display = 'none';
      });

      tabBtn.classList.add('active');
      const targetPane = document.getElementById(targetPaneId);
      if (targetPane) {
        targetPane.classList.add('active');
        targetPane.style.display = 'flex';
      }

      if (targetPaneId === 'paneRecorder') {
        loadRecordedSteps();
      } else if (targetPaneId === 'paneSaved') {
        loadSavedLocators(renderSavedLocators);
      }
    });
  });

  // ==========================================================================
  // Header Actions
  // ==========================================================================
  if (btnDevInspect) {
    btnDevInspect.addEventListener('click', () => {
      sendTabMessage({ action: 'TOGGLE_INSPECT', fromDevTools: true }, (res) => {
        if (res && res.isInspectMode) {
          showToast('🎯 Inspect active — click any element on the page');
          btnDevInspect.classList.add('inspect-active');
        } else {
          showToast('Inspect deactivated');
          btnDevInspect.classList.remove('inspect-active');
        }
      });
    });
  }

  if (btnDevFreeze) {
    btnDevFreeze.addEventListener('click', () => {
      sendTabMessage({ action: 'START_FREEZE_INSPECT', delay: 3, fromDevTools: true }, () => {
        showToast('❄️ Freeze countdown started (3s)');
      });
    });
  }

  if (btnDevRecord) {
    btnDevRecord.addEventListener('click', () => {
      sendTabMessage({ action: 'TOGGLE_RECORD', fromDevTools: true }, (res) => {
        const rec = res ? res.isRecording : !isRecording;
        updateRecorderUI(rec);
      });
    });
  }

  if (btnDevToggleDock) {
    btnDevToggleDock.addEventListener('click', () => {
      sendTabMessage({ action: 'TOGGLE_PANEL' });
    });
  }

  if (btnDevHeaderSave) {
    btnDevHeaderSave.addEventListener('click', () => {
      handleSaveCurrentPath();
    });
  }

  // ==========================================================================
  // DevTools $0 Synchronous Element Inspector
  // ==========================================================================
  function inspectDevToolsSelectedElement() {
    if (typeof chrome === 'undefined' || !chrome || !chrome.devtools || !chrome.devtools.inspectedWindow || !chrome.devtools.inspectedWindow.eval) return;

    // Use a unique marker attribute to link $0 directly with content script
    const marker = 'tp_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
    const evalCode = `
      (function() {
        if (typeof $0 !== 'undefined' && $0 && $0.nodeType === 1) {
          $0.setAttribute('data-testpath-active', '${marker}');
          return { success: true, tag: $0.tagName.toLowerCase(), id: $0.id || '' };
        }
        return { success: false };
      })();
    `;

    chrome.devtools.inspectedWindow.eval(evalCode, (evalResult, isException) => {
      if (isException || !evalResult || !evalResult.success) {
        return;
      }

      sendTabMessage({ action: 'ANALYZE_DEVTOOLS_ELEMENT', marker }, (res) => {
        if (res && res.success && res.data) {
          displayElementAnalysis(res.data);
        }
      });
    });
  }

  // Listen to Elements panel selection changes ($0 changes)
  if (typeof chrome !== 'undefined' && chrome && chrome.devtools && chrome.devtools.panels && chrome.devtools.panels.elements && chrome.devtools.panels.elements.onSelectionChanged) {
    chrome.devtools.panels.elements.onSelectionChanged.addListener(() => {
      inspectDevToolsSelectedElement();
    });
  }

  // ==========================================================================
  // Display Element Analysis & Populate All Cards
  // ==========================================================================
  function displayElementAnalysis(payload) {
    if (!payload || !payload.analysis) return;
    currentAnalysis = payload.analysis;
    currentMatrixAttributes = payload.matrix || [];
    currentBreadcrumbs = payload.breadcrumbs || [];

    // Switch to Inspector tab if not already there
    if (tabs.paneInspect && !tabs.paneInspect.classList.contains('active')) {
      tabs.paneInspect.click();
    }

    // Hide welcome state, reveal inspector content
    if (devWelcomeState) devWelcomeState.style.display = 'none';
    if (devInspectorContent) devInspectorContent.style.display = 'flex';

    // Populate Top Evaluator input with best selector
    if (devEvalInput && currentAnalysis.best) {
      devEvalInput.value = currentAnalysis.best;
      evaluateQuery(currentAnalysis.best, 0);
    }

    // Render individual components
    renderBreadcrumbs();
    renderHeroCard();
    renderPlaywrightCard();
    renderAttributeMatrix();
    renderRelativeAxes();
    renderAlternativeCandidates();
  }

  // 1. Breadcrumbs Trail
  function renderBreadcrumbs() {
    if (!devBreadcrumbPills) return;
    if (!currentBreadcrumbs || currentBreadcrumbs.length === 0) {
      devBreadcrumbPills.innerHTML = '<span class="dev-bc-empty">No element inspected yet</span>';
      return;
    }

    let html = '';
    currentBreadcrumbs.forEach((crumb, idx) => {
      const isLast = idx === currentBreadcrumbs.length - 1;
      html += `
        <span class="dev-bc-pill ${isLast ? 'active' : ''}" data-bc-idx="${idx}" title="Click to inspect this ancestor">
          ${escapeHTML(crumb.label || crumb.tag || 'elem')}
        </span>
      `;
      if (!isLast) {
        html += `<span class="dev-bc-separator">›</span>`;
      }
    });
    devBreadcrumbPills.innerHTML = html;

    // Attach hover & click listeners
    devBreadcrumbPills.querySelectorAll('.dev-bc-pill').forEach((pill) => {
      const idx = parseInt(pill.getAttribute('data-bc-idx'), 10);
      pill.addEventListener('mouseenter', () => {
        sendTabMessage({ action: 'DEVTOOLS_HIGHLIGHT_BREADCRUMB', index: idx });
      });
      pill.addEventListener('mouseleave', () => {
        sendTabMessage({ action: 'DEVTOOLS_CLEAR_HIGHLIGHT' });
      });
      pill.addEventListener('click', () => {
        sendTabMessage({ action: 'DEVTOOLS_SELECT_BREADCRUMB', index: idx }, (res) => {
          if (res && res.success && res.data) {
            displayElementAnalysis(res.data);
          }
        });
      });
    });
  }

  // 2. Hero Card
  function renderHeroCard() {
    if (!currentAnalysis) return;
    const tag = currentAnalysis.tagName || 'element';
    const id = currentAnalysis.elementInfo && currentAnalysis.elementInfo.id ? '#' + currentAnalysis.elementInfo.id : '';
    if (devHeroTag) devHeroTag.textContent = `<${tag}${id}>`;

    const score = currentAnalysis.score || 100;
    if (devHeroScore) devHeroScore.textContent = `Score: ${score}`;

    // Format action code
    const bestXPath = currentAnalysis.best || '//' + tag;
    const bestPlaywright = currentAnalysis.bestPlaywright || null;
    const bestPlaywrightJava = currentAnalysis.bestPlaywrightJava || null;
    const bestRelative = currentAnalysis.bestRelative || null;
    const fillValue = currentAnalysis.fillValue || 'Enter value';
    const iframeInfo = currentAnalysis.iframeInfo || null;
    const exactText = currentAnalysis.elementInfo && currentAnalysis.elementInfo.innerText ? currentAnalysis.elementInfo.innerText : null;

    const formatted = formatForFramework(
      bestXPath,
      currentFramework,
      bestPlaywright,
      bestPlaywrightJava,
      bestRelative,
      currentAction,
      fillValue,
      iframeInfo,
      exactText
    );
    if (devHeroCode) devHeroCode.textContent = formatted;

    // Uniqueness badge
    if (devHeroUniqueness) {
      devHeroUniqueness.className = 'dev-badge dev-badge-unique';
      devHeroUniqueness.textContent = '✓ 1 match (Unique)';
    }
  }

  // 3. Playwright Modern Card
  function renderPlaywrightCard() {
    if (!currentAnalysis || !devPlaywrightCard || !devPlaywrightLocatorsList) return;
    const pwLocators = currentAnalysis.playwrightLocators || [];
    if (pwLocators.length === 0 && !currentAnalysis.bestPlaywright) {
      devPlaywrightCard.style.display = 'none';
      return;
    }

    devPlaywrightCard.style.display = 'block';
    let html = '';

    // If bestPlaywright is present, ensure it's top of list
    const items = [...pwLocators];
    if (items.length === 0 && currentAnalysis.bestPlaywright) {
      items.push({
        method: 'getBy',
        locator: currentAnalysis.bestPlaywright,
        score: currentAnalysis.score || 100,
        type: 'user-facing'
      });
    }

    items.forEach((item) => {
      const code = item.locator || item.code || '';
      html += `
        <div class="dev-pw-item">
          <div class="dev-pw-item-info">
            <span class="dev-pw-method">${escapeHTML(item.method || item.type || 'locator')}</span>
            <span class="dev-pw-code" title="${escapeHTML(code)}">${escapeHTML(code)}</span>
          </div>
          <button class="dev-btn-copy dev-btn-copy-small btn-copy-item" data-code="${escapeHTML(code)}">Copy</button>
        </div>
      `;
    });
    devPlaywrightLocatorsList.innerHTML = html;

    devPlaywrightLocatorsList.querySelectorAll('.btn-copy-item').forEach((b) => {
      b.addEventListener('click', () => {
        copyText(b.getAttribute('data-code'), b);
      });
    });
  }

  // 4. Attribute Checkbox Matrix
  function renderAttributeMatrix() {
    if (!devMatrixChipsGrid || !currentMatrixAttributes) return;
    if (devMatrixCountBadge) {
      devMatrixCountBadge.textContent = `${currentMatrixAttributes.length} attributes`;
    }

    let html = '';
    currentMatrixAttributes.forEach((item, idx) => {
      const isChecked = Boolean(item.checked);
      html += `
        <label class="dev-matrix-chip ${isChecked ? 'active' : ''}">
          <input type="checkbox" data-matrix-idx="${idx}" ${isChecked ? 'checked' : ''} />
          <span class="chip-name">${escapeHTML(item.attribute || item.category)}:</span>
          <span class="chip-val" title="${escapeHTML(item.value)}">${escapeHTML(item.value)}</span>
        </label>
      `;
    });
    devMatrixChipsGrid.innerHTML = html;

    // Attach checkbox changes
    devMatrixChipsGrid.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
      cb.addEventListener('change', () => {
        const idx = parseInt(cb.getAttribute('data-matrix-idx'), 10);
        if (currentMatrixAttributes[idx]) {
          currentMatrixAttributes[idx].checked = cb.checked;
          const chip = cb.closest('.dev-matrix-chip');
          if (chip) chip.classList.toggle('active', cb.checked);
        }
        updateCustomXPathFromMatrix();
      });
    });

    updateCustomXPathFromMatrix();
  }

  function updateCustomXPathFromMatrix() {
    if (!currentAnalysis || !currentMatrixAttributes) return;
    const tag = currentAnalysis.tagName || 'element';
    const tagItem = currentMatrixAttributes.find((it) => it.category === 'tag');
    const tagChecked = tagItem ? tagItem.checked : true;

    const predicates = [];
    currentMatrixAttributes.forEach((it) => {
      if (it.category !== 'tag' && it.checked && it.predicate) {
        predicates.push(it.predicate);
      }
    });

    let customXPath = '';
    if (tagChecked) {
      customXPath = predicates.length > 0 ? `//${tag}[${predicates.join(' and ')}]` : `//${tag}`;
    } else {
      customXPath = predicates.length > 0 ? `//*[${predicates.join(' and ')}]` : `//*`;
    }

    if (devCustomXPathDisplay) {
      devCustomXPathDisplay.textContent = customXPath;
    }

    // Evaluate live custom xpath against page
    sendTabMessage({ action: 'DEVTOOLS_EVALUATE_CUSTOM_XPATH', xpath: customXPath }, (res) => {
      if (!devCustomMatchBadge) return;
      const count = res && typeof res.count === 'number' ? res.count : 0;
      if (count === 1) {
        devCustomMatchBadge.className = 'dev-badge dev-badge-unique';
        devCustomMatchBadge.textContent = '✓ 1 match (Unique)';
      } else if (count > 1) {
        devCustomMatchBadge.className = 'dev-badge dev-badge-multiple';
        devCustomMatchBadge.textContent = `${count} matches`;
      } else {
        devCustomMatchBadge.className = 'dev-badge dev-badge-none';
        devCustomMatchBadge.textContent = '0 matches';
      }
    });
  }

  // 5. Relative Axes Generator
  function renderRelativeAxes() {
    if (!currentAnalysis || !devRelativeAxesCard || !devRelativeList) return;
    const relatives = currentAnalysis.relativeLocators || [];
    if (relatives.length === 0 && !currentAnalysis.bestRelative) {
      devRelativeAxesCard.style.display = 'none';
      return;
    }

    devRelativeAxesCard.style.display = 'block';
    let html = '';
    const items = [...relatives];
    if (items.length === 0 && currentAnalysis.bestRelative) {
      items.push({
        relationship: 'Parent / Sibling Anchor',
        xpath: currentAnalysis.bestRelative,
        score: 85
      });
    }

    items.forEach((rel) => {
      const code = rel.xpath || rel.locator || '';
      html += `
        <div class="dev-relative-item">
          <div class="dev-rel-info">
            <span class="dev-rel-type">${escapeHTML(rel.relationship || rel.type || 'Relative')}</span>
            <span class="dev-rel-code" title="${escapeHTML(code)}">${escapeHTML(code)}</span>
          </div>
          <button class="dev-btn-copy dev-btn-copy-small btn-copy-item" data-code="${escapeHTML(code)}">Copy</button>
        </div>
      `;
    });
    devRelativeList.innerHTML = html;

    devRelativeList.querySelectorAll('.btn-copy-item').forEach((b) => {
      b.addEventListener('click', () => {
        copyText(b.getAttribute('data-code'), b);
      });
    });
  }


  // 7. Alternative Candidates List
  function renderAlternativeCandidates() {
    if (!currentAnalysis || !devAlternativesList) return;
    const alts = currentAnalysis.alternatives || [];
    if (alts.length === 0) {
      if (devAlternativesCard) devAlternativesCard.style.display = 'none';
      return;
    }

    if (devAlternativesCard) devAlternativesCard.style.display = 'block';
    let html = '';
    alts.forEach((alt) => {
      const xp = alt.xpath || alt.locator || '';
      const sc = alt.score || 50;
      const scBadge = sc >= 85 ? 'badge-high' : sc >= 60 ? 'badge-mid' : 'badge-low';
      html += `
        <div class="dev-alt-row">
          <div class="dev-alt-info">
            <span class="dev-alt-score ${scBadge}">Score ${sc}</span>
            <span class="dev-alt-type">${escapeHTML(alt.type || 'candidate')}</span>
            <span class="dev-alt-code" title="${escapeHTML(xp)}">${escapeHTML(xp)}</span>
          </div>
          <button class="dev-btn-copy dev-btn-copy-small btn-copy-item" data-code="${escapeHTML(xp)}">Copy</button>
        </div>
      `;
    });
    devAlternativesList.innerHTML = html;

    devAlternativesList.querySelectorAll('.btn-copy-item').forEach((b) => {
      b.addEventListener('click', () => {
        copyText(b.getAttribute('data-code'), b);
      });
    });
  }

  // ==========================================================================
  // Hero Card Event Handlers
  // ==========================================================================
  if (devActionSelect) {
    devActionSelect.addEventListener('change', () => {
      currentAction = devActionSelect.value;
      renderHeroCard();
    });
  }

  if (btnCopyHeroCode) {
    btnCopyHeroCode.addEventListener('click', () => {
      const text = devHeroCode ? devHeroCode.textContent : '';
      copyText(text, btnCopyHeroCode, 'Automation Code Copied!');
    });
  }

  // ==========================================================================
  // Save Matched Path / Active Locator Handler
  // ==========================================================================
  function handleSaveCurrentPath() {
    const evalQuery = (devEvalInput ? devEvalInput.value.trim() : '') || (lastEvaluatedQuery || '').trim();

    if (evalQuery) {
      // 1. Save currently matched path from evaluator
      const isXPath = evalQuery.startsWith('/') || evalQuery.startsWith('(');
      const isPW = /^(?:page\.)?getBy(Role|TestId|Label|Placeholder|Text|AltText|Title)\(/i.test(evalQuery);

      let tag = lastEvaluatedTag;
      if (!tag) {
        const mXp = evalQuery.match(/^\/{1,2}([a-zA-Z0-9_-]+)/);
        if (mXp && mXp[1]) {
          tag = mXp[1].toLowerCase();
        } else {
          const mRole = evalQuery.match(/getByRole\(\s*['"]([a-zA-Z0-9_-]+)['"]/i);
          if (mRole && mRole[1]) {
            tag = mRole[1].toLowerCase();
          } else {
            const mCss = evalQuery.match(/^([a-zA-Z0-9_-]+)[.#\[:]/);
            if (mCss && mCss[1]) {
              tag = mCss[1].toLowerCase();
            } else if (currentAnalysis && currentAnalysis.tagName) {
              tag = currentAnalysis.tagName;
            } else {
              tag = 'element';
            }
          }
        }
      }

      const elemText = lastEvaluatedText || (currentAnalysis && currentAnalysis.elementInfo ? (currentAnalysis.elementInfo.innerText || currentAnalysis.elementInfo.text || '') : '');
      const name = elemText
        ? elemText.trim().slice(0, 30)
        : (tag !== 'element' ? tag : evalQuery.slice(0, 30));

      let locator = evalQuery;
      let xpath = isXPath ? evalQuery : (currentAnalysis ? currentAnalysis.best : '');
      let bestXPath = xpath || (isXPath ? evalQuery : '');
      let bestPlaywright = '';

      if (isPW) {
        bestPlaywright = evalQuery.startsWith('page.') ? evalQuery : 'page.' + evalQuery;
        locator = bestPlaywright;
      } else if (isXPath) {
        locator = evalQuery;
        bestPlaywright = (currentAnalysis && currentAnalysis.bestPlaywright)
          ? currentAnalysis.bestPlaywright
          : `page.locator('${evalQuery.replace(/'/g, "\\'")}')`;
      } else {
        locator = evalQuery;
        bestPlaywright = `page.locator('${evalQuery.replace(/'/g, "\\'")}')`;
      }

      const actionCode = formatForFramework(
        xpath || evalQuery,
        currentFramework,
        bestPlaywright,
        currentAnalysis ? currentAnalysis.bestPlaywrightJava : null,
        currentAnalysis ? currentAnalysis.bestRelative : null,
        currentAction,
        'Enter value',
        currentAnalysis ? currentAnalysis.iframeInfo : null,
        elemText
      );

      let pageTitle = '';
      let pageUrl = '';
      if (devTargetUrl) {
        pageTitle = devTargetUrl.textContent || '';
        pageUrl = devTargetUrl.title || '';
      }

      const item = {
        id: 'loc_' + Date.now(),
        name: name,
        tag: tag,
        tagName: tag,
        text: elemText,
        locator: locator,
        xpath: xpath || evalQuery,
        bestXPath: bestXPath || evalQuery,
        bestPlaywright: bestPlaywright,
        bestPlaywrightJava: (currentAnalysis && currentAnalysis.bestPlaywrightJava) || '',
        actionCode: actionCode,
        action: currentAction || (currentAnalysis && currentAnalysis.defaultAction) || 'click',
        pageTitle: pageTitle,
        pageUrl: pageUrl,
        timestamp: Date.now()
      };

      saveLocatorToStorage(item);
      return;
    }

    // 2. Fallback to inspected element if evaluator is empty
    if (currentAnalysis) {
      const tag = currentAnalysis.tagName || 'element';
      const name = (currentAnalysis.elementInfo && currentAnalysis.elementInfo.innerText)
        ? currentAnalysis.elementInfo.innerText.trim().slice(0, 30)
        : (currentAnalysis.elementInfo && currentAnalysis.elementInfo.id)
          ? currentAnalysis.elementInfo.id
          : tag;

      const elemText = currentAnalysis.elementInfo ? (currentAnalysis.elementInfo.text || currentAnalysis.elementInfo.innerText || '') : '';
      const item = {
        id: 'loc_' + Date.now(),
        name: name,
        tag: tag,
        tagName: tag,
        text: elemText,
        locator: currentAnalysis.bestPlaywright || currentAnalysis.best || '//' + tag,
        xpath: currentAnalysis.best || '//' + tag,
        bestXPath: currentAnalysis.best || '//' + tag,
        bestPlaywright: currentAnalysis.bestPlaywright || '',
        bestPlaywrightJava: currentAnalysis.bestPlaywrightJava || '',
        actionCode: devHeroCode ? devHeroCode.textContent : '',
        action: currentAnalysis.defaultAction || currentAction || 'click',
        pageTitle: devTargetUrl ? (devTargetUrl.textContent || '') : '',
        pageUrl: devTargetUrl ? (devTargetUrl.title || '') : '',
        timestamp: Date.now()
      };
      saveLocatorToStorage(item);
      return;
    }

    // 3. Neither present
    showToast('⚠️ No matched path or element to save');
  }

  if (btnSaveHeroLocator) {
    btnSaveHeroLocator.addEventListener('click', () => {
      handleSaveCurrentPath();
    });
  }

  if (btnTestInEvaluator) {
    btnTestInEvaluator.addEventListener('click', () => {
      if (!currentAnalysis || !devEvalInput) return;
      const query = currentAnalysis.bestPlaywright || currentAnalysis.best || '';
      devEvalInput.value = query;
      evaluateQuery(query, 0);
      devTopEvaluatorCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
      devEvalInput.focus();
    });
  }

  if (btnDevMatrixReset) {
    btnDevMatrixReset.addEventListener('click', () => {
      if (!currentMatrixAttributes) return;
      currentMatrixAttributes.forEach((item) => {
        item.checked = item.initialChecked !== undefined ? item.initialChecked : true;
      });
      renderAttributeMatrix();
    });
  }

  if (btnDevMatrixClear) {
    btnDevMatrixClear.addEventListener('click', () => {
      if (!currentMatrixAttributes) return;
      currentMatrixAttributes.forEach((item) => {
        item.checked = item.category === 'tag';
      });
      renderAttributeMatrix();
    });
  }

  if (btnCopyCustomXPath) {
    btnCopyCustomXPath.addEventListener('click', () => {
      const text = devCustomXPathDisplay ? devCustomXPathDisplay.textContent : '';
      copyText(text, btnCopyCustomXPath, 'Custom XPath Copied!');
    });
  }

  // ==========================================================================
  // Top Live Evaluator Controller
  // ==========================================================================
  function evaluateQuery(query, matchIndex = 0) {
    query = (query || '').trim();
    lastEvaluatedQuery = query;
    if (!query) {
      lastEvaluatedTag = '';
      lastEvaluatedText = '';
      lastEvaluatedTotal = 0;
      if (devEvalCountBadge) {
        devEvalCountBadge.className = 'dev-badge dev-badge-unique';
        devEvalCountBadge.textContent = 'Ready';
      }
      if (devEvalMatchNav) devEvalMatchNav.style.display = 'none';
      if (devEvalMatchPreview) devEvalMatchPreview.style.display = 'none';
      if (btnInspectCurrentMatch) btnInspectCurrentMatch.style.display = 'none';
      sendTabMessage({ action: 'DEVTOOLS_CLEAR_HIGHLIGHT' });
      return;
    }

    sendTabMessage({ action: 'DEVTOOLS_EVALUATE_QUERY', query, matchIndex }, (res) => {
      if (!res || !res.success) {
        lastEvaluatedTag = '';
        lastEvaluatedText = '';
        lastEvaluatedTotal = 0;
        if (devEvalCountBadge) {
          devEvalCountBadge.className = 'dev-badge dev-badge-none';
          devEvalCountBadge.textContent = 'Invalid Syntax';
        }
        if (devEvalMatchNav) devEvalMatchNav.style.display = 'none';
        if (devEvalMatchPreview) devEvalMatchPreview.style.display = 'none';
        if (btnInspectCurrentMatch) btnInspectCurrentMatch.style.display = 'none';
        return;
      }

      evalTotalMatches = res.total || 0;
      evalCurrentIndex = res.index !== undefined ? res.index : 0;
      lastEvaluatedTotal = evalTotalMatches;

      if (evalTotalMatches > 0 && res.tag) {
        lastEvaluatedTag = res.tag || '';
        lastEvaluatedText = res.text || '';
      } else {
        lastEvaluatedTag = '';
        lastEvaluatedText = '';
      }

      if (evalTotalMatches === 1) {
        if (devEvalCountBadge) {
          devEvalCountBadge.className = 'dev-badge dev-badge-unique';
          devEvalCountBadge.textContent = '✓ 1 match (Unique)';
        }
        if (devEvalMatchNav) devEvalMatchNav.style.display = 'none';
      } else if (evalTotalMatches > 1) {
        if (devEvalCountBadge) {
          devEvalCountBadge.className = 'dev-badge dev-badge-multiple';
          devEvalCountBadge.textContent = `${evalTotalMatches} matches`;
        }
        if (devEvalMatchNav) devEvalMatchNav.style.display = 'flex';
        if (devEvalMatchIndex) {
          devEvalMatchIndex.textContent = `${evalCurrentIndex + 1} of ${evalTotalMatches}`;
        }
      } else {
        if (devEvalCountBadge) {
          devEvalCountBadge.className = 'dev-badge dev-badge-none';
          devEvalCountBadge.textContent = '0 matches';
        }
        if (devEvalMatchNav) devEvalMatchNav.style.display = 'none';
      }

      // Preview banner & Inspect Match button
      if (evalTotalMatches > 0 && res.tag) {
        if (devEvalMatchPreview) {
          devEvalMatchPreview.style.display = 'flex';
          if (devEvalPreviewTag) devEvalPreviewTag.textContent = `<${res.tag}>`;
          if (devEvalPreviewText) devEvalPreviewText.textContent = res.text ? `"${res.text}"` : '';
        }
        if (btnInspectCurrentMatch) btnInspectCurrentMatch.style.display = 'inline-flex';
      } else {
        if (devEvalMatchPreview) devEvalMatchPreview.style.display = 'none';
        if (btnInspectCurrentMatch) btnInspectCurrentMatch.style.display = 'none';
      }
    });
  }

  if (devEvalInput) {
    devEvalInput.addEventListener('input', () => {
      if (evalDebounceTimer) clearTimeout(evalDebounceTimer);
      evalDebounceTimer = setTimeout(() => {
        evaluateQuery(devEvalInput.value, 0);
      }, 180);
    });

    devEvalInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        if (e.shiftKey) {
          cycleEvalMatch(-1);
        } else if (evalTotalMatches > 1) {
          cycleEvalMatch(1);
        } else {
          evaluateQuery(devEvalInput.value, 0);
        }
      }
    });
  }

  if (btnDevEvalClear) {
    btnDevEvalClear.addEventListener('click', () => {
      if (devEvalInput) {
        devEvalInput.value = '';
        devEvalInput.focus();
      }
      evaluateQuery('', 0);
    });
  }

  if (btnDevEvalExecute) {
    btnDevEvalExecute.addEventListener('click', () => {
      if (devEvalInput) evaluateQuery(devEvalInput.value, 0);
    });
  }

  if (btnCopyEvalQuery) {
    btnCopyEvalQuery.addEventListener('click', () => {
      const q = devEvalInput ? devEvalInput.value : '';
      copyText(q, btnCopyEvalQuery, 'Query Copied!');
    });
  }

  if (btnToggleCheat) {
    btnToggleCheat.addEventListener('click', () => {
      if (!devCheatsheetInline) return;
      const isVisible = devCheatsheetInline.style.display === 'flex';
      devCheatsheetInline.style.display = isVisible ? 'none' : 'flex';
    });
  }

  function cycleEvalMatch(delta) {
    if (evalTotalMatches <= 1) return;
    const nextIdx = (evalCurrentIndex + delta + evalTotalMatches) % evalTotalMatches;
    evaluateQuery(devEvalInput ? devEvalInput.value : '', nextIdx);
  }

  if (btnEvalPrev) {
    btnEvalPrev.addEventListener('click', () => cycleEvalMatch(-1));
  }
  if (btnEvalNext) {
    btnEvalNext.addEventListener('click', () => cycleEvalMatch(1));
  }

  if (btnInspectCurrentMatch) {
    btnInspectCurrentMatch.addEventListener('click', () => {
      sendTabMessage({ action: 'DEVTOOLS_SELECT_CURRENT_MATCH', index: evalCurrentIndex }, (res) => {
        if (res && res.success && res.data) {
          displayElementAnalysis(res.data);
          showToast('🎯 Match analyzed');
        }
      });
    });
  }

  // ==========================================================================
  // Flow Recorder Management & Script Generator
  // ==========================================================================
  function updateRecorderUI(recState) {
    let rec = false;
    let paused = false;

    if (typeof recState === 'boolean') {
      rec = recState;
    } else if (recState && typeof recState === 'object') {
      rec = Boolean(recState.isRecording);
      paused = Boolean(recState.isPaused);
    }

    isRecording = rec;

    if (recorderTabBadge) {
      recorderTabBadge.style.display = isRecording ? 'inline-block' : 'none';
      if (paused) {
        recorderTabBadge.textContent = 'PAUSED';
      } else {
        recorderTabBadge.textContent = 'REC';
      }
    }
    if (btnDevRecord) {
      btnDevRecord.classList.toggle('recording', isRecording);
    }
    if (devRecordBtnText) {
      devRecordBtnText.textContent = isRecording ? '⏹️ Stop' : '🔴 Record';
    }

    if (devRecIndicator) {
      devRecIndicator.className = isRecording
        ? (paused ? 'dev-rec-indicator paused' : 'dev-rec-indicator recording')
        : 'dev-rec-indicator idle';
    }
    if (devRecStatusTitle) {
      devRecStatusTitle.textContent = isRecording
        ? (paused ? 'Recording Paused' : 'Recording User Flow...')
        : 'Test Flow Recorder';
    }
    if (devRecStatusSub) {
      devRecStatusSub.textContent = isRecording
        ? (paused ? 'Recording is paused. Click Resume to continue capturing interactions.' : 'Interact with buttons, inputs, and links on the page. Steps appear below in real time.')
        : 'Record user interactions on the page and export full automation scripts';
    }

    if (btnDevRecStart) btnDevRecStart.style.display = isRecording ? 'none' : 'inline-flex';
    if (btnDevRecPause) {
      btnDevRecPause.style.display = isRecording ? 'inline-flex' : 'none';
      btnDevRecPause.textContent = paused ? '▶️ Resume' : '⏸️ Pause';
    }
    if (btnDevRecStop) btnDevRecStop.style.display = isRecording ? 'inline-flex' : 'none';
  }

  function loadRecordedSteps(callback) {
    safeStorage.get([STORAGE_KEY_FLOW_STEPS], (res) => {
      const steps = (res && Array.isArray(res[STORAGE_KEY_FLOW_STEPS])) ? res[STORAGE_KEY_FLOW_STEPS] : [];
      renderRecordedSteps(steps);
      if (callback) callback(steps);
    });
  }

  function renderRecordedSteps(steps) {
    recordedSteps = Array.isArray(steps) ? steps : [];
    if (!devRecStepsList) return;

    if (recordedSteps.length === 0) {
      devRecStepsList.innerHTML = '<div class="dev-rec-empty">No steps recorded yet. Click "Start Recording" or press <kbd>Alt+Shift+R</kbd>!</div>';
      if (devGeneratedScriptDisplay) {
        devGeneratedScriptDisplay.textContent = '// Generated test script will appear here once steps are recorded';
      }
      return;
    }

    let html = '';
    recordedSteps.forEach((st, idx) => {
      const act = (st.action || 'click').toLowerCase();
      let actBadgeClass = 'act-click';
      let actIcon = '🖱️';
      if (act === 'fill') { actBadgeClass = 'act-fill'; actIcon = '⌨️'; }
      else if (act === 'check' || act === 'uncheck') { actBadgeClass = 'act-check'; actIcon = '☑️'; }
      else if (act === 'select') { actBadgeClass = 'act-select'; actIcon = '🔽'; }
      else if (act.startsWith('wait')) { actBadgeClass = 'act-wait'; actIcon = '⏳'; }
      else if (act.startsWith('assert')) { actBadgeClass = 'act-assert'; actIcon = '👁️'; }

      const tag = st.tagName || st.target || st.tag || 'element';
      const textDesc = st.text ? ` "${st.text}"` : (st.value && act === 'fill' ? ` [val: "${st.value}"]` : '');
      const targetDisplay = `<${tag}>${textDesc}`;

      const locatorDisplay = st.bestPlaywright || st.bestXPath || st.cssSelector || st.locator || (st.value ? `value="${st.value}"` : '');
      const stepCode = st.bestPlaywright || st.bestXPath || st.cssSelector || '';

      html += `
        <div class="dev-rec-step-row" data-step-id="${st.id || idx}">
          <span class="col-step">${idx + 1}</span>
          <span class="col-action">
            <span class="dev-act-badge ${actBadgeClass}">${actIcon} ${act}</span>
          </span>
          <span class="col-target" title="${escapeHTML(targetDisplay)}">${escapeHTML(targetDisplay)}</span>
          <span class="col-locator" title="${escapeHTML(locatorDisplay)}">
            <code>${escapeHTML(locatorDisplay)}</code>
            <div class="step-actions">
              <button class="dev-btn-xs btn-copy-step" data-code="${escapeHTML(stepCode)}" title="Copy locator">📋</button>
              <button class="dev-btn-xs btn-del-step" data-step-idx="${idx}" title="Delete step">✕</button>
            </div>
          </span>
        </div>
      `;
    });
    devRecStepsList.innerHTML = html;

    // Attach copy listeners
    devRecStepsList.querySelectorAll('.btn-copy-step').forEach((b) => {
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        copyText(b.getAttribute('data-code'), b, 'Step locator copied!');
      });
    });

    // Attach delete listeners
    devRecStepsList.querySelectorAll('.btn-del-step').forEach((b) => {
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        const stepIdx = parseInt(b.getAttribute('data-step-idx'), 10);
        deleteRecordedStep(stepIdx);
      });
    });

    // Generate script preview
    generateScriptPreview();
  }

  function deleteRecordedStep(index) {
    if (index >= 0 && index < recordedSteps.length) {
      recordedSteps.splice(index, 1);
      safeStorage.set({ [STORAGE_KEY_FLOW_STEPS]: recordedSteps }, () => {
        renderRecordedSteps(recordedSteps);
        showToast('Step removed');
      });
    }
  }

  function getInspectedWindowUrl(callback) {
    if (typeof chrome !== 'undefined' && chrome.devtools && chrome.devtools.inspectedWindow && chrome.devtools.inspectedWindow.eval) {
      chrome.devtools.inspectedWindow.eval('window.location.href', (result, isException) => {
        if (!isException && result && typeof result === 'string' && result.startsWith('http')) {
          callback(result);
          return;
        }
        queryDevTabUrl(callback);
      });
      return;
    }
    queryDevTabUrl(callback);
  }

  function queryDevTabUrl(callback) {
    if (devTargetUrl && devTargetUrl.title && devTargetUrl.title.startsWith('http')) {
      callback(devTargetUrl.title);
      return;
    }
    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0] && tabs[0].url && tabs[0].url.startsWith('http')) {
          callback(tabs[0].url);
        } else {
          callback(null);
        }
      });
      return;
    }
    callback(null);
  }

  function generateScriptPreview() {
    const fw = devRecFrameworkSelect ? devRecFrameworkSelect.value : 'playwright';
    getInspectedWindowUrl((liveUrl) => {
      const script = buildRunnableTestScript(recordedSteps, fw, liveUrl);
      if (devGeneratedScriptDisplay) devGeneratedScriptDisplay.textContent = script;
      if (devScriptLangBadge) {
        devScriptLangBadge.textContent = fw.startsWith('playwright')
          ? (fw.includes('python') ? 'test_recorded_flow.py' : fw.includes('java') ? 'RecordedFlowTest.java' : 'recorded_flow.spec.js')
          : fw.includes('python') ? 'test_recorded_flow.py' : fw.includes('java') ? 'RecordedFlowTest.java' : 'recorded_flow.cy.js';
      }
    });
  }

  function buildRunnableTestScript(steps, framework, pageUrl) {
    if (!pageUrl && devTargetUrl && devTargetUrl.title && devTargetUrl.title.startsWith('http')) {
      pageUrl = devTargetUrl.title.trim();
    }
    if (typeof globalThis.TestPathShared !== 'undefined' && typeof globalThis.TestPathShared.buildRunnableTestScript === 'function') {
      return globalThis.TestPathShared.buildRunnableTestScript(steps, framework, pageUrl);
    }
    if (typeof globalThis.buildRunnableTestScript === 'function' && globalThis.buildRunnableTestScript !== buildRunnableTestScript) {
      return globalThis.buildRunnableTestScript(steps, framework, pageUrl);
    }
    return '// Test script generation helper loaded from scripts/shared.js';
  }

  // Recorder Button Handlers
  if (btnDevRecStart) {
    btnDevRecStart.addEventListener('click', () => {
      sendTabMessage({ action: 'START_RECORD', fromDevTools: true }, () => {
        updateRecorderUI(true);
        showToast('🔴 Recording Started');
      });
    });
  }

  if (btnDevRecPause) {
    btnDevRecPause.addEventListener('click', () => {
      sendTabMessage({ action: 'TOGGLE_RECORD_PAUSE', fromDevTools: true }, (res) => {
        const isPaused = res && res.isPaused;
        btnDevRecPause.textContent = isPaused ? '▶️ Resume' : '⏸️ Pause';
        showToast(isPaused ? '⏸️ Recording Paused' : '▶️ Recording Resumed');
      });
    });
  }

  if (btnDevRecStop) {
    btnDevRecStop.addEventListener('click', () => {
      sendTabMessage({ action: 'STOP_RECORD', fromDevTools: true }, () => {
        updateRecorderUI(false);
        showToast('⏹️ Recording Stopped');
      });
    });
  }

  if (btnDevRecClear) {
    btnDevRecClear.addEventListener('click', () => {
      safeStorage.set({ [STORAGE_KEY_FLOW_STEPS]: [] }, () => {
        sendTabMessage({ action: 'CLEAR_RECORD_STEPS' });
        renderRecordedSteps([]);
        showToast('Cleared recorded steps');
      });
    });
  }

  if (devRecFrameworkSelect) {
    devRecFrameworkSelect.addEventListener('change', () => {
      generateScriptPreview();
    });
  }

  if (btnDevCopyScript) {
    btnDevCopyScript.addEventListener('click', () => {
      const text = devGeneratedScriptDisplay ? devGeneratedScriptDisplay.textContent : '';
      copyText(text, btnDevCopyScript, 'Test script copied!');
    });
  }

  if (btnDevDownloadRecScript) {
    btnDevDownloadRecScript.addEventListener('click', () => {
      if (!recordedSteps || recordedSteps.length === 0) {
        showToast('No recorded steps to export!');
        return;
      }
      const fw = devRecFrameworkSelect ? devRecFrameworkSelect.value : 'playwright';
      getInspectedWindowUrl((liveUrl) => {
        const script = buildRunnableTestScript(recordedSteps, fw, liveUrl);
        const extMap = {
          'playwright': 'recorded_flow.spec.js',
          'playwright-python': 'test_recorded_flow.py',
          'playwright-java': 'RecordedFlowTest.java',
          'playwright-csharp': 'RecordedFlowTest.cs',
          'selenium-java': 'RecordedFlowTest.java',
          'selenium-python': 'test_recorded_flow.py',
          'selenium-javascript': 'recorded_flow.js',
          'selenium-csharp': 'RecordedFlowTest.cs',
          'cypress': 'recorded_flow.cy.js',
          'robot': 'recorded_flow.robot',
          'puppeteer': 'recorded_flow.spec.js'
        };
        const filename = extMap[fw] || 'recorded_flow.spec.js';
        downloadFile(script, filename, 'application/octet-stream');
        showToast('⬇️ Test script downloaded!');
      });
    });
  }

  if (btnDevExportJSON) {
    btnDevExportJSON.addEventListener('click', () => {
      downloadFile(JSON.stringify(recordedSteps, null, 2), 'testpath_recorded_flow.json', 'application/json');
    });
  }

  if (btnDevExportCSV) {
    btnDevExportCSV.addEventListener('click', () => {
      let csv = 'Step,Action,Target,Locator,Value\n';
      recordedSteps.forEach((s, i) => {
        const loc = s.bestPlaywright || s.bestXPath || s.cssSelector || s.locator || '';
        const target = s.tagName || s.target || s.tag || 'element';
        csv += `${i + 1},"${s.action || 'click'}","${target}","${loc.replace(/"/g, '""')}","${(s.value || '').replace(/"/g, '""')}"\n`;
      });
      downloadFile(csv, 'testpath_recorded_flow.csv', 'text/csv');
    });
  }

  // ==========================================================================
  // Saved Locators Management
  // ==========================================================================

  function loadSavedLocators(callback) {
    safeStorage.get([STORAGE_KEY_SAVED], (res) => {
      const list = res && Array.isArray(res[STORAGE_KEY_SAVED]) ? res[STORAGE_KEY_SAVED] : [];
      if (callback) callback(list);
    });
  }

  function saveLocatorToStorage(locatorItem) {
    loadSavedLocators((list) => {
      const updated = [...list, locatorItem];
      safeStorage.set({ [STORAGE_KEY_SAVED]: updated }, () => {
        renderSavedLocators(updated);
        showToast('⭐ Locator saved!');
      });
    });
  }

  function renderSavedLocators(items) {
    if (!devSavedLocatorsList) return;
    const filter = devSavedSearchInput ? devSavedSearchInput.value.toLowerCase().trim() : '';
    let filtered = items.filter((it) => {
      if (!filter) return true;
      const str = `${it.name || ''} ${it.tag || ''} ${it.tagName || ''} ${it.locator || ''} ${it.xpath || ''} ${it.bestXPath || ''} ${it.actionCode || ''} ${it.pageTitle || ''}`.toLowerCase();
      return str.includes(filter);
    });

    const sortOrder = devSavedSortSelect ? devSavedSortSelect.value : 'step-asc';
    if (sortOrder === 'newest-desc') {
      filtered = [...filtered].reverse();
    }

    if (savedCountBadge) {
      savedCountBadge.textContent = String(items.length);
      savedCountBadge.style.display = items.length > 0 ? 'inline-block' : 'none';
    }

    if (filtered.length === 0) {
      devSavedLocatorsList.innerHTML = '<div class="dev-saved-empty">No saved locators yet. Inspect elements and click ⭐ Save to store them!</div>';
      return;
    }

    function timeAgo(ts) {
      if (!ts) return '';
      try {
        const diff = Date.now() - new Date(ts).getTime();
        const m = Math.floor(diff / 60000);
        if (m < 1) return 'just now';
        if (m < 60) return `${m}m ago`;
        const h = Math.floor(m / 60);
        if (h < 24) return `${h}h ago`;
        return `${Math.floor(h / 24)}d ago`;
      } catch (e) { return ''; }
    }

    let html = '';
    filtered.forEach((it, idx) => {
      const stepNum = idx + 1;
      const tag = it.tagName || it.tag || 'elem';
      const xpath = it.bestXPath || it.xpath || it.locator || '';
      const actionCode = it.actionCode || '';
      const pw = it.bestPlaywright || '';
      const ts = timeAgo(it.timestamp);
      const action = it.action || 'locator';

      // Action badge
      const actionIcons = { click: '⚡', fill: '✏️', assertVisible: '👁️', waitFor: '⏳', getText: '📄', locator: '🎯' };
      const ico = actionIcons[action] || '🎯';
      const actionLabel = action === 'locator' ? 'LOCATOR' : action.toUpperCase();
      const actionClass = `dev-sl-action-badge dev-sl-action-${escapeHTML(action)}`;

      html += `
        <div class="dev-sl-card" data-id="${it.id || idx}">
          <div class="dev-sl-top">
            <span class="dev-sl-step">#${stepNum}</span>
            <span class="dev-sl-tag">&lt;${escapeHTML(tag)}&gt;</span>
            <span class="${actionClass}">${ico} ${actionLabel}</span>
            <span class="dev-sl-title" title="${escapeHTML(it.text || tag)}">${escapeHTML(it.text || tag)}</span>
            <button class="dev-sl-del btn-del-saved" data-id="${it.id || idx}" title="Delete">✕</button>
          </div>

          ${actionCode ? `
          <div class="dev-sl-code-row dev-sl-action-row">
            <span class="dev-sl-badge dev-sl-badge-act">ACTION (CODE)</span>
            <span class="dev-sl-code-text dev-sl-code-amber" title="${escapeHTML(actionCode)}">${escapeHTML(actionCode)}</span>
            <button class="dev-sl-copy-btn btn-copy-saved" data-code="${escapeHTML(actionCode)}" title="Copy Action Code">Copy Action</button>
          </div>
          ` : ''}

          ${xpath ? `
          <div class="dev-sl-code-row">
            <span class="dev-sl-badge dev-sl-badge-xp">XPATH</span>
            <span class="dev-sl-code-text" title="${escapeHTML(xpath)}">${escapeHTML(xpath)}</span>
            <button class="dev-sl-copy-btn btn-copy-saved" data-code="${escapeHTML(xpath)}">Copy</button>
          </div>
          ` : ''}

          ${pw ? `
          <div class="dev-sl-code-row">
            <span class="dev-sl-badge dev-sl-badge-pw">PW</span>
            <span class="dev-sl-code-text dev-sl-code-pw" title="${escapeHTML(pw)}">${escapeHTML(pw)}</span>
            <button class="dev-sl-copy-btn btn-copy-saved" data-code="${escapeHTML(pw)}">Copy</button>
          </div>
          ` : ''}

          <div class="dev-sl-footer">
            <span class="dev-sl-time">${ts}</span>
            ${it.pageTitle ? `<span class="dev-sl-page" title="${escapeHTML(it.pageUrl || '')}">📄 ${escapeHTML(it.pageTitle.slice(0, 30))}</span>` : ''}
            <button class="dev-sl-test-btn btn-test-saved" data-xpath="${escapeHTML(xpath)}" title="Highlight this element on the page">🔍 Test on Page</button>
          </div>
        </div>
      `;
    });
    devSavedLocatorsList.innerHTML = html;

    // Attach copy listeners
    devSavedLocatorsList.querySelectorAll('.btn-copy-saved').forEach((b) => {
      b.addEventListener('click', () => {
        copyText(b.getAttribute('data-code'), b, 'Copied!');
      });
    });

    // Attach delete listeners
    devSavedLocatorsList.querySelectorAll('.btn-del-saved').forEach((b) => {
      b.addEventListener('click', () => {
        const id = b.getAttribute('data-id');
        deleteSavedLocator(id);
      });
    });

    // Attach "Test on Page" listeners
    devSavedLocatorsList.querySelectorAll('.btn-test-saved').forEach((b) => {
      b.addEventListener('click', () => {
        const xpath = b.getAttribute('data-xpath');
        if (xpath) {
          sendTabMessage({ action: 'DEVTOOLS_EVALUATE_QUERY', query: xpath, matchIndex: 0 }, () => { });
          showToast('🔍 Highlighted on page');
        }
      });
    });
  }

  function deleteSavedLocator(id) {
    loadSavedLocators((list) => {
      const updated = list.filter((it, idx) => (it.id ? it.id !== id : String(idx) !== id));
      safeStorage.set({ [STORAGE_KEY_SAVED]: updated }, () => {
        renderSavedLocators(updated);
        showToast('Locator deleted');
      });
    });
  }

  if (devSavedSearchInput) {
    devSavedSearchInput.addEventListener('input', () => {
      loadSavedLocators(renderSavedLocators);
    });
  }

  if (devSavedSortSelect) {
    devSavedSortSelect.addEventListener('change', () => {
      loadSavedLocators(renderSavedLocators);
    });
  }

  if (btnDevClearSaved) {
    btnDevClearSaved.addEventListener('click', () => {
      safeStorage.set({ [STORAGE_KEY_SAVED]: [] }, () => {
        renderSavedLocators([]);
        showToast('Cleared all saved locators');
      });
    });
  }

  if (btnDevExportSavedJSON) {
    btnDevExportSavedJSON.addEventListener('click', () => {
      loadSavedLocators((list) => {
        downloadFile(JSON.stringify(list, null, 2), 'testpath_saved_locators.json', 'application/json');
        checkDeleteAfterDownload();
      });
    });
  }

  if (btnDevExportSavedCSV) {
    btnDevExportSavedCSV.addEventListener('click', () => {
      loadSavedLocators((list) => {
        let csv = 'ID,Name,Tag,Locator,XPath,ActionCode\n';
        list.forEach((it, i) => {
          csv += `${i + 1},"${it.name || ''}","${it.tag || ''}","${(it.locator || '').replace(/"/g, '""')}","${(it.xpath || '').replace(/"/g, '""')}","${(it.actionCode || '').replace(/"/g, '""')}"\n`;
        });
        downloadFile(csv, 'testpath_saved_locators.csv', 'text/csv');
        checkDeleteAfterDownload();
      });
    });
  }

  if (btnDevExportSavedScript) {
    btnDevExportSavedScript.addEventListener('click', () => {
      loadSavedLocators((list) => {
        if (!list || list.length === 0) {
          showToast('No saved locators to export!');
          return;
        }
        // Map saved locator items to the step format buildRunnableTestScript expects
        const steps = list.map((it) => ({
          action: it.action || 'click',
          target: it.text || it.tagName || it.tag || 'element',
          bestXPath: it.bestXPath || it.xpath || it.locator || '//button',
          bestPlaywright: it.bestPlaywright || null,
          bestPlaywrightJava: it.bestPlaywrightJava || null,
          cssSelector: it.cssSelector || '',
          value: it.fillValue || '',
          pageUrl: it.pageUrl || it.url || null
        }));

        getInspectedWindowUrl((liveUrl) => {
          const script = buildRunnableTestScript(steps, currentFramework, liveUrl);

          // Pick filename extension based on framework
          const extMap = {
            'playwright': 'saved_locators.spec.js',
            'playwright-python': 'test_saved_locators.py',
            'playwright-java': 'SavedLocatorsTest.java',
            'playwright-csharp': 'SavedLocatorsTest.cs',
            'selenium-java': 'SavedLocatorsTest.java',
            'selenium-python': 'test_saved_locators.py',
            'selenium-javascript': 'saved_locators.js',
            'selenium-csharp': 'SavedLocatorsTest.cs',
            'cypress': 'saved_locators.cy.js',
            'robot': 'saved_locators.robot',
            'puppeteer': 'saved_locators.spec.js'
          };
          const filename = extMap[currentFramework] || 'saved_locators.spec.js';
          downloadFile(script, filename, 'application/octet-stream');
          showToast('⬇️ Script downloaded!');
          checkDeleteAfterDownload();
        });
      });
    });
  }

  function checkDeleteAfterDownload() {
    if (devChkDeleteAfter && devChkDeleteAfter.checked) {
      setTimeout(() => {
        safeStorage.set({ [STORAGE_KEY_SAVED]: [] }, () => {
          renderSavedLocators([]);
          showToast('Locators cleared after download');
        });
      }, 500);
    }
  }

  function downloadFile(content, fileName, contentType) {
    contentType = contentType || 'application/octet-stream';
    const file = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(file);

    // 1. Delegate to background service worker (safest, onDeterminingFilename enforces pure file extension)
    if (content && typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
      try {
        chrome.runtime.sendMessage({
          action: 'DOWNLOAD_FILE',
          content: content,
          filename: fileName,
          mimeType: contentType
        }, (res) => {
          if (!res || !res.success) {
            directDevDownload(url, fileName, content, contentType);
          } else {
            setTimeout(() => {
              try { URL.revokeObjectURL(url); } catch (e) { }
            }, 10000);
          }
        });
        return;
      } catch (err) {
        console.warn('sendMessage error, fallback to direct download:', err);
      }
    }

    directDevDownload(url, fileName, content, contentType);
  }

  function directDevDownload(url, fileName, content, contentType) {
    if (typeof chrome !== 'undefined' && chrome.downloads && typeof chrome.downloads.download === 'function') {
      try {
        let downloadUrl = url;
        if (content) {
          try {
            const base64 = (typeof globalThis.utf8ToBase64 === 'function')
              ? globalThis.utf8ToBase64(content)
              : btoa(unescape(encodeURIComponent(content)));
            downloadUrl = `data:${contentType || 'application/octet-stream'};charset=utf-8;base64,${base64}`;
          } catch (e) { }
        }
        chrome.downloads.download({
          url: downloadUrl,
          filename: fileName,
          saveAs: false,
          conflictAction: 'uniquify'
        }, (downloadId) => {
          if (chrome.runtime.lastError) {
            console.warn('Direct dev download failed, using anchor:', chrome.runtime.lastError.message);
            fallbackDevAnchor(url, fileName);
          } else {
            setTimeout(() => {
              try { URL.revokeObjectURL(url); } catch (e) { }
            }, 10000);
          }
        });
        return;
      } catch (err) {
        console.warn('chrome.downloads exception:', err);
      }
    }

    fallbackDevAnchor(url, fileName);
  }

  function fallbackDevAnchor(url, fileName) {
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      try {
        a.remove();
        URL.revokeObjectURL(url);
      } catch (e) { }
    }, 2000);
  }

  // ==========================================================================
  // Framework Preference Handler
  // ==========================================================================
  function handleFrameworkChange(newFramework) {
    if (!newFramework) return;
    currentFramework = newFramework;
    if (devHeaderFrameworkSelect) devHeaderFrameworkSelect.value = newFramework;
    if (devSettingFrameworkSelect) devSettingFrameworkSelect.value = newFramework;
    if (devRecFrameworkSelect) devRecFrameworkSelect.value = newFramework.startsWith('playwright') ? (newFramework.includes('python') ? 'playwright-python' : newFramework.includes('java') ? 'playwright-java' : 'playwright') : newFramework.startsWith('selenium') ? (newFramework.includes('python') ? 'selenium-python' : 'selenium-java') : 'playwright';

    try {
      safeStorage.set({ [STORAGE_KEY_PREF_FRAMEWORK]: newFramework });
    } catch (e) { }

    // Send to active page to update in-page inspector
    sendTabMessage({ action: 'SET_PREF_FRAMEWORK', framework: newFramework });

    renderHeroCard();
    generateScriptPreview();
  }

  if (devHeaderFrameworkSelect) {
    devHeaderFrameworkSelect.addEventListener('change', () => {
      handleFrameworkChange(devHeaderFrameworkSelect.value);
    });
  }

  if (devSettingFrameworkSelect) {
    devSettingFrameworkSelect.addEventListener('change', () => {
      handleFrameworkChange(devSettingFrameworkSelect.value);
    });
  }

  // ==========================================================================
  // Global Runtime Message Listeners
  // ==========================================================================
  if (typeof chrome !== 'undefined' && chrome && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg) return;
      if (msg.action === 'TESTPATH_ELEMENT_INSPECTED' && msg.data) {
        displayElementAnalysis(msg.data);
        if (btnDevInspect) btnDevInspect.classList.remove('inspect-active');
      } else if (msg.action === 'TESTPATH_STEP_RECORDED' && msg.step) {
        loadRecordedSteps();
      }
    });
  }

  // Listen to storage changes to sync state across popup, dock, and DevTools
  if (typeof chrome !== 'undefined' && chrome && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes[STORAGE_KEY_PREF_FRAMEWORK]) {
        const val = changes[STORAGE_KEY_PREF_FRAMEWORK].newValue;
        if (val && val !== currentFramework) {
          handleFrameworkChange(val);
        }
      }
      if (changes[STORAGE_KEY_SAVED]) {
        renderSavedLocators(changes[STORAGE_KEY_SAVED].newValue || []);
      }
      if (changes[STORAGE_KEY_REC_STATE]) {
        updateRecorderUI(changes[STORAGE_KEY_REC_STATE].newValue);
      }
      if (changes[STORAGE_KEY_FLOW_STEPS]) {
        renderRecordedSteps(changes[STORAGE_KEY_FLOW_STEPS].newValue || []);
      }
    });
  }

  // Helper escapeHTML
  function escapeHTML(str) {
    if (typeof str !== 'string') return String(str || '');
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // Initialization function
  function init() {
    updateInspectedUrl();

    // Default to idle recorder state
    updateRecorderUI(false);

    // Load framework preference & stored state
    safeStorage.get(
      [STORAGE_KEY_PREF_FRAMEWORK, STORAGE_KEY_SAVED, STORAGE_KEY_REC_STATE, STORAGE_KEY_FLOW_STEPS, STORAGE_KEY_DEL_AFTER],
      (res) => {
        if (res && res[STORAGE_KEY_PREF_FRAMEWORK]) {
          currentFramework = res[STORAGE_KEY_PREF_FRAMEWORK];
          if (devHeaderFrameworkSelect) devHeaderFrameworkSelect.value = currentFramework;
          if (devSettingFrameworkSelect) devSettingFrameworkSelect.value = currentFramework;
        }
        if (res && res[STORAGE_KEY_SAVED]) {
          renderSavedLocators(res[STORAGE_KEY_SAVED]);
        }
        if (res && res[STORAGE_KEY_REC_STATE] !== undefined) {
          updateRecorderUI(res[STORAGE_KEY_REC_STATE]);
        }
        if (res && res[STORAGE_KEY_FLOW_STEPS]) {
          renderRecordedSteps(res[STORAGE_KEY_FLOW_STEPS]);
        }
        if (res && res[STORAGE_KEY_DEL_AFTER] !== undefined && devChkDeleteAfter) {
          devChkDeleteAfter.checked = Boolean(res[STORAGE_KEY_DEL_AFTER]);
        }

        // Live check against active inspected tab
        sendTabMessage({ action: 'GET_RECORD_STATE' }, (tabRes) => {
          if (tabRes && tabRes.isRecording !== undefined) {
            updateRecorderUI(tabRes);
            if (tabRes.steps && Array.isArray(tabRes.steps)) {
              renderRecordedSteps(tabRes.steps);
            }
          }
        });
      }
    );

    // Initial check: if $0 is already selected in DevTools, inspect it immediately!
    setTimeout(() => {
      inspectDevToolsSelectedElement();
    }, 200);
  }

  // Called when DevTools panel is shown
  window.__onTestPathPanelShown = function () {
    updateInspectedUrl();
    if (!currentAnalysis) {
      inspectDevToolsSelectedElement();
    }
    // Query active tab directly for real-time recording state
    sendTabMessage({ action: 'GET_RECORD_STATE' }, (tabRes) => {
      if (tabRes && tabRes.isRecording !== undefined) {
        updateRecorderUI(tabRes);
        if (tabRes.steps && Array.isArray(tabRes.steps)) {
          renderRecordedSteps(tabRes.steps);
        }
      } else {
        safeStorage.get([STORAGE_KEY_REC_STATE], (res) => {
          updateRecorderUI(res ? res[STORAGE_KEY_REC_STATE] : false);
        });
      }
    });
  };

  // Run on DOM loaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
