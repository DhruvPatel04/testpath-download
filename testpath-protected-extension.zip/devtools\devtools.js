/**
 * TestPath - DevTools Initializer
 * Registers the "TestPath" tab near Network tab in Inspect (Chrome DevTools).
 */

(function () {
  'use strict';

  try {
    if (chrome && chrome.devtools && chrome.devtools.panels && chrome.devtools.panels.create) {
      chrome.devtools.panels.create(
        'TestPath',
        '../icons/icon16.png',
        'devtools/panel.html',
        function (panel) {
          if (!panel) return;
          try {
            panel.onShown.addListener(function (panelWindow) {
              try {
                if (panelWindow && typeof panelWindow.__onTestPathPanelShown === 'function') {
                  panelWindow.__onTestPathPanelShown();
                }
              } catch (err) {
                console.warn('TestPath: onShown listener error:', err);
              }
            });
          } catch (e) {
            console.warn('TestPath: panel listener registration warning:', e);
          }
        }
      );
    }
  } catch (globalErr) {
    console.warn('TestPath DevTools initialization warning:', globalErr);
  }
})();

