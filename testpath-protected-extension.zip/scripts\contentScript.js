/**
 * Smart XPath Finder - Autonomous Self-Contained Bundle
 * Contains: XPath Engine + Embedded CSS + Floating Inspector UI
 */

(function () {
  'use strict';

  // --- Embedded XPath Engine ---
/**
 * Smart XPath Finder - XPath Engine
 * Generates robust, reliable, and unique XPaths and CSS selectors.
 */

(function (global) {
  'use strict';

  const ELEMENT_NODE = typeof Node !== 'undefined' && Node.ELEMENT_NODE ? Node.ELEMENT_NODE : 1;

  function safeEscapeCSS(val) {
    if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') {
      return CSS.escape(val);
    }
    return String(val).replace(/["\\]/g, '\\$&');
  }

  function safeGetAttr(el, attr) {
    if (!el || el.nodeType !== ELEMENT_NODE) return null;
    try {
      if (typeof Element !== 'undefined' && Element.prototype && Element.prototype.getAttribute) {
        const v = Element.prototype.getAttribute.call(el, attr);
        return typeof v === 'string' ? v : (v !== null && v !== undefined ? String(v) : null);
      }
      if (typeof el.getAttribute === 'function') {
        const v = el.getAttribute(attr);
        return typeof v === 'string' ? v : (v !== null && v !== undefined ? String(v) : null);
      }
    } catch (e) { }
    return null;
  }

  function safeHasAttr(el, attr) {
    if (!el || el.nodeType !== ELEMENT_NODE) return false;
    try {
      if (typeof Element !== 'undefined' && Element.prototype && Element.prototype.hasAttribute) {
        return Boolean(Element.prototype.hasAttribute.call(el, attr));
      }
      if (typeof el.hasAttribute === 'function') {
        return Boolean(el.hasAttribute(attr));
      }
    } catch (e) { }
    return false;
  }

  function safeGetId(el) {
    const attrId = safeGetAttr(el, 'id');
    if (attrId && typeof attrId === 'string' && attrId.trim()) return attrId.trim();
    try {
      if (el && typeof el.id === 'string' && el.id.trim()) return el.id.trim();
    } catch (e) { }
    return null;
  }

  function safeGetTagName(el) {
    if (!el || el.nodeType !== ELEMENT_NODE) return '';
    try {
      if (typeof Element !== 'undefined' && Element.prototype) {
        const desc = Object.getOwnPropertyDescriptor(Element.prototype, 'tagName');
        if (desc && typeof desc.get === 'function') {
          const t = desc.get.call(el);
          if (typeof t === 'string') return t.toLowerCase();
        }
      }
      if (typeof el.tagName === 'string') return el.tagName.toLowerCase();
      if (typeof el.nodeName === 'string') return el.nodeName.toLowerCase();
    } catch (e) { }
    return '';
  }

  function safeGetText(el) {
    if (!el) return '';
    try {
      if (typeof el.innerText === 'string') return el.innerText;
      if (typeof el.textContent === 'string') return el.textContent;
    } catch (e) { }
    return '';
  }

  function safeGetChildren(el) {
    if (!el || el.nodeType !== ELEMENT_NODE) return [];
    try {
      if (typeof Element !== 'undefined' && Element.prototype) {
        const desc = Object.getOwnPropertyDescriptor(Element.prototype, 'children');
        if (desc && typeof desc.get === 'function') {
          const ch = desc.get.call(el);
          if (ch && typeof ch.length === 'number') return Array.from(ch);
        }
      }
      if (el.children && typeof el.children.length === 'number' && typeof el.children !== 'function') {
        return Array.from(el.children);
      }
    } catch (e) { }
    return [];
  }

  function safeGetParent(el) {
    if (!el) return null;
    try {
      if (typeof Node !== 'undefined' && Node.prototype) {
        const desc = Object.getOwnPropertyDescriptor(Node.prototype, 'parentElement');
        if (desc && typeof desc.get === 'function') {
          const p = desc.get.call(el);
          if (p && p.nodeType === ELEMENT_NODE) return p;
        }
      }
      if (el.parentElement && el.parentElement.nodeType === ELEMENT_NODE) return el.parentElement;
    } catch (e) { }
    return null;
  }

  function safeGetOwnerDocument(el) {
    if (!el) return (typeof document !== 'undefined' ? document : null);
    try {
      if (typeof Node !== 'undefined' && Node.prototype) {
        const desc = Object.getOwnPropertyDescriptor(Node.prototype, 'ownerDocument');
        if (desc && typeof desc.get === 'function') {
          const od = desc.get.call(el);
          if (od && od.nodeType === 9) return od;
        }
      }
      if (el.ownerDocument && el.ownerDocument.nodeType === 9) {
        return el.ownerDocument;
      }
    } catch (e) { }
    try {
      if (typeof el.getRootNode === 'function') {
        const root = el.getRootNode();
        if (root && root.nodeType === 9) return root;
      }
    } catch (e) { }
    return (typeof document !== 'undefined' ? document : null);
  }

  const DYNAMIC_ID_PATTERNS = [
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i, // UUID
    /^[0-9a-f]{10,}$/i, // Long hex hash
    /^[a-z_-]+[0-9]{3,}$/i, // Prefix with 3+ trailing digits e.g. gen-194, btn-10294
    /^(ember|mat-|cdk-|chakra|radix|mui|ng-|react-select|yui|headlessui|mantine|downshift|react-aria|rc-)[\w-]*\d+/i, // Framework IDs
    /^p[nvr]?[_-](id|[a-z]+)[_-]?\d+/i, // PrimeNG (pn_id_71_header), PrimeVue (pv_id_12), PrimeReact (pr_id_5), PrimeFaces
    /^(ui|ext)[_-](id|gen|element|comp)[_-]?\d+/i, // jQuery UI (ui-id-1), ExtJS (ext-gen12)
    /^[a-z0-9_-]+[_-]id[_-]\d+([_-].*)?$/i, // Generic component-id-number-part e.g. dialog_id_12_header
    /(^|:)r[0-9a-z]+:?$/i, // React 18 useId (:r1:)
    /^radix-.*$/i, // Radix UI
    /^\d+$/, // Pure numeric
    /__[a-z0-9_-]{5,}$/i // Hashed suffixes
  ];

  const TEST_ATTRIBUTES = [
    'data-testid',
    'data-test',
    'data-cy',
    'data-qa',
    'data-automation-id',
    'data-component-id',
    'data-id'
  ];

  const SEMANTIC_ATTRIBUTES = [
    'name',
    'placeholder',
    'aria-label',
    'role',
    'title',
    'alt',
    'type',
    'href',
    'value',
    'data-icon'
  ];

  const UTILITY_CLASS_PATTERNS = [
    /^(flex|grid|block|inline|hidden|relative|absolute|fixed|sticky)$/,
    /^(m|p|mt|mb|ml|mr|mx|my|pt|pb|pl|pr|px|py)-\w+/,
    /^(w|h|min-w|min-h|max-w|max-h)-\w+/,
    /^(text|bg|border|shadow|rounded|opacity|gap|z)-\w+/,
    /^(col|row|items|justify|self|content)-\w+/,
    /^[a-z0-9]{6,}$/i, // Short random CSS module hash
    /^css-[a-z0-9]+/i, // Emotion / styled-components
    /^sc-[a-z0-9]+/i,
    /^ng-/i, // Angular framework marker classes e.g. ng-star-inserted, ng-tns, ng-trigger
    /^_ng/i,
    /^cdk-/i,
    /^mat-(ripple|focus|elevation)/i,
    /^ant-/i
  ];

  const SVG_TAG_NAMES = [
    'svg', 'path', 'g', 'circle', 'rect', 'line', 'polyline', 'polygon',
    'ellipse', 'use', 'symbol', 'text', 'tspan', 'defs', 'clippath',
    'mask', 'pattern', 'marker', 'lineargradient', 'radialgradient', 'stop', 'foreignobject', 'image'
  ];

  class XPathEngine {
    /**
     * Test if a tag name belongs to the SVG specification
     */
    static isSVGTag(tag) {
      if (!tag || typeof tag !== 'string') return false;
      return SVG_TAG_NAMES.includes(tag.toLowerCase().trim());
    }

    /**
     * Test if an element is an SVG element or resides in the SVG XML namespace
     */
    static isSVGElement(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) return false;
      try {
        if (typeof SVGElement !== 'undefined' && element instanceof SVGElement) return true;
        if (element.namespaceURI === 'http://www.w3.org/2000/svg') return true;
        const tag = safeGetTagName(element);
        return XPathEngine.isSVGTag(tag);
      } catch (e) {
        return false;
      }
    }

    /**
     * Extract class string safely for both HTML and SVG elements (which use SVGAnimatedString)
     */
    static getElementClassString(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) return '';
      try {
        if (typeof element.className === 'string') return element.className;
        if (element.className && typeof element.className.baseVal === 'string') {
          return element.className.baseVal;
        }
        return safeGetAttr(element, 'class') || '';
      } catch (e) {
        return '';
      }
    }

    /**
     * Extract clean array of class tokens from element
     */
    static getElementClassList(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) return [];
      try {
        if (element.classList && typeof element.classList[Symbol.iterator] === 'function') {
          return Array.from(element.classList);
        }
      } catch (e) { }
      const str = XPathEngine.getElementClassString(element);
      return str ? str.trim().split(/\s+/).filter(Boolean) : [];
    }

    /**
     * Get the current or filled value of an interactive element (or 'Enter value' fallback)
     */
    static getElementFillValue(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) return 'Enter value';
      try {
        if (typeof element.value === 'string' && element.value.trim()) {
          return element.value.trim();
        }
      } catch (e) { }
      try {
        const attrVal = safeGetAttr(element, 'value');
        if (attrVal && typeof attrVal === 'string' && attrVal.trim()) {
          return attrVal.trim();
        }
      } catch (e) { }
      try {
        const isEditable = safeGetAttr(element, 'contenteditable');
        if (isEditable === 'true' || isEditable === '') {
          const txt = safeGetText(element).trim();
          if (txt) return txt;
        }
      } catch (e) { }
      return 'Enter value';
    }

    /**
     * Get robust XPath tag step (automatically converts SVG tags to namespace-agnostic *[local-name()='tag'])
     */
    static getXPathTagStep(element, tag = null) {
      const tagName = (tag || safeGetTagName(element) || '').toLowerCase();
      if (!tagName) return '*';
      if (XPathEngine.isSVGElement(element) || XPathEngine.isSVGTag(tagName)) {
        return `*[local-name()='${tagName}']`;
      }
      return tagName;
    }

    /**
     * Test if an ID is dynamic or generated
     */
    static isDynamicId(id) {
      if (!id || typeof id !== 'string') return true;
      const clean = id.trim();
      if (!clean) return true;
      return DYNAMIC_ID_PATTERNS.some((pattern) => pattern.test(clean));
    }

    /**
     * Escape strings for XPath expression
     */
    static escapeXPathString(str) {
      if (str === null || str === undefined) return "''";
      const s = String(str);
      if (!s.includes("'")) {
        return `'${s}'`;
      }
      if (!s.includes('"')) {
        return `"${s}"`;
      }
      // If it contains both single and double quotes, use concat()
      const parts = s.split("'").map((part) => `'${part}'`);
      return `concat(${parts.join(', "\'", ')})`;
    }

    /**
     * Evaluate an XPath in the context of the document
     * Returns array of matching DOM elements
     */
    static queryXPath(xpath, doc = (typeof document !== 'undefined' ? document : null)) {
      const results = [];
      if (!doc || typeof doc.evaluate !== 'function' || !xpath) {
        return results;
      }
      try {
        const snapshotType = (typeof XPathResult !== 'undefined' && XPathResult.ORDERED_NODE_SNAPSHOT_TYPE)
          ? XPathResult.ORDERED_NODE_SNAPSHOT_TYPE
          : 7;
        const query = doc.evaluate(
          xpath,
          doc,
          null,
          snapshotType,
          null
        );
        if (query) {
          for (let i = 0; i < query.snapshotLength; i++) {
            const item = query.snapshotItem(i);
            if (item) results.push(item);
          }
        }
      } catch (err) {
        // Invalid XPath syntax or context
      }
      return results;
    }

    /**
     * Check if an XPath uniquely identifies the given element
     */
    static isUnique(xpath, element, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!doc || typeof doc.evaluate !== 'function' || !xpath || !element) return false;
      try {
        // Fast early-exit iterator path: exits as soon as 2 nodes are evaluated
        if (typeof XPathResult !== 'undefined' && XPathResult.ORDERED_NODE_ITERATOR_TYPE) {
          const iter = doc.evaluate(xpath, doc, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
          if (iter && typeof iter.iterateNext === 'function') {
            const first = iter.iterateNext();
            if (!first || first !== element) return false;
            const second = iter.iterateNext();
            return second === null;
          }
        }
        // Direct snapshot evaluation avoiding array allocation
        const snapshotType = (typeof XPathResult !== 'undefined' && XPathResult.ORDERED_NODE_SNAPSHOT_TYPE)
          ? XPathResult.ORDERED_NODE_SNAPSHOT_TYPE
          : 7;
        const query = doc.evaluate(xpath, doc, null, snapshotType, null);
        if (query && typeof query.snapshotLength === 'number') {
          return query.snapshotLength === 1 && query.snapshotItem(0) === element;
        }
      } catch (err) { }

      // Fallback
      const matches = XPathEngine.queryXPath(xpath, doc);
      return matches.length === 1 && matches[0] === element;
    }

    /**
     * Evaluate CSS selector
     */
    static queryCSS(selector, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!doc || typeof doc.querySelectorAll !== 'function' || !selector) return [];
      try {
        return Array.from(doc.querySelectorAll(selector));
      } catch (e) {
        return [];
      }
    }

    static isUniqueCSS(selector, element, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!doc || typeof doc.querySelectorAll !== 'function' || !selector || !element) return false;
      try {
        const matches = doc.querySelectorAll(selector);
        return matches.length === 1 && matches[0] === element;
      } catch (e) {
        return false;
      }
    }

    /**
     * Generate all candidate XPaths and pick the best one
     */
    static analyzeElement(element, doc) {
      try {
        if (!element || element.nodeType !== ELEMENT_NODE) {
          return null;
        }
        const targetDoc = doc || safeGetOwnerDocument(element);
        const rawTag = safeGetTagName(element) || 'div';
        const tag = rawTag || 'div';
        const isSvg = XPathEngine.isSVGElement(element);
        const tagStep = isSvg ? `*[local-name()='${tag}']` : tag;
        const candidates = [];

        // Tier 1: Test IDs (data-testid, data-cy, etc.)
        for (const attr of TEST_ATTRIBUTES) {
          const val = safeGetAttr(element, attr);
          if (val && typeof val === 'string' && val.trim()) {
            const cleanVal = val.trim();
            const esc = XPathEngine.escapeXPathString(cleanVal);
            const xpTag = `//${tagStep}[@${attr}=${esc}]`;
            const xpAny = `//*[@${attr}=${esc}]`;

            if (XPathEngine.isUnique(xpAny, element, targetDoc)) {
              candidates.push({
                xpath: xpAny,
                type: 'test-id',
                score: 100,
                label: `Test ID (@${attr})`
              });
            } else if (XPathEngine.isUnique(xpTag, element, targetDoc) || (isSvg && XPathEngine.queryXPath(xpTag, targetDoc).length === 1)) {
              candidates.push({
                xpath: xpTag,
                type: isSvg ? 'svg-test-id' : 'test-id',
                score: 98,
                label: isSvg ? `SVG Namespace Test ID (@${attr})` : `Tag + Test ID (@${attr})`
              });
            }
          }
        }

        // Tier 2: Meaningful ID
        const id = safeGetId(element);
        if (id && !XPathEngine.isDynamicId(id)) {
          const cleanId = id.trim();
          const esc = XPathEngine.escapeXPathString(cleanId);
          const xpAny = `//*[@id=${esc}]`;
          const xpTag = `//${tagStep}[@id=${esc}]`;
          const pw = `page.locator('#${safeEscapeCSS(cleanId)}')`;
          const pwJava = `page.locator("#${safeEscapeCSS(cleanId)}");`;

          if (XPathEngine.isUnique(xpAny, element, targetDoc)) {
            candidates.push({
              xpath: xpAny,
              type: 'id',
              idValue: cleanId,
              playwright: pw,
              playwrightJava: pwJava,
              score: 95,
              label: 'Unique ID'
            });
          } else if (XPathEngine.isUnique(xpTag, element, targetDoc) || (isSvg && XPathEngine.queryXPath(xpTag, targetDoc).length === 1)) {
            candidates.push({
              xpath: xpTag,
              type: isSvg ? 'svg-id' : 'id',
              idValue: cleanId,
              playwright: pw,
              playwrightJava: pwJava,
              score: 94,
              label: isSvg ? 'SVG Namespace ID' : 'Tag + ID'
            });
          }
        }

        // Tier 2.5: SVG-Specific Robust Selectors (e.g. //*[local-name()='svg' and @data-icon='search'])
        if (isSvg) {
          const iconVal = safeGetAttr(element, 'data-icon');
          if (iconVal && typeof iconVal === 'string' && iconVal.trim()) {
            const cleanIcon = iconVal.trim();
            const escIcon = XPathEngine.escapeXPathString(cleanIcon);
            const xpSvgIcon = `//*[local-name()='${tag}' and @data-icon=${escIcon}]`;
            if (XPathEngine.isUnique(xpSvgIcon, element, targetDoc) || XPathEngine.queryXPath(xpSvgIcon, targetDoc).length === 1) {
              candidates.push({
                xpath: xpSvgIcon,
                type: 'svg-icon',
                score: 97,
                label: `SVG Namespace Locator (@data-icon='${cleanIcon}')`
              });
            }
          }
        }

        // Tier 3: Semantic Attributes (name, placeholder, aria-label, role, etc.)
        const semanticAttrs = isSvg
          ? ['data-icon', 'data-name', 'aria-label', 'role', 'title', 'name', 'viewBox']
          : SEMANTIC_ATTRIBUTES;

        for (const attr of semanticAttrs) {
          const val = safeGetAttr(element, attr);
          if (val && typeof val === 'string' && val.trim()) {
            const cleanVal = val.trim();
            if (cleanVal.length > 80) continue;
            const esc = XPathEngine.escapeXPathString(cleanVal);
            const xpTag = `//${tagStep}[@${attr}=${esc}]`;

            if (XPathEngine.isUnique(xpTag, element, targetDoc) || (isSvg && XPathEngine.queryXPath(xpTag, targetDoc).length === 1)) {
              candidates.push({
                xpath: xpTag,
                type: isSvg ? 'svg-attribute' : 'attribute',
                score: isSvg ? 92 : 88,
                label: isSvg ? `SVG Namespace (@${attr}='${cleanVal.substring(0, 16)}')` : `Attribute (@${attr})`
              });
            }

            // Combined attribute check for inputs e.g. //input[@type='email' and @name='user']
            if (attr === 'name' && safeHasAttr(element, 'type')) {
              const typeVal = safeGetAttr(element, 'type');
              if (typeVal) {
                const xpCombo = `//${tag}[@type='${typeVal}' and @name=${esc}]`;
                if (XPathEngine.isUnique(xpCombo, element, targetDoc)) {
                  candidates.push({
                    xpath: xpCombo,
                    type: 'attribute-combo',
                    score: 86,
                    label: `Type + Name`
                  });
                }
              }
            }
          }
        }

        // Tier 4: Exact Text & Normalized Text
        const rawText = safeGetText(element).trim();
        const cleanText = rawText.replace(/\s+/g, ' ');
        const childCount = safeGetChildren(element).length;
        if (cleanText && cleanText.length >= 1 && cleanText.length <= 60 && childCount <= 4) {
          const esc = XPathEngine.escapeXPathString(cleanText);
          const xpExact = `//${tagStep}[normalize-space()=${esc}]`;
          if (XPathEngine.isUnique(xpExact, element, targetDoc) || (isSvg && XPathEngine.queryXPath(xpExact, targetDoc).length === 1)) {
            candidates.push({
              xpath: xpExact,
              type: isSvg ? 'svg-text' : 'text',
              score: isSvg ? 87 : 85,
              label: isSvg ? `SVG Text (${cleanText.substring(0, 16)})` : 'Exact Text'
            });
          } else {
            const role = safeGetAttr(element, 'role');
            if (role) {
              const xpRoleText = `//${tagStep}[@role='${role}' and normalize-space()=${esc}]`;
              if (XPathEngine.isUnique(xpRoleText, element, targetDoc)) {
                candidates.push({
                  xpath: xpRoleText,
                  type: 'text-role',
                  score: 82,
                  label: 'Role + Text'
                });
              }
            }
          }
        }

        // Tier 5: Semantic CSS Classes
        const classList = XPathEngine.getElementClassList(element);
        if (classList.length > 0) {
          const classes = classList.filter((cls) => {
            return (
              typeof cls === 'string' &&
              cls.length > 2 &&
              cls.length < 35 &&
              !UTILITY_CLASS_PATTERNS.some((pat) => pat.test(cls))
            );
          });

          for (const cls of classes) {
            const esc = XPathEngine.escapeXPathString(cls);
            const xpClass = `//${tagStep}[contains(@class, ${esc})]`;
            if (XPathEngine.isUnique(xpClass, element, targetDoc) || (isSvg && XPathEngine.queryXPath(xpClass, targetDoc).length === 1)) {
              candidates.push({
                xpath: xpClass,
                type: isSvg ? 'svg-class' : 'class',
                score: isSvg ? 88 : 75,
                label: isSvg ? `SVG Namespace Class (.${cls})` : `Semantic Class (.${cls})`
              });
              break;
            }
          }
        }

        // Standalone SVG tag fallback
        if (isSvg) {
          const xpSvgOnly = `//*[local-name()='${tag}']`;
          if (XPathEngine.isUnique(xpSvgOnly, element, targetDoc) || XPathEngine.queryXPath(xpSvgOnly, targetDoc).length === 1) {
            candidates.push({
              xpath: xpSvgOnly,
              type: 'svg-tag',
              score: 80,
              label: `SVG Namespace Tag (*[local-name()='${tag}'])`
            });
          }
        }

        // Tier 6: Anchored Relative XPath
        try {
          const anchored = XPathEngine.generateAnchoredXPath(element, targetDoc);
          if (anchored && (XPathEngine.isUnique(anchored, element, targetDoc) || (isSvg && XPathEngine.queryXPath(anchored, targetDoc).length === 1))) {
            candidates.push({
              xpath: anchored,
              type: 'relative-anchor',
              score: 70,
              label: 'Relative to Anchor Ancestor'
            });
          }
        } catch (e) { }

        // Tier 7: Relative Axes Locators
        let relativeLocators = [];
        try {
          relativeLocators = XPathEngine.generateRelativeAxesLocators(element, targetDoc);
          for (const rel of relativeLocators) {
            candidates.push({
              xpath: rel.xpath,
              type: 'relative-axes',
              selenium4: rel.selenium4,
              score: rel.score,
              label: rel.label
            });
          }
        } catch (e) { }

        // Tier 8: Shortest Hierarchical Path
        try {
          const hier = XPathEngine.generateHierarchicalXPath(element, targetDoc);
          if (hier && (XPathEngine.isUnique(hier, element, targetDoc) || (isSvg && XPathEngine.queryXPath(hier, targetDoc).length === 1))) {
            candidates.push({
              xpath: hier,
              type: 'hierarchy',
              score: 60,
              label: 'Hierarchical Path'
            });
          }
        } catch (e) { }

        // Fallback: Full Absolute XPath
        try {
          const full = XPathEngine.generateAbsoluteXPath(element);
          if (full) {
            candidates.push({
              xpath: full,
              type: 'absolute',
              score: 20,
              label: 'Full Absolute XPath'
            });
          }
        } catch (e) { }

        // Deduplicate candidates by xpath string
        const uniqueCandidates = [];
        const seen = new Set();
        for (const cand of candidates) {
          if (cand && cand.xpath && !seen.has(cand.xpath)) {
            seen.add(cand.xpath);
            uniqueCandidates.push(cand);
          }
        }

        if (uniqueCandidates.length === 0) {
          uniqueCandidates.push({
            xpath: `//${tagStep}`,
            type: 'tag',
            score: 30,
            label: `Tag Locator (<${tag}>)`
          });
        }

        // Sort by score descending
        uniqueCandidates.sort((a, b) => b.score - a.score);

        const best = uniqueCandidates[0];
        let css = '';
        try {
          css = XPathEngine.generateBestCSS(element, targetDoc);
        } catch (e) { }

        let playwrightLocators = [];
        try {
          playwrightLocators = XPathEngine.generatePlaywrightLocators(element, targetDoc);
        } catch (e) { }

        const bestPlaywright = playwrightLocators.length > 0 ? playwrightLocators[0] : null;
        const bestIdCandidate = uniqueCandidates.find((c) => c.type === 'id');
        const bestId = bestIdCandidate ? bestIdCandidate.idValue : null;
        const bestPlaywrightJava = (bestPlaywright && bestPlaywright.codeJava)
          ? bestPlaywright.codeJava
          : (bestId ? `page.locator("#${bestId}");` : XPathEngine.toPlaywrightJava(bestPlaywright ? bestPlaywright.code : null, best.xpath));
        const bestRelative = relativeLocators.length > 0 ? relativeLocators[0] : null;
        const fillValue = XPathEngine.getElementFillValue(element);
        const iframeInfo = XPathEngine.detectIframe(element);

        return {
          best: best.xpath,
          bestType: best.type,
          bestLabel: best.label,
          score: best.score,
          alternatives: uniqueCandidates,
          cssSelector: css,
          playwrightLocators: playwrightLocators,
          bestPlaywright: bestPlaywright ? bestPlaywright.code : null,
          bestPlaywrightJava: bestPlaywrightJava,
          bestId: bestId,
          relativeLocators: relativeLocators,
          bestRelative: bestRelative,
          fillValue: fillValue,
          iframeInfo: iframeInfo,
          tagName: tag,
          isSvg: isSvg,
          elementInfo: {
            id: safeGetId(element),
            className: XPathEngine.getElementClassString(element) || null,
            innerText: safeGetText(element).substring(0, 100),
            nodeName: element.nodeName || tag
          }
        };
      } catch (err) {
        try {
          console.warn('XPathEngine: fallback analysis due to:', err);
        } catch (logErr) { }
        let fallbackTag = 'div';
        try {
          fallbackTag = safeGetTagName(element) || 'div';
        } catch (tErr) { }
        const isSvg = (typeof XPathEngine !== 'undefined' && XPathEngine.isSVGElement) ? XPathEngine.isSVGElement(element) : false;
        const fallbackXP = isSvg ? `//*[local-name()='${fallbackTag}']` : `//${fallbackTag}`;
        const fallbackIframe = (typeof XPathEngine !== 'undefined' && XPathEngine.detectIframe) ? XPathEngine.detectIframe(element) : null;
        return {
          best: fallbackXP,
          bestType: isSvg ? 'svg-tag' : 'fallback-tag',
          bestLabel: isSvg ? `SVG Namespace Tag (*[local-name()='${fallbackTag}'])` : `Tag (${fallbackTag})`,
          score: 30,
          alternatives: [{ xpath: fallbackXP, type: isSvg ? 'svg-tag' : 'fallback-tag', score: 30, label: isSvg ? `SVG Namespace Tag (*[local-name()='${fallbackTag}'])` : `Tag (${fallbackTag})` }],
          cssSelector: fallbackTag,
          playwrightLocators: [],
          bestPlaywright: null,
          bestPlaywrightJava: null,
          bestId: null,
          relativeLocators: [],
          bestRelative: null,
          fillValue: 'Enter value',
          iframeInfo: fallbackIframe,
          tagName: fallbackTag,
          isSvg: isSvg,
          elementInfo: {
            id: null,
            className: null,
            innerText: '',
            nodeName: fallbackTag
          }
        };
      }
    }

    /**
     * Find nearest ancestor with a stable ID or test-id and form a relative path
     */
    static generateAnchoredXPath(element, doc) {
      let curr = safeGetParent(element);
      const isTargetSvg = XPathEngine.isSVGElement(element);
      const targetTag = safeGetTagName(element) || '*';
      const targetStep = isTargetSvg ? `*[local-name()='${targetTag}']` : targetTag;
      const targetDoc = doc || safeGetOwnerDocument(element);

      while (curr && (!targetDoc || (curr !== targetDoc.body && curr !== targetDoc.documentElement))) {
        // Check test id
        for (const attr of TEST_ATTRIBUTES) {
          const val = safeGetAttr(curr, attr);
          if (val && val.trim()) {
            const esc = XPathEngine.escapeXPathString(val.trim());
            const anchor = `//*[@${attr}=${esc}]`;
            const path = `${anchor}//${targetStep}`;
            if (XPathEngine.isUnique(path, element, targetDoc) || (isTargetSvg && XPathEngine.queryXPath(path, targetDoc).length === 1)) {
              return path;
            }
            if (safeHasAttr(element, 'data-icon')) {
              const iconEsc = XPathEngine.escapeXPathString(safeGetAttr(element, 'data-icon') || '');
              const pathWithIcon = isTargetSvg
                ? `${anchor}//*[local-name()='${targetTag}' and @data-icon=${iconEsc}]`
                : `${anchor}//${targetTag}[@data-icon=${iconEsc}]`;
              if (XPathEngine.isUnique(pathWithIcon, element, targetDoc) || (isTargetSvg && XPathEngine.queryXPath(pathWithIcon, targetDoc).length === 1)) {
                return pathWithIcon;
              }
            }
            if (safeHasAttr(element, 'name')) {
              const nameEsc = XPathEngine.escapeXPathString(safeGetAttr(element, 'name') || '');
              const pathWithName = isTargetSvg
                ? `${anchor}//*[local-name()='${targetTag}' and @name=${nameEsc}]`
                : `${anchor}//${targetTag}[@name=${nameEsc}]`;
              if (XPathEngine.isUnique(pathWithName, element, targetDoc) || (isTargetSvg && XPathEngine.queryXPath(pathWithName, targetDoc).length === 1)) {
                return pathWithName;
              }
            }
          }
        }

        // Check stable ID
        const id = safeGetId(curr);
        if (id && !XPathEngine.isDynamicId(id)) {
          const esc = XPathEngine.escapeXPathString(id.trim());
          const anchor = `//*[@id=${esc}]`;
          const path = `${anchor}//${targetStep}`;
          if (XPathEngine.isUnique(path, element, targetDoc) || (isTargetSvg && XPathEngine.queryXPath(path, targetDoc).length === 1)) {
            return path;
          }
          if (safeHasAttr(element, 'data-icon')) {
            const iconEsc = XPathEngine.escapeXPathString(safeGetAttr(element, 'data-icon') || '');
            const pathWithIcon = isTargetSvg
              ? `${anchor}//*[local-name()='${targetTag}' and @data-icon=${iconEsc}]`
              : `${anchor}//${targetTag}[@data-icon=${iconEsc}]`;
            if (XPathEngine.isUnique(pathWithIcon, element, targetDoc) || (isTargetSvg && XPathEngine.queryXPath(pathWithIcon, targetDoc).length === 1)) {
              return pathWithIcon;
            }
          }
          if (safeHasAttr(element, 'name')) {
            const nameEsc = XPathEngine.escapeXPathString(safeGetAttr(element, 'name') || '');
            const pathWithName = isTargetSvg
              ? `${anchor}//*[local-name()='${targetTag}' and @name=${nameEsc}]`
              : `${anchor}//${targetTag}[@name=${nameEsc}]`;
            if (XPathEngine.isUnique(pathWithName, element, targetDoc) || (isTargetSvg && XPathEngine.queryXPath(pathWithName, targetDoc).length === 1)) {
              return pathWithName;
            }
          }
        }

        curr = safeGetParent(curr);
      }
      return null;
    }

    /**
     * Generate hierarchical relative XPath
     */
    static generateHierarchicalXPath(element, doc) {
      if (!element || element.nodeType !== ELEMENT_NODE) return '';
      let path = '';
      let curr = element;
      const targetDoc = doc || safeGetOwnerDocument(element);

      while (curr && curr.nodeType === ELEMENT_NODE && (!targetDoc || (curr !== targetDoc.documentElement && curr !== targetDoc.body))) {
        let rawTag = safeGetTagName(curr) || '*';
        const isSvg = XPathEngine.isSVGElement(curr);
        const tag = isSvg ? `*[local-name()='${rawTag}']` : rawTag;
        let index = 1;
        let sib = curr.previousElementSibling;

        while (sib) {
          if (safeGetTagName(sib) === rawTag) {
            index++;
          }
          sib = sib.previousElementSibling;
        }

        const step = index > 1 ? `${tag}[${index}]` : tag;
        path = path ? `${step}/${path}` : step;

        const candidate = `//${path}`;
        if (XPathEngine.isUnique(candidate, element, targetDoc) || (isSvg && XPathEngine.queryXPath(candidate, targetDoc).length === 1)) {
          return candidate;
        }

        curr = safeGetParent(curr);
      }

      return path ? `//${path}` : `//${safeGetTagName(element) || '*'}`;
    }

    /**
     * Generate Full Absolute XPath
     */
    static generateAbsoluteXPath(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) {
        return '';
      }
      const rawTag = safeGetTagName(element) || '*';
      if (rawTag === 'html') return '/html';
      if (rawTag === 'body') return '/html/body';

      let ix = 1;
      const parent = safeGetParent(element);
      let siblings = [];
      if (parent) {
        siblings = safeGetChildren(parent);
      }

      const isSvg = XPathEngine.isSVGElement(element);
      const tagStep = isSvg ? `*[local-name()='${rawTag}']` : rawTag;

      for (let i = 0; i < siblings.length; i++) {
        let sibling = siblings[i];
        if (sibling === element) {
          const parentPath = parent ? XPathEngine.generateAbsoluteXPath(parent) : '';
          return parentPath ? `${parentPath}/${tagStep}[${ix}]` : `/${tagStep}[${ix}]`;
        }
        if (sibling && sibling.nodeType === ELEMENT_NODE && safeGetTagName(sibling) === rawTag) {
          ix++;
        }
      }
      return `/${tagStep}`;
    }

    /**
     * Generate cleanest unique CSS Selector
     */
    static generateBestCSS(element, doc) {
      if (!element || element.nodeType !== ELEMENT_NODE) return '';

      const tag = safeGetTagName(element) || 'div';
      const isSvg = XPathEngine.isSVGElement(element);
      const targetDoc = doc || safeGetOwnerDocument(element);

      // Test ID
      for (const attr of TEST_ATTRIBUTES) {
        const val = safeGetAttr(element, attr);
        if (val) {
          const sel = `[${attr}="${safeEscapeCSS(val)}"]`;
          if (XPathEngine.isUniqueCSS(sel, element, targetDoc)) return sel;
          const selWithTag = `${tag}[${attr}="${safeEscapeCSS(val)}"]`;
          if (XPathEngine.isUniqueCSS(selWithTag, element, targetDoc)) return selWithTag;
        }
      }

      // Unique ID
      const elemId = safeGetId(element);
      if (elemId && !XPathEngine.isDynamicId(elemId)) {
        const sel = `#${safeEscapeCSS(elemId)}`;
        if (XPathEngine.isUniqueCSS(sel, element, targetDoc)) return sel;
      }

      // data-icon (for SVGs e.g. svg.icon-search or svg[data-icon="search"])
      const iconVal = safeGetAttr(element, 'data-icon');
      if (iconVal && typeof iconVal === 'string' && iconVal.trim()) {
        const cleanIcon = iconVal.trim();
        const selTag = `${tag}[data-icon="${safeEscapeCSS(cleanIcon)}"]`;
        if (XPathEngine.isUniqueCSS(selTag, element, targetDoc)) return selTag;
        const selIcon = `[data-icon="${safeEscapeCSS(cleanIcon)}"]`;
        if (XPathEngine.isUniqueCSS(selIcon, element, targetDoc)) return selIcon;
      }

      // Clean classes (e.g. svg.icon-search)
      const classList = XPathEngine.getElementClassList(element);
      if (classList.length > 0) {
        for (const cls of classList) {
          if (!UTILITY_CLASS_PATTERNS.some((p) => p.test(cls))) {
            const sel = `${tag}.${safeEscapeCSS(cls)}`;
            if (XPathEngine.isUniqueCSS(sel, element, targetDoc)) return sel;
            const selClassOnly = `.${safeEscapeCSS(cls)}`;
            if (XPathEngine.isUniqueCSS(selClassOnly, element, targetDoc)) return selClassOnly;
          }
        }
      }

      // Parent combination for SVG icons (e.g. button > svg.icon-search or button#search > svg)
      const parent = safeGetParent(element);
      if (isSvg && parent && (!targetDoc || parent !== targetDoc.body)) {
        const pTag = safeGetTagName(parent) || 'div';
        const pId = safeGetId(parent);
        if (pId && !XPathEngine.isDynamicId(pId)) {
          const pSel = `#${safeEscapeCSS(pId)} > ${tag}`;
          if (XPathEngine.isUniqueCSS(pSel, element, targetDoc)) return pSel;
        }
        const pClasses = XPathEngine.getElementClassList(parent).filter((c) => !UTILITY_CLASS_PATTERNS.some((pat) => pat.test(c)));
        if (pClasses.length > 0) {
          const pSel = `${pTag}.${safeEscapeCSS(pClasses[0])} > ${tag}`;
          if (XPathEngine.isUniqueCSS(pSel, element, targetDoc)) return pSel;
        }
      }

      // Name attribute
      const nameVal = safeGetAttr(element, 'name');
      if (nameVal) {
        const sel = `${tag}[name="${safeEscapeCSS(nameVal)}"]`;
        if (XPathEngine.isUniqueCSS(sel, element, targetDoc)) return sel;
      }

      // Placeholder
      const phVal = safeGetAttr(element, 'placeholder');
      if (phVal) {
        const sel = `${tag}[placeholder="${safeEscapeCSS(phVal)}"]`;
        if (XPathEngine.isUniqueCSS(sel, element, targetDoc)) return sel;
      }

      return `${tag}`;
    }

    /**
     * Escape strings for JavaScript / Playwright code literals
     */
    static escapeJSString(str) {
      return (str || '')
        .replace(/\\/g, '\\\\')
        .replace(/'/g, "\\'")
        .replace(/\r/g, '\\r')
        .replace(/\n/g, '\\n');
    }

    /**
     * Compute approximate accessible name for element according to W3C AccName spec
     */
    static getAccessibleName(element, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!element || element.nodeType !== ELEMENT_NODE) return '';
      const targetDoc = doc || safeGetOwnerDocument(element);

      // 1. aria-label
      const ariaLabel = safeGetAttr(element, 'aria-label');
      if (ariaLabel && ariaLabel.trim()) {
        return ariaLabel.trim();
      }

      // 2. aria-labelledby
      const ariaLabelledBy = safeGetAttr(element, 'aria-labelledby');
      if (ariaLabelledBy && ariaLabelledBy.trim() && targetDoc) {
        const ids = ariaLabelledBy.trim().split(/\s+/);
        const text = ids.map((id) => {
          const el = targetDoc.getElementById(id);
          return el ? safeGetText(el).trim() : '';
        }).filter(Boolean).join(' ');
        if (text) return text;
      }

      const tag = safeGetTagName(element);

      // 3. For input buttons
      if (tag === 'input') {
        const type = (safeGetAttr(element, 'type') || 'text').toLowerCase();
        if (['button', 'submit', 'reset'].includes(type) && safeHasAttr(element, 'value')) {
          return (safeGetAttr(element, 'value') || '').trim();
        }
      }

      // 4. Associated label for form elements
      if (['input', 'select', 'textarea'].includes(tag)) {
        const elemId = safeGetId(element);
        if (elemId && targetDoc) {
          try {
            const label = targetDoc.querySelector(`label[for="${safeEscapeCSS(elemId)}"]`);
            if (label) {
              const t = safeGetText(label).trim();
              if (t) return t.replace(/\s+/g, ' ');
            }
          } catch (e) { }
        }
        if (typeof element.closest === 'function') {
          try {
            const parentLabel = element.closest('label');
            if (parentLabel) {
              let labelText = '';
              const childNodes = parentLabel.childNodes;
              if (childNodes && childNodes.length > 0) {
                for (let i = 0; i < childNodes.length; i++) {
                  const n = childNodes[i];
                  if (n.nodeType === 3) {
                    labelText += n.nodeValue + ' ';
                  } else if (n.nodeType === ELEMENT_NODE) {
                    const chTag = safeGetTagName(n);
                    if (!['input', 'select', 'textarea'].includes(chTag)) {
                      labelText += safeGetText(n) + ' ';
                    }
                  }
                }
              } else {
                labelText = safeGetText(parentLabel);
              }
              const t = labelText.trim();
              if (t) return t.replace(/\s+/g, ' ');
            }
          } catch (e) { }
        }
      }

      // 5. Image alt
      if (tag === 'img' && safeHasAttr(element, 'alt')) {
        return (safeGetAttr(element, 'alt') || '').trim();
      }

      // 6. Direct / subtree text for buttons, links, headings, options, menuitems, etc.
      const explicitRole = (safeGetAttr(element, 'role') || '').toLowerCase();
      if (
        ['button', 'a', 'summary', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'th', 'option'].includes(tag) ||
        ['button', 'option', 'menuitem', 'tab', 'treeitem'].includes(explicitRole)
      ) {
        const text = safeGetText(element).trim();
        if (text) return text.replace(/\s+/g, ' ');
      }

      // 7. Title or placeholder
      const titleVal = safeGetAttr(element, 'title');
      if (titleVal && titleVal.trim()) {
        return titleVal.trim();
      }
      const phVal = safeGetAttr(element, 'placeholder');
      if (phVal && phVal.trim()) {
        return phVal.trim();
      }

      return '';
    }

    /**
     * Compute implicit or explicit ARIA role of element
     */
    static getImplicitOrExplicitRole(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) return null;
      const explicitRole = safeGetAttr(element, 'role');
      if (explicitRole && explicitRole.trim()) {
        return explicitRole.trim().toLowerCase();
      }

      const tag = safeGetTagName(element);
      switch (tag) {
        case 'button':
          return 'button';
        case 'a':
          return safeHasAttr(element, 'href') ? 'link' : null;
        case 'summary':
          return 'button';
        case 'select':
          return 'combobox';
        case 'textarea':
          return 'textbox';
        case 'dialog':
          return 'dialog';
        case 'nav':
          return 'navigation';
        case 'main':
          return 'main';
        case 'form':
          return 'form';
        case 'ul':
        case 'ol':
          return 'list';
        case 'li':
          return 'listitem';
        case 'table':
          return 'table';
        case 'tr':
          return 'row';
        case 'td':
          return 'cell';
        case 'th':
          return 'columnheader';
        case 'h1':
        case 'h2':
        case 'h3':
        case 'h4':
        case 'h5':
        case 'h6':
          return 'heading';
        case 'img':
          return 'img';
        case 'input': {
          const type = (safeGetAttr(element, 'type') || 'text').toLowerCase();
          if (['button', 'submit', 'reset'].includes(type)) return 'button';
          if (type === 'checkbox') return 'checkbox';
          if (type === 'radio') return 'radio';
          if (type === 'range') return 'slider';
          if (type === 'number') return 'spinbutton';
          if (type === 'search') return 'searchbox';
          return 'textbox';
        }
        default:
          return null;
      }
    }

    /**
     * Test if element matches selector safely
     */
    static elementMatches(el, selector) {
      if (!el || el.nodeType !== ELEMENT_NODE || !selector) return false;
      if (typeof el.matches === 'function') {
        try {
          return el.matches(selector);
        } catch (e) { }
      }
      const tag = safeGetTagName(el);
      const parts = selector.split(',').map((s) => s.trim().toLowerCase());
      return parts.some((p) => {
        if (p === tag) return true;
        if (p.startsWith('[role=')) {
          const expectedRole = p.replace(/^\[role=["']?/, '').replace(/["']?\]$/, '');
          return (safeGetAttr(el, 'role') || '').toLowerCase() === expectedRole;
        }
        return false;
      });
    }

    /**
     * Get a descriptive step and Selenium By for an interactive form control
     */
    static getControlDescriptor(ctrl) {
      if (!ctrl || ctrl.nodeType !== ELEMENT_NODE) {
        return { step: 'input', by: 'By.tagName("input")', tag: 'input', type: 'input' };
      }
      const tag = safeGetTagName(ctrl) || 'input';
      if (tag === 'input') {
        const type = (safeGetAttr(ctrl, 'type') || '').toLowerCase();
        if (type === 'checkbox') {
          return { step: "input[@type='checkbox']", by: 'By.xpath("//input[@type=\'checkbox\']")', tag: 'input', type: 'checkbox' };
        }
        if (type === 'radio') {
          return { step: "input[@type='radio']", by: 'By.xpath("//input[@type=\'radio\']")', tag: 'input', type: 'radio' };
        }
        const fcn = safeGetAttr(ctrl, 'formcontrolname');
        if (fcn && fcn.trim()) {
          const esc = XPathEngine.escapeXPathString(fcn.trim());
          return { step: `input[@formcontrolname=${esc}]`, by: `By.xpath("//input[@formcontrolname=${esc}]")`, tag: 'input', type: type || 'text' };
        }
        const name = safeGetAttr(ctrl, 'name');
        if (name && name.trim() && name.trim().length <= 30) {
          const cleanName = name.trim();
          const esc = XPathEngine.escapeXPathString(cleanName);
          return { step: `input[@name=${esc}]`, by: `By.name("${cleanName.replace(/"/g, '\\"')}")`, tag: 'input', type: type || 'text' };
        }
        const ph = safeGetAttr(ctrl, 'placeholder');
        if (ph && ph.trim() && ph.trim().length <= 30) {
          const cleanPh = ph.trim();
          const esc = XPathEngine.escapeXPathString(cleanPh);
          return { step: `input[@placeholder=${esc}]`, by: `By.xpath("//input[@placeholder=${esc}]")`, tag: 'input', type: type || 'text' };
        }
        if (type && type !== 'text') {
          return { step: `input[@type='${type}']`, by: `By.xpath("//input[@type='${type}']")`, tag: 'input', type };
        }
        return { step: 'input', by: 'By.tagName("input")', tag: 'input', type: 'text' };
      }
      if (tag === 'select') {
        const name = safeGetAttr(ctrl, 'name');
        if (name && name.trim()) {
          const cleanName = name.trim();
          return { step: `select[@name='${cleanName}']`, by: `By.name("${cleanName.replace(/"/g, '\\"')}")`, tag: 'select', type: 'select' };
        }
        return { step: 'select', by: 'By.tagName("select")', tag: 'select', type: 'select' };
      }
      if (tag === 'textarea') {
        const name = safeGetAttr(ctrl, 'name');
        if (name && name.trim()) {
          const cleanName = name.trim();
          return { step: `textarea[@name='${cleanName}']`, by: `By.name("${cleanName.replace(/"/g, '\\"')}")`, tag: 'textarea', type: 'textarea' };
        }
        return { step: 'textarea', by: 'By.tagName("textarea")', tag: 'textarea', type: 'textarea' };
      }
      if (tag === 'button') {
        const title = safeGetAttr(ctrl, 'title');
        if (title && title.trim() && title.trim().length <= 30) {
          const cleanTitle = title.trim();
          const esc = XPathEngine.escapeXPathString(cleanTitle);
          return { step: `button[@title=${esc}]`, by: `By.xpath("//button[@title=${esc}]")`, tag: 'button', type: 'button' };
        }
        return { step: 'button', by: 'By.tagName("button")', tag: 'button', type: 'button' };
      }
      const role = (safeGetAttr(ctrl, 'role') || '').toLowerCase();
      if (role) {
        return { step: `*[@role='${role}']`, by: `By.xpath("//*[@role='${role}']")`, tag, type: role };
      }
      return { step: tag, by: `By.tagName("${tag}")`, tag, type: tag };
    }

    /**
     * Get a robust, concise descriptor for an element when referenced in relative axes
     */
    static getTargetShortDescriptor(element) {
      if (!element || element.nodeType !== ELEMENT_NODE) {
        return { tag: 'div', step: 'div', by: 'By.tagName("div")' };
      }
      const tag = safeGetTagName(element) || 'div';
      const isSvg = XPathEngine.isSVGElement(element);

      if (['input', 'select', 'textarea', 'button'].includes(tag) || safeHasAttr(element, 'role')) {
        return XPathEngine.getControlDescriptor(element);
      }

      // SVG specific descriptor
      if (isSvg) {
        const icon = safeGetAttr(element, 'data-icon');
        if (icon && icon.trim()) {
          const escIcon = XPathEngine.escapeXPathString(icon.trim());
          return {
            tag,
            step: `*[local-name()='${tag}' and @data-icon=${escIcon}]`,
            by: `By.xpath("//*[local-name()='${tag}' and @data-icon=${escIcon}]")`
          };
        }
        const svgClasses = XPathEngine.getElementClassList(element).filter((c) => !UTILITY_CLASS_PATTERNS.some((p) => p.test(c)));
        if (svgClasses.length > 0) {
          const escCls = XPathEngine.escapeXPathString(svgClasses[0]);
          return {
            tag,
            step: `*[local-name()='${tag}' and contains(@class, ${escCls})]`,
            by: `By.xpath("//*[local-name()='${tag}' and contains(@class, ${escCls})]")`
          };
        }
        const al = safeGetAttr(element, 'aria-label');
        if (al && al.trim()) {
          const escAl = XPathEngine.escapeXPathString(al.trim());
          return {
            tag,
            step: `*[local-name()='${tag}' and @aria-label=${escAl}]`,
            by: `By.xpath("//*[local-name()='${tag}' and @aria-label=${escAl}]")`
          };
        }
        return {
          tag,
          step: `*[local-name()='${tag}']`,
          by: `By.xpath("//*[local-name()='${tag}']")`
        };
      }

      // 1. Text on button or link or span
      if (['button', 'a', 'span', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'].includes(tag)) {
        const text = safeGetText(element).trim().replace(/\s+/g, ' ');
        if (text && text.length >= 1 && text.length <= 40) {
          const esc = XPathEngine.escapeXPathString(text);
          return {
            tag,
            step: `${tag}[normalize-space()=${esc}]`,
            by: `By.xpath("//${tag}[normalize-space()=${esc}]")`
          };
        }
      }

      // 2. Primary distinctive attributes (title, name, type, role, value)
      for (const attr of ['title', 'name', 'aria-label', 'placeholder', 'type', 'role', 'value']) {
        const val = safeGetAttr(element, attr);
        if (val && val.trim() && val.trim().length <= 40) {
          const esc = XPathEngine.escapeXPathString(val.trim());
          return {
            tag,
            step: `${tag}[@${attr}=${esc}]`,
            by: `By.xpath("//${tag}[@${attr}=${esc}]")`
          };
        }
      }

      // 3. Specific semantic classes
      const classList = XPathEngine.getElementClassList(element);
      if (classList.length > 0) {
        for (const cls of classList) {
          if (cls.length > 2 && cls.length < 25 && !UTILITY_CLASS_PATTERNS.some((p) => p.test(cls))) {
            const esc = XPathEngine.escapeXPathString(cls);
            return {
              tag,
              step: `${tag}[contains(@class, ${esc})]`,
              by: `By.xpath("//${tag}[contains(@class, ${esc})]")`
            };
          }
        }
      }

      // 4. Default to plain tag
      return {
        tag,
        step: tag,
        by: `By.tagName("${tag}")`
      };
    }

    /**
     * Generate Relative XPaths with Axes (Parent/Sibling Anchoring) and Selenium 4 Relative Locators
     */
    static generateRelativeAxesLocators(element, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!element || element.nodeType !== ELEMENT_NODE) return [];

      const results = [];
      const tag = safeGetTagName(element) || 'div';
      const targetDesc = XPathEngine.getTargetShortDescriptor(element);
      const CONTROL_SEL = 'input, select, textarea, button, [role="checkbox"], [role="combobox"], [role="listbox"], [role="textbox"], [contenteditable="true"]';
      const targetDoc = doc || safeGetOwnerDocument(element);

      // --- Category A: Table Row / Data Grid Sibling Traversals ---
      let currCell = element;
      while (currCell && (!targetDoc || (currCell !== targetDoc.body && currCell !== targetDoc.documentElement))) {
        const cTag = safeGetTagName(currCell);
        const cRole = safeGetAttr(currCell, 'role') || '';
        if (cTag === 'td' || cTag === 'th' || cRole === 'cell' || cRole === 'gridcell') {
          break;
        }
        currCell = safeGetParent(currCell);
      }

      if (currCell && (!targetDoc || (currCell !== targetDoc.body && currCell !== targetDoc.documentElement))) {
        let currRow = safeGetParent(currCell);
        while (currRow && (!targetDoc || (currRow !== targetDoc.body && currRow !== targetDoc.documentElement))) {
          const rTag = safeGetTagName(currRow);
          const rRole = safeGetAttr(currRow, 'role') || '';
          if (rTag === 'tr' || rRole === 'row') {
            break;
          }
          currRow = safeGetParent(currRow);
        }

        if (currRow) {
          const cells = safeGetChildren(currRow).filter((ch) => {
            const chTag = safeGetTagName(ch);
            const chRole = safeGetAttr(ch, 'role') || '';
            return chTag === 'td' || chTag === 'th' || chRole === 'cell' || chRole === 'gridcell';
          });

          const targetCellIndex = cells.indexOf(currCell);
          if (targetCellIndex !== -1) {
            for (let i = 0; i < cells.length; i++) {
              if (i === targetCellIndex) continue;
              const sibCell = cells[i];
              const sibText = safeGetText(sibCell).trim().replace(/\s+/g, ' ');

              if (sibText && sibText.length >= 2 && sibText.length <= 60 && !/^\d+$/.test(sibText)) {
                const escText = XPathEngine.escapeXPathString(sibText);
                const sibTag = safeGetTagName(sibCell) || 'td';
                const cellAnchorXP = `//${sibTag}[normalize-space()=${escText}]`;

                const isAnchorUnique = XPathEngine.queryXPath(cellAnchorXP, targetDoc).length === 1;
                const scoreBoost = isAnchorUnique ? 0 : -4;

                const isFollowing = i < targetCellIndex; // target comes after anchor
                const axis = isFollowing ? 'following-sibling' : 'preceding-sibling';
                const direction = isFollowing ? 'toRightOf' : 'toLeftOf';
                const cellTag = safeGetTagName(currCell) || 'td';

                let candidateXP = '';
                if (element === currCell) {
                  candidateXP = `${cellAnchorXP}/${axis}::${cellTag}`;
                } else {
                  candidateXP = `${cellAnchorXP}/${axis}::${cellTag}//${targetDesc.step}`;
                }

                if (XPathEngine.isUnique(candidateXP, element, targetDoc) || XPathEngine.queryXPath(candidateXP, targetDoc).length === 1) {
                  const sel4 = `RelativeLocator.with(${targetDesc.by}).${direction}(By.xpath("${cellAnchorXP.replace(/"/g, '\\"')}"))`;
                  results.push({
                    xpath: candidateXP,
                    selenium4: sel4,
                    type: 'relative-table-sibling',
                    anchorText: sibText,
                    score: 94 + scoreBoost,
                    label: `Table Sibling (${axis} from "${sibText.substring(0, 18)}")`
                  });
                }

                // Row Container Alternative: //tr[.//td[normalize-space()='...']]//button
                const rowXP = `//tr[.//${sibTag}[normalize-space()=${escText}]]//${targetDesc.step}`;
                if (XPathEngine.isUnique(rowXP, element, targetDoc) || XPathEngine.queryXPath(rowXP, targetDoc).length === 1) {
                  const sel4 = `RelativeLocator.with(${targetDesc.by}).near(By.xpath("${cellAnchorXP.replace(/"/g, '\\"')}"))`;
                  results.push({
                    xpath: rowXP,
                    selenium4: sel4,
                    type: 'relative-row-container',
                    anchorText: sibText,
                    score: 93 + scoreBoost,
                    label: `Table Row Container (Row with "${sibText.substring(0, 18)}")`
                  });
                }
              }
            }
          }
        }
      }

      // --- Category B: Form Controls & Sibling Label Anchoring ---
      const isTargetControl = XPathEngine.elementMatches(element, CONTROL_SEL);
      const parentControl = (!isTargetControl && typeof element.closest === 'function') ? element.closest(CONTROL_SEL) : null;
      const effectiveControl = isTargetControl ? element : (parentControl || element);
      const ctrlDesc = XPathEngine.getControlDescriptor(effectiveControl);

      let ancestor = effectiveControl;
      let depth = 0;
      while (ancestor && (!targetDoc || (ancestor !== targetDoc.body && ancestor !== targetDoc.documentElement)) && depth <= 3) {
        // Look at previous siblings of ancestor
        let pSib = ancestor.previousElementSibling;
        let pSteps = 1;
        while (pSib && pSteps <= 4) {
          const pTag = safeGetTagName(pSib) || '*';
          const pText = safeGetText(pSib).trim().replace(/\s+/g, ' ');

          if (pText && pText.length >= 2 && pText.length <= 60) {
            const escP = XPathEngine.escapeXPathString(pText);
            const anchorXP = `//${pTag}[normalize-space()=${escP}]`;

            const cands = [];
            if (ancestor === effectiveControl) {
              cands.push({ xp: `${anchorXP}/following-sibling::${ctrlDesc.step}`, wild: false });
            } else {
              const ancTag = safeGetTagName(ancestor) || '*';
              cands.push({ xp: `${anchorXP}/following-sibling::${ancTag}//${ctrlDesc.step}`, wild: false });
              cands.push({ xp: `${anchorXP}/following-sibling::*//${ctrlDesc.step}`, wild: true });
            }

            for (const cand of cands) {
              if (XPathEngine.isUnique(cand.xp, effectiveControl, targetDoc) || XPathEngine.queryXPath(cand.xp, targetDoc).length === 1) {
                const sel4 = `RelativeLocator.with(${ctrlDesc.by}).toRightOf(By.xpath("${anchorXP.replace(/"/g, '\\"')}"))`;
                results.push({
                  xpath: cand.xp,
                  selenium4: sel4,
                  type: 'relative-label-sibling',
                  anchorText: pText,
                  score: cand.wild ? 94 : 95,
                  label: `Form Control (<${ctrlDesc.step}> following <${pTag}> "${pText.substring(0, 16)}")`
                });
              }
            }
            break;
          }
          pSib = pSib.previousElementSibling;
          pSteps++;
        }

        // Look at following siblings of ancestor
        let nSib = ancestor.nextElementSibling;
        let nSteps = 1;
        while (nSib && nSteps <= 4) {
          const nTag = safeGetTagName(nSib) || '*';
          const nText = safeGetText(nSib).trim().replace(/\s+/g, ' ');

          if (nText && nText.length >= 2 && nText.length <= 60) {
            const escN = XPathEngine.escapeXPathString(nText);
            const anchorXP = `//${nTag}[normalize-space()=${escN}]`;

            const cands = [];
            if (ancestor === effectiveControl) {
              cands.push({ xp: `${anchorXP}/preceding-sibling::${ctrlDesc.step}`, wild: false });
            } else {
              const ancTag = safeGetTagName(ancestor) || '*';
              cands.push({ xp: `${anchorXP}/preceding-sibling::${ancTag}//${ctrlDesc.step}`, wild: false });
              cands.push({ xp: `${anchorXP}/preceding-sibling::*//${ctrlDesc.step}`, wild: true });
            }

            for (const cand of cands) {
              if (XPathEngine.isUnique(cand.xp, effectiveControl, targetDoc) || XPathEngine.queryXPath(cand.xp, targetDoc).length === 1) {
                const sel4 = `RelativeLocator.with(${ctrlDesc.by}).toLeftOf(By.xpath("${anchorXP.replace(/"/g, '\\"')}"))`;
                results.push({
                  xpath: cand.xp,
                  selenium4: sel4,
                  type: 'relative-label-sibling',
                  anchorText: nText,
                  score: cand.wild ? 94 : 95,
                  label: `Form Control (<${ctrlDesc.step}> preceding <${nTag}> "${nText.substring(0, 16)}")`
                });
              }
            }
            break;
          }
          nSib = nSib.nextElementSibling;
          nSteps++;
        }

        ancestor = safeGetParent(ancestor);
        depth++;
      }

      // Case B2: element is a wrapper container that CONTAINS form controls
      if (typeof element.querySelectorAll === 'function') {
        const childControls = Array.from(element.querySelectorAll(CONTROL_SEL)).slice(0, 3);
        if (childControls.length > 0) {
          let pSib = element.previousElementSibling;
          let pSteps = 1;
          while (pSib && pSteps <= 4) {
            const pTag = safeGetTagName(pSib) || '*';
            const pText = safeGetText(pSib).trim().replace(/\s+/g, ' ');

            if (pText && pText.length >= 2 && pText.length <= 60) {
              const escP = XPathEngine.escapeXPathString(pText);
              const anchorXP = `//${pTag}[normalize-space()=${escP}]`;

              for (const childCtrl of childControls) {
                const cDesc = XPathEngine.getControlDescriptor(childCtrl);
                const cand1 = `${anchorXP}/following-sibling::${tag}//${cDesc.step}`;
                const cand2 = `${anchorXP}/following-sibling::*//${cDesc.step}`;

                if (XPathEngine.queryXPath(cand1, targetDoc).length === 1) {
                  results.push({
                    xpath: cand1,
                    selenium4: `RelativeLocator.with(${cDesc.by}).toRightOf(By.xpath("${anchorXP.replace(/"/g, '\\"')}"))`,
                    type: 'relative-label-sibling',
                    anchorText: pText,
                    score: 95,
                    label: `Form Control inside Sibling (<${cDesc.step}> from "${pText.substring(0, 16)}")`
                  });
                }
                if (XPathEngine.queryXPath(cand2, targetDoc).length === 1 && cand2 !== cand1) {
                  results.push({
                    xpath: cand2,
                    selenium4: `RelativeLocator.with(${cDesc.by}).toRightOf(By.xpath("${anchorXP.replace(/"/g, '\\"')}"))`,
                    type: 'relative-label-sibling',
                    anchorText: pText,
                    score: 94,
                    label: `Wildcard Sibling Control (<${cDesc.step}> from "${pText.substring(0, 16)}")`
                  });
                }
              }
              break;
            }
            pSib = pSib.previousElementSibling;
            pSteps++;
          }
        }
      }

      // Case B3: element is the label or text element itself
      const elemText = safeGetText(element).trim().replace(/\s+/g, ' ');
      const isLabelLike = (
        tag === 'label' ||
        safeGetAttr(element, 'role') === 'label' ||
        (elemText.length >= 2 && elemText.length <= 60 && (!element.querySelectorAll || element.querySelectorAll(CONTROL_SEL).length === 0))
      );

      if (isLabelLike && elemText.length >= 2) {
        const escLabel = XPathEngine.escapeXPathString(elemText);
        const labelXP = `//${tag}[normalize-space()=${escLabel}]`;

        // 1. Sibling controls
        let sib = element.nextElementSibling;
        let sSteps = 1;
        while (sib && sSteps <= 4) {
          const sibCtrls = (XPathEngine.elementMatches(sib, CONTROL_SEL))
            ? [sib]
            : (sib.querySelectorAll ? Array.from(sib.querySelectorAll(CONTROL_SEL)).slice(0, 3) : []);

          for (const ctrl of sibCtrls) {
            const cDesc = XPathEngine.getControlDescriptor(ctrl);
            const sibTag = safeGetTagName(sib) || '*';
            const candXP = (sib === ctrl)
              ? `${labelXP}/following-sibling::${cDesc.step}`
              : `${labelXP}/following-sibling::${sibTag}//${cDesc.step}`;
            const candWild = (sib === ctrl) ? '' : `${labelXP}/following-sibling::*//${cDesc.step}`;

            if (XPathEngine.queryXPath(candXP, targetDoc).length === 1) {
              results.push({
                xpath: candXP,
                selenium4: `RelativeLocator.with(${cDesc.by}).toRightOf(By.xpath("${labelXP.replace(/"/g, '\\"')}"))`,
                type: 'relative-label-sibling',
                anchorText: elemText,
                score: 95,
                label: `Input for Label (<${cDesc.step}> from "${elemText.substring(0, 16)}")`
              });
            }
            if (candWild && XPathEngine.queryXPath(candWild, targetDoc).length === 1 && candWild !== candXP) {
              results.push({
                xpath: candWild,
                selenium4: `RelativeLocator.with(${cDesc.by}).toRightOf(By.xpath("${labelXP.replace(/"/g, '\\"')}"))`,
                type: 'relative-label-sibling',
                anchorText: elemText,
                score: 94,
                label: `Wildcard Input for Label (<${cDesc.step}> from "${elemText.substring(0, 16)}")`
              });
            }
          }
          sib = sib.nextElementSibling;
          sSteps++;
        }

        // 2. Parent's following siblings
        const parentElem = safeGetParent(element);
        if (parentElem && (!targetDoc || parentElem !== targetDoc.body)) {
          let parentSib = parentElem.nextElementSibling;
          let psSteps = 1;
          while (parentSib && psSteps <= 3) {
            const psCtrls = (XPathEngine.elementMatches(parentSib, CONTROL_SEL))
              ? [parentSib]
              : (parentSib.querySelectorAll ? Array.from(parentSib.querySelectorAll(CONTROL_SEL)).slice(0, 3) : []);

            for (const ctrl of psCtrls) {
              const cDesc = XPathEngine.getControlDescriptor(ctrl);
              const candXP = `${labelXP}/../following-sibling::*//${cDesc.step}`;
              if (XPathEngine.queryXPath(candXP, targetDoc).length === 1) {
                results.push({
                  xpath: candXP,
                  selenium4: `RelativeLocator.with(${cDesc.by}).toRightOf(By.xpath("${labelXP.replace(/"/g, '\\"')}"))`,
                  type: 'relative-label-sibling',
                  anchorText: elemText,
                  score: 94,
                  label: `Input in Next Column (<${cDesc.step}> from "${elemText.substring(0, 16)}")`
                });
              }
            }
            parentSib = parentSib.nextElementSibling;
            psSteps++;
          }
        }

        // 3. Preceding siblings
        let pSib = element.previousElementSibling;
        let psSteps = 1;
        while (pSib && psSteps <= 4) {
          const pCtrls = (XPathEngine.elementMatches(pSib, CONTROL_SEL))
            ? [pSib]
            : (pSib.querySelectorAll ? Array.from(pSib.querySelectorAll(CONTROL_SEL)).slice(0, 3) : []);

          for (const ctrl of pCtrls) {
            const cDesc = XPathEngine.getControlDescriptor(ctrl);
            const pTag = safeGetTagName(pSib) || '*';
            const candXP = (pSib === ctrl)
              ? `${labelXP}/preceding-sibling::${cDesc.step}`
              : `${labelXP}/preceding-sibling::${pTag}//${cDesc.step}`;

            if (XPathEngine.queryXPath(candXP, targetDoc).length === 1) {
              results.push({
                xpath: candXP,
                selenium4: `RelativeLocator.with(${cDesc.by}).toLeftOf(By.xpath("${labelXP.replace(/"/g, '\\"')}"))`,
                type: 'relative-label-sibling',
                anchorText: elemText,
                score: 95,
                label: `Input preceding Label (<${cDesc.step}> from "${elemText.substring(0, 16)}")`
              });
            }
          }
          pSib = pSib.previousElementSibling;
          psSteps++;
        }

        // 4. Common parent container wrapper
        if (parentElem && (!targetDoc || parentElem !== targetDoc.body)) {
          const groupCtrls = parentElem.querySelectorAll
            ? Array.from(parentElem.querySelectorAll(CONTROL_SEL)).filter((c) => c !== element && (!element.contains || !element.contains(c)))
            : [];
          for (const ctrl of groupCtrls.slice(0, 3)) {
            const cDesc = XPathEngine.getControlDescriptor(ctrl);
            const candXP = `${labelXP}/..//${cDesc.step}`;
            if (XPathEngine.queryXPath(candXP, targetDoc).length === 1) {
              results.push({
                xpath: candXP,
                selenium4: `RelativeLocator.with(${cDesc.by}).below(By.xpath("${labelXP.replace(/"/g, '\\"')}"))`,
                type: 'relative-form-group',
                anchorText: elemText,
                score: 93,
                label: `Form Group Input (<${cDesc.step}> from "${elemText.substring(0, 16)}")`
              });
            }
          }
        }
      }

      // Case B4: Direct fallback sibling anchor for non-control elements
      if (results.length === 0) {
        let prevSib = element.previousElementSibling;
        let prevSteps = 1;
        while (prevSib && prevSteps <= 3) {
          const pTag = safeGetTagName(prevSib) || '*';
          const pText = safeGetText(prevSib).trim().replace(/\s+/g, ' ');

          if (pText && pText.length >= 2 && pText.length <= 50) {
            const escP = XPathEngine.escapeXPathString(pText);
            const anchorXP = `//${pTag}[normalize-space()=${escP}]`;
            const fsXP = `${anchorXP}/following-sibling::${targetDesc.step}`;
            if (XPathEngine.isUnique(fsXP, element, targetDoc) || XPathEngine.queryXPath(fsXP, targetDoc).length === 1) {
              const sel4 = `RelativeLocator.with(${targetDesc.by}).toRightOf(By.xpath("${anchorXP.replace(/"/g, '\\"')}"))`;
              results.push({
                xpath: fsXP,
                selenium4: sel4,
                type: 'relative-label-sibling',
                anchorText: pText,
                score: 89,
                label: `Sibling Anchor (following-sibling from <${pTag}> "${pText.substring(0, 16)}")`
              });
              break;
            }
          }
          prevSib = prevSib.previousElementSibling;
          prevSteps++;
        }
      }

      // --- Category C: Parent Axis Traversal ---
      const elementChildren = safeGetChildren(element);
      if (elementChildren.length >= 1 && elementChildren.length <= 3) {
        for (const child of elementChildren) {
          const cTag = safeGetTagName(child) || '*';
          const isCSvg = XPathEngine.isSVGElement(child);
          const cText = safeGetText(child).trim().replace(/\s+/g, ' ');

          if (isCSvg) {
            let svgStep = `*[local-name()='${cTag}']`;
            let svgLabel = `SVG`;
            if (safeHasAttr(child, 'data-icon')) {
              const icon = (safeGetAttr(child, 'data-icon') || '').trim();
              if (icon) {
                svgStep = `*[local-name()='${cTag}' and @data-icon=${XPathEngine.escapeXPathString(icon)}]`;
                svgLabel = `SVG (${icon})`;
              }
            } else {
              const svgCls = XPathEngine.getElementClassList(child).filter((c) => !UTILITY_CLASS_PATTERNS.some((p) => p.test(c)));
              if (svgCls.length > 0) {
                svgStep = `*[local-name()='${cTag}' and contains(@class, ${XPathEngine.escapeXPathString(svgCls[0])})]`;
                svgLabel = `SVG (.${svgCls[0]})`;
              }
            }
            const parentXP = `//${svgStep}/parent::${tag}`;
            if (XPathEngine.isUnique(parentXP, element, targetDoc) || XPathEngine.queryXPath(parentXP, targetDoc).length === 1) {
              const sel4 = `RelativeLocator.with(${targetDesc.by}).near(By.xpath("//${svgStep}"))`;
              results.push({
                xpath: parentXP,
                selenium4: sel4,
                type: 'relative-parent-svg',
                anchorText: svgLabel,
                score: 92,
                label: `Parent Axis (parent::${tag} of ${svgLabel})`
              });
            }
          } else if (cText && cText.length >= 2 && cText.length <= 40) {
            const escC = XPathEngine.escapeXPathString(cText);
            const parentXP = `//${cTag}[normalize-space()=${escC}]/parent::${tag}`;
            if (XPathEngine.isUnique(parentXP, element, targetDoc) || XPathEngine.queryXPath(parentXP, targetDoc).length === 1) {
              const sel4 = `RelativeLocator.with(${targetDesc.by}).near(By.xpath("//${cTag}[normalize-space()=${escC.replace(/"/g, '\\"')}"]"))`;
              results.push({
                xpath: parentXP,
                selenium4: sel4,
                type: 'relative-parent',
                anchorText: cText,
                score: 91,
                label: `Parent Axis (parent::${tag} of "${cText.substring(0, 16)}")`
              });
            }
          }
        }
      }

      // If element is SVG itself and parent is a button or interactive container
      const parentNode = safeGetParent(element);
      if (XPathEngine.isSVGElement(element) && parentNode && (!targetDoc || parentNode !== targetDoc.body)) {
        const pTag = safeGetTagName(parentNode) || '*';
        if (['button', 'a', 'div', 'span'].includes(pTag)) {
          const parentXP = `//${targetDesc.step}/parent::${pTag}`;
          if (XPathEngine.queryXPath(parentXP, targetDoc).length === 1) {
            results.push({
              xpath: parentXP,
              selenium4: `RelativeLocator.with(By.tagName("${pTag}")).near(By.xpath("//${targetDesc.step}"))`,
              type: 'relative-parent-container',
              anchorText: targetDesc.step,
              score: 90,
              label: `Parent Container (parent::${pTag})`
            });
          }
        }
      }

      // Deduplicate by xpath
      const uniqueResults = [];
      const seen = new Set();
      for (const res of results) {
        if (!seen.has(res.xpath)) {
          seen.add(res.xpath);
          uniqueResults.push(res);
        }
      }

      // Boost locators targeting actual form controls over raw containers
      uniqueResults.sort((a, b) => {
        const aIsControl = a.xpath.includes('input') || a.xpath.includes('select') || a.xpath.includes('textarea') || a.xpath.includes('button');
        const bIsControl = b.xpath.includes('input') || b.xpath.includes('select') || b.xpath.includes('textarea') || b.xpath.includes('button');
        if (aIsControl && !bIsControl) return -1;
        if (!aIsControl && bIsControl) return 1;
        return b.score - a.score;
      });

      return uniqueResults;
    }

    /**
     * Map role string to Playwright Java AriaRole enum name
     */
    static getAriaRoleJavaEnum(role) {
      if (!role) return 'BUTTON';
      const clean = role.toLowerCase().trim();
      const map = {
        button: 'BUTTON',
        link: 'LINK',
        textbox: 'TEXTBOX',
        checkbox: 'CHECKBOX',
        radio: 'RADIO',
        combobox: 'COMBOBOX',
        heading: 'HEADING',
        dialog: 'DIALOG',
        navigation: 'NAVIGATION',
        main: 'MAIN',
        form: 'FORM',
        list: 'LIST',
        listitem: 'LISTITEM',
        table: 'TABLE',
        row: 'ROW',
        cell: 'CELL',
        columnheader: 'COLUMNHEADER',
        img: 'IMG',
        slider: 'SLIDER',
        spinbutton: 'SPINBUTTON',
        searchbox: 'SEARCHBOX',
        alert: 'ALERT',
        alertdialog: 'ALERTDIALOG',
        banner: 'BANNER',
        complementary: 'COMPLEMENTARY',
        contentinfo: 'CONTENTINFO',
        definition: 'DEFINITION',
        document: 'DOCUMENT',
        feed: 'FEED',
        figure: 'FIGURE',
        grid: 'GRID',
        gridcell: 'GRIDCELL',
        group: 'GROUP',
        log: 'LOG',
        marquee: 'MARQUEE',
        math: 'MATH',
        menu: 'MENU',
        menubar: 'MENUBAR',
        menuitem: 'MENUITEM',
        menuitemcheckbox: 'MENUITEMCHECKBOX',
        menuitemradio: 'MENUITEMRADIO',
        none: 'NONE',
        note: 'NOTE',
        option: 'OPTION',
        presentation: 'PRESENTATION',
        progressbar: 'PROGRESSBAR',
        radiogroup: 'RADIOGROUP',
        region: 'REGION',
        rowgroup: 'ROWGROUP',
        rowheader: 'ROWHEADER',
        scrollbar: 'SCROLLBAR',
        search: 'SEARCH',
        separator: 'SEPARATOR',
        status: 'STATUS',
        switch: 'SWITCH',
        tab: 'TAB',
        tablist: 'TABLIST',
        tabpanel: 'TABPANEL',
        term: 'TERM',
        timer: 'TIMER',
        toolbar: 'TOOLBAR',
        tooltip: 'TOOLTIP',
        tree: 'TREE',
        treegrid: 'TREEGRID',
        treeitem: 'TREEITEM'
      };
      return map[clean] || clean.toUpperCase().replace(/-/g, '_');
    }

    /**
     * Convert Playwright locator code (or XPath) into Playwright Modern Java syntax
     */
    static toPlaywrightJava(playwrightCode, xpath = null) {
      if (playwrightCode) {
        const clean = playwrightCode.trim().replace(/;$/, '');

        // 1. page.locator('#id') or page.locator("...")
        const locatorM = clean.match(/(?:page\.)?locator\(\s*['"](.*?)['"]\s*\)/i);
        if (locatorM) {
          return `page.locator("${locatorM[1].replace(/"/g, '\\"')}");`;
        }

        // 2. page.getByTestId('val')
        const testIdM = clean.match(/(?:page\.)?getByTestId\(\s*['"](.*?)['"]\s*\)/i);
        if (testIdM) {
          return `page.getByTestId("${testIdM[1].replace(/"/g, '\\"')}");`;
        }

        // 3. page.getByRole('role', { name: 'name', exact: true/false })
        const roleM = clean.match(/(?:page\.)?getByRole\(\s*['"]([a-z0-9_-]+)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (roleM) {
          const roleEnum = XPathEngine.getAriaRoleJavaEnum(roleM[1]);
          const optsRaw = roleM[2] || '';
          const nameM = optsRaw.match(/name:\s*['"](.*?)['"]/i);
          const exactM = optsRaw.match(/exact:\s*(true|false)/i);
          if (nameM) {
            const escName = nameM[1].replace(/"/g, '\\"');
            const exactPart = (exactM && exactM[1] === 'true') ? '.setExact(true)' : '';
            return `page.getByRole(AriaRole.${roleEnum}, new Page.GetByRoleOptions().setName("${escName}")${exactPart});`;
          }
          return `page.getByRole(AriaRole.${roleEnum});`;
        }

        // 4. page.getByLabel('val', { exact: true/false })
        const labelM = clean.match(/(?:page\.)?getByLabel\(\s*['"](.*?)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (labelM) {
          const escVal = labelM[1].replace(/"/g, '\\"');
          const exactM = (labelM[2] || '').match(/exact:\s*(true|false)/i);
          const exactPart = (exactM && exactM[1] === 'true') ? ', new Page.GetByLabelOptions().setExact(true)' : '';
          return `page.getByLabel("${escVal}"${exactPart});`;
        }

        // 5. page.getByPlaceholder('val')
        const phM = clean.match(/(?:page\.)?getByPlaceholder\(\s*['"](.*?)['"]\s*\)/i);
        if (phM) {
          const escVal = phM[1].replace(/"/g, '\\"');
          return `page.getByPlaceholder("${escVal}");`;
        }

        // 6. page.getByAltText('val')
        const altM = clean.match(/(?:page\.)?getByAltText\(\s*['"](.*?)['"]\s*\)/i);
        if (altM) {
          const escVal = altM[1].replace(/"/g, '\\"');
          return `page.getByAltText("${escVal}");`;
        }

        // 7. page.getByTitle('val')
        const titleM = clean.match(/(?:page\.)?getByTitle\(\s*['"](.*?)['"]\s*\)/i);
        if (titleM) {
          const escVal = titleM[1].replace(/"/g, '\\"');
          return `page.getByTitle("${escVal}");`;
        }

        // 8. page.getByText('val', { exact: true/false })
        const textM = clean.match(/(?:page\.)?getByText\(\s*['"](.*?)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (textM) {
          const escVal = textM[1].replace(/"/g, '\\"');
          const exactM = (textM[2] || '').match(/exact:\s*(true|false)/i);
          const exactPart = (exactM && exactM[1] === 'true') ? ', new Page.GetByTextOptions().setExact(true)' : '';
          return `page.getByText("${escVal}"${exactPart});`;
        }
      }

      // If raw XPath or ID XPath
      if (xpath) {
        const idMatch = xpath.match(/^\/\/[a-z0-9_-]*\[@id=['"]([^'"]+)['"]\]$/i);
        if (idMatch) {
          return `page.locator("#${safeEscapeCSS(idMatch[1])}");`;
        }
        return `page.locator("xpath=${xpath.replace(/"/g, '\\"')}");`;
      }

      return 'page.locator("");';
    }

    /**
     * Convert standard Playwright JS locator into Python Playwright syntax
     */
    static toPlaywrightPython(playwrightCode, xpath = null) {
      if (playwrightCode) {
        const clean = playwrightCode.trim().replace(/;$/, '');

        // 1. page.locator('#id') or page.locator("...")
        const locatorM = clean.match(/(?:page\.)?locator\(\s*['"](.*?)['"]\s*\)/i);
        if (locatorM) {
          return `page.locator("${locatorM[1].replace(/"/g, '\\"')}")`;
        }

        // 2. page.getByTestId('val')
        const testIdM = clean.match(/(?:page\.)?getByTestId\(\s*['"](.*?)['"]\s*\)/i);
        if (testIdM) {
          return `page.get_by_test_id("${testIdM[1].replace(/"/g, '\\"')}")`;
        }

        // 3. page.getByRole('role', { name: 'name', exact: true/false })
        const roleM = clean.match(/(?:page\.)?getByRole\(\s*['"]([a-z0-9_-]+)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (roleM) {
          const rawRole = roleM[1];
          const optsRaw = roleM[2] || '';
          const nameM = optsRaw.match(/name:\s*['"](.*?)['"]/i);
          const exactM = optsRaw.match(/exact:\s*(true|false)/i);
          const parts = [`"${rawRole}"`];
          if (nameM) {
            parts.push(`name="${nameM[1].replace(/"/g, '\\"')}"`);
          }
          if (exactM && exactM[1] === 'true') {
            parts.push('exact=True');
          }
          return `page.get_by_role(${parts.join(', ')})`;
        }

        // 4. page.getByLabel('val', { exact: true/false })
        const labelM = clean.match(/(?:page\.)?getByLabel\(\s*['"](.*?)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (labelM) {
          const escVal = labelM[1].replace(/"/g, '\\"');
          const exactM = (labelM[2] || '').match(/exact:\s*(true|false)/i);
          const exactPart = (exactM && exactM[1] === 'true') ? ', exact=True' : '';
          return `page.get_by_label("${escVal}"${exactPart})`;
        }

        // 5. page.getByPlaceholder('val')
        const phM = clean.match(/(?:page\.)?getByPlaceholder\(\s*['"](.*?)['"]\s*\)/i);
        if (phM) {
          return `page.get_by_placeholder("${phM[1].replace(/"/g, '\\"')}")`;
        }

        // 6. page.getByAltText('val')
        const altM = clean.match(/(?:page\.)?getByAltText\(\s*['"](.*?)['"]\s*\)/i);
        if (altM) {
          return `page.get_by_alt_text("${altM[1].replace(/"/g, '\\"')}")`;
        }

        // 7. page.getByTitle('val')
        const titleM = clean.match(/(?:page\.)?getByTitle\(\s*['"](.*?)['"]\s*\)/i);
        if (titleM) {
          return `page.get_by_title("${titleM[1].replace(/"/g, '\\"')}")`;
        }

        // 8. page.getByText('val', { exact: true/false })
        const textM = clean.match(/(?:page\.)?getByText\(\s*['"](.*?)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (textM) {
          const escVal = textM[1].replace(/"/g, '\\"');
          const exactM = (textM[2] || '').match(/exact:\s*(true|false)/i);
          const exactPart = (exactM && exactM[1] === 'true') ? ', exact=True' : '';
          return `page.get_by_text("${escVal}"${exactPart})`;
        }
      }

      if (xpath) {
        const idMatch = xpath.match(/^\/\/[a-z0-9_-]*\[@id=['"]([^'"]+)['"]\]$/i);
        if (idMatch) {
          return `page.locator("#${safeEscapeCSS(idMatch[1])}")`;
        }
        return `page.locator("xpath=${xpath.replace(/"/g, '\\"')}")`;
      }

      return 'page.locator("")';
    }

    /**
     * Convert standard Playwright JS locator into C# Playwright syntax
     */
    static toPlaywrightCSharp(playwrightCode, xpath = null) {
      if (playwrightCode) {
        const clean = playwrightCode.trim().replace(/;$/, '');

        // 1. page.locator('#id') or page.locator("...")
        const locatorM = clean.match(/(?:page\.)?locator\(\s*['"](.*?)['"]\s*\)/i);
        if (locatorM) {
          return `Page.Locator("${locatorM[1].replace(/"/g, '\\"')}")`;
        }

        // 2. page.getByTestId('val')
        const testIdM = clean.match(/(?:page\.)?getByTestId\(\s*['"](.*?)['"]\s*\)/i);
        if (testIdM) {
          return `Page.GetByTestId("${testIdM[1].replace(/"/g, '\\"')}")`;
        }

        // 3. page.getByRole('role', { name: 'name' })
        const roleM = clean.match(/(?:page\.)?getByRole\(\s*['"]([a-z0-9_-]+)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (roleM) {
          const roleEnum = XPathEngine.getAriaRoleJavaEnum(roleM[1]);
          const optsRaw = roleM[2] || '';
          const nameM = optsRaw.match(/name:\s*['"](.*?)['"]/i);
          if (nameM) {
            return `Page.GetByRole(AriaRole.${roleEnum}, new() { Name = "${nameM[1].replace(/"/g, '\\"')}" })`;
          }
          return `Page.GetByRole(AriaRole.${roleEnum})`;
        }

        // 4. page.getByLabel('val')
        const labelM = clean.match(/(?:page\.)?getByLabel\(\s*['"](.*?)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (labelM) {
          return `Page.GetByLabel("${labelM[1].replace(/"/g, '\\"')}")`;
        }

        // 5. page.getByPlaceholder('val')
        const phM = clean.match(/(?:page\.)?getByPlaceholder\(\s*['"](.*?)['"]\s*\)/i);
        if (phM) {
          return `Page.GetByPlaceholder("${phM[1].replace(/"/g, '\\"')}")`;
        }

        // 6. page.getByAltText('val')
        const altM = clean.match(/(?:page\.)?getByAltText\(\s*['"](.*?)['"]\s*\)/i);
        if (altM) {
          return `Page.GetByAltText("${altM[1].replace(/"/g, '\\"')}")`;
        }

        // 7. page.getByTitle('val')
        const titleM = clean.match(/(?:page\.)?getByTitle\(\s*['"](.*?)['"]\s*\)/i);
        if (titleM) {
          return `Page.GetByTitle("${titleM[1].replace(/"/g, '\\"')}")`;
        }

        // 8. page.getByText('val')
        const textM = clean.match(/(?:page\.)?getByText\(\s*['"](.*?)['"]\s*(?:,\s*\{([\s\S]*?)\})?\s*\)/i);
        if (textM) {
          return `Page.GetByText("${textM[1].replace(/"/g, '\\"')}")`;
        }
      }

      if (xpath) {
        const idMatch = xpath.match(/^\/\/[a-z0-9_-]*\[@id=['"]([^'"]+)['"]\]$/i);
        if (idMatch) {
          return `Page.Locator("#${safeEscapeCSS(idMatch[1])}")`;
        }
        return `Page.Locator("xpath=${xpath.replace(/"/g, '\\"')}")`;
      }

      return 'Page.Locator("")';
    }

    /**
     * Detect if an element lives inside an iframe or nested frame
     * Returns iframe metadata or null if in top-level document
     */
    static detectIframe(element) {
      if (!element) return null;
      try {
        const ownerDoc = safeGetOwnerDocument(element) || (element && element.ownerDocument) || (typeof document !== 'undefined' ? document : null);
        if (!ownerDoc) return null;
        const win = ownerDoc.defaultView || (ownerDoc.parentWindow ? ownerDoc.parentWindow : null);
        if (!win) return null;

        // Check if current window is child frame
        let isChild = false;
        try {
          isChild = win !== win.top;
        } catch (crossErr) {
          isChild = true;
        }
        if (!isChild) return null;

        let frameEl = null;
        try {
          frameEl = win.frameElement;
        } catch (e) { }

        // Fallback: search parent frames for matching contentWindow if accessible
        if (!frameEl) {
          try {
            if (win.parent && win.parent.document) {
              const frames = Array.from(win.parent.document.querySelectorAll('iframe, frame'));
              for (const f of frames) {
                try {
                  if (f.contentWindow === win) {
                    frameEl = f;
                    break;
                  }
                } catch (fe) { }
              }
            }
          } catch (pe) { }
        }

        let id = null;
        let name = null;
        let title = null;
        let src = null;
        let selector = 'iframe';
        let xpath = '//iframe';
        let switchTarget = '0';

        if (frameEl) {
          id = safeGetAttr(frameEl, 'id') || (typeof frameEl.id === 'string' ? frameEl.id : (typeof frameEl.getAttribute === 'function' ? frameEl.getAttribute('id') : null));
          name = safeGetAttr(frameEl, 'name') || (typeof frameEl.name === 'string' ? frameEl.name : (typeof frameEl.getAttribute === 'function' ? frameEl.getAttribute('name') : null));
          title = safeGetAttr(frameEl, 'title') || (typeof frameEl.title === 'string' ? frameEl.title : (typeof frameEl.getAttribute === 'function' ? frameEl.getAttribute('title') : null));
          src = safeGetAttr(frameEl, 'src') || (typeof frameEl.src === 'string' ? frameEl.src : (typeof frameEl.getAttribute === 'function' ? frameEl.getAttribute('src') : null));

          if (id && !XPathEngine.isDynamicId(id)) {
            const safeId = id.split("'").join("\\'");
            const safeIdDouble = id.split('"').join('\\"');
            selector = `#${safeEscapeCSS(id)}`;
            xpath = `//iframe[@id='${safeId}']`;
            switchTarget = `"${safeIdDouble}"`;
          } else if (name) {
            const safeName = name.split("'").join("\\'");
            const safeNameDouble = name.split('"').join('\\"');
            selector = `iframe[name="${safeNameDouble}"]`;
            xpath = `//iframe[@name='${safeName}']`;
            switchTarget = `"${safeNameDouble}"`;
          } else if (title) {
            const safeTitle = title.split("'").join("\\'");
            const safeTitleDouble = title.split('"').join('\\"');
            selector = `iframe[title="${safeTitleDouble}"]`;
            xpath = `//iframe[@title='${safeTitle}']`;
            switchTarget = `"${safeTitleDouble}"`;
          } else if (src) {
            const shortSrc = src.split('?')[0].slice(-24);
            const safeShortSrc = shortSrc.split("'").join("\\'");
            const safeShortSrcDouble = shortSrc.split('"').join('\\"');
            selector = `iframe[src*="${safeShortSrcDouble}"]`;
            xpath = `//iframe[contains(@src, '${safeShortSrc}')]`;
            switchTarget = '0';
          }
        }

        return {
          isIframe: true,
          id: id || null,
          name: name || null,
          title: title || null,
          src: src || null,
          selector: selector || 'iframe',
          xpath: xpath || '//iframe',
          switchTarget: switchTarget || '0',
          displayName: id ? `#${id}` : (name ? `name="${name}"` : (title ? `title="${title}"` : 'iframe'))
        };
      } catch (err) {
        return null;
      }
    }

    /**
     * Generate modern Playwright user-facing locators
     */
    static generatePlaywrightLocators(element, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!element || element.nodeType !== ELEMENT_NODE) return [];

      const candidates = [];
      const tag = safeGetTagName(element) || 'div';
      const targetDoc = doc || safeGetOwnerDocument(element);

      // 1. getByTestId (data-testid, data-test, data-cy, data-qa)
      for (const attr of TEST_ATTRIBUTES) {
        const val = safeGetAttr(element, attr);
        if (val && val.trim()) {
          const cleanVal = val.trim();
          const code = `page.getByTestId('${XPathEngine.escapeJSString(cleanVal)}')`;
          const codeJava = `page.getByTestId("${cleanVal.replace(/"/g, '\\"')}");`;
          if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
            candidates.push({
              code,
              codeJava,
              type: 'getByTestId',
              score: 100,
              label: `Playwright Test ID (@${attr})`
            });
            break;
          }
        }
      }

      // 2. getByRole (with accessible name or standalone)
      const role = XPathEngine.getImplicitOrExplicitRole(element);
      if (role) {
        const roleEnum = XPathEngine.getAriaRoleJavaEnum(role);
        const accName = XPathEngine.getAccessibleName(element, targetDoc);
        if (accName && accName.length <= 80) {
          const code = `page.getByRole('${role}', { name: '${XPathEngine.escapeJSString(accName)}' })`;
          const codeJava = `page.getByRole(AriaRole.${roleEnum}, new Page.GetByRoleOptions().setName("${accName.replace(/"/g, '\\"')}"));`;
          if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
            candidates.push({
              code,
              codeJava,
              type: 'getByRole',
              score: 98,
              label: `Playwright Role (${role} "${accName.substring(0, 20)}")`
            });
          }
        }

        // Standalone getByRole if unique on page
        const standaloneRoleCode = `page.getByRole('${role}')`;
        const standaloneRoleJava = `page.getByRole(AriaRole.${roleEnum});`;
        if (XPathEngine.isUniquePlaywright(standaloneRoleCode, element, targetDoc)) {
          candidates.push({
            code: standaloneRoleCode,
            codeJava: standaloneRoleJava,
            type: 'getByRole',
            score: 95,
            label: `Playwright Role (${role})`
          });
        }
      }

      // 3. Unique ID (page.locator('#id'))
      const elemId = safeGetId(element);
      if (elemId && !XPathEngine.isDynamicId(elemId)) {
        const cleanId = elemId.trim();
        const escId = safeEscapeCSS(cleanId);
        const code = `page.locator('#${escId}')`;
        const codeJava = `page.locator("#${escId}");`;
        if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
          candidates.push({
            code,
            codeJava,
            type: 'id',
            score: 97,
            label: `Playwright ID (#${cleanId})`
          });
        }
      }

      // 4. getByLabel (for inputs, selects, textareas, or aria-label)
      if (['input', 'select', 'textarea'].includes(tag) || safeHasAttr(element, 'aria-label')) {
        let labelText = '';
        if (safeHasAttr(element, 'aria-label')) {
          labelText = (safeGetAttr(element, 'aria-label') || '').trim();
        } else if (elemId && targetDoc) {
          try {
            const lbl = targetDoc.querySelector(`label[for="${safeEscapeCSS(elemId)}"]`);
            if (lbl) labelText = safeGetText(lbl).trim();
          } catch (e) { }
        }
        if (!labelText && typeof element.closest === 'function') {
          try {
            const pLabel = element.closest('label');
            if (pLabel) {
              const clone = pLabel.cloneNode(true);
              clone.querySelectorAll('input, select, textarea').forEach((n) => n.remove());
              labelText = safeGetText(clone).trim();
            }
          } catch (e) { }
        }

        if (labelText && labelText.length <= 80) {
          const cleanLabel = labelText.replace(/\s+/g, ' ');
          const code = `page.getByLabel('${XPathEngine.escapeJSString(cleanLabel)}')`;
          const codeJava = `page.getByLabel("${cleanLabel.replace(/"/g, '\\"')}");`;
          if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
            candidates.push({
              code,
              codeJava,
              type: 'getByLabel',
              score: 96,
              label: `Playwright Label ("${cleanLabel.substring(0, 20)}")`
            });
          }
        }
      }

      // 5. getByPlaceholder
      if (safeHasAttr(element, 'placeholder')) {
        const ph = (safeGetAttr(element, 'placeholder') || '').trim();
        if (ph && ph.length <= 80) {
          const code = `page.getByPlaceholder('${XPathEngine.escapeJSString(ph)}')`;
          const codeJava = `page.getByPlaceholder("${ph.replace(/"/g, '\\"')}");`;
          if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
            candidates.push({
              code,
              codeJava,
              type: 'getByPlaceholder',
              score: 94,
              label: `Playwright Placeholder`
            });
          }
        }
      }

      // 6. getByAltText (images, areas)
      if ((tag === 'img' || tag === 'area' || (tag === 'input' && safeGetAttr(element, 'type') === 'image')) && safeHasAttr(element, 'alt')) {
        const alt = (safeGetAttr(element, 'alt') || '').trim();
        if (alt && alt.length <= 80) {
          const code = `page.getByAltText('${XPathEngine.escapeJSString(alt)}')`;
          const codeJava = `page.getByAltText("${alt.replace(/"/g, '\\"')}");`;
          if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
            candidates.push({
              code,
              codeJava,
              type: 'getByAltText',
              score: 93,
              label: `Playwright Alt Text`
            });
          }
        }
      }

      // 7. getByTitle
      if (safeHasAttr(element, 'title')) {
        const title = (safeGetAttr(element, 'title') || '').trim();
        if (title && title.length <= 80) {
          const code = `page.getByTitle('${XPathEngine.escapeJSString(title)}')`;
          const codeJava = `page.getByTitle("${title.replace(/"/g, '\\"')}");`;
          if (XPathEngine.isUniquePlaywright(code, element, targetDoc)) {
            candidates.push({
              code,
              codeJava,
              type: 'getByTitle',
              score: 91,
              label: `Playwright Title`
            });
          }
        }
      }

      // 8. getByText (concise visible text on leaf or shallow elements)
      const text = safeGetText(element).trim();
      const childrenLen = safeGetChildren(element).length;
      if (text && text.length >= 2 && text.length <= 60 && childrenLen <= 2) {
        const cleanText = text.replace(/\s+/g, ' ');
        const codeExact = `page.getByText('${XPathEngine.escapeJSString(cleanText)}', { exact: true })`;
        const codeExactJava = `page.getByText("${cleanText.replace(/"/g, '\\"')}", new Page.GetByTextOptions().setExact(true));`;
        const codeGeneral = `page.getByText('${XPathEngine.escapeJSString(cleanText)}')`;
        const codeGeneralJava = `page.getByText("${cleanText.replace(/"/g, '\\"')}");`;

        if (XPathEngine.isUniquePlaywright(codeExact, element, targetDoc)) {
          candidates.push({
            code: codeExact,
            codeJava: codeExactJava,
            type: 'getByText',
            score: 89,
            label: `Playwright Exact Text`
          });
        } else if (XPathEngine.isUniquePlaywright(codeGeneral, element, targetDoc)) {
          candidates.push({
            code: codeGeneral,
            codeJava: codeGeneralJava,
            type: 'getByText',
            score: 87,
            label: `Playwright Text`
          });
        }
      }

      // Sort by score descending
      candidates.sort((a, b) => b.score - a.score);
      return candidates;
    }

    /**
     * Check if a Playwright locator uniquely identifies the element
     */
    static isUniquePlaywright(locatorCode, element, doc = (typeof document !== 'undefined' ? document : null)) {
      const matches = XPathEngine.queryPlaywright(locatorCode, doc);
      return matches.length === 1 && matches[0] === element;
    }

    /**
     * Parse and query a Playwright locator expression against the document
     * Supports: locator('#id'), getByRole, getByTestId, getByLabel, getByPlaceholder, getByText, getByAltText, getByTitle
     */
    static queryPlaywright(locatorCode, doc = (typeof document !== 'undefined' ? document : null)) {
      if (!locatorCode || typeof locatorCode !== 'string' || !doc) return [];
      let clean = locatorCode.trim().replace(/;$/, '').trim();

      // 0. page.locator(...)
      const locatorMatch = clean.match(/(?:page\.)?locator\(\s*['"](.*?)['"]\s*\)/i);
      if (locatorMatch) {
        const sel = locatorMatch[1];
        if (sel.startsWith('xpath=')) {
          return XPathEngine.queryXPath(sel.substring(6), doc);
        }
        if (sel.startsWith('//') || sel.startsWith('(')) {
          return XPathEngine.queryXPath(sel, doc);
        }
        if (sel.startsWith('id=')) {
          const el = doc.getElementById(sel.substring(3));
          return el ? [el] : [];
        }
        try {
          return Array.from(doc.querySelectorAll(sel));
        } catch (e) {
          return [];
        }
      }

      // 1. getByTestId
      const testIdMatch = clean.match(/(?:page\.)?getByTestId\(\s*['"](.*?)['"]\s*\)/i);
      if (testIdMatch) {
        const val = testIdMatch[1];
        const sel = TEST_ATTRIBUTES.map((attr) => `[${attr}="${safeEscapeCSS(val)}"]`).join(', ');
        try {
          return Array.from(doc.querySelectorAll(sel));
        } catch (e) {
          return [];
        }
      }

      // 2. getByPlaceholder
      const phMatch = clean.match(/(?:page\.)?getByPlaceholder\(\s*['"](.*?)['"]\s*(?:,\s*\{\s*exact:\s*(true|false)\s*\}\s*)?\)/i);
      if (phMatch) {
        const val = phMatch[1];
        const exact = phMatch[2] === 'true';
        try {
          const els = Array.from(doc.querySelectorAll('[placeholder]'));
          return els.filter((el) => {
            const p = safeGetAttr(el, 'placeholder') || '';
            return exact ? p === val : p.toLowerCase().includes(val.toLowerCase());
          });
        } catch (e) {
          return [];
        }
      }

      // 3. getByTitle
      const titleMatch = clean.match(/(?:page\.)?getByTitle\(\s*['"](.*?)['"]\s*(?:,\s*\{\s*exact:\s*(true|false)\s*\}\s*)?\)/i);
      if (titleMatch) {
        const val = titleMatch[1];
        const exact = titleMatch[2] === 'true';
        try {
          const els = Array.from(doc.querySelectorAll('[title]'));
          return els.filter((el) => {
            const t = safeGetAttr(el, 'title') || '';
            return exact ? t === val : t.toLowerCase().includes(val.toLowerCase());
          });
        } catch (e) {
          return [];
        }
      }

      // 4. getByAltText
      const altMatch = clean.match(/(?:page\.)?getByAltText\(\s*['"](.*?)['"]\s*(?:,\s*\{\s*exact:\s*(true|false)\s*\}\s*)?\)/i);
      if (altMatch) {
        const val = altMatch[1];
        const exact = altMatch[2] === 'true';
        try {
          const els = Array.from(doc.querySelectorAll('[alt]'));
          return els.filter((el) => {
            const a = safeGetAttr(el, 'alt') || '';
            return exact ? a === val : a.toLowerCase().includes(val.toLowerCase());
          });
        } catch (e) {
          return [];
        }
      }

      // 5. getByLabel
      const labelMatch = clean.match(/(?:page\.)?getByLabel\(\s*['"](.*?)['"]\s*(?:,\s*(?:\{\s*exact:\s*(true|false)\s*\}|new\s+Page\.GetByLabelOptions\(\)\.setExact\((true|false)\))?\s*)?\)/i);
      if (labelMatch) {
        const val = labelMatch[1];
        const exact = (labelMatch[2] || labelMatch[3]) === 'true';
        const results = new Set();

        // Check aria-label
        try {
          const ariaEls = Array.from(doc.querySelectorAll('[aria-label]'));
          ariaEls.forEach((el) => {
            const al = safeGetAttr(el, 'aria-label') || '';
            if (exact ? al === val : al.toLowerCase().includes(val.toLowerCase())) {
              results.add(el);
            }
          });
        } catch (e) { }

        // Check HTML labels
        try {
          const labels = Array.from(doc.querySelectorAll('label'));
          labels.forEach((lbl) => {
            const txt = safeGetText(lbl).trim().replace(/\s+/g, ' ');
            if (exact ? txt === val : txt.toLowerCase().includes(val.toLowerCase())) {
              const forAttr = safeGetAttr(lbl, 'for');
              if (forAttr) {
                const target = doc.getElementById(forAttr);
                if (target) results.add(target);
              }
              const nestedInput = lbl.querySelector('input, select, textarea');
              if (nestedInput) results.add(nestedInput);
            }
          });
        } catch (e) { }

        return Array.from(results);
      }

      // 6. getByText
      const textMatch = clean.match(/(?:page\.)?getByText\(\s*['"](.*?)['"]\s*(?:,\s*(?:\{\s*exact:\s*(true|false)\s*\}|new\s+Page\.GetByTextOptions\(\)\.setExact\((true|false)\))?\s*)?\)/i);
      if (textMatch) {
        const val = textMatch[1];
        const exact = (textMatch[2] || textMatch[3]) === 'true';
        const root = doc.body || doc.documentElement;
        if (!root || !root.querySelectorAll) return [];
        const all = Array.from(root.querySelectorAll('*'));
        const lowerVal = val.toLowerCase();
        return all.filter((el) => {
          // Fast check: skip elements without any text
          if (!el.textContent && !el.innerText) return false;
          const raw = safeGetText(el);
          if (!raw) return false;
          if (exact ? !raw.includes(val) : !raw.toLowerCase().includes(lowerVal)) return false;

          const t = raw.trim().replace(/\s+/g, ' ');
          const matchesText = exact ? t === val : t.toLowerCase().includes(lowerVal);
          if (!matchesText) return false;

          const chList = safeGetChildren(el);
          for (let i = 0; i < chList.length; i++) {
            const chRaw = safeGetText(chList[i]);
            if (!chRaw) continue;
            const childText = chRaw.trim().replace(/\s+/g, ' ');
            if (exact ? childText === val : childText.toLowerCase().includes(lowerVal)) {
              return false;
            }
          }
          return true;
        });
      }

      // 7. getByRole (supports JS and Java AriaRole enum syntax)
      const roleMatch = clean.match(/(?:page\.)?getByRole\(\s*(?:AriaRole\.([a-z0-9_-]+)|['"]([a-z0-9_-]+)['"])\s*(?:,\s*([\s\S]*?))?\s*\)/i);
      if (roleMatch) {
        const rawRole = (roleMatch[1] || roleMatch[2]).toLowerCase();
        const optionsRaw = roleMatch[3] || '';
        let nameFilter = null;
        let exactName = false;

        const nameMatch = optionsRaw.match(/(?:name:\s*['"](.*?)['"]|\.setName\(\s*['"](.*?)['"]\s*\))/i);
        if (nameMatch) {
          nameFilter = nameMatch[1] !== undefined ? nameMatch[1] : nameMatch[2];
        }
        const exactMatch = optionsRaw.match(/(?:exact:\s*(true|false)|\.setExact\(\s*(true|false)\s*\))/i);
        if (exactMatch) {
          exactName = (exactMatch[1] || exactMatch[2]) === 'true';
        }

        const ROLE_SELECTOR_MAP = {
          button: 'button, input[type="button"], input[type="submit"], input[type="reset"], summary, [role="button"]',
          link: 'a[href], [role="link"]',
          textbox: 'input, textarea, [role="textbox"]',
          checkbox: 'input[type="checkbox"], [role="checkbox"]',
          radio: 'input[type="radio"], [role="radio"]',
          combobox: 'select, [role="combobox"]',
          heading: 'h1, h2, h3, h4, h5, h6, [role="heading"]',
          dialog: 'dialog, [role="dialog"], [role="alertdialog"]',
          list: 'ul, ol, [role="list"]',
          listitem: 'li, [role="listitem"]',
          table: 'table, [role="table"], [role="grid"]',
          row: 'tr, [role="row"]',
          cell: 'td, [role="cell"], [role="gridcell"]',
          columnheader: 'th, [role="columnheader"]',
          img: 'img, svg, [role="img"]',
          slider: 'input[type="range"], [role="slider"]',
          spinbutton: 'input[type="number"], [role="spinbutton"]',
          searchbox: 'input[type="search"], [role="searchbox"]',
          navigation: 'nav, [role="navigation"]',
          main: 'main, [role="main"]',
          form: 'form, [role="form"]'
        };

        let candidateNodes = [];
        if (ROLE_SELECTOR_MAP[rawRole]) {
          try {
            candidateNodes = Array.from(doc.querySelectorAll(ROLE_SELECTOR_MAP[rawRole]));
          } catch (e) {
            candidateNodes = [];
          }
        }
        if (candidateNodes.length === 0) {
          try {
            candidateNodes = Array.from(doc.querySelectorAll(`[role="${rawRole}"], ${rawRole}`));
          } catch (e) {
            candidateNodes = [];
          }
        }
        if (candidateNodes.length === 0) {
          const root = doc.body || doc.documentElement;
          if (!root || !root.querySelectorAll) return [];
          candidateNodes = Array.from(root.querySelectorAll('*'));
        }

        return candidateNodes.filter((el) => {
          const role = XPathEngine.getImplicitOrExplicitRole(el);
          if (role !== rawRole) return false;

          if (nameFilter !== null) {
            const accName = XPathEngine.getAccessibleName(el, doc);
            return exactName
              ? accName === nameFilter
              : accName.toLowerCase().includes(nameFilter.toLowerCase());
          }
          return true;
        });
      }

      return [];
    }

    /**
     * Export XPath to target test framework code template
     */
    static formatForFramework(xpath, framework = 'raw', bestPlaywright = null, bestPlaywrightJava = null, bestRelative = null, action = 'locator', sampleText = 'Enter value', iframeInfo = null, exactText = null) {
      if (action && action !== 'locator') {
        return XPathEngine.formatActionCode(xpath, framework, action, bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText);
      }

      const escapedDouble = (xpath || '').replace(/"/g, '\\"');
      const inFrame = iframeInfo && iframeInfo.isIframe;
      const frameSel = inFrame ? (iframeInfo.selector || 'iframe').replace(/'/g, "\\'") : '';
      const frameSelDouble = inFrame ? (iframeInfo.selector || 'iframe').replace(/"/g, '\\"') : '';

      switch (framework) {
        case 'playwright': {
          if (inFrame) {
            const basePw = bestPlaywright || `page.locator("xpath=${escapedDouble}");`;
            return basePw.startsWith('page.')
              ? basePw.replace(/^page\./, `page.frameLocator('${frameSel}').`)
              : `page.frameLocator('${frameSel}').locator("xpath=${escapedDouble}");`;
          }
          return bestPlaywright || `page.locator("xpath=${escapedDouble}");`;
        }
        case 'playwright-python': {
          const basePy = XPathEngine.toPlaywrightPython(bestPlaywright, xpath);
          if (inFrame) {
            return basePy.startsWith('page.')
              ? basePy.replace(/^page\./, `page.frame_locator('${frameSel}').`)
              : `page.frame_locator('${frameSel}').locator("xpath=${escapedDouble}")`;
          }
          return basePy;
        }
        case 'playwright-csharp': {
          const baseCs = XPathEngine.toPlaywrightCSharp(bestPlaywright, xpath);
          if (inFrame) {
            return (baseCs.startsWith('Page.')
              ? baseCs.replace(/^Page\./, `Page.FrameLocator("${frameSelDouble}").`)
              : `Page.FrameLocator("${frameSelDouble}").Locator("xpath=${escapedDouble}")`) + ';';
          }
          return baseCs + ';';
        }
        case 'playwright-java':
        case 'playwright-modern-java': {
          const baseJava = (bestPlaywrightJava || XPathEngine.toPlaywrightJava(bestPlaywright, xpath)).trim().replace(/;$/, '');
          if (inFrame) {
            return (baseJava.startsWith('page.')
              ? baseJava.replace(/^page\./, `page.frameLocator("${frameSelDouble}").`)
              : `page.frameLocator("${frameSelDouble}").locator("xpath=${escapedDouble}")`) + ';';
          }
          return baseJava + ';';
        }
        case 'playwright-xpath':
          return inFrame
            ? `page.frameLocator('${frameSel}').locator("xpath=${escapedDouble}");`
            : `page.locator("xpath=${escapedDouble}");`;
        case 'playwright-java-xpath':
          return inFrame
            ? `page.frameLocator("${frameSelDouble}").locator("xpath=${escapedDouble}");`
            : `page.locator("xpath=${escapedDouble}");`;
        case 'selenium4-relative': {
          const relBase = (bestRelative && bestRelative.selenium4)
            ? bestRelative.selenium4 + ';'
            : `RelativeLocator.with(By.xpath("${escapedDouble}")).near(By.xpath("..."));`;
          return inFrame
            ? `driver.switchTo().frame(${iframeInfo.switchTarget});\n${relBase}`
            : relBase;
        }
        case 'selenium-java':
          return inFrame
            ? `driver.switchTo().frame(${iframeInfo.switchTarget});\ndriver.findElement(By.xpath("${escapedDouble}"));`
            : `driver.findElement(By.xpath("${escapedDouble}"));`;
        case 'selenium-python':
          return inFrame
            ? `driver.switch_to.frame(${iframeInfo.switchTarget})\ndriver.find_element(By.XPATH, "${escapedDouble}")`
            : `driver.find_element(By.XPATH, "${escapedDouble}")`;
        case 'selenium-javascript':
          return inFrame
            ? `await driver.switchTo().frame(${iframeInfo.switchTarget});\nawait driver.findElement(By.xpath("${escapedDouble}"));`
            : `driver.findElement(By.xpath("${escapedDouble}"));`;
        case 'selenium-csharp':
          return inFrame
            ? `driver.SwitchTo().Frame(${iframeInfo.switchTarget});\ndriver.FindElement(By.XPath("${escapedDouble}"));`
            : `driver.FindElement(By.XPath("${escapedDouble}"));`;
        case 'cypress':
          return inFrame
            ? `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}");\n});`
            : `cy.xpath("${escapedDouble}");`;
        case 'robot':
          return inFrame
            ? `Select Frame    ${iframeInfo.xpath}\n# Locator: xpath=${xpath}`
            : `xpath=${xpath}`;
        case 'puppeteer':
          return inFrame
            ? `const frame = (await page.$("${frameSelDouble}")).contentFrame();\nawait frame.$x("${escapedDouble}");`
            : `await page.$x("${escapedDouble}");`;
        case 'raw':
        default:
          return xpath;
      }
    }

    /**
     * Generate complete executable action code for given locator, framework and action type
     * Actions: 'locator', 'click', 'fill', 'assertVisible', 'assertText', 'assertChecked', 'assertEnabled', 'waitFor', 'getText'
     */
    static formatActionCode(xpath, framework = 'raw', action = 'locator', bestPlaywright = null, bestPlaywrightJava = null, bestRelative = null, sampleText = 'Enter value', iframeInfo = null, exactText = null) {
      if (action === 'locator') {
        return XPathEngine.formatForFramework(xpath, framework, bestPlaywright, bestPlaywrightJava, bestRelative, 'locator', sampleText, iframeInfo, exactText);
      }

      const escapedDouble = (xpath || '').replace(/"/g, '\\"');
      const inFrame = iframeInfo && iframeInfo.isIframe;
      const frameSel = inFrame ? (iframeInfo.selector || 'iframe').replace(/'/g, "\\'") : '';
      const frameSelDouble = inFrame ? (iframeInfo.selector || 'iframe').replace(/"/g, '\\"') : '';

      const actualText = (sampleText && typeof sampleText === 'string' && sampleText.trim().length > 0)
        ? sampleText.trim()
        : 'Enter value';
      const escText = actualText.replace(/"/g, '\\"');

      const targetText = (exactText && typeof exactText === 'string' && exactText.trim().length > 0)
        ? exactText.trim()
        : actualText;
      const escTargetText = targetText.replace(/"/g, '\\"');

      // Resolved locators
      let cleanPlaywrightJS = (bestPlaywright || `page.locator("xpath=${escapedDouble}")`).trim().replace(/;$/, '');
      if (inFrame) {
        cleanPlaywrightJS = cleanPlaywrightJS.startsWith('page.')
          ? cleanPlaywrightJS.replace(/^page\./, `page.frameLocator('${frameSel}').`)
          : `page.frameLocator('${frameSel}').locator("xpath=${escapedDouble}")`;
      }

      let cleanPlaywrightJava = (bestPlaywrightJava || XPathEngine.toPlaywrightJava(bestPlaywright, xpath)).trim().replace(/;$/, '');
      if (inFrame) {
        cleanPlaywrightJava = cleanPlaywrightJava.startsWith('page.')
          ? cleanPlaywrightJava.replace(/^page\./, `page.frameLocator("${frameSelDouble}").`)
          : `page.frameLocator("${frameSelDouble}").locator("xpath=${escapedDouble}")`;
      }

      const selenium4Target = (bestRelative && bestRelative.selenium4)
        ? bestRelative.selenium4.trim().replace(/;$/, '')
        : `RelativeLocator.with(By.xpath("${escapedDouble}")).near(By.xpath("..."))`;

      switch (framework) {
        case 'playwright':
          if (action === 'click') return `await ${cleanPlaywrightJS}.click();`;
          if (action === 'fill') return `await ${cleanPlaywrightJS}.fill("${escText}");`;
          if (action === 'assertVisible') return `await expect(${cleanPlaywrightJS}).toBeVisible();`;
          if (action === 'assertText') return `await expect(${cleanPlaywrightJS}).toHaveText("${escTargetText}");`;
          if (action === 'assertChecked') return `await expect(${cleanPlaywrightJS}).toBeChecked();`;
          if (action === 'assertEnabled') return `await expect(${cleanPlaywrightJS}).toBeEnabled();`;
          if (action === 'waitFor') return `await ${cleanPlaywrightJS}.waitFor({ state: 'visible' });`;
          if (action === 'getText') return `const text = await ${cleanPlaywrightJS}.textContent();`;
          return `await ${cleanPlaywrightJS}.${action}();`;

        case 'playwright-python': {
          let cleanPlaywrightPy = XPathEngine.toPlaywrightPython(bestPlaywright, xpath).trim().replace(/;$/, '');
          if (inFrame) {
            cleanPlaywrightPy = cleanPlaywrightPy.startsWith('page.')
              ? cleanPlaywrightPy.replace(/^page\./, `page.frame_locator('${frameSel}').`)
              : `page.frame_locator('${frameSel}').locator("xpath=${escapedDouble}")`;
          }
          if (action === 'click') return `${cleanPlaywrightPy}.click()`;
          if (action === 'fill') return `${cleanPlaywrightPy}.fill("${escText}")`;
          if (action === 'assertVisible') return `expect(${cleanPlaywrightPy}).to_be_visible()`;
          if (action === 'assertText') return `expect(${cleanPlaywrightPy}).to_have_text("${escTargetText}")`;
          if (action === 'assertChecked') return `expect(${cleanPlaywrightPy}).to_be_checked()`;
          if (action === 'assertEnabled') return `expect(${cleanPlaywrightPy}).to_be_enabled()`;
          if (action === 'waitFor') return `${cleanPlaywrightPy}.wait_for(state="visible")`;
          if (action === 'getText') return `text = ${cleanPlaywrightPy}.text_content()`;
          return `${cleanPlaywrightPy}.${action}()`;
        }

        case 'playwright-csharp': {
          let cleanPlaywrightCs = XPathEngine.toPlaywrightCSharp(bestPlaywright, xpath).trim().replace(/;$/, '');
          if (inFrame) {
            cleanPlaywrightCs = cleanPlaywrightCs.startsWith('Page.')
              ? cleanPlaywrightCs.replace(/^Page\./, `Page.FrameLocator("${frameSelDouble}").`)
              : `Page.FrameLocator("${frameSelDouble}").Locator("xpath=${escapedDouble}")`;
          }
          if (action === 'click') return `await ${cleanPlaywrightCs}.ClickAsync();`;
          if (action === 'fill') return `await ${cleanPlaywrightCs}.FillAsync("${escText}");`;
          if (action === 'assertVisible') return `await Expect(${cleanPlaywrightCs}).ToBeVisibleAsync();`;
          if (action === 'assertText') return `await Expect(${cleanPlaywrightCs}).ToHaveTextAsync("${escTargetText}");`;
          if (action === 'assertChecked') return `await Expect(${cleanPlaywrightCs}).ToBeCheckedAsync();`;
          if (action === 'assertEnabled') return `await Expect(${cleanPlaywrightCs}).ToBeEnabledAsync();`;
          if (action === 'waitFor') return `await ${cleanPlaywrightCs}.WaitForAsync();`;
          if (action === 'getText') return `string text = await ${cleanPlaywrightCs}.TextContentAsync();`;
          return `await ${cleanPlaywrightCs}.${action}Async();`;
        }

        case 'playwright-xpath': {
          const pwXpTarget = inFrame
            ? `page.frameLocator('${frameSel}').locator("xpath=${escapedDouble}")`
            : `page.locator("xpath=${escapedDouble}")`;
          if (action === 'click') return `await ${pwXpTarget}.click();`;
          if (action === 'fill') return `await ${pwXpTarget}.fill("${escText}");`;
          if (action === 'assertVisible') return `await expect(${pwXpTarget}).toBeVisible();`;
          if (action === 'assertText') return `await expect(${pwXpTarget}).toHaveText("${escTargetText}");`;
          if (action === 'assertChecked') return `await expect(${pwXpTarget}).toBeChecked();`;
          if (action === 'assertEnabled') return `await expect(${pwXpTarget}).toBeEnabled();`;
          if (action === 'waitFor') return `await ${pwXpTarget}.waitFor();`;
          if (action === 'getText') return `const text = await ${pwXpTarget}.textContent();`;
          return `await ${pwXpTarget}.${action}();`;
        }

        case 'playwright-java':
        case 'playwright-modern-java':
          if (action === 'click') return `${cleanPlaywrightJava}.click();`;
          if (action === 'fill') return `${cleanPlaywrightJava}.fill("${escText}");`;
          if (action === 'assertVisible') return `assertThat(${cleanPlaywrightJava}).isVisible();`;
          if (action === 'assertText') return `assertThat(${cleanPlaywrightJava}).hasText("${escTargetText}");`;
          if (action === 'assertChecked') return `assertThat(${cleanPlaywrightJava}).isChecked();`;
          if (action === 'assertEnabled') return `assertThat(${cleanPlaywrightJava}).isEnabled();`;
          if (action === 'waitFor') return `${cleanPlaywrightJava}.waitFor();`;
          if (action === 'getText') return `String text = ${cleanPlaywrightJava}.textContent();`;
          return `${cleanPlaywrightJava}.${action}();`;

        case 'playwright-java-xpath': {
          const pwJavaXpTarget = inFrame
            ? `page.frameLocator("${frameSelDouble}").locator("xpath=${escapedDouble}")`
            : `page.locator("xpath=${escapedDouble}")`;
          if (action === 'click') return `${pwJavaXpTarget}.click();`;
          if (action === 'fill') return `${pwJavaXpTarget}.fill("${escText}");`;
          if (action === 'assertVisible') return `assertThat(${pwJavaXpTarget}).isVisible();`;
          if (action === 'assertText') return `assertThat(${pwJavaXpTarget}).hasText("${escTargetText}");`;
          if (action === 'assertChecked') return `assertThat(${pwJavaXpTarget}).isChecked();`;
          if (action === 'assertEnabled') return `assertThat(${pwJavaXpTarget}).isEnabled();`;
          if (action === 'waitFor') return `${pwJavaXpTarget}.waitFor();`;
          if (action === 'getText') return `String text = ${pwJavaXpTarget}.textContent();`;
          return `${pwJavaXpTarget}.${action}();`;
        }

        case 'selenium-java': {
          const framePrefix = inFrame ? `driver.switchTo().frame(${iframeInfo.switchTarget});\n` : '';
          if (action === 'click') return `${framePrefix}driver.findElement(By.xpath("${escapedDouble}")).click();`;
          if (action === 'fill') return `${framePrefix}driver.findElement(By.xpath("${escapedDouble}")).sendKeys("${escText}");`;
          if (action === 'assertVisible') return `${framePrefix}Assert.assertTrue(driver.findElement(By.xpath("${escapedDouble}")).isDisplayed());`;
          if (action === 'assertText') return `${framePrefix}Assert.assertEquals(driver.findElement(By.xpath("${escapedDouble}")).getText(), "${escTargetText}");`;
          if (action === 'assertChecked') return `${framePrefix}Assert.assertTrue(driver.findElement(By.xpath("${escapedDouble}")).isSelected());`;
          if (action === 'assertEnabled') return `${framePrefix}Assert.assertTrue(driver.findElement(By.xpath("${escapedDouble}")).isEnabled());`;
          if (action === 'waitFor') return `${framePrefix}new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("${escapedDouble}")));`;
          if (action === 'getText') return `${framePrefix}String text = driver.findElement(By.xpath("${escapedDouble}")).getText();`;
          return `${framePrefix}driver.findElement(By.xpath("${escapedDouble}")).${action}();`;
        }

        case 'selenium-python': {
          const framePrefix = inFrame ? `driver.switch_to.frame(${iframeInfo.switchTarget})\n` : '';
          if (action === 'click') return `${framePrefix}driver.find_element(By.XPATH, "${escapedDouble}").click()`;
          if (action === 'fill') return `${framePrefix}driver.find_element(By.XPATH, "${escapedDouble}").send_keys("${escText}")`;
          if (action === 'assertVisible') return `${framePrefix}assert driver.find_element(By.XPATH, "${escapedDouble}").is_displayed()`;
          if (action === 'assertText') return `${framePrefix}assert driver.find_element(By.XPATH, "${escapedDouble}").text == "${escTargetText}"`;
          if (action === 'assertChecked') return `${framePrefix}assert driver.find_element(By.XPATH, "${escapedDouble}").is_selected()`;
          if (action === 'assertEnabled') return `${framePrefix}assert driver.find_element(By.XPATH, "${escapedDouble}").is_enabled()`;
          if (action === 'waitFor') return `${framePrefix}WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, "${escapedDouble}")))`;
          if (action === 'getText') return `${framePrefix}text = driver.find_element(By.XPATH, "${escapedDouble}").text`;
          return `${framePrefix}driver.find_element(By.XPATH, "${escapedDouble}").${action}()`;
        }

        case 'selenium-javascript': {
          const framePrefix = inFrame ? `await driver.switchTo().frame(${iframeInfo.switchTarget});\n` : '';
          if (action === 'click') return `${framePrefix}await driver.findElement(By.xpath("${escapedDouble}")).click();`;
          if (action === 'fill') return `${framePrefix}await driver.findElement(By.xpath("${escapedDouble}")).sendKeys("${escText}");`;
          if (action === 'assertVisible') return `${framePrefix}await driver.findElement(By.xpath("${escapedDouble}")).isDisplayed();`;
          if (action === 'assertText') return `${framePrefix}const text = await driver.findElement(By.xpath("${escapedDouble}")).getText();\nexpect(text).toBe("${escTargetText}");`;
          if (action === 'assertChecked') return `${framePrefix}await driver.findElement(By.xpath("${escapedDouble}")).isSelected();`;
          if (action === 'assertEnabled') return `${framePrefix}await driver.findElement(By.xpath("${escapedDouble}")).isEnabled();`;
          if (action === 'waitFor') return `${framePrefix}await driver.wait(until.elementLocated(By.xpath("${escapedDouble}")), 10000);`;
          if (action === 'getText') return `${framePrefix}const text = await driver.findElement(By.xpath("${escapedDouble}")).getText();`;
          return `${framePrefix}await driver.findElement(By.xpath("${escapedDouble}")).${action}();`;
        }

        case 'selenium-csharp': {
          const framePrefix = inFrame ? `driver.SwitchTo().Frame(${iframeInfo.switchTarget});\n` : '';
          if (action === 'click') return `${framePrefix}driver.FindElement(By.XPath("${escapedDouble}")).Click();`;
          if (action === 'fill') return `${framePrefix}driver.FindElement(By.XPath("${escapedDouble}")).SendKeys("${escText}");`;
          if (action === 'assertVisible') return `${framePrefix}Assert.IsTrue(driver.FindElement(By.XPath("${escapedDouble}")).Displayed);`;
          if (action === 'assertText') return `${framePrefix}Assert.AreEqual("${escTargetText}", driver.FindElement(By.XPath("${escapedDouble}")).Text);`;
          if (action === 'assertChecked') return `${framePrefix}Assert.IsTrue(driver.FindElement(By.XPath("${escapedDouble}")).Selected);`;
          if (action === 'assertEnabled') return `${framePrefix}Assert.IsTrue(driver.FindElement(By.XPath("${escapedDouble}")).Enabled);`;
          if (action === 'waitFor') return `${framePrefix}new WebDriverWait(driver, TimeSpan.FromSeconds(10)).Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("${escapedDouble}")));`;
          if (action === 'getText') return `${framePrefix}string text = driver.FindElement(By.XPath("${escapedDouble}")).Text;`;
          return `${framePrefix}driver.FindElement(By.XPath("${escapedDouble}")).${action}();`;
        }

        case 'selenium4-relative': {
          const framePrefix = inFrame ? `driver.switchTo().frame(${iframeInfo.switchTarget});\n` : '';
          if (action === 'click') return `${framePrefix}driver.findElement(${selenium4Target}).click();`;
          if (action === 'fill') return `${framePrefix}driver.findElement(${selenium4Target}).sendKeys("${escText}");`;
          if (action === 'assertVisible') return `${framePrefix}Assert.assertTrue(driver.findElement(${selenium4Target}).isDisplayed());`;
          if (action === 'assertText') return `${framePrefix}Assert.assertEquals(driver.findElement(${selenium4Target}).getText(), "${escTargetText}");`;
          if (action === 'assertChecked') return `${framePrefix}Assert.assertTrue(driver.findElement(${selenium4Target}).isSelected());`;
          if (action === 'assertEnabled') return `${framePrefix}Assert.assertTrue(driver.findElement(${selenium4Target}).isEnabled());`;
          if (action === 'waitFor') return `${framePrefix}new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOf(driver.findElement(${selenium4Target})));`;
          if (action === 'getText') return `${framePrefix}String text = driver.findElement(${selenium4Target}).getText();`;
          return `${framePrefix}driver.findElement(${selenium4Target}).${action}();`;
        }

        case 'cypress':
          if (inFrame) {
            if (action === 'click') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").click();\n});`;
            if (action === 'fill') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").type("${escText}");\n});`;
            if (action === 'assertVisible') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").should('be.visible');\n});`;
            if (action === 'assertText') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").should('have.text', "${escTargetText}");\n});`;
            if (action === 'assertChecked') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").should('be.checked');\n});`;
            if (action === 'assertEnabled') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").should('be.enabled');\n});`;
            if (action === 'waitFor') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").should('exist');\n});`;
            if (action === 'getText') return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").invoke('text').then((text) => {\n    console.log(text);\n  });\n});`;
            return `cy.get('${frameSel}').within(() => {\n  cy.xpath("${escapedDouble}").${action}();\n});`;
          }
          if (action === 'click') return `cy.xpath("${escapedDouble}").click();`;
          if (action === 'fill') return `cy.xpath("${escapedDouble}").type("${escText}");`;
          if (action === 'assertVisible') return `cy.xpath("${escapedDouble}").should('be.visible');`;
          if (action === 'assertText') return `cy.xpath("${escapedDouble}").should('have.text', "${escTargetText}");`;
          if (action === 'assertChecked') return `cy.xpath("${escapedDouble}").should('be.checked');`;
          if (action === 'assertEnabled') return `cy.xpath("${escapedDouble}").should('be.enabled');`;
          if (action === 'waitFor') return `cy.xpath("${escapedDouble}").should('exist');`;
          if (action === 'getText') return `cy.xpath("${escapedDouble}").invoke('text').then((text) => {\n  console.log(text);\n});`;
          return `cy.xpath("${escapedDouble}").${action}();`;

        case 'robot': {
          const framePrefix = inFrame ? `Select Frame    ${iframeInfo.xpath}\n` : '';
          if (action === 'click') return `${framePrefix}Click Element    xpath=${xpath}`;
          if (action === 'fill') return `${framePrefix}Input Text    xpath=${xpath}    ${actualText}`;
          if (action === 'assertVisible') return `${framePrefix}Element Should Be Visible    xpath=${xpath}`;
          if (action === 'assertText') return `${framePrefix}Element Text Should Be    xpath=${xpath}    ${targetText}`;
          if (action === 'assertChecked') return `${framePrefix}Checkbox Should Be Selected    xpath=${xpath}`;
          if (action === 'assertEnabled') return `${framePrefix}Element Should Be Enabled    xpath=${xpath}`;
          if (action === 'waitFor') return `${framePrefix}Wait Until Element Is Visible    xpath=${xpath}`;
          if (action === 'getText') return `${framePrefix}\${text} =    Get Text    xpath=${xpath}`;
          return `${framePrefix}xpath=${xpath}`;
        }

        case 'puppeteer': {
          const pupFrame = inFrame ? `const frameHandle = await page.$("${frameSelDouble}");\nconst frame = await frameHandle.contentFrame();\n` : '';
          const rootTarget = inFrame ? 'frame' : 'page';
          if (action === 'click') return `${pupFrame}await ${rootTarget}.locator("xpath=${escapedDouble}").click();`;
          if (action === 'fill') return `${pupFrame}await ${rootTarget}.locator("xpath=${escapedDouble}").fill("${escText}");`;
          if (action === 'assertVisible') return `${pupFrame}await ${rootTarget}.waitForXPath("${escapedDouble}", { visible: true });`;
          if (action === 'assertText') return `${pupFrame}const el = (await ${rootTarget}.$x("${escapedDouble}"))[0];\nconst text = await (await el?.getProperty('textContent'))?.jsonValue();\nif (text !== "${escTargetText}") throw new Error('Text mismatch');`;
          if (action === 'assertChecked') return `${pupFrame}const isChecked = await (await (await ${rootTarget}.$x("${escapedDouble}"))[0]?.getProperty('checked'))?.jsonValue();`;
          if (action === 'assertEnabled') return `${pupFrame}const isDisabled = await (await (await ${rootTarget}.$x("${escapedDouble}"))[0]?.getProperty('disabled'))?.jsonValue();`;
          if (action === 'waitFor') return `${pupFrame}await ${rootTarget}.waitForSelector("xpath=${escapedDouble}");`;
          if (action === 'getText') return `${pupFrame}const text = await (await (await ${rootTarget}.$x("${escapedDouble}"))[0]?.getProperty('textContent'))?.jsonValue();`;
          return `${pupFrame}await ${rootTarget}.$x("${escapedDouble}");`;
        }

        case 'raw':
        default:
          return xpath;
      }
    }

    /**
     * Generate an action map with all ready-to-use action code snippets
     */
    static generateActionMap(xpath, framework = 'playwright', bestPlaywright = null, bestPlaywrightJava = null, bestRelative = null, sampleText = 'Enter value', iframeInfo = null, exactText = null) {
      return {
        locator: XPathEngine.formatActionCode(xpath, framework, 'locator', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        click: XPathEngine.formatActionCode(xpath, framework, 'click', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        fill: XPathEngine.formatActionCode(xpath, framework, 'fill', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        assertVisible: XPathEngine.formatActionCode(xpath, framework, 'assertVisible', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        assertText: XPathEngine.formatActionCode(xpath, framework, 'assertText', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        assertChecked: XPathEngine.formatActionCode(xpath, framework, 'assertChecked', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        assertEnabled: XPathEngine.formatActionCode(xpath, framework, 'assertEnabled', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        waitFor: XPathEngine.formatActionCode(xpath, framework, 'waitFor', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText),
        getText: XPathEngine.formatActionCode(xpath, framework, 'getText', bestPlaywright, bestPlaywrightJava, bestRelative, sampleText, iframeInfo, exactText)
      };
    }
  }

  // Export helper functions on XPathEngine for unified safe access
  XPathEngine.safeEscapeCSS = safeEscapeCSS;
  XPathEngine.safeGetAttr = safeGetAttr;
  XPathEngine.safeHasAttr = safeHasAttr;
  XPathEngine.safeGetId = safeGetId;
  XPathEngine.safeGetTagName = safeGetTagName;
  XPathEngine.safeGetText = safeGetText;
  XPathEngine.safeGetChildren = safeGetChildren;
  XPathEngine.safeGetParent = safeGetParent;
  XPathEngine.safeGetOwnerDocument = safeGetOwnerDocument;
  XPathEngine.getElementFillValue = XPathEngine.getElementFillValue;

  // Export to window / global / module
  if (typeof window !== 'undefined') {
    window.XPathEngine = XPathEngine;
  }
  if (typeof globalThis !== 'undefined') {
    globalThis.XPathEngine = XPathEngine;
  }
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = XPathEngine;
  }
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));


  const XPathEngineRef = (typeof window !== 'undefined' && window.XPathEngine)
    ? window.XPathEngine
    : ((typeof globalThis !== 'undefined' && globalThis.XPathEngine)
      ? globalThis.XPathEngine
      : (typeof XPathEngine !== 'undefined' ? XPathEngine : null));

  // Clean up any previously injected instance to allow hot re-injection
  if (window.__SMART_XPATH_FINDER_INJECTED__) {
    if (typeof window.__SMART_XPATH_CLEANUP__ === 'function') {
      try {
        window.__SMART_XPATH_CLEANUP__();
      } catch (e) {}
    }
  }
  window.__SMART_XPATH_FINDER_INJECTED__ = true;

  // Anti-tamper protection for sites using disable-devtool
  try {
    if (window.DisableDevtool) {
      window.DisableDevtool.isEnable = false;
      window.DisableDevtool.isRunning = false;
    }
  } catch (e) {}

  let isInspectMode = false;
  let isInspectFromDevTools = false;
  let isRecordFromDevTools = false;
  let isFrozenMode = false;
  let freezeShieldCleanups = [];
  let freezeTimerInterval = null;
  let freezeHudElement = null;
  let currentSelectFrameworkFn = null;
  let currentFormat = 'playwright';
  try {
    const prefFmt = localStorage.getItem('__xpath_pref_framework__');
    if (prefFmt) currentFormat = prefFmt;
  } catch (e) {}

  function applyFrameworkChange(newFmt) {
    if (!newFmt) return;
    currentFormat = newFmt;
    if (typeof currentSelectFrameworkFn === 'function') {
      currentSelectFrameworkFn(newFmt);
    } else if (currentAnalysis && typeof renderAnalysisDetails === 'function') {
      try {
        renderAnalysisDetails(currentAnalysis, currentTargetElement);
      } catch (e) {}
    }
  }

  let currentAction = 'locator';
  let currentSnapMode = 'float';
  try {
    const savedSnap = localStorage.getItem('__xpath_dock_snap_mode__');
    if (savedSnap === 'mini') currentSnapMode = 'mini';
    else currentSnapMode = 'float';
  } catch (e) {}
  let evaluatorMatches = [];
  let currentMatchIndex = 0;
  let activeBreadcrumbElements = [];
  let activeChildElements = [];
  let currentMatrixAttributes = [];
  let currentAnalysis = null;
  let activeDockTab = 'inspector';
  let isRecordingMode = false;
  let isRecordingPaused = false;
  let isAssertPickingMode = false;
  let recordedFlowSteps = [];
  let recHudElement = null;
  let activeTypingTimer = null;
  let lastTypingElement = null;
  const STORAGE_KEY_SAVED = '__xpath_pro_saved_locators__';
  const STORAGE_KEY_DEL_AFTER = '__xpath_pro_del_after_download__';
  const STORAGE_KEY_PREF_FRAMEWORK = '__xpath_pref_framework__';
  const STORAGE_KEY_SNAP_MODE = '__xpath_dock_snap_mode__';
  const STORAGE_KEY_FLOW_STEPS = '__xpath_pro_recorded_flow__';
  const STORAGE_KEY_REC_STATE = '__xpath_pro_recording_state__';

  // Read stored framework preference from chrome.storage.local
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get([STORAGE_KEY_PREF_FRAMEWORK], (res) => {
      if (res && res[STORAGE_KEY_PREF_FRAMEWORK]) {
        applyFrameworkChange(res[STORAGE_KEY_PREF_FRAMEWORK]);
      }
    });
  }

  // React to framework changes from popup or another tab in real-time
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[STORAGE_KEY_PREF_FRAMEWORK]) {
        const val = changes[STORAGE_KEY_PREF_FRAMEWORK].newValue;
        if (val && val !== currentFormat) {
          applyFrameworkChange(val);
        }
      }
    });
  }

  // DOM Elements
  let shadowHost = null;
  let shadowRoot = null;
  let dockContainer = null;
  let launcherBtn = null;
  let highlightOverlay = null;
  let evalHighlightContainer = null;

  // Embedded CSS to bypass any Content Security Policy (CSP) restrictions
  const EMBEDDED_CSS = ":host{all:initial;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;font-size:13px;line-height:1.4;color:#e2e8f0;box-sizing:border-box}*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}.xpath-floating-launcher{position:fixed;bottom:20px;right:20px;background:#1e2430;color:#e2e8f0;border:1px solid rgba(255,255,255,0.14);padding:8px 14px;border-radius:9999px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;font-size:12px;font-weight:600;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,0.25);display:flex;align-items:center;gap:6px;z-index:2147483647;transition:all 0.2s ease;user-select:none}.xpath-floating-launcher:hover{transform:translateY(-2px);background:#262e3d;box-shadow:0 6px 18px rgba(0,0,0,0.35);border-color:rgba(99,140,240,0.4);color:#ffffff}.xpath-finder-dock{position:fixed;bottom:24px;right:24px;width:490px;height:580px;min-width:360px;min-height:260px;max-width:calc(100vw - 20px);max-height:calc(100vh - 20px);background:#181c24;backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,0.1);border-radius:14px;box-shadow:0 16px 36px rgba(0,0,0,0.4),0 0 0 1px rgba(255,255,255,0.04);display:flex;flex-direction:column;overflow:hidden;z-index:2147483647;transition:opacity 0.2s cubic-bezier(0.16,1,0.3,1),transform 0.2s cubic-bezier(0.16,1,0.3,1);box-sizing:border-box}.xpath-finder-dock.minimized{height:48px !important;width:280px !important;min-height:48px !important;overflow:hidden}.xpath-finder-dock.maximized{width:min(920px,calc(100vw - 40px)) !important;height:calc(90vh - 20px) !important}.xpath-dock-header{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:#1f2430;border-bottom:1px solid rgba(255,255,255,0.08);cursor:grab;user-select:none}.xpath-dock-header:active{cursor:grabbing}.xpath-brand{display:flex;align-items:center;gap:8px;font-weight:600;font-size:13px;color:#f8fafc;letter-spacing:-0.01em}.xpath-brand-icon{width:18px;height:18px;fill:none;stroke:#60a5fa;stroke-width:2.2}.xpath-header-actions{display:flex;align-items:center;gap:6px}.xpath-btn-icon{background:transparent;border:none;color:#94a3b8;width:24px;height:24px;border-radius:6px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all 0.15s ease}.xpath-btn-icon:hover{background:rgba(255,255,255,0.08);color:#f8fafc}.xpath-btn-icon.active{background:#3b82f6;color:#ffffff}.xpath-inspect-banner{display:flex;align-items:center;justify-content:space-between;padding:8px 14px;background:rgba(31,36,48,0.5);border-bottom:1px solid rgba(255,255,255,0.06)}.xpath-inspect-status{display:flex;align-items:center;gap:8px;font-size:12px;color:#94a3b8}.xpath-pulse-dot{width:8px;height:8px;border-radius:50%;background-color:#60a5fa;box-shadow:0 0 6px rgba(96,165,250,0.6);animation:pulse-glow 1.5s infinite}@keyframes pulse-glow{0%{transform:scale(0.9);opacity:0.7}50%{transform:scale(1.15);opacity:1;box-shadow:0 0 8px rgba(96,165,250,0.8)}100%{transform:scale(0.9);opacity:0.7}}.xpath-btn-inspect{background:#3b82f6;color:white;border:none;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;display:flex;align-items:center;gap:5px;transition:background 0.15s}.xpath-btn-inspect:hover{background:#2563eb}.xpath-btn-inspect.active{background:#ef4444}.xpath-btn-freeze{background:rgba(56,189,248,0.15);border:1px solid rgba(56,189,248,0.35);color:#38bdf8}.xpath-btn-freeze:hover{background:rgba(56,189,248,0.28);border-color:rgba(56,189,248,0.6);color:#f0f9ff;box-shadow:0 0 10px rgba(56,189,248,0.3)}.xpath-btn-freeze.active{background:#0284c7;color:white}.xpath-dock-body{padding:12px 14px;overflow-y:auto;flex:1;min-height:0;display:flex;flex-direction:column;gap:12px}.xpath-resizer{position:absolute;z-index:100;user-select:none}.xpath-resizer-r{top:0;right:0;width:7px;height:100%;cursor:ew-resize}.xpath-resizer-l{top:0;left:0;width:7px;height:100%;cursor:ew-resize}.xpath-resizer-b{bottom:0;left:0;width:100%;height:7px;cursor:ns-resize}.xpath-resizer-t{top:0;left:0;width:100%;height:7px;cursor:ns-resize}.xpath-resizer-br{bottom:0;right:0;width:18px;height:18px;cursor:nwse-resize;display:flex;align-items:center;justify-content:center;padding-bottom:2px;padding-right:2px;opacity:0.55;transition:opacity 0.15s ease}.xpath-resizer-br:hover{opacity:1}.xpath-resizer-bl{bottom:0;left:0;width:14px;height:14px;cursor:nesw-resize}.xpath-resizer-tr{top:0;right:0;width:14px;height:14px;cursor:nesw-resize}.xpath-resizer-tl{top:0;left:0;width:14px;height:14px;cursor:nwse-resize}.xpath-dock-body::-webkit-scrollbar{width:6px}.xpath-dock-body::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.12);border-radius:3px}.xpath-tester-section{display:flex;flex-direction:column;gap:6px}.xpath-input-row{display:flex;align-items:center;background:#13161f;border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:2px 4px 2px 8px;gap:6px;transition:border-color 0.2s,box-shadow 0.2s}.xpath-input-row:focus-within{border-color:#60a5fa;box-shadow:0 0 0 2px rgba(96,165,250,0.2)}.xpath-tester-input{flex:1;background:transparent;border:none;color:#f1f5f9;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:12px;outline:none;padding:6px 0}.xpath-tester-input::placeholder{color:#64748b;font-family:inherit}.xpath-eval-badge{font-size:11px;padding:2px 6px;border-radius:4px;font-weight:600;white-space:nowrap}.xpath-eval-badge.match-unique{background:rgba(34,197,94,0.15);color:#4ade80;border:1px solid rgba(34,197,94,0.3)}.xpath-eval-badge.match-multiple{background:rgba(234,179,8,0.15);color:#facc15;border:1px solid rgba(234,179,8,0.3)}.xpath-eval-badge.match-none{background:rgba(239,68,68,0.15);color:#f87171;border:1px solid rgba(239,68,68,0.3)}.xpath-match-nav{display:flex;align-items:center;gap:2px}.xpath-btn-mini{background:rgba(255,255,255,0.08);border:none;color:#cbd5e1;width:20px;height:20px;border-radius:4px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:10px}.xpath-btn-mini:hover{background:rgba(255,255,255,0.16);color:#fff}.xpath-breadcrumbs-container{background:#141822;border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:6px 10px;display:flex;flex-direction:column;gap:5px}.xpath-breadcrumbs-header{display:flex;align-items:center;justify-content:space-between;font-size:10px;text-transform:uppercase;letter-spacing:0.05em;font-weight:700;color:#64748b}.xpath-breadcrumbs-track{display:flex;align-items:center;gap:4px;overflow-x:auto;white-space:nowrap;padding-bottom:2px;scrollbar-width:thin;scrollbar-color:rgba(255,255,255,0.15) transparent}.xpath-breadcrumbs-track::-webkit-scrollbar{height:3px}.xpath-breadcrumbs-track::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.18);border-radius:3px}.xpath-bc-btn{background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#94a3b8;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:11px;padding:2px 7px;border-radius:5px;cursor:pointer;transition:all 0.15s ease;flex-shrink:0;display:inline-flex;align-items:center}.xpath-bc-btn:hover{background:rgba(59,130,246,0.2);border-color:rgba(59,130,246,0.5);color:#93c5fd;transform:translateY(-1px)}.xpath-bc-btn.active{background:rgba(59,130,246,0.25);border-color:#3b82f6;color:#60a5fa;font-weight:700;box-shadow:0 0 8px rgba(59,130,246,0.25)}.xpath-bc-sep{color:#475569;font-size:10px;flex-shrink:0;user-select:none}.xpath-children-row{display:flex;align-items:center;gap:4px;overflow-x:auto;white-space:nowrap;padding-top:4px;border-top:1px dashed rgba(255,255,255,0.06)}.xpath-children-label{font-size:10px;font-weight:600;color:#64748b;margin-right:2px;flex-shrink:0}.xpath-child-pill{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);color:#cbd5e1;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:10px;padding:2px 6px;border-radius:4px;cursor:pointer;transition:all 0.15s ease;flex-shrink:0}.xpath-child-pill:hover{background:rgba(147,197,253,0.15);border-color:rgba(147,197,253,0.4);color:#93c5fd;transform:translateY(-1px)}.xpath-matrix-card{background:#151a24;border:1px solid rgba(147,197,253,0.18);border-radius:10px;overflow:hidden;display:flex;flex-direction:column}.xpath-matrix-header{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;background:#1a202c;cursor:pointer;user-select:none;border-bottom:1px solid rgba(255,255,255,0.06);transition:background 0.15s ease}.xpath-matrix-header:hover{background:#202736}.xpath-matrix-title{display:flex;align-items:center;gap:6px;font-size:11px;font-weight:700;color:#93c5fd;letter-spacing:0.02em}.xpath-matrix-count{font-size:10px;background:rgba(147,197,253,0.12);color:#60a5fa;border:1px solid rgba(147,197,253,0.25);padding:1px 6px;border-radius:9999px;font-weight:600}.xpath-matrix-toggle-icon{color:#64748b;font-size:10px;transition:transform 0.2s ease}.xpath-matrix-card.collapsed .xpath-matrix-toggle-icon{transform:rotate(-90deg)}.xpath-matrix-card.collapsed .xpath-matrix-body{display:none}.xpath-matrix-body{padding:10px 12px;display:flex;flex-direction:column;gap:10px}.xpath-custom-preview{background:#0f131a;border:1px solid rgba(255,255,255,0.08);border-radius:6px;padding:8px 10px;display:flex;flex-direction:column;gap:6px}.xpath-custom-code{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:11px;color:#e2e8f0;word-break:break-all;line-height:1.4;user-select:all}.xpath-custom-actions{display:flex;align-items:center;justify-content:space-between;gap:8px;padding-top:4px;border-top:1px dashed rgba(255,255,255,0.08)}.xpath-matrix-grid{display:flex;flex-wrap:wrap;gap:6px;max-height:160px;overflow-y:auto;padding-right:2px;scrollbar-width:thin}.xpath-matrix-grid::-webkit-scrollbar{width:3px}.xpath-matrix-grid::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.16);border-radius:3px}.xpath-matrix-chip{display:inline-flex;align-items:center;gap:6px;background:#1a202c;border:1px solid rgba(255,255,255,0.08);border-radius:6px;padding:4px 8px;cursor:pointer;user-select:none;font-size:11px;transition:all 0.15s ease}.xpath-matrix-chip:hover{background:#232c3d;border-color:rgba(147,197,253,0.3)}.xpath-matrix-chip input[type=\"checkbox\"]{cursor:pointer;accent-color:#3b82f6;width:13px;height:13px;margin:0}.xpath-chip-tag{font-size:10px;font-weight:700;padding:1px 4px;border-radius:3px;text-transform:uppercase}.xpath-chip-tag.type-tag{background:rgba(239,68,68,0.15);color:#fca5a5}.xpath-chip-tag.type-id{background:rgba(168,85,247,0.15);color:#d8b4fe}.xpath-chip-tag.type-attr{background:rgba(59,130,246,0.15);color:#93c5fd}.xpath-chip-tag.type-class{background:rgba(245,158,11,0.15);color:#fcd34d}.xpath-chip-tag.type-text{background:rgba(16,185,129,0.15);color:#6ee7b7}.xpath-chip-val{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:11px;color:#cbd5e1;max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.xpath-target-card{background:rgba(31,36,48,0.5);border:1px solid rgba(255,255,255,0.06);border-radius:8px;padding:8px 10px;display:flex;align-items:center;justify-content:space-between}.xpath-element-tag{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:11px;font-weight:700;color:#f87171;background:rgba(239,68,68,0.1);padding:2px 6px;border-radius:4px;border:1px solid rgba(239,68,68,0.25)}.xpath-element-desc{font-size:11px;color:#94a3b8;max-width:260px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.xpath-best-card{background:#1f2533;border:1px solid rgba(96,165,250,0.25);border-radius:10px;padding:12px;display:flex;flex-direction:column;gap:8px;position:relative;box-shadow:0 4px 14px rgba(0,0,0,0.15)}.xpath-card-top{display:flex;align-items:center;justify-content:space-between}.xpath-badge-score{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;letter-spacing:0.03em;text-transform:uppercase;background:rgba(34,197,94,0.15);color:#4ade80;border:1px solid rgba(34,197,94,0.25);padding:2px 8px;border-radius:9999px}.xpath-badge-type{font-size:11px;color:#93c5fd;font-weight:600}.xpath-code-display{background:#13161f;border:1px solid rgba(255,255,255,0.08);border-radius:6px;padding:8px 10px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:12px;color:#bfdbfe;word-break:break-all;user-select:all;line-height:1.5}.xpath-actions-row{display:flex;align-items:center;justify-content:space-between;gap:8px}.xpath-format-select{background:#181c24;border:1px solid rgba(255,255,255,0.12);color:#e2e8f0;font-size:11px;padding:4px 8px;border-radius:6px;outline:none;cursor:pointer}.xpath-btn-copy{background:#3b82f6;color:white;border:none;padding:6px 12px;border-radius:6px;font-size:11px;font-weight:600;display:inline-flex;align-items:center;gap:6px;cursor:pointer;transition:all 0.15s ease}.xpath-btn-copy:hover{background:#2563eb;transform:translateY(-1px)}.xpath-btn-copy.copied{background:#16a34a;color:#ffffff}.xpath-action-toolbar{display:flex;align-items:center;gap:4px;background:rgba(15,19,26,0.7);padding:3px 4px;border-radius:6px;border:1px solid rgba(255,255,255,0.08);overflow:visible !important;position:relative;z-index:40;flex-wrap:wrap}.xpath-action-btn{background:transparent;border:1px solid transparent;color:#94a3b8;font-size:10px;font-weight:600;padding:3px 8px;border-radius:4px;cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;gap:4px;transition:all 0.15s ease;user-select:none}.xpath-action-btn:hover{background:rgba(255,255,255,0.08);color:#e2e8f0}.xpath-action-btn.active{background:#3b82f6;color:#ffffff;border-color:#60a5fa;box-shadow:0 1px 4px rgba(59,130,246,0.35)}.xpath-action-dropdown-wrapper{position:relative;display:inline-flex}.xpath-action-dropdown-menu{position:absolute;top:calc(100% + 4px);left:0;background:#0f172a;border:1px solid rgba(255,255,255,0.18);border-radius:8px;box-shadow:0 16px 36px rgba(0,0,0,0.85),0 0 0 1px rgba(255,255,255,0.08);padding:5px;z-index:999999;display:none;flex-direction:column;min-width:175px;gap:2px;backdrop-filter:blur(16px);animation:xpathDropdownFade 0.14s ease-out}.xpath-action-dropdown-menu.open{display:flex !important}.xpath-action-dropdown-item{background:transparent;border:none;color:#cbd5e1;font-size:11px;font-weight:500;text-align:left;padding:5px 8px;border-radius:5px;cursor:pointer;transition:all 0.12s ease;display:flex;align-items:center;justify-content:space-between;gap:6px}.xpath-action-dropdown-item:hover{background:rgba(59,130,246,0.2);color:#93c5fd}.xpath-action-dropdown-item.active{background:rgba(59,130,246,0.3);color:#ffffff;font-weight:600}.xpath-action-dropdown-item .opt-check{font-size:11px;color:#60a5fa;font-weight:700}.xpath-playwright-actions-row{display:flex;align-items:center;gap:5px;flex-wrap:wrap;margin-top:6px;padding-top:6px;border-top:1px dashed rgba(34,197,94,0.2)}.xpath-playwright-actions-label{font-size:10px;font-weight:700;color:#86efac;margin-right:2px}.xpath-btn-action-mini{background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.25);color:#86efac;font-size:10px;font-weight:600;padding:2px 7px;border-radius:4px;cursor:pointer;display:inline-flex;align-items:center;gap:3px;transition:all 0.15s ease}.xpath-btn-action-mini:hover{background:rgba(34,197,94,0.25);border-color:rgba(34,197,94,0.45);color:#ffffff;transform:translateY(-1px)}.xpath-btn-action-mini.copied{background:#16a34a;color:#ffffff}.xpath-section-title{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;color:#64748b;margin-top:4px}.xpath-alt-list{display:flex;flex-direction:column;gap:6px}.xpath-alt-item{background:#1f2430;border:1px solid rgba(255,255,255,0.06);border-radius:8px;padding:8px 10px;display:flex;align-items:center;justify-content:space-between;gap:8px;transition:border-color 0.15s,background-color 0.15s}.xpath-alt-item:hover{background:#242b38;border-color:rgba(255,255,255,0.12)}.xpath-alt-meta{display:flex;flex-direction:column;gap:3px;overflow:hidden;flex:1}.xpath-alt-label{font-size:10px;font-weight:600;color:#94a3b8}.xpath-alt-code{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:11px;color:#e2e8f0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.xpath-btn-small,.xpath-btn-copy-small{background:rgba(255,255,255,0.06);border:none;color:#94a3b8;padding:4px 8px;border-radius:5px;font-size:10px;font-weight:600;cursor:pointer;white-space:nowrap;transition:all 0.15s ease}.xpath-btn-small:hover,.xpath-btn-copy-small:hover{background:rgba(255,255,255,0.14);color:#ffffff}.xpath-btn-copy-small.copied{background:#16a34a;color:#ffffff}.xpath-empty-state{text-align:center;padding:24px 16px;color:#64748b;display:flex;flex-direction:column;align-items:center;gap:8px}.xpath-empty-icon{width:32px;height:32px;stroke:#475569}.xpath-playwright-card{background:#112019;border:1px solid rgba(34,197,94,0.35);border-radius:10px;padding:12px;display:flex;flex-direction:column;gap:8px;position:relative;box-shadow:0 4px 14px rgba(0,0,0,0.2)}.xpath-badge-playwright{display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:700;color:#4ade80;background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.25);padding:2px 7px;border-radius:5px}.xpath-badge-playwright svg{fill:#4ade80;stroke:none}.xpath-code-playwright{background:#091711 !important;border-color:rgba(34,197,94,0.2) !important;color:#86efac !important}.xpath-btn-copy-playwright{background:#15803d !important;color:white !important}.xpath-btn-copy-playwright:hover{background:#16a34a !important}.xpath-hint-text{font-size:11px;color:#86efac;opacity:0.8;font-style:italic}.xpath-playwright-more{margin-top:4px;padding-top:6px;border-top:1px dashed rgba(34,197,94,0.2);display:flex;flex-direction:column;gap:5px}.xpath-relative-card{background:#171226;border:1px solid rgba(168,85,247,0.35);border-radius:10px;padding:10px 12px;display:flex;flex-direction:column;position:relative;box-shadow:0 4px 14px rgba(0,0,0,0.2)}.xpath-relative-header{display:flex;align-items:center;justify-content:space-between;cursor:pointer;user-select:none}.xpath-relative-toggle-icon{color:#c084fc;font-size:10px;transition:transform 0.2s ease}.xpath-relative-card.collapsed .xpath-relative-toggle-icon{transform:rotate(-90deg)}.xpath-relative-card.collapsed .xpath-relative-body{display:none}.xpath-relative-body{display:flex;flex-direction:column;gap:8px;margin-top:8px}.xpath-alt-dropdown-card{background:#151a24;border:1px solid rgba(255,255,255,0.08);border-radius:10px;overflow:hidden;display:flex;flex-direction:column}.xpath-alt-dropdown-header{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;background:#191f2b;cursor:pointer;user-select:none;border-bottom:1px solid rgba(255,255,255,0.06);transition:background 0.15s ease}.xpath-alt-dropdown-header:hover{background:#202736}.xpath-alt-dropdown-title{display:flex;align-items:center;gap:6px;font-size:11px;font-weight:700;color:#c7d2fe}.xpath-alt-count-badge{font-size:10px;background:rgba(165,180,252,0.14);color:#a5b4fc;border:1px solid rgba(165,180,252,0.28);padding:1px 6px;border-radius:9999px;font-weight:600}.xpath-alt-toggle-icon{color:#64748b;font-size:10px;transition:transform 0.2s ease}.xpath-alt-dropdown-card.collapsed .xpath-alt-toggle-icon{transform:rotate(-90deg)}.xpath-alt-dropdown-card.collapsed .xpath-alt-dropdown-body{display:none}.xpath-alt-dropdown-body{padding:8px 10px}.xpath-btn-save-common{background:rgba(245,158,11,0.14) !important;color:#fbbf24 !important;border:1px solid rgba(245,158,11,0.35) !important;font-weight:700 !important;transition:all 0.2s cubic-bezier(0.16,1,0.3,1) !important}.xpath-btn-save-common:hover{background:rgba(245,158,11,0.25) !important;border-color:#f59e0b !important;box-shadow:0 0 10px rgba(245,158,11,0.3);transform:translateY(-1px)}.xpath-btn-save-common.is-saved{background:#f59e0b !important;color:#18150e !important;border-color:#fbbf24 !important;box-shadow:0 0 12px rgba(245,158,11,0.45)}.xpath-saved-action-tag{display:inline-flex;align-items:center;gap:3px;font-size:9.5px;font-weight:700;text-transform:uppercase;padding:1px 5px;border-radius:3px;letter-spacing:0.03em}.xpath-saved-action-click{background:rgba(245,158,11,0.18);color:#fbbf24;border:1px solid rgba(245,158,11,0.35)}.xpath-saved-action-fill{background:rgba(56,189,248,0.18);color:#38bdf8;border:1px solid rgba(56,189,248,0.35)}.xpath-saved-action-assert{background:rgba(168,85,247,0.18);color:#c084fc;border:1px solid rgba(168,85,247,0.35)}.xpath-saved-action-wait{background:rgba(249,115,22,0.18);color:#fb923c;border:1px solid rgba(249,115,22,0.35)}.xpath-saved-action-text{background:rgba(16,185,129,0.18);color:#4ade80;border:1px solid rgba(16,185,129,0.35)}.xpath-saved-action-locator{background:rgba(148,163,184,0.14);color:#94a3b8;border:1px solid rgba(148,163,184,0.25)}.xpath-saved-label-action{background:rgba(245,158,11,0.2);color:#fbbf24}.xpath-badge-relative{display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:700;color:#c084fc;background:rgba(168,85,247,0.14);border:1px solid rgba(168,85,247,0.28);padding:2px 7px;border-radius:5px}.xpath-badge-relative svg{fill:none;stroke:#c084fc}.xpath-code-relative{background:#110d1c !important;border-color:rgba(168,85,247,0.22) !important;color:#e9d5ff !important}.xpath-btn-copy-relative{background:#7e22ce !important;color:white !important}.xpath-btn-copy-relative:hover{background:#9333ea !important}.xpath-hint-relative{font-size:11px;color:#d8b4fe;opacity:0.85;font-style:italic;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:250px}.xpath-relative-more{margin-top:4px;padding-top:6px;border-top:1px dashed rgba(168,85,247,0.22);display:flex;flex-direction:column;gap:5px}.xpath-dock-tabs{display:flex;align-items:center;background:#151922;border-bottom:1px solid rgba(255,255,255,0.08);padding:0 10px;gap:4px;user-select:none}.xpath-dock-tab{display:inline-flex;align-items:center;gap:6px;padding:8px 12px;background:transparent;border:none;border-bottom:2px solid transparent;color:#94a3b8;font-size:12px;font-weight:600;cursor:pointer;transition:all 0.15s ease}.xpath-dock-tab:hover{color:#f1f5f9;background:rgba(255,255,255,0.03)}.xpath-dock-tab.active{color:#60a5fa;border-bottom-color:#3b82f6;background:rgba(59,130,246,0.06)}.xpath-dock-tab svg{width:14px;height:14px}.xpath-tab-badge{display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;padding:0 5px;border-radius:9999px;font-size:10px;font-weight:700;background:rgba(245,158,11,0.2);color:#fbbf24;border:1px solid rgba(245,158,11,0.4)}.xpath-btn-save-locator{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;background:rgba(245,158,11,0.12);border:1px solid rgba(245,158,11,0.35);color:#fbbf24;transition:all 0.2s cubic-bezier(0.16,1,0.3,1)}.xpath-btn-save-locator:hover{background:rgba(245,158,11,0.22);border-color:#f59e0b;transform:translateY(-1px);box-shadow:0 2px 8px rgba(245,158,11,0.25)}.xpath-btn-save-locator.is-saved{background:#f59e0b;color:#1a160d;border-color:#fbbf24;box-shadow:0 0 12px rgba(245,158,11,0.4)}.xpath-btn-save-locator.is-saved:hover{background:#d97706}.xpath-saved-view{display:flex;flex-direction:column;flex:1;overflow:hidden;background:#181c24}.xpath-saved-toolbar{display:flex;flex-direction:column;gap:8px;padding:10px 14px;background:#161a22;border-bottom:1px solid rgba(255,255,255,0.08)}.xpath-saved-search-row{display:flex;align-items:center;gap:8px;background:#0f131a;border:1px solid rgba(255,255,255,0.12);border-radius:6px;padding:4px 10px}.xpath-saved-search-row:focus-within{border-color:#3b82f6;box-shadow:0 0 0 2px rgba(59,130,246,0.2)}.xpath-saved-search-input{flex:1;background:transparent;border:none;outline:none;color:#f1f5f9;font-size:12px;font-family:inherit}.xpath-saved-search-input::placeholder{color:#64748b}.xpath-saved-actions-bar{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px}.xpath-delete-download-toggle{display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-size:11px;color:#cbd5e1;user-select:none}.xpath-delete-download-toggle input[type=\"checkbox\"]{cursor:pointer;accent-color:#ef4444;width:14px;height:14px}.xpath-saved-sort-select{background:#0d1117;color:#93c5fd;border:1px solid rgba(59,130,246,0.3);border-radius:4px;font-size:10.5px;font-weight:600;padding:3px 6px;outline:none;cursor:pointer;transition:all 0.15s ease}.xpath-saved-sort-select:hover{border-color:#3b82f6;background:#141a24}.xpath-saved-step-badge{font-size:9.5px;font-weight:800;color:#a5b4fc;background:rgba(99,102,241,0.18);border:1px solid rgba(99,102,241,0.35);padding:1px 6px;border-radius:9999px;flex-shrink:0;letter-spacing:0.02em}.xpath-export-buttons-group{display:flex;align-items:center;gap:6px}.xpath-btn-export{display:inline-flex;align-items:center;gap:4px;padding:4px 9px;border-radius:5px;font-size:11px;font-weight:600;cursor:pointer;background:#1e293b;color:#f8fafc;border:1px solid rgba(255,255,255,0.14);transition:all 0.15s ease}.xpath-btn-export:hover{background:#334155;border-color:rgba(255,255,255,0.25);transform:translateY(-1px)}.xpath-btn-export-json{background:rgba(16,185,129,0.15);color:#6ee7b7;border-color:rgba(16,185,129,0.35)}.xpath-btn-export-json:hover{background:rgba(16,185,129,0.25);border-color:#10b981}.xpath-btn-export-csv{background:rgba(59,130,246,0.15);color:#93c5fd;border-color:rgba(59,130,246,0.35)}.xpath-btn-export-csv:hover{background:rgba(59,130,246,0.25);border-color:#3b82f6}.xpath-btn-clear-saved{display:inline-flex;align-items:center;gap:4px;padding:4px 8px;border-radius:5px;font-size:11px;font-weight:600;cursor:pointer;background:rgba(239,68,68,0.1);color:#fca5a5;border:1px solid rgba(239,68,68,0.25);transition:all 0.15s ease}.xpath-btn-clear-saved:hover{background:rgba(239,68,68,0.2);border-color:#ef4444}.xpath-saved-list{flex:1;overflow-y:auto;padding:10px 14px;display:flex;flex-direction:column;gap:10px}.xpath-saved-item{background:#151922;border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:10px;display:flex;flex-direction:column;gap:6px;position:relative;transition:all 0.15s ease}.xpath-saved-item:hover{border-color:rgba(147,197,253,0.25);box-shadow:0 4px 12px rgba(0,0,0,0.25)}.xpath-saved-item-header{display:flex;align-items:center;justify-content:space-between;gap:8px}.xpath-saved-item-info{display:flex;align-items:center;gap:6px;overflow:hidden}.xpath-saved-tag{background:rgba(96,165,250,0.15);color:#93c5fd;border:1px solid rgba(96,165,250,0.3);font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:10px;font-weight:700;padding:1px 5px;border-radius:4px;flex-shrink:0}.xpath-saved-text{font-size:12px;font-weight:600;color:#f1f5f9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.xpath-saved-source-pill{font-size:9px;color:#94a3b8;background:rgba(255,255,255,0.05);padding:1px 5px;border-radius:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:140px}.xpath-saved-item-actions{display:flex;align-items:center;gap:4px;flex-shrink:0}.xpath-saved-btn-del{background:transparent;border:none;color:#64748b;cursor:pointer;padding:3px;border-radius:4px;display:flex;align-items:center;justify-content:center;transition:all 0.15s ease}.xpath-saved-btn-del:hover{color:#ef4444;background:rgba(239,68,68,0.1)}.xpath-saved-code-box{background:#0d1117;border:1px solid rgba(255,255,255,0.06);border-radius:5px;padding:6px 8px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:11px;color:#cbd5e1;word-break:break-all;display:flex;align-items:flex-start;justify-content:space-between;gap:6px}.xpath-saved-code-label{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.04em;padding:1px 4px;border-radius:3px;margin-right:4px;flex-shrink:0}.xpath-saved-label-xpath{background:rgba(59,130,246,0.15);color:#60a5fa}.xpath-saved-label-pw{background:rgba(34,197,94,0.15);color:#4ade80}.xpath-saved-code-text{flex:1}.xpath-saved-btn-copy{background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);color:#e2e8f0;font-size:10px;padding:2px 6px;border-radius:3px;cursor:pointer;flex-shrink:0;transition:all 0.15s ease}.xpath-saved-btn-copy:hover{background:rgba(59,130,246,0.25);border-color:#3b82f6;color:#93c5fd}.xpath-saved-foot{display:flex;align-items:center;justify-content:space-between;margin-top:2px}.xpath-saved-time{font-size:10px;color:#64748b}.xpath-saved-foot-actions{display:flex;gap:6px}.xpath-btn-test-page{font-size:10px;padding:2px 7px;background:rgba(99,102,241,0.15);color:#a5b4fc;border:1px solid rgba(99,102,241,0.3);border-radius:4px;cursor:pointer;transition:all 0.15s ease}.xpath-btn-test-page:hover{background:rgba(99,102,241,0.3);border-color:#818cf8}.xpath-saved-toast{position:absolute;top:10px;left:50%;transform:translateX(-50%);background:#10b981;color:white;padding:6px 14px;border-radius:9999px;font-size:11px;font-weight:600;box-shadow:0 4px 12px rgba(0,0,0,0.3);z-index:10;pointer-events:none;animation:xpathToastFade 2.4s forwards}@keyframes xpathToastFade{0%{opacity:0;transform:translate(-50%,-6px)}15%{opacity:1;transform:translate(-50%,0)}80%{opacity:1;transform:translate(-50%,0)}100%{opacity:0;transform:translate(-50%,-6px)}}.xpath-empty-saved{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:40px 20px;color:#64748b;gap:10px}.xpath-empty-saved svg{width:44px;height:44px;stroke:#475569}.xpath-empty-saved h4{font-size:14px;font-weight:600;color:#cbd5e1}.xpath-empty-saved p{font-size:12px;max-width:260px;line-height:1.5}.xpath-finder-dock.mini-bar{width:220px !important;height:42px !important;min-height:42px !important;overflow:hidden !important;border-radius:24px !important;box-shadow:0 8px 28px rgba(0,0,0,0.6),0 0 0 1px rgba(99,102,241,0.4) !important}.xpath-finder-dock.mini-bar .xpath-dock-tabs,.xpath-finder-dock.mini-bar #inspectorTabPane,.xpath-finder-dock.mini-bar #savedTabPane,.xpath-finder-dock.mini-bar #recorderTabPane,.xpath-finder-dock.mini-bar .xpath-resizer,.xpath-finder-dock.mini-bar .xpath-mini-bar-preview{display:none !important}.xpath-finder-dock.mini-bar .xpath-dock-header{height:42px;padding:0 12px;border-bottom:none;background:#0f172a}.xpath-mini-bar-preview{display:none;align-items:center;gap:8px;flex:1;overflow:hidden;margin:0 8px}.xpath-finder-dock.mini-bar .xpath-mini-bar-preview{display:flex}.xpath-mini-tag{font-size:10px;font-weight:700;color:#38bdf8;background:rgba(56,189,248,0.15);padding:1px 6px;border-radius:4px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;flex-shrink:0}.xpath-mini-code{font-size:11px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;color:#cbd5e1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1}.xpath-mini-copy-btn{background:#6366f1;color:#ffffff;border:none;border-radius:4px;font-size:10px;font-weight:600;padding:3px 8px;cursor:pointer;flex-shrink:0}.xpath-mini-copy-btn.copied{background:#10b981}.xpath-input-clear-btn{background:none;border:none;color:#64748b;font-size:12px;cursor:pointer;padding:2px 4px;display:flex;align-items:center;justify-content:center;transition:color 0.15s ease}.xpath-input-clear-btn:hover{color:#f1f5f9}.xpath-hero-card{background:#131b2e;border:1px solid rgba(99,102,241,0.25);border-radius:10px;padding:12px;display:flex;flex-direction:column;gap:10px;box-shadow:0 4px 18px rgba(0,0,0,0.25);position:relative;overflow:visible !important}.xpath-hero-header{display:flex;align-items:center;justify-content:space-between;gap:8px}.xpath-hero-target-info{display:flex;align-items:center;gap:8px;overflow:hidden;flex:1}.xpath-hero-score-badge{font-size:10px;font-weight:700;padding:2px 8px;border-radius:9999px;background:rgba(34,197,94,0.15);color:#4ade80;border:1px solid rgba(34,197,94,0.3);white-space:nowrap;flex-shrink:0}.xpath-hero-iframe-badge{display:inline-flex;align-items:center;gap:3px;font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px;background:rgba(168,85,247,0.18);color:#c084fc;border:1px solid rgba(168,85,247,0.38);white-space:nowrap;flex-shrink:0}.xpath-framework-segmented{display:flex;align-items:center;gap:3px;background:#0b0f19;padding:3px;border-radius:8px;border:1px solid rgba(255,255,255,0.08);overflow:visible !important;position:relative;z-index:50;flex-wrap:wrap}.xpath-framework-pill{background:transparent;border:none;color:#94a3b8;font-size:10px;font-weight:600;padding:4px 8px;border-radius:6px;cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;gap:4px;transition:all 0.15s ease;user-select:none}.xpath-framework-pill:hover{color:#e2e8f0;background:rgba(255,255,255,0.05)}.xpath-framework-pill.active{background:#6366f1;color:#ffffff;box-shadow:0 1px 6px rgba(99,102,241,0.4)}.xpath-framework-pill.active.is-playwright{background:#16a34a;box-shadow:0 1px 6px rgba(22,163,74,0.4)}.xpath-framework-pill.active.is-xpath{background:#2563eb;box-shadow:0 1px 6px rgba(37,99,235,0.4)}.xpath-framework-pill.active.is-selenium{background:#d97706;box-shadow:0 1px 6px rgba(217,119,6,0.4)}.xpath-framework-pill.active.is-css{background:#0284c7;box-shadow:0 1px 6px rgba(2,132,199,0.4)}.xpath-dropdown-wrapper,.xpath-framework-more-wrapper{position:relative;display:inline-flex;z-index:55}.xpath-dropdown-menu,.xpath-framework-more-dropdown{position:absolute;top:calc(100% + 5px);left:0;background:#0f172a;border:1px solid rgba(255,255,255,0.18);border-radius:8px;box-shadow:0 16px 36px rgba(0,0,0,0.85),0 0 0 1px rgba(255,255,255,0.08);padding:5px;z-index:999999;display:none;flex-direction:column;min-width:195px;gap:2px;backdrop-filter:blur(16px);animation:xpathDropdownFade 0.14s ease-out}.xpath-dropdown-menu.open,.xpath-framework-more-dropdown.open{display:flex !important}.xpath-dropdown-menu.align-right,.xpath-framework-more-dropdown{left:auto;right:0}@keyframes xpathDropdownFade{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}.xpath-dropdown-header{font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:0.05em;color:#64748b;padding:4px 8px 2px;user-select:none}.xpath-dropdown-item,.xpath-framework-more-opt{background:transparent;border:none;color:#cbd5e1;font-size:11px;font-weight:500;text-align:left;padding:6px 10px;border-radius:5px;cursor:pointer;transition:all 0.12s ease;display:flex;align-items:center;justify-content:space-between;gap:8px}.xpath-dropdown-item:hover,.xpath-framework-more-opt:hover{background:rgba(99,102,241,0.2);color:#c7d2fe}.xpath-dropdown-item.active,.xpath-framework-more-opt.active{background:rgba(99,102,241,0.3);color:#ffffff;font-weight:600}.xpath-dropdown-item.active.is-pw{background:rgba(22,163,74,0.25);color:#86efac}.xpath-dropdown-item.active.is-sel{background:rgba(217,119,6,0.25);color:#fde68a}.xpath-dropdown-item .opt-check{font-size:11px;color:#60a5fa;font-weight:700}.xpath-hero-code-wrap{position:relative;background:#090d16;border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:10px 12px;display:flex;flex-direction:column;gap:8px}.xpath-hero-code{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:12px;color:#38bdf8;line-height:1.5;word-break:break-all;user-select:all;min-height:24px}.xpath-hero-code.is-xpath{color:#93c5fd}.xpath-hero-code.is-playwright{color:#4ade80}.xpath-hero-code-footer{display:flex;align-items:center;justify-content:space-between;gap:8px;padding-top:6px;border-top:1px dashed rgba(255,255,255,0.08)}.xpath-hero-framework-tag{font-size:10px;color:#94a3b8;font-weight:500}.xpath-hero-btn-copy{background:#6366f1;color:#ffffff;border:none;border-radius:6px;font-size:11px;font-weight:600;padding:5px 12px;cursor:pointer;display:inline-flex;align-items:center;gap:6px;transition:all 0.15s ease}.xpath-hero-btn-copy:hover{background:#4f46e5;transform:translateY(-1px);box-shadow:0 4px 12px rgba(99,102,241,0.4)}.xpath-hero-btn-copy.copied{background:#10b981 !important;box-shadow:0 0 12px rgba(16,185,129,0.5) !important}.xpath-btn-export-script{background:rgba(168,85,247,0.18);color:#d8b4fe;border:1px solid rgba(168,85,247,0.35)}.xpath-btn-export-script:hover{background:rgba(168,85,247,0.32);border-color:#a855f7;color:#f3e8ff}.xpath-btn-record{background:rgba(239,68,68,0.15) !important;color:#fca5a5 !important;border:1px solid rgba(239,68,68,0.38) !important;font-weight:600;display:inline-flex;align-items:center;gap:5px;white-space:nowrap;flex-shrink:0}.xpath-btn-record:hover{background:rgba(239,68,68,0.28) !important;border-color:#ef4444 !important;color:#fee2e2 !important;box-shadow:0 0 10px rgba(239,68,68,0.3)}.xpath-btn-record.is-recording{background:#dc2626 !important;color:#ffffff !important;border-color:#ef4444 !important;animation:xpath-pulse-rec 1.8s infinite}@keyframes xpath-pulse-rec{0%{box-shadow:0 0 0 0 rgba(239,68,68,0.6)}70%{box-shadow:0 0 0 8px rgba(239,68,68,0)}100%{box-shadow:0 0 0 0 rgba(239,68,68,0)}}.xpath-rec-hud{position:fixed;top:18px;left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:10px;padding:8px 16px;background:rgba(15,23,42,0.94);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1.5px solid rgba(239,68,68,0.5);border-radius:9999px;box-shadow:0 12px 36px rgba(0,0,0,0.55),0 0 18px rgba(239,68,68,0.25);z-index:2147483647;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#f1f5f9;user-select:none;animation:xpath-hud-slide 0.25s cubic-bezier(0.16,1,0.3,1)}@keyframes xpath-hud-slide{from{opacity:0;transform:translate(-50%,-16px)}to{opacity:1;transform:translate(-50%,0)}}.xpath-rec-dot{width:10px;height:10px;border-radius:50%;background:#ef4444;box-shadow:0 0 10px #ef4444;animation:xpath-rec-blink 1.2s infinite ease-in-out}.xpath-rec-dot.paused{background:#eab308;box-shadow:0 0 10px #eab308;animation:none}@keyframes xpath-rec-blink{0%,100%{opacity:1;transform:scale(1)}50%{opacity:0.35;transform:scale(0.85)}}.xpath-rec-hud-title{font-size:12px;font-weight:700;letter-spacing:0.3px;color:#fca5a5;display:flex;align-items:center;gap:6px}.xpath-rec-hud-count{font-size:11px;background:rgba(239,68,68,0.2);color:#fecaca;padding:2px 7px;border-radius:9999px;border:1px solid rgba(239,68,68,0.3);font-weight:600}.xpath-rec-hud-divider{width:1px;height:18px;background:rgba(255,255,255,0.15)}.xpath-rec-hud-btn{background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.14);color:#e2e8f0;padding:5px 11px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:5px;transition:all 0.15s ease}.xpath-rec-hud-btn:hover{background:rgba(255,255,255,0.16);border-color:rgba(255,255,255,0.3);color:#ffffff;transform:translateY(-1px)}.xpath-rec-hud-btn.is-assert{background:rgba(234,179,8,0.15);border-color:rgba(234,179,8,0.4);color:#fde047}.xpath-rec-hud-btn.is-assert:hover{background:rgba(234,179,8,0.28);border-color:#facc15;color:#fef08a}.xpath-rec-hud-btn.is-assert.active{background:#ca8a04;border-color:#eab308;color:#000000;font-weight:700;animation:xpath-pulse-rec 1.5s infinite}.xpath-rec-hud-btn.is-stop{background:#ef4444;border-color:#f87171;color:#ffffff;font-weight:700}.xpath-rec-hud-btn.is-stop:hover{background:#dc2626;border-color:#ef4444;box-shadow:0 0 12px rgba(239,68,68,0.5)}body.xpath-assert-picking-active *{cursor:crosshair !important}.xpath-recorder-view{display:flex;flex-direction:column;flex:1;overflow:hidden;background:#141720}.xpath-recorder-toolbar{padding:10px 14px;background:#1a1e29;border-bottom:1px solid rgba(255,255,255,0.08);display:flex;flex-direction:column;gap:8px}.xpath-recorder-status-row{display:flex;align-items:center;justify-content:space-between}.xpath-rec-live-badge{font-size:11px;font-weight:700;display:inline-flex;align-items:center;gap:6px;padding:3px 8px;border-radius:9999px;background:rgba(239,68,68,0.18);color:#fca5a5;border:1px solid rgba(239,68,68,0.35)}.xpath-rec-live-badge.idle{background:rgba(100,116,139,0.15);color:#94a3b8;border-color:rgba(100,116,139,0.25)}.xpath-rec-live-badge.paused{background:rgba(234,179,8,0.18);color:#fde047;border-color:rgba(234,179,8,0.35)}.xpath-recorder-actions-row{display:flex;align-items:center;justify-content:space-between;gap:6px;flex-wrap:wrap}.xpath-recorder-framework-select{background:#0f1420;border:1px solid rgba(255,255,255,0.15);color:#e2e8f0;font-size:11px;padding:4px 8px;border-radius:6px;outline:none;cursor:pointer}.xpath-recorder-framework-select:focus{border-color:#6366f1}.xpath-recorder-btn-group{display:flex;align-items:center;gap:6px}.xpath-recorder-timeline{flex:1;overflow-y:auto;padding:12px 14px;display:flex;flex-direction:column;gap:10px}.xpath-recorder-timeline::-webkit-scrollbar{width:6px}.xpath-recorder-timeline::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.15);border-radius:3px}.xpath-rec-step-card{background:#1c2230;border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:10px 12px;display:flex;flex-direction:column;gap:6px;transition:all 0.15s ease;position:relative}.xpath-rec-step-card:hover{border-color:rgba(99,102,241,0.35);background:#202738}.xpath-rec-step-card.is-assert,.xpath-rec-step-card.is-assertVisible,.xpath-rec-step-card.is-assertText{border-left:3px solid #eab308}.xpath-rec-step-card.is-click{border-left:3px solid #22c55e}.xpath-rec-step-card.is-fill{border-left:3px solid #3b82f6}.xpath-rec-step-card.is-check{border-left:3px solid #a855f7}.xpath-rec-step-card.is-select{border-left:3px solid #ec4899}.xpath-step-header{display:flex;align-items:center;justify-content:space-between;gap:8px}.xpath-step-badge-wrap{display:flex;align-items:center;gap:6px}.xpath-step-number{font-size:10px;font-weight:700;color:#94a3b8;background:rgba(255,255,255,0.07);width:18px;height:18px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center}.xpath-step-action-pill{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.4px;padding:2px 7px;border-radius:4px}.xpath-step-action-pill.click{background:rgba(34,197,94,0.18);color:#86efac;border:1px solid rgba(34,197,94,0.3)}.xpath-step-action-pill.fill{background:rgba(59,130,246,0.18);color:#93c5fd;border:1px solid rgba(59,130,246,0.3)}.xpath-step-action-pill.check,.xpath-step-action-pill.uncheck{background:rgba(168,85,247,0.18);color:#d8b4fe;border:1px solid rgba(168,85,247,0.3)}.xpath-step-action-pill.select{background:rgba(236,72,153,0.18);color:#f472b6;border:1px solid rgba(236,72,153,0.3)}.xpath-step-action-pill.assertVisible,.xpath-step-action-pill.assertText{background:rgba(234,179,8,0.18);color:#fde047;border:1px solid rgba(234,179,8,0.3)}.xpath-step-target-desc{font-size:11px;color:#cbd5e1;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:200px}.xpath-step-timestamp{font-size:10px;color:#64748b;font-family:ui-monospace,monospace}.xpath-step-code-box{background:#0c101a;border:1px solid rgba(255,255,255,0.08);border-radius:6px;padding:6px 8px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:11px;color:#38bdf8;word-break:break-all;line-height:1.45}.xpath-step-footer{display:flex;align-items:center;justify-content:space-between;padding-top:4px}.xpath-step-val-info{font-size:10px;color:#94a3b8;font-style:italic;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:250px}.xpath-step-buttons{display:flex;align-items:center;gap:5px}.xpath-btn-step-mini{background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:#94a3b8;font-size:10px;font-weight:600;padding:3px 7px;border-radius:4px;cursor:pointer;transition:all 0.12s ease;display:inline-flex;align-items:center;gap:4px}.xpath-btn-step-mini:hover{background:rgba(255,255,255,0.14);color:#ffffff;border-color:rgba(255,255,255,0.2)}.xpath-btn-step-delete{color:#f87171}.xpath-btn-step-delete:hover{background:rgba(239,68,68,0.2);border-color:#ef4444;color:#fca5a5}.xpath-recorder-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:40px 20px;text-align:center;color:#94a3b8;gap:12px}.xpath-recorder-empty-icon{width:48px;height:48px;color:#f87171;opacity:0.8;animation:xpath-pulse-rec 2.5s infinite;border-radius:50%;padding:4px}.xpath-recorder-empty h3{font-size:15px;font-weight:700;color:#f1f5f9}.xpath-recorder-empty p{font-size:12px;line-height:1.5;max-width:320px;color:#94a3b8}.xpath-btn-start-rec-big{background:#ef4444;color:#ffffff;border:none;padding:9px 18px;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:6px;margin-top:6px;transition:all 0.15s ease;box-shadow:0 4px 14px rgba(239,68,68,0.35)}.xpath-btn-start-rec-big:hover{background:#dc2626;transform:translateY(-1px);box-shadow:0 6px 18px rgba(239,68,68,0.5)}.xpath-rec-step-card.is-assert,.xpath-rec-step-card.is-assertVisible,.xpath-rec-step-card.is-assertHidden,.xpath-rec-step-card.is-assertText,.xpath-rec-step-card.is-assertContains,.xpath-rec-step-card.is-assertChecked,.xpath-rec-step-card.is-assertEnabled{border-left:3px solid #eab308}.xpath-rec-step-card.is-wait,.xpath-rec-step-card.is-waitForHidden,.xpath-rec-step-card.is-waitForVisible,.xpath-rec-step-card.is-waitTimeout{border-left:3px solid #06b6d4}.xpath-step-action-pill.waitForHidden,.xpath-step-action-pill.waitForVisible,.xpath-step-action-pill.waitTimeout{background:rgba(6,182,212,0.18);color:#67e8f9;border:1px solid rgba(6,182,212,0.35)}.xpath-step-action-pill.assertHidden{background:rgba(239,68,68,0.18);color:#fca5a5;border:1px solid rgba(239,68,68,0.35)}.xpath-step-action-pill.assertContains,.xpath-step-action-pill.assertChecked,.xpath-step-action-pill.assertEnabled{background:rgba(234,179,8,0.18);color:#fde047;border:1px solid rgba(234,179,8,0.3)}.xpath-step-action-select{background:#0f1420;border:1px solid rgba(255,255,255,0.15);color:#f8fafc;font-size:10px;font-weight:600;padding:2px 4px;border-radius:4px;outline:none;cursor:pointer;transition:all 0.15s ease;max-width:155px}.xpath-step-action-select:focus{border-color:#6366f1}.xpath-checkpoint-popover{position:fixed;z-index:2147483647;background:#0f172a;border:1.5px solid #38bdf8;border-radius:12px;padding:12px 14px;box-shadow:0 14px 40px rgba(0,0,0,0.75),0 0 24px rgba(56,189,248,0.35);width:320px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#f8fafc;display:flex;flex-direction:column;gap:8px;animation:xpathPopoverFade 0.15s ease-out forwards}@keyframes xpathPopoverFade{from{opacity:0;transform:translateY(-4px) scale(0.98)}to{opacity:1;transform:translateY(0) scale(1)}}.xpath-cp-header{display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.08);padding-bottom:6px}.xpath-cp-title{font-size:12px;font-weight:700;color:#38bdf8;display:flex;align-items:center;gap:6px}.xpath-cp-close{background:transparent;border:none;color:#94a3b8;cursor:pointer;font-size:13px;line-height:1;padding:2px 4px;border-radius:4px}.xpath-cp-close:hover{color:#ffffff;background:rgba(255,255,255,0.1)}.xpath-cp-element-desc{font-size:11px;color:#cbd5e1;background:rgba(255,255,255,0.05);padding:4px 7px;border-radius:5px;font-family:ui-monospace,monospace;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.xpath-cp-section-title{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:#94a3b8;margin-top:2px;display:flex;align-items:center;gap:4px}.xpath-cp-btn-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px}.xpath-cp-btn{background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);border-radius:6px;padding:6px 8px;color:#f1f5f9;font-size:11px;font-weight:600;cursor:pointer;display:flex;align-items:center;gap:5px;transition:all 0.15s ease;text-align:left}.xpath-cp-btn:hover{background:rgba(255,255,255,0.14);border-color:rgba(255,255,255,0.25);transform:translateY(-1px)}.xpath-cp-btn.recommended{grid-column:span 2;background:rgba(6,182,212,0.2);border:1.5px solid #06b6d4;color:#67e8f9;box-shadow:0 0 10px rgba(6,182,212,0.3)}.xpath-cp-btn.recommended:hover{background:rgba(6,182,212,0.35);box-shadow:0 0 14px rgba(6,182,212,0.5)}.xpath-cp-btn.is-assert:hover{border-color:#eab308;color:#fde047}.xpath-cp-btn.is-wait:hover{border-color:#38bdf8;color:#7dd3fc}";

  // Icons SVG constants
  const ICONS = {
    crosshair: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="22" y1="12" x2="18" y2="12"/><line x1="6" y1="12" x2="2" y2="12"/><line x1="12" y1="6" x2="12" y2="2"/><line x1="12" y1="22" x2="12" y2="18"/></svg>',
    copy: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
    check: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>',
    close: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    minus: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/></svg>',
    arrowLeft: '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>',
    arrowRight: '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>',
    search: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
    sparkles: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/></svg>',
    playwright: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polygon points="5 3 19 12 5 21 5 3"/></svg>',
    relative: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>',
    star: '<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
    starOutline: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
    trash: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
    download: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    code: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
    snapRight: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="15" y1="3" x2="15" y2="21"/></svg>',
    snapLeft: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/></svg>'
  };

  /**
   * Safe check for active extension context (guards against 'Extension context invalidated')
   */
  function isExtensionValid() {
    try {
      return Boolean(
        typeof chrome !== 'undefined' &&
        chrome.runtime &&
        chrome.runtime.id &&
        chrome.storage &&
        chrome.storage.local
      );
    } catch (e) {
      return false;
    }
  }

  /**
   * Storage helpers for Saved Locators (cross-tab via chrome.storage.local with localStorage fallback)
   */
  function getSavedLocators(callback) {
    try {
      if (isExtensionValid()) {
        chrome.storage.local.get([STORAGE_KEY_SAVED], (result) => {
          if (chrome.runtime && chrome.runtime.lastError) {
            fallbackLocalGet();
            return;
          }
          const list = (result && Array.isArray(result[STORAGE_KEY_SAVED])) ? result[STORAGE_KEY_SAVED] : [];
          callback(list);
        });
        return;
      }
    } catch (e) {}
    fallbackLocalGet();

    function fallbackLocalGet() {
      try {
        const raw = localStorage.getItem(STORAGE_KEY_SAVED);
        const list = raw ? JSON.parse(raw) : [];
        callback(Array.isArray(list) ? list : []);
      } catch (e) {
        callback([]);
      }
    }
  }

  function setSavedLocators(list, callback) {
    try {
      if (isExtensionValid()) {
        chrome.storage.local.set({ [STORAGE_KEY_SAVED]: list }, () => {
          if (chrome.runtime && chrome.runtime.lastError) {
            // Silently handled
          }
          if (callback) callback();
        });
        return;
      }
    } catch (e) {}
    try {
      localStorage.setItem(STORAGE_KEY_SAVED, JSON.stringify(list));
    } catch (e) {}
    if (callback) callback();
  }

  function isLocatorSaved(xpath, callback) {
    if (!xpath) {
      callback(false, null);
      return;
    }
    getSavedLocators((list) => {
      const found = list.find(it => it.bestXPath === xpath);
      callback(Boolean(found), found || null);
    });
  }

  function updateSavedCountBadge() {
    if (!shadowRoot) return;
    const badge = shadowRoot.getElementById('savedTabBadge');
    if (!badge) return;
    getSavedLocators((list) => {
      const count = list ? list.length : 0;
      badge.textContent = String(count);
      badge.style.display = count > 0 ? 'inline-flex' : 'none';
    });
  }

  function updateInspectorSaveButtonState() {
    if (!shadowRoot) return;
    const btnSave = shadowRoot.getElementById('btnSaveLocator');
    const saveBtnText = shadowRoot.getElementById('saveLocatorBtnText');
    if (!btnSave || !currentAnalysis || !currentAnalysis.best) return;

    isLocatorSaved(currentAnalysis.best, (saved) => {
      if (saved) {
        btnSave.classList.add('is-saved');
        if (saveBtnText) saveBtnText.textContent = 'Saved!';
        btnSave.title = 'Saved! Click to remove';
      } else {
        btnSave.classList.remove('is-saved');
        if (saveBtnText) saveBtnText.textContent = 'Save';
        btnSave.title = 'Save this locator across tabs';
      }
    });
  }

  function showSavedToast(message) {
    if (!shadowRoot) return;
    const existing = shadowRoot.querySelector('.xpath-saved-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'xpath-saved-toast';
    toast.textContent = message;
    if (dockContainer) {
      dockContainer.appendChild(toast);
      setTimeout(() => {
        try { toast.remove(); } catch (e) {}
      }, 2400);
    }
  }

  function formatRelativeTime(isoString) {
    if (!isoString) return '';
    try {
      const past = new Date(isoString).getTime();
      const now = Date.now();
      const diffSec = Math.floor((now - past) / 1000);
      if (diffSec < 45) return 'Just now';
      if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
      if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
      return new Date(isoString).toLocaleDateString();
    } catch (e) {
      return '';
    }
  }

  function triggerDownload(url, filename, rawContent, mimeType) {
    mimeType = mimeType || 'application/octet-stream';

    // 1. Delegate download to background service worker (uses chrome.downloads with downloads permission)
    if (rawContent && typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
      try {
        chrome.runtime.sendMessage({
          action: 'DOWNLOAD_FILE',
          content: rawContent,
          filename: filename,
          mimeType: mimeType
        }, (res) => {
          if (chrome.runtime.lastError || !res || !res.success) {
            fallbackAnchorDownload(url, filename);
          }
        });
        return;
      } catch (e) {
        console.warn('sendMessage exception, falling back to anchor:', e);
      }
    }

    // 2. Fallback to anchor click
    fallbackAnchorDownload(url, filename);
  }

  function fallbackAnchorDownload(url, filename) {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    (document.body || document.documentElement).appendChild(a);
    a.click();
    setTimeout(() => {
      try {
        a.remove();
        URL.revokeObjectURL(url);
      } catch (e) {}
    }, 2000);
  }

  function handlePostDownloadCleanup() {
    const chk = shadowRoot ? shadowRoot.getElementById('chkDeleteAfterDownload') : null;
    if (chk && chk.checked) {
      setSavedLocators([], () => {
        renderSavedLocatorsList();
        updateSavedCountBadge();
        updateInspectorSaveButtonState();
        showSavedToast('Exported & deleted saved locators! 🗑️');
      });
    } else {
      showSavedToast('Exported successfully! 📥');
    }
  }

  function getSortedAndFilteredSavedLocators(list, query = '', sortOrder = 'step-asc') {
    let result = Array.isArray(list) ? [...list] : [];
    if (sortOrder === 'step-asc') {
      result.sort((a, b) => new Date(a.timestamp || 0) - new Date(b.timestamp || 0));
    } else if (sortOrder === 'newest-desc') {
      result.sort((a, b) => new Date(b.timestamp || 0) - new Date(a.timestamp || 0));
    }

    if (query) {
      const q = query.toLowerCase();
      result = result.filter(item => 
        (item.tagName && item.tagName.toLowerCase().includes(q)) ||
        (item.text && item.text.toLowerCase().includes(q)) ||
        (item.bestXPath && item.bestXPath.toLowerCase().includes(q)) ||
        (item.bestPlaywright && item.bestPlaywright.toLowerCase().includes(q)) ||
        (item.action && item.action.toLowerCase().includes(q)) ||
        (item.actionCode && item.actionCode.toLowerCase().includes(q)) ||
        (item.pageTitle && item.pageTitle.toLowerCase().includes(q)) ||
        (item.pageUrl && item.pageUrl.toLowerCase().includes(q))
      );
    }
    return result;
  }

  function exportSavedLocatorsJSON() {
    getSavedLocators((list) => {
      if (!list || list.length === 0) {
        showSavedToast('No saved locators to export!');
        return;
      }
      const sInput = shadowRoot ? shadowRoot.getElementById('savedSearchInput') : null;
      const sortEl = shadowRoot ? shadowRoot.getElementById('savedSortSelect') : null;
      const query = sInput ? sInput.value.trim() : '';
      const sortOrder = sortEl ? sortEl.value : 'step-asc';
      const itemsToExport = getSortedAndFilteredSavedLocators(list, query, sortOrder);

      const jsonStr = JSON.stringify(itemsToExport, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const filename = `testpath-locators-${new Date().toISOString().slice(0, 10)}.json`;
      triggerDownload(url, filename, jsonStr, 'application/json');
      handlePostDownloadCleanup();
    });
  }

  function exportSavedLocatorsCSV() {
    getSavedLocators((list) => {
      if (!list || list.length === 0) {
        showSavedToast('No saved locators to export!');
        return;
      }
      const sInput = shadowRoot ? shadowRoot.getElementById('savedSearchInput') : null;
      const sortEl = shadowRoot ? shadowRoot.getElementById('savedSortSelect') : null;
      const query = sInput ? sInput.value.trim() : '';
      const sortOrder = sortEl ? sortEl.value : 'step-asc';
      const itemsToExport = getSortedAndFilteredSavedLocators(list, query, sortOrder);

      const headers = ['Step', 'ID', 'Timestamp', 'Tag', 'Text / Label', 'Best XPath', 'Action', 'Action Code', 'Framework Format', 'Playwright Locator', 'CSS Selector', 'Relative XPath', 'Score', 'Page Title', 'Page URL'];
      const rows = itemsToExport.map((item, idx) => [
        idx + 1,
        item.id || '',
        item.timestamp || '',
        item.tagName || '',
        item.text || '',
        item.bestXPath || '',
        item.action || 'locator',
        item.actionCode || '',
        item.actionFormat || 'raw',
        item.bestPlaywright || '',
        item.cssSelector || '',
        item.bestRelative || '',
        String(item.score || ''),
        item.pageTitle || '',
        item.pageUrl || ''
      ]);
      const csvContent = [headers, ...rows].map(row => 
        row.map(cell => '"' + String(cell).replace(/"/g, '""') + '"').join(',')
      ).join('\r\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const filename = 'testpath-locators-' + (new Date().toISOString().slice(0, 10)) + '.csv';
      triggerDownload(url, filename, csvContent, 'text/csv');
      handlePostDownloadCleanup();
    });
  }

  function buildRunnableTestScript(steps, framework, pageUrl) {
    if (!steps || steps.length === 0) {
      return '// No steps to export yet.';
    }

    var esc = function(s) { return String(s || '').replace(/\\/g, '\\\\').replace(/"/g, '\"'); };
    var escS = function(s) { return String(s || '').replace(/\\/g, '\\\\').replace(/'/g, "\'"); };

    // Resolve target page URL dynamically from current page or step metadata
    var targetUrl = (pageUrl && typeof pageUrl === 'string' && pageUrl.startsWith('http'))
      ? pageUrl.trim()
      : null;

    if (!targetUrl && steps && steps.length > 0) {
      for (var k = 0; k < steps.length; k++) {
        var stepUrl = steps[k].pageUrl || steps[k].url;
        if (stepUrl && typeof stepUrl === 'string' && stepUrl.startsWith('http')) {
          targetUrl = stepUrl.trim();
          break;
        }
      }
    }

    if (!targetUrl && typeof window !== 'undefined' && window.location && typeof window.location.href === 'string' && window.location.href.startsWith('http')) {
      targetUrl = window.location.href.trim();
    }

    if (!targetUrl) {
      targetUrl = 'https://your-app-url.com';
    }

    var urlEsc = esc(targetUrl);
    var urlEscS = escS(targetUrl);

    function getLoc(s, fw) {
      if (fw === 'playwright-python') {
        var l = s.bestPlaywright
          ? s.bestPlaywright.replace(/page\.getByRole/g,'page.get_by_role').replace(/page\.getByTestId/g,'page.get_by_test_id').replace(/page\.getByText/g,'page.get_by_text').replace(/page\.getByPlaceholder/g,'page.get_by_placeholder').replace(/page\.getByLabel/g,'page.get_by_label')
          : ('page.locator("' + esc(s.bestXPath || s.cssSelector || '//button') + '")');
        return l;
      }
      if (fw === 'playwright-java') {
        return s.bestPlaywrightJava || ('page.locator("' + esc(s.bestXPath || s.cssSelector || '//button') + '")');
      }
      return s.bestPlaywright || ("page.locator('" + escS(s.bestXPath || s.cssSelector || '//button') + "')");
    }
    function cmt(s, i, pad) {
      return pad + '// Step ' + (i+1) + ': ' + (s.action||'click').toUpperCase() + ' <' + (s.tagName||s.tag||'element') + '>' + (s.target ? (' - "' + s.target.slice(0,40) + '"') : '') + '\n';
    }
    var xp  = function(s) { return esc(s.bestXPath || s.cssSelector || '//button'); };
    var xpS = function(s) { return escS(s.bestXPath || s.cssSelector || '//button'); };

    var isRecorded = steps.some(function(s) { return !!s.timestamp; });
    var testTitle = isRecorded ? 'Recorded Flow Test' : 'Saved Locators Flow';
    var className = isRecorded ? 'RecordedFlowTest' : 'SavedLocatorsTest';
    var fnName = isRecorded ? 'test_recorded_flow' : 'test_saved_locators_flow';

    if (!framework || framework === 'playwright' || framework === 'raw') {
      var o = "import { test, expect } from '@playwright/test';\n\ntest('" + testTitle + "', async ({ page }) => {\n  await page.goto('" + urlEscS + "');\n\n";
      steps.forEach(function(s,i){ var a=(s.action||'click').toLowerCase(),l=getLoc(s,'playwright'); o+=cmt(s,i,'  ');
        if(a==='click') o+='  await '+l+'.click();\n';
        else if(a==='fill') o+="  await "+l+".fill('"+escS(s.value||'Enter text')+"');\n";
        else if(a==='assertvisible') o+='  await expect('+l+').toBeVisible();\n';
        else if(a==='asserttext') o+="  await expect("+l+").toHaveText('"+escS(s.target||'')+"');\n";
        else if(a==='assertchecked') o+='  await expect('+l+').toBeChecked();\n';
        else if(a==='assertenabled') o+='  await expect('+l+').toBeEnabled();\n';
        else if(a==='waitfor') o+="  await "+l+".waitFor({ state: 'visible' });\n";
        else if(a==='gettext') o+='  const text'+(i+1)+' = await '+l+'.textContent();\n';
        else o+='  await '+l+'.click();\n';
        o+='\n';
      });
      return o + '});\n';
    }

    if (framework === 'playwright-python') {
      var o = 'import pytest\nfrom playwright.sync_api import Page, expect\n\n\ndef ' + fnName + '(page: Page):\n    page.goto("' + urlEsc + '")\n\n';
      steps.forEach(function(s,i){ var a=(s.action||'click').toLowerCase(),l=getLoc(s,'playwright-python'); o+=cmt(s,i,'    ');
        if(a==='click') o+='    '+l+'.click()\n';
        else if(a==='fill') o+='    '+l+'.fill("'+esc(s.value||'Enter text')+'")\n';
        else if(a==='assertvisible') o+='    expect('+l+').to_be_visible()\n';
        else if(a==='asserttext') o+='    expect('+l+').to_have_text("'+esc(s.target||'')+'")\n';
        else if(a==='waitfor') o+='    '+l+'.wait_for(state="visible")\n';
        else if(a==='gettext') o+='    text_'+(i+1)+' = '+l+'.text_content()\n';
        else o+='    '+l+'.click()\n';
        o+='\n';
      });
      return o;
    }

    if (framework === 'playwright-java') {
      var o = 'package com.example.tests;\n\nimport com.microsoft.playwright.*;\nimport org.junit.jupiter.api.*;\nimport static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;\n\npublic class ' + className + ' {\n\n    static Playwright playwright;\n    static Browser browser;\n    BrowserContext context;\n    Page page;\n\n    @BeforeAll\n    static void launchBrowser() {\n        playwright = Playwright.create();\n        browser = playwright.chromium().launch();\n    }\n\n    @AfterAll\n    static void closeBrowser() {\n        playwright.close();\n    }\n\n    @BeforeEach\n    void createContextAndPage() {\n        context = browser.newContext();\n        page = context.newPage();\n        page.navigate("' + urlEsc + '");\n    }\n\n    @AfterEach\n    void closeContext() {\n        context.close();\n    }\n\n    @Test\n    void ' + fnName + '() {\n';
      steps.forEach(function(s,i){ var a=(s.action||'click').toLowerCase(),l=getLoc(s,'playwright-java'); o+=cmt(s,i,'        ');
        if(a==='click') o+='        '+l+'.click();\n';
        else if(a==='fill') o+='        '+l+'.fill("'+esc(s.value||'Enter text')+'");\n';
        else if(a==='assertvisible') o+='        assertThat('+l+').isVisible();\n';
        else if(a==='asserttext') o+='        assertThat('+l+').hasText("'+esc(s.target||'')+'");\n';
        else if(a==='assertchecked') o+='        assertThat('+l+').isChecked();\n';
        else if(a==='assertenabled') o+='        assertThat('+l+').isEnabled();\n';
        else if(a==='waitfor') o+='        '+l+'.waitFor();\n';
        else if(a==='gettext') o+='        String text'+(i+1)+' = '+l+'.textContent();\n';
        else o+='        '+l+'.click();\n';
        o+='\n';
      });
      return o + '    }\n}\n';
    }

    if (framework === 'playwright-csharp') {
      var o = 'using Microsoft.Playwright;\nusing NUnit.Framework;\nusing System.Threading.Tasks;\n\nnamespace TestPathTests;\n\n[Parallelizable(ParallelScope.Self)]\n[TestFixture]\npublic class ' + className + ' : PageTest\n{\n    [Test]\n    public async Task ' + (isRecorded ? 'RecordedFlowTest' : 'SavedLocatorsFlowTest') + '()\n    {\n        await Page.GotoAsync("' + urlEsc + '");\n\n';
      steps.forEach(function(s,i){ var a=(s.action||'click').toLowerCase(),x=xp(s); o+=cmt(s,i,'        ');
        if(a==='click') o+='        await Page.Locator("' + x + '").ClickAsync();\n';
        else if(a==='fill') o+='        await Page.Locator("' + x + '").FillAsync("' + esc(s.value||'Enter text') + '");\n';
        else if(a==='waitfor') o+='        await Page.Locator("' + x + '").WaitForAsync();\n';
        else o+='        await Page.Locator("' + x + '").ClickAsync();\n';
        o+='\n';
      });
      return o + '    }\n}\n';
    }

    if (framework === 'selenium-java') {
      var o = 'package com.example.tests;\n\nimport org.openqa.selenium.By;\nimport org.openqa.selenium.WebDriver;\nimport org.openqa.selenium.chrome.ChromeDriver;\nimport org.openqa.selenium.support.ui.ExpectedConditions;\nimport org.openqa.selenium.support.ui.WebDriverWait;\nimport org.junit.jupiter.api.*;\nimport java.time.Duration;\nimport static org.junit.jupiter.api.Assertions.*;\n\npublic class ' + className + ' {\n\n    WebDriver driver;\n    WebDriverWait wait;\n\n    @BeforeEach\n    void setUp() {\n        driver = new ChromeDriver();\n        wait = new WebDriverWait(driver, Duration.ofSeconds(10));\n        driver.get("' + urlEsc + '");\n    }\n\n    @AfterEach\n    void tearDown() {\n        if (driver != null) driver.quit();\n    }\n\n    @Test\n    void ' + fnName + '() {\n';
      steps.forEach(function(s,i){ var a=(s.action||'click').toLowerCase(),x=xp(s); o+=cmt(s,i,'        ');
        if(a==='click') o+='        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("'+x+'"))).click();\n';
        else if(a==='fill') o+='        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("'+x+'"))).sendKeys("'+esc(s.value||'Enter text')+'");\n';
        else if(a==='assertvisible') o+='        assertTrue(driver.findElement(By.xpath("'+x+'")).isDisplayed());\n';
        else if(a==='asserttext') o+='        assertEquals("'+esc(s.target||'')+'", driver.findElement(By.xpath("'+x+'")).getText());\n';
        else if(a==='waitfor') o+='        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("'+x+'")));\n';
        else if(a==='gettext') o+='        String text'+(i+1)+' = driver.findElement(By.xpath("'+x+'")).getText();\n';
        else o+='        driver.findElement(By.xpath("'+x+'")).click();\n';
        o+='\n';
      });
      return o + '    }\n}\n';
    }

    if (framework === 'selenium-python') {
      var o = 'import pytest\nfrom selenium import webdriver\nfrom selenium.webdriver.common.by import By\nfrom selenium.webdriver.support.ui import WebDriverWait\nfrom selenium.webdriver.support import expected_conditions as EC\n\n\n@pytest.fixture\ndef driver():\n    d = webdriver.Chrome()\n    d.get("' + urlEsc + '")\n    yield d\n    d.quit()\n\n\ndef ' + fnName + '(driver):\n    wait = WebDriverWait(driver, 10)\n\n';
      steps.forEach(function(s,i){ var a=(s.action||'click').toLowerCase(),x=xp(s); o+=cmt(s,i,'    ');
        if(a==='click') o+='    wait.until(EC.element_to_be_clickable((By.XPATH, "'+x+'"))).click()\n';
        else if(a==='fill') o+='    wait.until(EC.visibility_of_element_located((By.XPATH, "'+x+'"))).send_keys("'+esc(s.value||'Enter text')+'")\n';
        else if(a==='assertvisible') o+='    assert driver.find_element(By.XPATH, "'+x+'").is_displayed()\n';
        else if(a==='asserttext') o+='    assert driver.find_element(By.XPATH, "'+x+'").text == "'+esc(s.target||'')+'"\n';
        else if(a==='waitfor') o+='    wait.until(EC.visibility_of_element_located((By.XPATH, "'+x+'")))\n';
        else if(a==='gettext') o+='    text_'+(i+1)+' = driver.find_element(By.XPATH, "'+x+'").text\n';
        else o+='    driver.find_element(By.XPATH, "'+x+'").click()\n';
        o+='\n';
      });
      return o;
    }

    if (framework === 'selenium-javascript') {
      var o = "const { Builder, By, Key, until } = require('selenium-webdriver');\n\n(async function " + fnName + "() {\n  const driver = await new Builder().forBrowser('chrome').build();\n  try {\n    await driver.get('" + urlEscS + "');\n\n";
      steps.forEach(function(s,i){ var a=(s.action||'click').toLowerCase(),x=xp(s); o+=cmt(s,i,'    ');
        if(a==='click') o+='    await driver.findElement(By.xpath("'+x+'")).click();\n';
        else if(a==='fill') o+='    await driver.findElement(By.xpath("'+x+'")).sendKeys("'+esc(s.value||'Enter text')+'");\n';
        else if(a==='waitfor') o+='    await driver.wait(until.elementLocated(By.xpath("'+x+'")), 10000);\n';
        else o+='    await driver.findElement(By.xpath("'+x+'")).click();\n';
        o+='\n';
      });
      return o + '  } finally {\n    await driver.quit();\n  }\n})();\n';
    }

    if (framework === 'selenium-csharp') {
      var o = 'using OpenQA.Selenium;\nusing OpenQA.Selenium.Chrome;\nusing OpenQA.Selenium.Support.UI;\nusing NUnit.Framework;\nusing System;\n\nnamespace TestPathTests;\n\n[TestFixture]\npublic class ' + className + '\n{\n    private IWebDriver driver;\n    private WebDriverWait wait;\n\n    [SetUp]\n    public void SetUp()\n    {\n        driver = new ChromeDriver();\n        wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));\n        driver.Navigate().GoToUrl("' + urlEsc + '");\n    }\n\n    [TearDown]\n    public void TearDown()\n    {\n        driver?.Quit();\n    }\n\n    [Test]\n    public void ' + (isRecorded ? 'RecordedFlowTest' : 'SavedLocatorsFlowTest') + '()\n    {\n';
      steps.forEach(function(s,i){ var a=(s.action||'click').toLowerCase(),x=xp(s); o+=cmt(s,i,'        ');
        if(a==='click') o+='        wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("'+x+'"))).Click();\n';
        else if(a==='fill') o+='        wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("'+x+'"))).SendKeys("'+esc(s.value||'Enter text')+'");\n';
        else if(a==='waitfor') o+='        wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("'+x+'")));\n';
        else o+='        driver.FindElement(By.XPath("'+x+'")).Click();\n';
        o+='\n';
      });
      return o + '    }\n}\n';
    }

    if (framework === 'cypress') {
      var o = "describe('" + testTitle + "', () => {\n  before(() => {\n    cy.visit('" + urlEscS + "');\n  });\n\n  it('executes all test flow actions', () => {\n";
      steps.forEach(function(s,i){ var a=(s.action||'click').toLowerCase(),x=xpS(s); o+=cmt(s,i,'    ');
        if(a==='click') o+="    cy.xpath('"+x+"').click();\n";
        else if(a==='fill') o+="    cy.xpath('"+x+"').type('"+escS(s.value||'Enter text')+"');\n";
        else if(a==='assertvisible') o+="    cy.xpath('"+x+"').should('be.visible');\n";
        else if(a==='asserttext') o+="    cy.xpath('"+x+"').should('have.text', '"+escS(s.target||'')+"');\n";
        else if(a==='waitfor') o+="    cy.xpath('"+x+"').should('exist');\n";
        else if(a==='gettext') o+="    cy.xpath('"+x+"').invoke('text').then((t) => { cy.log(t); });\n";
        else o+="    cy.xpath('"+x+"').click();\n";
        o+='\n';
      });
      return o + '  });\n});\n';
    }

    if (framework === 'robot') {
      var o = '*** Settings ***\nLibrary    Browser\n\n*** Test Cases ***\n' + testTitle + '\n    New Page    ' + targetUrl + '\n\n';
      steps.forEach(function(s,i){ var a=(s.action||'click').toLowerCase(),x=s.bestXPath||s.cssSelector||'//button'; o+='    # Step '+(i+1)+': '+a.toUpperCase()+' <'+(s.tagName||'element')+'>\n';
        if(a==='click') o+='    Click    xpath='+x+'\n';
        else if(a==='fill') o+='    Fill Text    xpath='+x+'    '+(s.value||'Enter text')+'\n';
        else if(a==='assertvisible') o+='    Get Element    xpath='+x+'\n';
        else if(a==='waitfor') o+='    Wait For Elements State    xpath='+x+'    visible\n';
        else o+='    Click    xpath='+x+'\n';
        o+='\n';
      });
      return o;
    }

    if (framework === 'puppeteer') {
      var o = "const puppeteer = require('puppeteer');\n\n(async () => {\n  const browser = await puppeteer.launch({ headless: false });\n  const page = await browser.newPage();\n  await page.goto('" + urlEscS + "');\n\n";
      steps.forEach(function(s,i){ var a=(s.action||'click').toLowerCase(),x=xpS(s); o+=cmt(s,i,'  ');
        if(a==='fill') o+="  const [el"+(i+1)+"] = await page.$x('"+x+"');\n  if(el"+(i+1)+") await el"+(i+1)+".type('"+escS(s.value||'Enter text')+"');\n";
        else if(a==='waitfor') o+="  await page.waitForXPath('"+x+"');\n";
        else o+="  const [el"+(i+1)+"] = await page.$x('"+x+"');\n  if(el"+(i+1)+") await el"+(i+1)+".click();\n";
        o+='\n';
      });
      return o + '  await browser.close();\n})();\n';
    }

    var o = '// Saved Locators Export - TestPath\n\n';
    steps.forEach(function(s,i){ o+='// Step '+(i+1)+': '+(s.action||'locator').toUpperCase()+' - <'+(s.tagName||s.tag||'element')+'>\n'+(s.bestXPath||s.cssSelector||'//button')+'\n\n'; });
    return o;
  }

  function exportSavedLocatorsScript() {
    getSavedLocators((list) => {
      if (!list || list.length === 0) {
        showSavedToast('No saved locators to generate script!');
        return;
      }
      const sInput = shadowRoot ? shadowRoot.getElementById('savedSearchInput') : null;
      const sortEl = shadowRoot ? shadowRoot.getElementById('savedSortSelect') : null;
      const query = sInput ? sInput.value.trim() : '';
      const sortOrder = sortEl ? sortEl.value : 'step-asc';
      const itemsToExport = getSortedAndFilteredSavedLocators(list, query, sortOrder);

      const framework = currentFormat || 'playwright';

      const livePageUrl = (typeof window !== 'undefined' && window.location && typeof window.location.href === 'string' && window.location.href.startsWith('http'))
        ? window.location.href
        : null;

      const steps = itemsToExport.map((it) => ({
        action: it.action || 'click',
        target: it.text || it.name || it.tagName || it.tag || 'element',
        tagName: it.tagName || it.tag || 'element',
        tag: it.tagName || it.tag || 'element',
        bestXPath: it.bestXPath || it.xpath || it.locator || '//button',
        bestPlaywright: it.bestPlaywright || (it.locator && !it.locator.startsWith('//') ? it.locator : null),
        bestPlaywrightJava: it.bestPlaywrightJava || null,
        cssSelector: it.cssSelector || '',
        value: it.fillValue || it.value || '',
        pageUrl: it.pageUrl || it.url || livePageUrl
      }));

      const scriptContent = buildRunnableTestScript(steps, framework, livePageUrl);

      // Copy to clipboard
      copyToClipboard(scriptContent, null, 'Test script copied!');

      // Pick filename extension based on framework
      const extMap = {
        'playwright': 'saved_locators.spec.js',
        'playwright-python': 'test_saved_locators.py',
        'playwright-java': 'SavedLocatorsTest.java',
        'playwright-csharp': 'SavedLocatorsTest.cs',
        'selenium-java': 'SavedLocatorsTest.java',
        'selenium-python': 'test_saved_locators.py',
        'selenium-javascript': 'saved_locators.js',
        'selenium-csharp': 'SavedLocatorsTest.cs',
        'cypress': 'saved_locators.cy.js',
        'robot': 'saved_locators.robot',
        'puppeteer': 'saved_locators.spec.js'
      };
      const filename = extMap[framework] || 'saved_locators.spec.js';

      // Download spec file
      const blob = new Blob([scriptContent], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      triggerDownload(url, filename, scriptContent, 'application/octet-stream');
      handlePostDownloadCleanup();
    });
  }

  function extractTagNameFromQuery(q) {
    if (!q) return 'element';
    const trimmed = String(q).trim();
    if (trimmed.startsWith('//')) {
      const sub = trimmed.slice(2).trim();
      const parts = sub.split(/[^a-zA-Z0-9_-]/);
      if (parts[0]) return parts[0].toLowerCase();
    }
    const cssParts = trimmed.split(/[^a-zA-Z0-9_-]/);
    if (cssParts[0]) return cssParts[0].toLowerCase();
    return 'element';
  }

  function updateCommonSaveButtonState() {
    if (!shadowRoot) return;
    const btn = shadowRoot.getElementById('btnCommonSave');
    const textSpan = shadowRoot.getElementById('commonSaveBtnText');
    if (!btn) return;
    const inputEl = shadowRoot.getElementById('xpathInput');
    const currentVal = inputEl ? inputEl.value.trim() : (currentAnalysis ? currentAnalysis.best : '');
    if (!currentVal) {
      btn.classList.remove('is-saved');
      if (textSpan) textSpan.textContent = 'Save';
      btn.title = 'Save current searched path & action';
      return;
    }
    isLocatorSaved(currentVal, (saved, existing) => {
      if (saved) {
        btn.classList.add('is-saved');
        if (textSpan) textSpan.textContent = 'Saved!';
        btn.title = 'Saved with action "' + (existing && existing.action ? existing.action.toUpperCase() : 'LOCATOR') + '". Click to remove or update';
      } else {
        btn.classList.remove('is-saved');
        if (textSpan) textSpan.textContent = 'Save';
        btn.title = 'Save current searched path & action across tabs';
      }
    });
  }

  function handleCommonSaveClick() {
    const inputEl = shadowRoot ? shadowRoot.getElementById('xpathInput') : null;
    const inputVal = inputEl ? inputEl.value.trim() : '';
    const currentVal = inputVal || (currentAnalysis ? currentAnalysis.best : '');
    if (!currentVal) {
      showSavedToast('Type or search a path in the search box first!');
      return;
    }

    const actionVal = currentAction || 'locator';
    const formatVal = currentFormat || 'raw';
    const fillEl = (currentAnalysis && currentAnalysis.fillValue) ? currentAnalysis.fillValue : 'Enter value';

    const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
    let actionCodeVal = '';
    const heroCodeEl = shadowRoot ? shadowRoot.getElementById('heroCodeDisplay') : null;
    const bestCodeEl = shadowRoot ? shadowRoot.getElementById('bestCodeDisplay') : null;
    const activeCodeEl = heroCodeEl || bestCodeEl;

    // If saving the inspected element (search box is empty or matches currentAnalysis.best), use displayed action code
    if (activeCodeEl && activeCodeEl.textContent && (!inputVal || (currentAnalysis && inputVal === currentAnalysis.best))) {
      actionCodeVal = activeCodeEl.textContent;
    } else if (engine && typeof engine.formatForFramework === 'function') {
      // Custom typed/searched query: generate action code specifically for this searched query!
      const ifr = (currentAnalysis && inputVal === currentAnalysis.best) ? currentAnalysis.iframeInfo : null;
      const exactText = (currentAnalysis && currentAnalysis.elementInfo) ? currentAnalysis.elementInfo.innerText : null;
      actionCodeVal = engine.formatForFramework(currentVal, formatVal, null, null, null, actionVal, fillEl, ifr, exactText);
    } else {
      actionCodeVal = currentVal;
    }

    getSavedLocators((list) => {
      const idx = list.findIndex(it => it.bestXPath === currentVal);
      if (idx >= 0) {
        // If already in list with same action, toggle remove
        if (list[idx].action === actionVal) {
          list.splice(idx, 1);
          setSavedLocators(list, () => {
            updateCommonSaveButtonState();
            updateSavedCountBadge();
            showSavedToast('Removed from Saved');
          });
          return;
        } else {
          // Update to newly selected action and code
          list[idx].action = actionVal;
          list[idx].actionCode = actionCodeVal;
          list[idx].actionFormat = formatVal;
          list[idx].fillValue = fillEl;
          setSavedLocators(list, () => {
            updateCommonSaveButtonState();
            updateSavedCountBadge();
            showSavedToast('Updated to "' + actionVal.toUpperCase() + '" in Saved ⭐');
          });
          return;
        }
      }

      // New item to save: distinguish between inspected element and custom searched query
      const isInspected = currentAnalysis && (!inputVal || inputVal === currentAnalysis.best);
      const topPw = isInspected
        ? ((currentAnalysis.playwrightLocators && currentAnalysis.playwrightLocators[0] && currentAnalysis.playwrightLocators[0].code) || currentAnalysis.bestPlaywright || '')
        : (currentVal.startsWith('page.getBy') ? currentVal : '');
      const topRel = isInspected
        ? ((currentAnalysis.relativeLocators && currentAnalysis.relativeLocators[0] && currentAnalysis.relativeLocators[0].xpath) || currentAnalysis.bestRelative || '')
        : '';
      const tagVal = isInspected ? currentAnalysis.tagName : (extractTagNameFromQuery(currentVal) || 'element');
      const textVal = isInspected ? ((currentAnalysis.elementInfo && currentAnalysis.elementInfo.innerText) || '') : '';
      const iframeVal = (isInspected && currentAnalysis && currentAnalysis.iframeInfo && currentAnalysis.iframeInfo.isIframe)
        ? (currentAnalysis.iframeInfo.displayName || 'iframe')
        : null;

      const newItem = {
        id: 'loc_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
        timestamp: new Date().toISOString(),
        tagName: tagVal,
        text: textVal,
        iframe: iframeVal,
        bestXPath: currentVal,
        bestPlaywright: topPw,
        bestRelative: topRel,
        cssSelector: isInspected ? (currentAnalysis.cssSelector || '') : (currentVal.startsWith('/') ? '' : currentVal),
        score: isInspected ? (currentAnalysis.score || 95) : 90,
        pageUrl: window.location.href,
        pageTitle: document.title || window.location.hostname,
        action: actionVal,
        actionCode: actionCodeVal,
        actionFormat: formatVal,
        fillValue: fillEl
      };

      list.push(newItem);
      setSavedLocators(list, () => {
        updateCommonSaveButtonState();
        updateSavedCountBadge();
        showSavedToast('⭐ Saved with "' + actionVal.toUpperCase() + '" action!');
      });
    });
  }

  function renderSavedLocatorsList(query = '') {
    const listContainer = shadowRoot.getElementById('savedLocatorsList');
    if (!listContainer) return;
    const sortEl = shadowRoot.getElementById('savedSortSelect');
    const sortOrder = sortEl ? sortEl.value : 'step-asc';

    getSavedLocators((list) => {
      const filtered = getSortedAndFilteredSavedLocators(list, query, sortOrder);

      if (filtered.length === 0) {
        if (query) {
          listContainer.innerHTML = `
            <div class="xpath-empty-saved">
              ${ICONS.search}
              <h4>No matches found</h4>
              <p>No saved locators match "${escapeHTML(query)}". Try another search keyword.</p>
            </div>
          `;
        } else {
          listContainer.innerHTML = `
            <div class="xpath-empty-saved">
              ${ICONS.star}
              <h4>No saved locators yet</h4>
              <p>Search or inspect any element and click the <strong>⭐ Save</strong> button near Freeze to store locators and actions across tabs.</p>
            </div>
          `;
        }
        return;
      }

      let html = '';
      filtered.forEach((item, index) => {
        const dateStr = formatRelativeTime(item.timestamp);
        let domain = '';
        try {
          domain = new URL(item.pageUrl).hostname;
        } catch (e) {
          domain = item.pageTitle || '';
        }

        let actionBadgeHTML = '';
        if (item.action && item.action !== 'locator') {
          const actIcons = {
            click: '⚡',
            fill: '✏️',
            assertVisible: '👁️',
            assertText: '🔤',
            assertChecked: '☑️',
            assertEnabled: '⚡',
            waitFor: '⏳',
            getText: '📄'
          };
          const ico = actIcons[item.action] || '⚡';
          actionBadgeHTML = '<span class="xpath-saved-action-tag xpath-saved-action-' + escapeHTML(item.action) + '">' + ico + ' ' + escapeHTML(item.action.toUpperCase()) + '</span>';
        } else if (item.action === 'locator') {
          actionBadgeHTML = '<span class="xpath-saved-action-tag xpath-saved-action-locator">🎯 LOCATOR</span>';
        }

        let iframeBadgeHTML = '';
        if (item.iframe) {
          iframeBadgeHTML = '<span class="xpath-saved-source-pill" style="border-color: rgba(168, 85, 247, 0.35); color: #c084fc; background: rgba(168, 85, 247, 0.12);" title="In Frame: ' + escapeHTML(item.iframe) + '">🖼️ ' + escapeHTML(item.iframe) + '</span>';
        }

        html += `
          <div class="xpath-saved-item" data-saved-id="${escapeHTML(item.id)}">
            <div class="xpath-saved-item-header">
              <div class="xpath-saved-item-info">
                <span class="xpath-saved-step-badge">#${index + 1}</span>
                <span class="xpath-saved-tag">&lt;${escapeHTML(item.tagName)}&gt;</span>
                ${actionBadgeHTML}
                ${iframeBadgeHTML}
                <span class="xpath-saved-text" title="${escapeHTML(item.text || item.tagName)}">${escapeHTML(item.text || item.tagName)}</span>
                <span class="xpath-saved-source-pill" title="${escapeHTML(item.pageTitle + ' • ' + item.pageUrl)}">${escapeHTML(domain)}</span>
              </div>
              <div class="xpath-saved-item-actions">
                <button class="xpath-saved-btn-del" data-del-id="${escapeHTML(item.id)}" title="Delete locator">
                  ${ICONS.trash}
                </button>
              </div>
            </div>

            <!-- Form Control Action Code (if present) -->
            ${item.actionCode ? `
              <div class="xpath-saved-code-box" style="border-color: rgba(245, 158, 11, 0.25); background: #14111d;">
                <span class="xpath-saved-code-label xpath-saved-label-action">Action (${escapeHTML(item.action || 'Code')})</span>
                <span class="xpath-saved-code-text" style="color: #fde68a;" title="${escapeHTML(item.actionCode)}">${escapeHTML(item.actionCode)}</span>
                <button class="xpath-saved-btn-copy" data-copy="${escapeHTML(item.actionCode)}" title="Copy Action Code">Copy Action</button>
              </div>
            ` : ''}

            <!-- Best XPath -->
            <div class="xpath-saved-code-box">
              <span class="xpath-saved-code-label xpath-saved-label-xpath">XPath</span>
              <span class="xpath-saved-code-text" title="${escapeHTML(item.bestXPath)}">${escapeHTML(item.bestXPath)}</span>
              <button class="xpath-saved-btn-copy" data-copy="${escapeHTML(item.bestXPath)}" title="Copy XPath">Copy</button>
            </div>

            <!-- Playwright if available -->
            ${item.bestPlaywright ? `
              <div class="xpath-saved-code-box">
                <span class="xpath-saved-code-label xpath-saved-label-pw">Playwright</span>
                <span class="xpath-saved-code-text" title="${escapeHTML(item.bestPlaywright)}">${escapeHTML(item.bestPlaywright)}</span>
                <button class="xpath-saved-btn-copy" data-copy="${escapeHTML(item.bestPlaywright)}" title="Copy Playwright">Copy</button>
              </div>
            ` : ''}

            <!-- Footer: Timestamp & Test in Page -->
            <div class="xpath-saved-foot">
              <span class="xpath-saved-time">${escapeHTML(dateStr)}</span>
              <div class="xpath-saved-foot-actions">
                <button class="xpath-btn-test-page" data-test-xpath="${escapeHTML(item.bestXPath)}" title="Test this XPath on current live page">
                  🔍 Test on Page
                </button>
              </div>
            </div>
          </div>
        `;
      });

      listContainer.innerHTML = html;

      // Bind copy buttons
      const copyBtns = listContainer.querySelectorAll('.xpath-saved-btn-copy');
      copyBtns.forEach((cb) => {
        cb.addEventListener('click', () => {
          const text = cb.getAttribute('data-copy');
          copyToClipboard(text, cb, 'Copied!');
        });
      });

      // Bind delete buttons
      const delBtns = listContainer.querySelectorAll('.xpath-saved-btn-del');
      delBtns.forEach((db) => {
        db.addEventListener('click', () => {
          const id = db.getAttribute('data-del-id');
          getSavedLocators((fullList) => {
            const updated = fullList.filter(it => it.id !== id);
            setSavedLocators(updated, () => {
              renderSavedLocatorsList(shadowRoot.getElementById('savedSearchInput')?.value?.trim() || '');
              updateSavedCountBadge();
              updateInspectorSaveButtonState();
              showSavedToast('Locator deleted');
            });
          });
        });
      });

      // Bind test on page buttons
      const testBtns = listContainer.querySelectorAll('.xpath-btn-test-page');
      testBtns.forEach((tb) => {
        tb.addEventListener('click', () => {
          const xp = tb.getAttribute('data-test-xpath');
          if (!xp) return;
          // Switch to inspector tab
          const tabBtnInsp = shadowRoot.getElementById('tabBtnInspector');
          if (tabBtnInsp) tabBtnInsp.click();
          const xpInput = shadowRoot.getElementById('xpathInput');
          if (xpInput) {
            xpInput.value = xp;
            evaluateCustomQuery(xp);
          }
        });
      });
    });
  }

  // ========================================================
  // Flow Recorder Engine (Record-to-Code Sequence - New in v2.1)
  // ========================================================

  function fallbackLocalFlowSteps(callback) {
    try {
      const stored = sessionStorage.getItem(STORAGE_KEY_FLOW_STEPS);
      if (stored) recordedFlowSteps = JSON.parse(stored);
    } catch (e) {}
    if (typeof callback === 'function') callback(recordedFlowSteps || []);
  }

  function getRecordedFlowSteps(callback) {
    if (isExtensionValid()) {
      try {
        chrome.storage.local.get([STORAGE_KEY_FLOW_STEPS], (res) => {
          if (chrome.runtime && chrome.runtime.lastError) {
            fallbackLocalFlowSteps(callback);
            return;
          }
          const list = (res && Array.isArray(res[STORAGE_KEY_FLOW_STEPS])) ? res[STORAGE_KEY_FLOW_STEPS] : recordedFlowSteps;
          recordedFlowSteps = list || [];
          if (typeof callback === 'function') callback(recordedFlowSteps);
        });
        return;
      } catch (err) {
        // Fall through to fallback
      }
    }
    fallbackLocalFlowSteps(callback);
  }

  function setRecordedFlowSteps(steps, callback) {
    recordedFlowSteps = steps || [];
    try {
      sessionStorage.setItem(STORAGE_KEY_FLOW_STEPS, JSON.stringify(recordedFlowSteps));
    } catch (e) {}

    if (isExtensionValid()) {
      try {
        chrome.storage.local.set({ [STORAGE_KEY_FLOW_STEPS]: recordedFlowSteps }, () => {
          if (chrome.runtime && chrome.runtime.lastError) {
            // Silently handled
          }
          updateRecorderCountBadge();
          updateRecordingHUD();
          if (typeof callback === 'function') callback();
        });
        return;
      } catch (err) {}
    }
    updateRecorderCountBadge();
    updateRecordingHUD();
    if (typeof callback === 'function') callback();
  }

  function appendRecordedStep(step) {
    if (!step) return;
    getRecordedFlowSteps((steps) => {
      steps.push(step);
      setRecordedFlowSteps(steps, () => {
        if (activeDockTab === 'recorder') {
          renderRecorderStepsList();
        }
        try {
          if (isExtensionValid() && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage({ action: 'TESTPATH_STEP_RECORDED', step: step }, () => {
              if (chrome.runtime.lastError) {}
            });
          }
        } catch (e) {}
      });
    });
  }

  function updateRecorderCountBadge() {
    const count = recordedFlowSteps ? recordedFlowSteps.length : 0;
    if (shadowRoot) {
      const badge = shadowRoot.getElementById('recorderTabBadge');
      if (badge) {
        badge.textContent = String(count);
        badge.style.display = count > 0 ? 'inline-flex' : 'none';
      }
      const counterEl = shadowRoot.getElementById('recToolbarStepCounter');
      if (counterEl) {
        counterEl.textContent = count + ' step' + (count === 1 ? '' : 's') + ' recorded';
      }
    }
  }

  function createRecordingHUD() {
    removeRecordingHUD();
    initUI();
    const container = shadowRoot || document.body;
    const hud = document.createElement('div');
    hud.id = 'xpath_rec_hud';
    hud.className = 'xpath-rec-hud';

    const count = recordedFlowSteps ? recordedFlowSteps.length : 0;
    hud.innerHTML = `
      <div class="xpath-rec-dot ${isRecordingPaused ? 'paused' : ''}" id="xpathRecDot"></div>
      <div class="xpath-rec-hud-title">
        <span>REC</span>
        <span class="xpath-rec-hud-count" id="xpathRecHudCount">${count}</span>
      </div>
      <div class="xpath-rec-hud-divider"></div>
      <button class="xpath-rec-hud-btn" id="btnRecHudPause" title="Pause or Resume Recording">
        ${isRecordingPaused ? '▶️ Resume' : '⏸️ Pause'}
      </button>
      <button class="xpath-rec-hud-btn is-assert ${isAssertPickingMode ? 'active' : ''}" id="btnRecHudAssert" title="Click any element on page to insert an assertion or dynamic wait (waitForHidden, loader, text, etc.)">
        👁️ Assert / Wait
      </button>
      <button class="xpath-rec-hud-btn is-stop" id="btnRecHudFinish" title="Stop recording and open test code in dock">
        ⏹️ Finish
      </button>
    `;

    container.appendChild(hud);
    recHudElement = hud;

    const btnPause = hud.querySelector('#btnRecHudPause');
    if (btnPause) {
      btnPause.addEventListener('click', (e) => {
        e.stopPropagation();
        if (isRecordingPaused) resumeRecording();
        else pauseRecording();
      });
    }

    const btnAssert = hud.querySelector('#btnRecHudAssert');
    if (btnAssert) {
      btnAssert.addEventListener('click', (e) => {
        e.stopPropagation();
        if (isAssertPickingMode) cancelAssertPicking();
        else startAssertPicking();
      });
    }

    const btnFinish = hud.querySelector('#btnRecHudFinish');
    if (btnFinish) {
      btnFinish.addEventListener('click', (e) => {
        e.stopPropagation();
        stopRecording();
      });
    }
  }

  function updateRecorderBannerButtonState() {
    if (!shadowRoot) return;
    const bannerBtn = shadowRoot.getElementById('btnDockRecord');
    const bannerLabel = shadowRoot.getElementById('dockRecordBtnLabel');
    const bannerIcon = shadowRoot.getElementById('dockRecordIcon');
    if (bannerBtn) {
      if (isRecordingMode) {
        bannerBtn.classList.add('is-recording');
        bannerBtn.title = 'Stop recording user actions (Alt+Shift+R)';
        if (bannerLabel) bannerLabel.textContent = 'Stop Recording';
        if (bannerIcon) bannerIcon.textContent = '⏹';
      } else {
        bannerBtn.classList.remove('is-recording');
        bannerBtn.title = 'Record user actions on this page to generate test code (Alt+Shift+R)';
        if (bannerLabel) bannerLabel.textContent = 'Record Flow';
        if (bannerIcon) bannerIcon.textContent = '⏺';
      }
    }

    const bannerAssertBtn = shadowRoot.getElementById('btnBannerAddAssert');
    if (bannerAssertBtn) {
      bannerAssertBtn.style.display = isRecordingMode ? 'inline-flex' : 'none';
      if (isAssertPickingMode) {
        bannerAssertBtn.classList.add('active');
        bannerAssertBtn.style.background = '#ca8a04';
        bannerAssertBtn.style.color = '#000000';
      } else {
        bannerAssertBtn.classList.remove('active');
        bannerAssertBtn.style.background = 'rgba(234, 179, 8, 0.18)';
        bannerAssertBtn.style.color = '#fde047';
      }
    }

    const liveBadge = shadowRoot.getElementById('recToolbarLiveBadge');
    if (liveBadge) {
      if (!isRecordingMode) {
        liveBadge.className = 'xpath-rec-live-badge idle';
        liveBadge.textContent = '● IDLE';
      } else if (isRecordingPaused) {
        liveBadge.className = 'xpath-rec-live-badge paused';
        liveBadge.textContent = '⏸ PAUSED';
      } else {
        liveBadge.className = 'xpath-rec-live-badge';
        liveBadge.textContent = '🔴 RECORDING';
      }
    }

    const btnDockAddAssert = shadowRoot.getElementById('btnDockAddAssert');
    if (btnDockAddAssert) {
      if (isAssertPickingMode) {
        btnDockAddAssert.classList.add('active');
        btnDockAddAssert.style.background = '#ca8a04';
        btnDockAddAssert.style.color = '#000000';
      } else {
        btnDockAddAssert.classList.remove('active');
        btnDockAddAssert.style.background = 'rgba(234, 179, 8, 0.18)';
        btnDockAddAssert.style.color = '#fde047';
      }
    }

    updateRecorderCountBadge();
  }

  function updateRecordingHUD() {
    if (recHudElement) {
      const countEl = recHudElement.querySelector('#xpathRecHudCount');
      if (countEl) countEl.textContent = String(recordedFlowSteps ? recordedFlowSteps.length : 0);

      const dot = recHudElement.querySelector('#xpathRecDot');
      if (dot) {
        if (isRecordingPaused) dot.classList.add('paused');
        else dot.classList.remove('paused');
      }

      const btnPause = recHudElement.querySelector('#btnRecHudPause');
      if (btnPause) {
        btnPause.textContent = isRecordingPaused ? '▶️ Resume' : '⏸️ Pause';
      }

      const btnAssert = recHudElement.querySelector('#btnRecHudAssert');
      if (btnAssert) {
        if (isAssertPickingMode) btnAssert.classList.add('active');
        else btnAssert.classList.remove('active');
      }
    }

    updateRecorderBannerButtonState();
  }

  function removeRecordingHUD() {
    if (recHudElement) {
      recHudElement.remove();
      recHudElement = null;
    }
    if (shadowRoot) {
      const existingShadow = shadowRoot.getElementById('xpath_rec_hud');
      if (existingShadow) existingShadow.remove();
    }
    const existingDoc = document.getElementById('xpath_rec_hud');
    if (existingDoc) existingDoc.remove();
    recHudElement = null;
    cancelAssertPicking();
    removeCheckpointPopover();
  }

  function startRecording(isResume = false) {
    ensureInDOM();
    if (isInspectMode) stopInspect();
    isRecordingMode = true;
    isRecordingPaused = false;
    isAssertPickingMode = false;

    try {
      if (isExtensionValid()) {
        chrome.storage.local.set({ [STORAGE_KEY_REC_STATE]: { isRecording: true, isPaused: false } }, () => {
          if (chrome.runtime && chrome.runtime.lastError) {}
        });
      }
    } catch (e) {}

    document.addEventListener('click', onRecorderClick, true);
    document.addEventListener('input', onRecorderInput, true);
    document.addEventListener('change', onRecorderChange, true);

    updateRecorderBannerButtonState();

    getRecordedFlowSteps(() => {
      createRecordingHUD();
      updateRecordingHUD();
      updateRecorderCountBadge();
      updateRecorderBannerButtonState();
      if (!isResume) {
        showSavedToast('🔴 Recording Started! Click and type on the page.');
      }
    });
  }

  function pauseRecording() {
    isRecordingPaused = true;
    try {
      if (isExtensionValid()) {
        chrome.storage.local.set({ [STORAGE_KEY_REC_STATE]: { isRecording: true, isPaused: true } }, () => {
          if (chrome.runtime && chrome.runtime.lastError) {}
        });
      }
    } catch (e) {}
    updateRecordingHUD();
    updateRecorderBannerButtonState();
    showSavedToast('⏸️ Recording Paused');
  }

  function resumeRecording() {
    isRecordingPaused = false;
    try {
      if (isExtensionValid()) {
        chrome.storage.local.set({ [STORAGE_KEY_REC_STATE]: { isRecording: true, isPaused: false } }, () => {
          if (chrome.runtime && chrome.runtime.lastError) {}
        });
      }
    } catch (e) {}
    updateRecordingHUD();
    updateRecorderBannerButtonState();
    showSavedToast('▶️ Recording Resumed');
  }

  function stopRecording() {
    isRecordingMode = false;
    isRecordingPaused = false;
    isAssertPickingMode = false;

    try {
      if (isExtensionValid()) {
        chrome.storage.local.set({ [STORAGE_KEY_REC_STATE]: { isRecording: false } }, () => {
          if (chrome.runtime && chrome.runtime.lastError) {}
        });
      }
    } catch (e) {}

    document.removeEventListener('click', onRecorderClick, true);
    document.removeEventListener('input', onRecorderInput, true);
    document.removeEventListener('change', onRecorderChange, true);

    removeRecordingHUD();
    updateRecordingHUD();
    updateRecorderBannerButtonState();

    if (!isRecordFromDevTools) {
      openDock();
      switchDockTab('recorder');
      showSavedToast('✅ Recording complete! Test flow ready.');
    }
    isRecordFromDevTools = false;
  }

  function toggleRecording() {
    if (isRecordingMode) {
      stopRecording();
    } else {
      startRecording();
    }
  }

  let assertHoverOverlay = null;

  function ensureAssertHighlightElement() {
    if (!assertHoverOverlay) {
      assertHoverOverlay = document.createElement('div');
      assertHoverOverlay.id = '__xpath_assert_highlighter__';
      assertHoverOverlay.style.cssText = `
        position: fixed;
        display: none;
        pointer-events: none;
        z-index: 2147483645;
        border: 2px dashed #eab308;
        background: rgba(234, 179, 8, 0.12);
        box-shadow: 0 0 12px rgba(234, 179, 8, 0.35);
        border-radius: 4px;
        transition: all 0.05s ease-out;
      `;
      (document.body || document.documentElement).appendChild(assertHoverOverlay);
    }
  }

  function onAssertHover(e) {
    if (!isAssertPickingMode) return;
    let target = e.target;
    if (!target) return;
    if (target.nodeType !== 1 && target.parentElement) target = target.parentElement;
    if (!target || target.nodeType !== 1) return;
    if (isDescendantOfDock(target)) {
      if (assertHoverOverlay) assertHoverOverlay.style.display = 'none';
      return;
    }
    ensureAssertHighlightElement();
    const rect = target.getBoundingClientRect();
    assertHoverOverlay.style.display = 'block';
    assertHoverOverlay.style.top = `${rect.top}px`;
    assertHoverOverlay.style.left = `${rect.left}px`;
    assertHoverOverlay.style.width = `${rect.width}px`;
    assertHoverOverlay.style.height = `${rect.height}px`;
  }

  function startAssertPicking() {
    isAssertPickingMode = true;
    document.body.classList.add('xpath-assert-picking-active');
    document.addEventListener('mouseover', onAssertHover, true);
    updateRecordingHUD();
    updateRecorderBannerButtonState();
    showSavedToast('👁️ Click any element to insert an assertion checkpoint');
  }

  function cancelAssertPicking() {
    isAssertPickingMode = false;
    document.body.classList.remove('xpath-assert-picking-active');
    document.removeEventListener('mouseover', onAssertHover, true);
    if (assertHoverOverlay) assertHoverOverlay.style.display = 'none';
    updateRecordingHUD();
    updateRecorderBannerButtonState();
  }

  function isDescendantOfDock(node) {
    if (!node) return false;
    if (shadowHost && (node === shadowHost || shadowHost.contains(node))) return true;
    if (recHudElement && (node === recHudElement || recHudElement.contains(node))) return true;
    if (checkpointPopoverEl && (node === checkpointPopoverEl || checkpointPopoverEl.contains(node))) return true;
    try {
      if (node.closest && (node.closest('#__smart_xpath_dock_host__') || node.closest('#xpath_rec_hud') || node.closest('#__xpath_checkpoint_popover__'))) return true;
    } catch (e) {}
    return false;
  }

  let checkpointPopoverEl = null;

  function removeCheckpointPopover() {
    if (checkpointPopoverEl) {
      checkpointPopoverEl.remove();
      checkpointPopoverEl = null;
    }
  }

  function isLoaderElement(el) {
    if (!el) return false;
    const str = ((el.className || '') + ' ' + (el.id || '') + ' ' + (el.getAttribute('role') || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
    return /spin|load|progress|overlay|backdrop|wait|skeleton|modal-mask|mask/.test(str);
  }

  function showCheckpointPopover(el, clientX, clientY) {
    removeCheckpointPopover();
    const container = shadowRoot || document.body;
    const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
    if (!engine) return;

    const targetDoc = el.ownerDocument || document;
    const analysis = engine.analyzeElement(el, targetDoc);
    const rawText = (el.innerText || el.textContent || '').trim().replace(/\s+/g, ' ');
    const isLoader = isLoaderElement(el);
    const tag = el.tagName ? el.tagName.toLowerCase() : 'element';
    const shortDesc = '<' + tag + '>' + (rawText ? ' "' + (rawText.length > 20 ? rawText.substring(0, 18) + '...' : rawText) + '"' : '');

    const popover = document.createElement('div');
    popover.id = '__xpath_checkpoint_popover__';
    popover.className = 'xpath-checkpoint-popover';

    const popW = 320;
    const popH = 340;
    let left = clientX + 10;
    let top = clientY + 10;
    if (left + popW > window.innerWidth - 10) left = Math.max(10, clientX - popW - 10);
    if (top + popH > window.innerHeight - 10) top = Math.max(10, window.innerHeight - popH - 10);
    popover.style.left = left + 'px';
    popover.style.top = top + 'px';

    popover.innerHTML = `
      <div class="xpath-cp-header">
        <div class="xpath-cp-title">
          <span>🎯 Choose Checkpoint / Wait</span>
        </div>
        <button class="xpath-cp-close" id="btnCpClose" title="Cancel">✕</button>
      </div>
      <div class="xpath-cp-element-desc" title="${escapeHTML(analysis.best || '')}">
        ${escapeHTML(shortDesc)}
      </div>

      <div class="xpath-cp-section-title">⏳ Dynamic Waits (Synchronization)</div>
      <div class="xpath-cp-btn-grid">
        ${isLoader ? `
          <button class="xpath-cp-btn recommended" data-action="waitForHidden">
            ⭐ <span>Wait for Hidden (Loader Gone)</span>
          </button>
        ` : `
          <button class="xpath-cp-btn is-wait" data-action="waitForHidden">
            ⏳ <span>Wait for Hidden</span>
          </button>
        `}
        <button class="xpath-cp-btn is-wait" data-action="waitForVisible">
          👁️ <span>Wait for Visible</span>
        </button>
        <button class="xpath-cp-btn is-wait" data-action="waitTimeout" data-val="2000">
          ⏱️ <span>Wait Delay (2s)</span>
        </button>
      </div>

      <div class="xpath-cp-section-title">🧪 Assertions</div>
      <div class="xpath-cp-btn-grid">
        <button class="xpath-cp-btn is-assert" data-action="assertVisible">
          👁️ <span>Assert Visible</span>
        </button>
        <button class="xpath-cp-btn is-assert" data-action="assertHidden">
          🙈 <span>Assert Hidden</span>
        </button>
        ${rawText ? `
          <button class="xpath-cp-btn is-assert" data-action="assertText" data-val="${escapeHTML(rawText)}" title="toHaveText">
            🔤 <span>Assert Exact Text</span>
          </button>
          <button class="xpath-cp-btn is-assert" data-action="assertContains" data-val="${escapeHTML(rawText.length > 25 ? rawText.substring(0, 25) : rawText)}" title="toContainText">
            🔍 <span>Assert Contains</span>
          </button>
        ` : `
          <button class="xpath-cp-btn is-assert" data-action="assertText" data-val="" title="toHaveText">
            🔤 <span>Assert Text</span>
          </button>
        `}
        ${['checkbox', 'radio'].includes((el.type || '').toLowerCase()) ? `
          <button class="xpath-cp-btn is-assert" data-action="assertChecked">
            ☑️ <span>Assert Checked</span>
          </button>
        ` : ''}
        ${['button', 'input', 'select', 'textarea'].includes(tag) ? `
          <button class="xpath-cp-btn is-assert" data-action="assertEnabled">
            ⚡ <span>Assert Enabled</span>
          </button>
        ` : ''}
      </div>
    `;

    container.appendChild(popover);
    checkpointPopoverEl = popover;

    const btnClose = popover.querySelector('#btnCpClose');
    if (btnClose) {
      btnClose.addEventListener('click', (e) => {
        e.stopPropagation();
        removeCheckpointPopover();
      });
    }

    popover.querySelectorAll('.xpath-cp-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const action = btn.getAttribute('data-action');
        const customVal = btn.getAttribute('data-val') || '';

        const step = {
          id: 'step_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
          action: action,
          value: customVal || (action === 'assertText' ? rawText : (action === 'waitTimeout' ? '2000' : '')),
          tagName: tag,
          text: rawText ? (rawText.length > 30 ? rawText.substring(0, 27) + '...' : rawText) : (analysis.text || ''),
          bestPlaywright: (analysis.playwrightLocators && analysis.playwrightLocators[0]) ? analysis.playwrightLocators[0].code : null,
          bestPlaywrightJava: (analysis.playwrightLocators && analysis.playwrightLocators[0]) ? (analysis.playwrightLocators[0].javaCode || analysis.playwrightLocators[0].code) : null,
          bestXPath: analysis.best || '',
          cssSelector: analysis.cssSelector || '',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
        };

        appendRecordedStep(step);
        removeCheckpointPopover();

        let actionDesc = action;
        if (action === 'waitForHidden') actionDesc = '⏳ Wait for Hidden (Loader)';
        else if (action === 'waitForVisible') actionDesc = '👁️ Wait for Visible';
        else if (action === 'waitTimeout') actionDesc = '⏱️ 2s Delay';
        else if (action === 'assertVisible') actionDesc = '👁️ Assert: toBeVisible()';
        else if (action === 'assertHidden') actionDesc = '🙈 Assert: toBeHidden()';
        else if (action === 'assertText') actionDesc = '🔤 Assert: toHaveText("' + (rawText.length > 15 ? rawText.substring(0, 15) + '...' : rawText) + '")';
        else if (action === 'assertContains') actionDesc = '🔍 Assert: toContainText';
        else if (action === 'assertChecked') actionDesc = '☑️ Assert: toBeChecked()';
        else if (action === 'assertEnabled') actionDesc = '⚡ Assert: toBeEnabled()';

        showSavedToast('Added: ' + actionDesc);
      });
    });
  }

  function insertFixedDelayStep(delayMs = 2000) {
    const step = {
      id: 'step_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      action: 'waitTimeout',
      value: String(delayMs),
      tagName: 'timer',
      text: 'Pause ' + (delayMs / 1000) + 's',
      bestPlaywright: 'page',
      bestPlaywrightJava: 'page',
      bestXPath: '',
      cssSelector: '',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    };
    appendRecordedStep(step);
    showSavedToast('⏱️ Added ' + (delayMs / 1000) + 's Delay Checkpoint');
  }

  function onRecorderClick(e) {
    if (!e.target || isDescendantOfDock(e.target)) return;

    if (isAssertPickingMode) {
      e.preventDefault();
      e.stopPropagation();
      let el = e.target;
      if (el && el.nodeType !== 1 && el.parentElement) el = el.parentElement;
      if (!el || el.nodeType !== 1) return;
      cancelAssertPicking();
      showCheckpointPopover(el, e.clientX, e.clientY);
      return;
    }

    if (isRecordingPaused) return;

    const el = e.target;
    const tag = el.tagName ? el.tagName.toLowerCase() : '';

    if (tag === 'textarea' || tag === 'select') return;
    if (tag === 'input') {
      const type = (el.type || 'text').toLowerCase();
      if (!['checkbox', 'radio', 'button', 'submit', 'reset', 'image'].includes(type)) {
        return;
      }
    }

    const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
    if (!engine) return;

    const analysis = engine.analyzeElement(el, document);
    const rawText = (el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('value') || '').trim().replace(/\s+/g, ' ');

    let actionName = 'click';
    if (tag === 'input' && (el.type === 'checkbox' || el.type === 'radio')) {
      actionName = el.checked ? 'check' : 'uncheck';
    }

    const step = {
      id: 'step_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      action: actionName,
      value: '',
      tagName: tag,
      text: rawText ? (rawText.length > 30 ? rawText.substring(0, 27) + '...' : rawText) : (analysis.text || ''),
      bestPlaywright: (analysis.playwrightLocators && analysis.playwrightLocators[0]) ? analysis.playwrightLocators[0].code : null,
      bestPlaywrightJava: (analysis.playwrightLocators && analysis.playwrightLocators[0]) ? (analysis.playwrightLocators[0].javaCode || analysis.playwrightLocators[0].code) : null,
      bestXPath: analysis.best || '',
      cssSelector: analysis.cssSelector || '',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    };

    appendRecordedStep(step);
  }

  function onRecorderChange(e) {
    if (!e.target || isDescendantOfDock(e.target) || isRecordingPaused) return;
    const el = e.target;
    const tag = el.tagName ? el.tagName.toLowerCase() : '';

    if (tag === 'select') {
      const optText = el.options && el.selectedIndex >= 0 && el.options[el.selectedIndex]
        ? el.options[el.selectedIndex].text.trim()
        : el.value;

      const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
      if (!engine) return;
      const analysis = engine.analyzeElement(el, document);

      const step = {
        id: 'step_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
        action: 'select',
        value: optText,
        tagName: 'select',
        text: optText,
        bestPlaywright: (analysis.playwrightLocators && analysis.playwrightLocators[0]) ? analysis.playwrightLocators[0].code : null,
        bestPlaywrightJava: (analysis.playwrightLocators && analysis.playwrightLocators[0]) ? (analysis.playwrightLocators[0].javaCode || analysis.playwrightLocators[0].code) : null,
        bestXPath: analysis.best || '',
        cssSelector: analysis.cssSelector || '',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      };
      appendRecordedStep(step);
      return;
    }

    if (tag === 'input' && (el.type === 'checkbox' || el.type === 'radio')) {
      const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
      if (!engine) return;
      const analysis = engine.analyzeElement(el, document);

      const step = {
        id: 'step_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
        action: el.checked ? 'check' : 'uncheck',
        value: el.checked ? 'true' : 'false',
        tagName: 'input',
        text: el.getAttribute('name') || el.id || '',
        bestPlaywright: (analysis.playwrightLocators && analysis.playwrightLocators[0]) ? analysis.playwrightLocators[0].code : null,
        bestPlaywrightJava: (analysis.playwrightLocators && analysis.playwrightLocators[0]) ? (analysis.playwrightLocators[0].javaCode || analysis.playwrightLocators[0].code) : null,
        bestXPath: analysis.best || '',
        cssSelector: analysis.cssSelector || '',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      };
      appendRecordedStep(step);
      return;
    }

    if (tag === 'input' || tag === 'textarea') {
      commitTypingStep(el);
    }
  }

  function onRecorderInput(e) {
    if (!e.target || isDescendantOfDock(e.target) || isRecordingPaused) return;
    const el = e.target;
    const tag = el.tagName ? el.tagName.toLowerCase() : '';
    if (tag !== 'input' && tag !== 'textarea') return;

    if (activeTypingTimer) clearTimeout(activeTypingTimer);
    lastTypingElement = el;
    activeTypingTimer = setTimeout(() => {
      commitTypingStep(el);
    }, 650);
  }

  function commitTypingStep(el) {
    if (!el || !el.value) return;
    const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
    if (!engine) return;

    const analysis = engine.analyzeElement(el, document);
    const label = el.getAttribute('placeholder') || el.getAttribute('name') || el.getAttribute('aria-label') || el.id || 'input';

    getRecordedFlowSteps((steps) => {
      if (steps.length > 0) {
        const last = steps[steps.length - 1];
        if (last.action === 'fill' && last.bestXPath === analysis.best) {
          last.value = el.value;
          last.timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
          setRecordedFlowSteps(steps, () => {
            if (activeDockTab === 'recorder') renderRecorderStepsList();
          });
          return;
        }
      }

      const step = {
        id: 'step_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
        action: 'fill',
        value: el.value,
        isPassword: el.type === 'password',
        tagName: el.tagName.toLowerCase(),
        text: label,
        bestPlaywright: (analysis.playwrightLocators && analysis.playwrightLocators[0]) ? analysis.playwrightLocators[0].code : null,
        bestPlaywrightJava: (analysis.playwrightLocators && analysis.playwrightLocators[0]) ? (analysis.playwrightLocators[0].javaCode || analysis.playwrightLocators[0].code) : null,
        bestXPath: analysis.best || '',
        cssSelector: analysis.cssSelector || '',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      };

      steps.push(step);
      setRecordedFlowSteps(steps, () => {
        if (activeDockTab === 'recorder') renderRecorderStepsList();
      });
    });
  }

  function formatFlowStepCode(step, framework = 'playwright') {
    if (!step) return '';
    const action = step.action || 'click';
    const val = step.value || '';
    const safeXp = (step.bestXPath || '').replace(/"/g, '\"');
    const safeVal = JSON.stringify(val);
    const safeTimeout = step.timeout || 15000;
    const safeTimeoutSec = Math.round(safeTimeout / 1000);

    const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);

    const pwTarget = step.bestPlaywright || (step.cssSelector ? 'page.locator(\'' + step.cssSelector.replace(/'/g, "\\'") + '\')' : 'page.locator("xpath=' + safeXp + '")');
    const pyTarget = (engine && typeof engine.toPlaywrightPython === 'function')
      ? engine.toPlaywrightPython(step.bestPlaywright, step.bestXPath)
      : 'page.locator("xpath=' + safeXp + '")';
    const javaPwTarget = step.bestPlaywrightJava || ('page.locator("xpath=' + safeXp + '")');

    // 1. Playwright Python
    if (framework === 'playwright-python') {
      if (action === 'click') return pyTarget + '.click()';
      if (action === 'fill') return pyTarget + '.fill(' + safeVal + ')';
      if (action === 'check') return pyTarget + '.check()';
      if (action === 'uncheck') return pyTarget + '.uncheck()';
      if (action === 'select') return pyTarget + '.select_option(label=' + safeVal + ')';
      // Dynamic Waits
      if (action === 'waitForHidden') return pyTarget + '.wait_for(state="hidden", timeout=' + safeTimeout + ')';
      if (action === 'waitForVisible') return pyTarget + '.wait_for(state="visible", timeout=' + safeTimeout + ')';
      if (action === 'waitTimeout') return 'page.wait_for_timeout(' + (parseInt(val) || 2000) + ')';
      // Assertions
      if (action === 'assertVisible') return 'expect(' + pyTarget + ').to_be_visible()';
      if (action === 'assertHidden') return 'expect(' + pyTarget + ').to_be_hidden()';
      if (action === 'assertText') return 'expect(' + pyTarget + ').to_have_text(' + JSON.stringify(val || step.text || '') + ')';
      if (action === 'assertContains') return 'expect(' + pyTarget + ').to_contain_text(' + JSON.stringify(val || step.text || '') + ')';
      if (action === 'assertChecked') return 'expect(' + pyTarget + ').to_be_checked()';
      if (action === 'assertEnabled') return 'expect(' + pyTarget + ').to_be_enabled()';
      return pyTarget + '.click()';
    }

    // 2. Playwright Java
    if (framework === 'playwright-java') {
      if (action === 'click') return javaPwTarget + '.click();';
      if (action === 'fill') return javaPwTarget + '.fill(' + safeVal + ');';
      if (action === 'check') return javaPwTarget + '.check();';
      if (action === 'uncheck') return javaPwTarget + '.uncheck();';
      if (action === 'select') return javaPwTarget + '.selectOption(new SelectOption().setLabel(' + safeVal + '));';
      // Dynamic Waits
      if (action === 'waitForHidden') return javaPwTarget + '.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN).setTimeout(' + safeTimeout + '));';
      if (action === 'waitForVisible') return javaPwTarget + '.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(' + safeTimeout + '));';
      if (action === 'waitTimeout') return 'page.waitForTimeout(' + (parseInt(val) || 2000) + ');';
      // Assertions
      if (action === 'assertVisible') return 'assertThat(' + javaPwTarget + ').isVisible();';
      if (action === 'assertHidden') return 'assertThat(' + javaPwTarget + ').isHidden();';
      if (action === 'assertText') return 'assertThat(' + javaPwTarget + ').hasText(' + JSON.stringify(val || step.text || '') + ');';
      if (action === 'assertContains') return 'assertThat(' + javaPwTarget + ').containsText(' + JSON.stringify(val || step.text || '') + ');';
      if (action === 'assertChecked') return 'assertThat(' + javaPwTarget + ').isChecked();';
      if (action === 'assertEnabled') return 'assertThat(' + javaPwTarget + ').isEnabled();';
      return javaPwTarget + '.click();';
    }

    // 3. Selenium Java
    if (framework === 'selenium-java') {
      if (action === 'click') return 'driver.findElement(By.xpath("' + safeXp + '")).click();';
      if (action === 'fill') return 'driver.findElement(By.xpath("' + safeXp + '")).sendKeys(' + safeVal + ');';
      if (action === 'check') return 'if (!driver.findElement(By.xpath("' + safeXp + '")).isSelected()) driver.findElement(By.xpath("' + safeXp + '")).click();';
      if (action === 'uncheck') return 'if (driver.findElement(By.xpath("' + safeXp + '")).isSelected()) driver.findElement(By.xpath("' + safeXp + '")).click();';
      if (action === 'select') return 'new Select(driver.findElement(By.xpath("' + safeXp + '"))).selectByVisibleText(' + safeVal + ');';
      // Dynamic Waits
      if (action === 'waitForHidden') return 'new WebDriverWait(driver, Duration.ofSeconds(' + safeTimeoutSec + ')).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("' + safeXp + '")));';
      if (action === 'waitForVisible') return 'new WebDriverWait(driver, Duration.ofSeconds(' + safeTimeoutSec + ')).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("' + safeXp + '")));';
      if (action === 'waitTimeout') return 'Thread.sleep(' + (parseInt(val) || 2000) + ');';
      // Assertions
      if (action === 'assertVisible') return 'Assert.assertTrue(driver.findElement(By.xpath("' + safeXp + '")).isDisplayed());';
      if (action === 'assertHidden') return 'Assert.assertTrue(driver.findElements(By.xpath("' + safeXp + '")).isEmpty() || !driver.findElement(By.xpath("' + safeXp + '")).isDisplayed());';
      if (action === 'assertText') return 'Assert.assertEquals(driver.findElement(By.xpath("' + safeXp + '")).getText().trim(), ' + JSON.stringify(val || step.text || '') + ');';
      if (action === 'assertContains') return 'Assert.assertTrue(driver.findElement(By.xpath("' + safeXp + '")).getText().contains(' + JSON.stringify(val || step.text || '') + '));';
      if (action === 'assertChecked') return 'Assert.assertTrue(driver.findElement(By.xpath("' + safeXp + '")).isSelected());';
      if (action === 'assertEnabled') return 'Assert.assertTrue(driver.findElement(By.xpath("' + safeXp + '")).isEnabled());';
      return 'driver.findElement(By.xpath("' + safeXp + '")).click();';
    }

    // 4. Selenium Python
    if (framework === 'selenium-python') {
      if (action === 'click') return 'driver.find_element(By.XPATH, "' + safeXp + '").click()';
      if (action === 'fill') return 'driver.find_element(By.XPATH, "' + safeXp + '").send_keys(' + safeVal + ')';
      if (action === 'check') return '_el = driver.find_element(By.XPATH, "' + safeXp + '")\nif not _el.is_selected(): _el.click()';
      if (action === 'uncheck') return '_el = driver.find_element(By.XPATH, "' + safeXp + '")\nif _el.is_selected(): _el.click()';
      if (action === 'select') return 'Select(driver.find_element(By.XPATH, "' + safeXp + '")).select_by_visible_text(' + safeVal + ')';
      // Dynamic Waits
      if (action === 'waitForHidden') return 'WebDriverWait(driver, ' + safeTimeoutSec + ').until(EC.invisibility_of_element_located((By.XPATH, "' + safeXp + '")))';
      if (action === 'waitForVisible') return 'WebDriverWait(driver, ' + safeTimeoutSec + ').until(EC.visibility_of_element_located((By.XPATH, "' + safeXp + '")))';
      if (action === 'waitTimeout') return 'time.sleep(' + ((parseInt(val) || 2000) / 1000) + ')';
      // Assertions
      if (action === 'assertVisible') return 'assert driver.find_element(By.XPATH, "' + safeXp + '").is_displayed()';
      if (action === 'assertHidden') return 'assert len(driver.find_elements(By.XPATH, "' + safeXp + '")) == 0 or not driver.find_element(By.XPATH, "' + safeXp + '").is_displayed()';
      if (action === 'assertText') return 'assert driver.find_element(By.XPATH, "' + safeXp + '").text.strip() == ' + JSON.stringify(val || step.text || '');
      if (action === 'assertContains') return 'assert ' + JSON.stringify(val || step.text || '') + ' in driver.find_element(By.XPATH, "' + safeXp + '").text';
      if (action === 'assertChecked') return 'assert driver.find_element(By.XPATH, "' + safeXp + '").is_selected()';
      if (action === 'assertEnabled') return 'assert driver.find_element(By.XPATH, "' + safeXp + '").is_enabled()';
      return 'driver.find_element(By.XPATH, "' + safeXp + '").click()';
    }

    // 5. Cypress
    if (framework === 'cypress') {
      if (action === 'click') return 'cy.xpath("' + safeXp + '").click();';
      if (action === 'fill') return 'cy.xpath("' + safeXp + '").type(' + safeVal + ');';
      if (action === 'check') return 'cy.xpath("' + safeXp + '").check();';
      if (action === 'uncheck') return 'cy.xpath("' + safeXp + '").uncheck();';
      if (action === 'select') return 'cy.xpath("' + safeXp + '").select(' + safeVal + ');';
      // Dynamic Waits
      if (action === 'waitForHidden') return 'cy.xpath("' + safeXp + '", { timeout: ' + safeTimeout + ' }).should("not.exist");';
      if (action === 'waitForVisible') return 'cy.xpath("' + safeXp + '", { timeout: ' + safeTimeout + ' }).should("be.visible");';
      if (action === 'waitTimeout') return 'cy.wait(' + (parseInt(val) || 2000) + ');';
      // Assertions
      if (action === 'assertVisible') return 'cy.xpath("' + safeXp + '").should(\'be.visible\');';
      if (action === 'assertHidden') return 'cy.xpath("' + safeXp + '").should(\'not.be.visible\');';
      if (action === 'assertText') return 'cy.xpath("' + safeXp + '").should(\'have.text\', ' + JSON.stringify(val || step.text || '') + ');';
      if (action === 'assertContains') return 'cy.xpath("' + safeXp + '").should(\'contain.text\', ' + JSON.stringify(val || step.text || '') + ');';
      if (action === 'assertChecked') return 'cy.xpath("' + safeXp + '").should(\'be.checked\');';
      if (action === 'assertEnabled') return 'cy.xpath("' + safeXp + '").should(\'be.enabled\');';
      return 'cy.xpath("' + safeXp + '").click();';
    }

    // 6. Robot Framework
    if (framework === 'robot') {
      if (action === 'click') return 'Click Element    xpath=' + step.bestXPath;
      if (action === 'fill') return 'Input Text    xpath=' + step.bestXPath + '    ' + val;
      if (action === 'check') return 'Select Checkbox    xpath=' + step.bestXPath;
      if (action === 'uncheck') return 'Unselect Checkbox    xpath=' + step.bestXPath;
      if (action === 'select') return 'Select From List By Label    xpath=' + step.bestXPath + '    ' + val;
      // Dynamic Waits
      if (action === 'waitForHidden') return 'Wait Until Element Is Not Visible    xpath=' + step.bestXPath + '    ' + safeTimeoutSec + 's';
      if (action === 'waitForVisible') return 'Wait Until Element Is Visible    xpath=' + step.bestXPath + '    ' + safeTimeoutSec + 's';
      if (action === 'waitTimeout') return 'Sleep    ' + ((parseInt(val) || 2000) / 1000) + 's';
      // Assertions
      if (action === 'assertVisible') return 'Element Should Be Visible    xpath=' + step.bestXPath;
      if (action === 'assertHidden') return 'Element Should Not Be Visible    xpath=' + step.bestXPath;
      if (action === 'assertText') return 'Element Text Should Be    xpath=' + step.bestXPath + '    ' + (val || step.text || '');
      if (action === 'assertContains') return 'Element Should Contain    xpath=' + step.bestXPath + '    ' + (val || step.text || '');
      if (action === 'assertChecked') return 'Checkbox Should Be Selected    xpath=' + step.bestXPath;
      if (action === 'assertEnabled') return 'Element Should Be Enabled    xpath=' + step.bestXPath;
      return 'Click Element    xpath=' + step.bestXPath;
    }

    // Default: Playwright JS/TS
    if (action === 'click') return 'await ' + pwTarget + '.click();';
    if (action === 'fill') return 'await ' + pwTarget + '.fill(' + safeVal + ');';
    if (action === 'check') return 'await ' + pwTarget + '.check();';
    if (action === 'uncheck') return 'await ' + pwTarget + '.uncheck();';
    if (action === 'select') return 'await ' + pwTarget + '.selectOption({ label: ' + safeVal + ' });';
    // Dynamic Waits
    if (action === 'waitForHidden') return 'await ' + pwTarget + '.waitFor({ state: "hidden", timeout: ' + safeTimeout + ' });';
    if (action === 'waitForVisible') return 'await ' + pwTarget + '.waitFor({ state: "visible", timeout: ' + safeTimeout + ' });';
    if (action === 'waitTimeout') return 'await page.waitForTimeout(' + (parseInt(val) || 2000) + ');';
    // Assertions
    if (action === 'assertVisible') return 'await expect(' + pwTarget + ').toBeVisible();';
    if (action === 'assertHidden') return 'await expect(' + pwTarget + ').toBeHidden();';
    if (action === 'assertText') return 'await expect(' + pwTarget + ').toHaveText(' + JSON.stringify(val || step.text || '') + ');';
    if (action === 'assertContains') return 'await expect(' + pwTarget + ').toContainText(' + JSON.stringify(val || step.text || '') + ');';
    if (action === 'assertChecked') return 'await expect(' + pwTarget + ').toBeChecked();';
    if (action === 'assertEnabled') return 'await expect(' + pwTarget + ').toBeEnabled();';
    return 'await ' + pwTarget + '.click();';
  }

  function generateFullFlowScript(steps, framework = 'playwright') {
    if (!steps || steps.length === 0) return '';
    const startUrl = window.location.href;

    if (framework === 'playwright-python') {
      const stepLines = steps.map((s, i) => {
        const comment = '    # Step ' + (i + 1) + ': ' + s.action.toUpperCase() + ' <' + s.tagName + '> "' + (s.text || s.value || '') + '"';
        return comment + '\n    ' + formatFlowStepCode(s, framework);
      }).join('\n\n');

      return 'import pytest\nfrom playwright.sync_api import Page, expect\n\ndef test_recorded_flow(page: Page):\n    # Navigate to starting page\n    page.goto(\'' + startUrl + '\')\n\n' + stepLines + '\n';
    }

    if (framework === 'playwright-java') {
      const stepLines = steps.map((s, i) => {
        const comment = '        // Step ' + (i + 1) + ': ' + s.action.toUpperCase() + ' <' + s.tagName + '> "' + (s.text || s.value || '') + '"';
        return comment + '\n        ' + formatFlowStepCode(s, framework);
      }).join('\n\n');

      return 'package com.automation.tests;\n\nimport com.microsoft.playwright.*;\nimport com.microsoft.playwright.options.*;\nimport static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;\nimport org.junit.jupiter.api.Test;\n\npublic class RecordedFlowTest {\n    @Test\n    void testRecordedFlow() {\n        try (Playwright playwright = Playwright.create()) {\n            Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));\n            Page page = browser.newPage();\n            \n            // Navigate to starting page\n            page.goto("' + startUrl + '");\n            \n' + stepLines + '\n        }\n    }\n}\n';
    }

    if (framework === 'selenium-java') {
      const stepLines = steps.map((s, i) => {
        const comment = '        // Step ' + (i + 1) + ': ' + s.action.toUpperCase() + ' <' + s.tagName + '> "' + (s.text || s.value || '') + '"';
        return comment + '\n        ' + formatFlowStepCode(s, framework);
      }).join('\n\n');

      return 'package com.automation.tests;\n\nimport java.time.Duration;\nimport org.openqa.selenium.By;\nimport org.openqa.selenium.WebDriver;\nimport org.openqa.selenium.chrome.ChromeDriver;\nimport org.openqa.selenium.support.ui.Select;\nimport org.openqa.selenium.support.ui.WebDriverWait;\nimport org.openqa.selenium.support.ui.ExpectedConditions;\nimport org.junit.jupiter.api.Test;\nimport org.junit.jupiter.api.Assertions;\n\npublic class SeleniumFlowTest {\n    @Test\n    public void testRecordedFlow() throws Exception {\n        WebDriver driver = new ChromeDriver();\n        driver.manage().window().maximize();\n        try {\n            // Navigate to starting page\n            driver.get("' + startUrl + '");\n            \n' + stepLines + '\n        } finally {\n            driver.quit();\n        }\n    }\n}\n';
    }

    if (framework === 'selenium-python') {
      const stepLines = steps.map((s, i) => {
        const comment = '    # Step ' + (i + 1) + ': ' + s.action.toUpperCase() + ' <' + s.tagName + '> "' + (s.text || s.value || '') + '"';
        return comment + '\n    ' + formatFlowStepCode(s, framework);
      }).join('\n\n');

      return 'import pytest\nfrom selenium import webdriver\nfrom selenium.webdriver.common.by import By\nfrom selenium.webdriver.support.ui import Select, WebDriverWait\nfrom selenium.webdriver.support import expected_conditions as EC\nimport time\n\ndef test_recorded_flow():\n    driver = webdriver.Chrome()\n    driver.implicitly_wait(10)\n    try:\n        # Navigate to starting page\n        driver.get("' + startUrl + '")\n        \n' + stepLines + '\n    finally:\n        driver.quit()\n';
    }

    if (framework === 'cypress') {
      const stepLines = steps.map((s, i) => {
        const comment = '    // Step ' + (i + 1) + ': ' + s.action.toUpperCase() + ' <' + s.tagName + '> "' + (s.text || s.value || '') + '"';
        return comment + '\n    ' + formatFlowStepCode(s, framework);
      }).join('\n\n');

      return 'describe(\'TestPath - Recorded Flow\', () => {\n  it(\'executes recorded test sequence\', () => {\n    // Navigate to starting page\n    cy.visit(\'' + startUrl + '\');\n\n' + stepLines + '\n  });\n});\n';
    }

    if (framework === 'robot') {
      const stepLines = steps.map((s, i) => {
        const comment = '    # Step ' + (i + 1) + ': ' + s.action.toUpperCase() + ' <' + s.tagName + '> "' + (s.text || s.value || '') + '"';
        return comment + '\n    ' + formatFlowStepCode(s, framework);
      }).join('\n\n');

      return '*** Settings ***\nLibrary    SeleniumLibrary\n\n*** Test Cases ***\nRecorded Test Flow\n    Open Browser    ' + startUrl + '    chrome\n    Maximize Browser Window\n    Set Selenium Implicit Wait    10 seconds\n\n' + stepLines + '\n\n    [Teardown]    Close Browser\n';
    }

    // Default: Playwright JS/TS
    const stepLines = steps.map((s, i) => {
      const comment = '  // Step ' + (i + 1) + ': ' + s.action.toUpperCase() + ' <' + s.tagName + '> "' + (s.text || s.value || '') + '"';
      return comment + '\n  ' + formatFlowStepCode(s, framework);
    }).join('\n\n');

    return "import { test, expect } from '@playwright/test';\n\ntest('TestPath - Recorded Test Flow', async ({ page }) => {\n  // Navigate to starting page\n  await page.goto('" + startUrl + "');\n\n" + stepLines + "\n});\n";
  }

  function renderRecorderStepsList() {
    if (!shadowRoot) return;
    const timeline = shadowRoot.getElementById('recorderStepsTimeline');
    if (!timeline) return;

    const frameworkSelect = shadowRoot.getElementById('recorderFrameworkSelect');
    const framework = frameworkSelect ? frameworkSelect.value : (currentFormat || 'playwright');

    getRecordedFlowSteps((steps) => {
      updateRecorderCountBadge();

      if (!steps || steps.length === 0) {
        timeline.innerHTML = `
          <div class="xpath-recorder-empty">
            <svg class="xpath-recorder-empty-icon" viewBox="0 0 24 24" fill="currentColor">
              <circle cx="12" cy="12" r="8"/>
            </svg>
            <h3>No steps recorded yet</h3>
            <p>Click <strong>Record Flow</strong> to capture clicks, typing, checkboxes, and assertions live as you interact with the page.</p>
            <button class="xpath-btn-start-rec-big" id="btnTimelineStartRec">
              🔴 Start Recording Flow
            </button>
          </div>
        `;

        const btnBig = timeline.querySelector('#btnTimelineStartRec');
        if (btnBig) {
          btnBig.addEventListener('click', () => {
            startRecording();
          });
        }
        return;
      }

      let html = '';
      steps.forEach((step, index) => {
        const stepNum = index + 1;
        const codeSnippet = formatFlowStepCode(step, framework);
        const actionCls = step.action || 'click';

        let valDesc = '';
        if (step.action === 'fill') {
          valDesc = 'Value: "' + escapeHTML(step.value || '') + '"';
        } else if (step.action === 'select') {
          valDesc = 'Selected: "' + escapeHTML(step.value || '') + '"';
        } else if (step.action === 'assertText' || step.action === 'assertContains') {
          valDesc = 'Expected text: "' + escapeHTML(step.value || step.text || '') + '"';
        } else if (step.action === 'waitForHidden') {
          valDesc = 'Wait until loader / spinner disappears (max 15s)';
        } else if (step.action === 'waitForVisible') {
          valDesc = 'Wait until element appears (max 15s)';
        } else if (step.action === 'waitTimeout') {
          valDesc = 'Pause: ' + ((parseInt(step.value) || 2000) / 1000) + 's';
        } else if (step.action === 'assertHidden') {
          valDesc = 'Assert element is not visible or removed';
        } else if (step.action === 'assertVisible') {
          valDesc = 'Assert element is displayed';
        } else if (step.action === 'assertChecked') {
          valDesc = 'Assert checkbox/radio is checked';
        } else if (step.action === 'assertEnabled') {
          valDesc = 'Assert element is enabled';
        }

        html += `
          <div class="xpath-rec-step-card is-${escapeHTML(actionCls)} ${actionCls.startsWith('assert') ? 'is-assert' : ''} ${actionCls.startsWith('wait') ? 'is-wait' : ''}" data-step-id="${escapeHTML(step.id)}">
            <div class="xpath-step-header">
              <div class="xpath-step-badge-wrap">
                <span class="xpath-step-number">${stepNum}</span>
                <select class="xpath-step-action-select" data-step-id="${escapeHTML(step.id)}" title="Change step action">
                  <optgroup label="User Actions">
                    <option value="click" ${step.action === 'click' ? 'selected' : ''}>⚡ Click</option>
                    <option value="fill" ${step.action === 'fill' ? 'selected' : ''}>✏️ Fill</option>
                    <option value="check" ${step.action === 'check' ? 'selected' : ''}>☑️ Check</option>
                    <option value="uncheck" ${step.action === 'uncheck' ? 'selected' : ''}>⬜ Uncheck</option>
                    <option value="select" ${step.action === 'select' ? 'selected' : ''}>🔽 Select</option>
                  </optgroup>
                  <optgroup label="Dynamic Synchronization (Waits)">
                    <option value="waitForHidden" ${step.action === 'waitForHidden' ? 'selected' : ''}>⏳ Wait Hidden (Loader Gone)</option>
                    <option value="waitForVisible" ${step.action === 'waitForVisible' ? 'selected' : ''}>👁️ Wait for Visible</option>
                    <option value="waitTimeout" ${step.action === 'waitTimeout' ? 'selected' : ''}>⏱️ Wait Delay (Sleep)</option>
                  </optgroup>
                  <optgroup label="Assertions">
                    <option value="assertVisible" ${step.action === 'assertVisible' ? 'selected' : ''}>👁️ Assert: toBeVisible</option>
                    <option value="assertHidden" ${step.action === 'assertHidden' ? 'selected' : ''}>🙈 Assert: toBeHidden</option>
                    <option value="assertText" ${step.action === 'assertText' ? 'selected' : ''}>🔤 Assert: toHaveText</option>
                    <option value="assertContains" ${step.action === 'assertContains' ? 'selected' : ''}>🔍 Assert: toContainText</option>
                    <option value="assertChecked" ${step.action === 'assertChecked' ? 'selected' : ''}>☑️ Assert: toBeChecked</option>
                    <option value="assertEnabled" ${step.action === 'assertEnabled' ? 'selected' : ''}>⚡ Assert: toBeEnabled</option>
                  </optgroup>
                </select>
                <span class="xpath-step-target-desc" title="${escapeHTML(step.text || step.tagName)}">&lt;${escapeHTML(step.tagName)}&gt; ${escapeHTML(step.text || '')}</span>
              </div>
              <span class="xpath-step-timestamp">${escapeHTML(step.timestamp || '')}</span>
            </div>
            <div class="xpath-step-code-box">${escapeHTML(codeSnippet)}</div>
            <div class="xpath-step-footer">
              <span class="xpath-step-val-info">${valDesc}</span>
              <div class="xpath-step-buttons">
                <button class="xpath-btn-step-mini xpath-btn-test-step" data-test-xpath="${escapeHTML(step.bestXPath || '')}" title="Highlight element on current page">
                  🔍 Test
                </button>
                <button class="xpath-btn-step-mini xpath-btn-copy-step" data-copy="${escapeHTML(codeSnippet)}" title="Copy step code">
                  ${ICONS.copy} Copy
                </button>
                <button class="xpath-btn-step-mini xpath-btn-step-delete" data-del-id="${escapeHTML(step.id)}" title="Delete this step">
                  ✕
                </button>
              </div>
            </div>
          </div>
        `;
      });

      timeline.innerHTML = html;

      // Bind inline action switcher
      timeline.querySelectorAll('.xpath-step-action-select').forEach((sel) => {
        sel.addEventListener('change', () => {
          const stepId = sel.getAttribute('data-step-id');
          const newAction = sel.value;
          getRecordedFlowSteps((allSteps) => {
            const st = allSteps.find(s => s.id === stepId);
            if (st) {
              st.action = newAction;
              if (newAction === 'waitTimeout' && !st.value) st.value = '2000';
              setRecordedFlowSteps(allSteps, () => {
                renderRecorderStepsList();
                showSavedToast('Updated step to ' + newAction);
              });
            }
          });
        });
      });

      // Bind Test button
      timeline.querySelectorAll('.xpath-btn-test-step').forEach((btn) => {
        btn.addEventListener('click', () => {
          const xp = btn.getAttribute('data-test-xpath');
          if (!xp) return;
          const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
          if (engine) {
            const matches = engine.queryXPath(xp, document);
            if (matches && matches.length > 0) {
              highlightEvaluatedElements(matches, 0);
              matches[0].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
              showSavedToast('🎯 Highlighted on page');
            } else {
              showSavedToast('0 matches found on current page');
            }
          }
        });
      });

      // Bind Copy button
      timeline.querySelectorAll('.xpath-btn-copy-step').forEach((btn) => {
        btn.addEventListener('click', () => {
          const code = btn.getAttribute('data-copy');
          copyToClipboard(code, btn, 'Copied!');
        });
      });

      // Bind Delete button
      timeline.querySelectorAll('.xpath-btn-step-delete').forEach((btn) => {
        btn.addEventListener('click', () => {
          const id = btn.getAttribute('data-del-id');
          getRecordedFlowSteps((allSteps) => {
            const filtered = allSteps.filter(s => s.id !== id);
            setRecordedFlowSteps(filtered, () => {
              renderRecorderStepsList();
              showSavedToast('Step deleted');
            });
          });
        });
      });
    });
  }

  function exportFlowTestScript() {
    getRecordedFlowSteps((steps) => {
      if (!steps || steps.length === 0) {
        showSavedToast('No recorded steps to export!');
        return;
      }
      const frameworkSelect = shadowRoot ? shadowRoot.getElementById('recorderFrameworkSelect') : null;
      const framework = frameworkSelect ? frameworkSelect.value : 'playwright';

      const script = generateFullFlowScript(steps, framework);
      copyToClipboard(script, null, 'Flow script copied!');

      let ext = 'spec.ts';
      if (framework === 'playwright-python' || framework === 'selenium-python') ext = 'py';
      else if (framework === 'playwright-java' || framework === 'selenium-java') ext = 'java';
      else if (framework === 'cypress') ext = 'cy.js';
      else if (framework === 'robot') ext = 'robot';

      const blob = new Blob([script], { type: 'text/plain;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const filename = 'testpath-flow-' + (new Date().toISOString().slice(0, 10)) + '.' + ext;
      triggerDownload(url, filename);
      showSavedToast('⚡ Exported ' + steps.length + ' steps to ' + filename);
    });
  }

  function copyFlowFullCode() {
    getRecordedFlowSteps((steps) => {
      if (!steps || steps.length === 0) {
        showSavedToast('No recorded steps to copy!');
        return;
      }
      const frameworkSelect = shadowRoot ? shadowRoot.getElementById('recorderFrameworkSelect') : null;
      const framework = frameworkSelect ? frameworkSelect.value : 'playwright';

      const lines = steps.map(s => formatFlowStepCode(s, framework)).join('\n');
      const btn = shadowRoot ? shadowRoot.getElementById('btnCopyFlowCode') : null;
      copyToClipboard(lines, btn, 'All Copied!');
    });
  }

  function saveFlowStepsToLocatorsCollection() {
    getRecordedFlowSteps((steps) => {
      if (!steps || steps.length === 0) {
        showSavedToast('No recorded steps to save!');
        return;
      }

      getSavedLocators((existingSaved) => {
        let addedCount = 0;
        steps.forEach((s) => {
          const locItem = {
            id: 'loc_rec_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
            timestamp: new Date().toISOString(),
            tagName: s.tagName || 'element',
            text: s.text || s.value || '',
            bestXPath: s.bestXPath || '',
            bestPlaywright: s.bestPlaywright || '',
            cssSelector: s.cssSelector || '',
            action: s.action || 'click',
            actionCode: formatFlowStepCode(s, currentFormat || 'playwright'),
            actionFormat: currentFormat || 'playwright',
            fillValue: s.value || '',
            pageUrl: window.location.href,
            pageTitle: document.title
          };
          existingSaved.push(locItem);
          addedCount++;
        });

        setSavedLocators(existingSaved, () => {
          updateSavedCountBadge();
          showSavedToast('⭐ Saved ' + addedCount + ' steps to Saved Locators!');
        });
      });
    });
  }

  /**
   * Ensure extension host elements are present in DOM
   */
  function ensureInDOM() {
    const target = document.body || document.documentElement;
    if (!target) return false;

    if (shadowHost) {
      if (document.body && shadowHost.parentElement !== document.body) {
        document.body.appendChild(shadowHost);
      } else if (!document.contains(shadowHost)) {
        target.appendChild(shadowHost);
      }
    }

    if (highlightOverlay) {
      if (document.body && highlightOverlay.parentElement !== document.body) {
        document.body.appendChild(highlightOverlay);
      } else if (!document.contains(highlightOverlay)) {
        target.appendChild(highlightOverlay);
      }
    }

    if (evalHighlightContainer) {
      if (document.body && evalHighlightContainer.parentElement !== document.body) {
        document.body.appendChild(evalHighlightContainer);
      } else if (!document.contains(evalHighlightContainer)) {
        target.appendChild(evalHighlightContainer);
      }
    }
    return true;
  }

  /**
   * Initialize Shadow DOM UI & Highlight Layers (Singleton Guarantee)
   */
  function initUI() {
    // 1. Remove duplicate hosts if any exist from reloads
    const allHosts = document.querySelectorAll('#__smart_xpath_dock_host__');
    if (allHosts.length > 1) {
      for (let i = 1; i < allHosts.length; i++) {
        allHosts[i].remove();
      }
    }

    if (shadowHost && document.contains(shadowHost)) {
      ensureInDOM();
      return;
    }

    // Reuse existing DOM element if present
    const existing = document.getElementById('__smart_xpath_dock_host__');
    if (existing && existing.shadowRoot) {
      shadowHost = existing;
      shadowRoot = existing.shadowRoot;
      dockContainer = shadowRoot.querySelector('.xpath-finder-dock');
      launcherBtn = shadowRoot.querySelector('#btnFloatingLauncher');
      ensureInDOM();
      return;
    }

    const target = document.body || document.documentElement;
    if (!target) return;

    // 1. Create In-page Hover Highlight Element
    highlightOverlay = document.createElement('div');
    highlightOverlay.id = '__smart_xpath_highlighter__';
    highlightOverlay.style.cssText = `
      position: fixed;
      display: none;
      pointer-events: none;
      z-index: 2147483640;
      border: 1.5px solid #3b82f6;
      background: rgba(59, 130, 246, 0.08);
      box-shadow: 0 1px 4px rgba(0, 0, 0, 0.15);
      border-radius: 3px;
      transition: all 0.06s ease-out;
    `;

    // Tooltip for element info on hover
    const tooltip = document.createElement('div');
    tooltip.id = '__smart_xpath_tooltip__';
    tooltip.style.cssText = `
      position: absolute;
      top: -26px;
      left: 0;
      background: #1e2430;
      color: #f1f5f9;
      border: 1px solid rgba(255, 255, 255, 0.14);
      padding: 2px 7px;
      border-radius: 4px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 11px;
      font-weight: 500;
      white-space: nowrap;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25);
    `;
    highlightOverlay.appendChild(tooltip);
    target.appendChild(highlightOverlay);

    // 2. Multi-match highlighter container for live evaluation
    evalHighlightContainer = document.createElement('div');
    evalHighlightContainer.id = '__smart_xpath_eval_container__';
    evalHighlightContainer.style.cssText = `
      position: fixed;
      top: 0; left: 0; width: 0; height: 0;
      pointer-events: none;
      z-index: 2147483639;
    `;
    target.appendChild(evalHighlightContainer);

    // 3. Shadow DOM Container for Floating Dock & Launcher
    shadowHost = document.createElement('div');
    shadowHost.id = '__smart_xpath_dock_host__';
    shadowHost.style.cssText = `
      position: fixed;
      top: 0; left: 0; width: 0; height: 0;
      z-index: 2147483647;
    `;
    shadowRoot = shadowHost.attachShadow({ mode: 'open' });

    // Inject Embedded CSS directly inside Shadow DOM (immune to CSP restrictions)
    const styleEl = document.createElement('style');
    styleEl.textContent = EMBEDDED_CSS;
    shadowRoot.appendChild(styleEl);

    // Render Floating Launcher Button (visible by default)
    launcherBtn = document.createElement('button');
    launcherBtn.className = 'xpath-floating-launcher';
    launcherBtn.id = 'btnFloatingLauncher';
    launcherBtn.innerHTML = `${ICONS.crosshair} <span>TestPath</span>`;
    launcherBtn.title = 'Click to open TestPath Inspector';
    shadowRoot.appendChild(launcherBtn);

    // Render Dock markup (hidden by default until opened)
    dockContainer = document.createElement('div');
    dockContainer.className = 'xpath-finder-dock';
    dockContainer.style.display = 'none';
    dockContainer.innerHTML = buildDockHTML();
    shadowRoot.appendChild(dockContainer);

    target.appendChild(shadowHost);

    // Bind Dock & Launcher Events
    setupDockEvents();
  }

  /**
   * HTML Structure of the Floating Inspector Dock
   */
  function buildDockHTML() {
    return `
      <!-- Header -->
      <div class="xpath-dock-header" id="dockHeader">
        <div class="xpath-brand">
          <svg class="xpath-brand-icon" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10"/>
            <line x1="12" y1="2" x2="12" y2="6"/>
            <line x1="12" y1="18" x2="12" y2="22"/>
            <line x1="2" y1="12" x2="6" y2="12"/>
            <line x1="18" y1="12" x2="22" y2="12"/>
          </svg>
          <span>TestPath</span>
        </div>

        <div class="xpath-header-actions">
          <button class="xpath-btn-icon" id="btnMiniBar" title="Mini-Bar Mode (Compact Floating Bar)">${ICONS.minus}</button>
          <button class="xpath-btn-icon" id="btnMaximize" title="Maximize/Restore Size">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/></svg>
          </button>
          <button class="xpath-btn-icon" id="btnClose" title="Close Panel">${ICONS.close}</button>
        </div>
      </div>

      <!-- Dock Navigation Tabs -->
      <div class="xpath-dock-tabs" id="dockTabs">
        <button class="xpath-dock-tab active" id="tabBtnInspector" data-tab="inspector">
          ${ICONS.crosshair} <span>Inspector</span>
        </button>
        <button class="xpath-dock-tab" id="tabBtnRecorder" data-tab="recorder">
          <span style="color: #f87171; font-size: 11px;">⏺</span> <span>Flow Recorder</span>
          <span class="xpath-tab-badge" id="recorderTabBadge" style="display: none; background: rgba(239, 68, 68, 0.25); color: #fca5a5; border-color: rgba(239, 68, 68, 0.4);">0</span>
        </button>
        <button class="xpath-dock-tab" id="tabBtnSaved" data-tab="saved">
          ${ICONS.star} <span>Saved Locators</span>
          <span class="xpath-tab-badge" id="savedTabBadge" style="display: none;">0</span>
        </button>
      </div>

      <!-- Tab Pane 1: Inspector Pane -->
      <div id="inspectorTabPane" style="display: flex; flex-direction: column; flex: 1; overflow: hidden;">
        <!-- Inspect Mode Banner -->
        <div class="xpath-inspect-banner">
          <div class="xpath-inspect-status">
            <div class="xpath-pulse-dot" id="pulseDot" style="display: none;"></div>
            <span id="inspectStatusText">Click "Inspect" or press Alt+Shift+X to pick an element</span>
          </div>
          <div style="display: flex; align-items: center; gap: 6px;">
            <button class="xpath-btn-inspect" id="btnToggleInspect">
              ${ICONS.crosshair} <span id="inspectBtnLabel">Inspect</span>
            </button>
            <button class="xpath-btn-inspect xpath-btn-record" id="btnDockRecord" title="Record user actions on this page to generate test code (Alt+Shift+R)">
              <span id="dockRecordIcon">⏺</span> <span id="dockRecordBtnLabel">Record Flow</span>
            </button>
            <button class="xpath-btn-inspect xpath-btn-record-assert" id="btnBannerAddAssert" title="Click to pick and insert an assertion checkpoint into the flow (toBeVisible / toHaveText)" style="display: none; background: rgba(234, 179, 8, 0.18); border: 1px solid rgba(234, 179, 8, 0.4); color: #fde047; padding: 4px 10px; font-size: 11px; font-weight: 600; border-radius: 6px; cursor: pointer; align-items: center; gap: 4px; transition: all 0.15s ease;">
              👁️ <span id="bannerAssertLabel">Assert</span>
            </button>
            <button class="xpath-btn-inspect xpath-btn-save-common" id="btnCommonSave" title="Save searched/evaluated locator or active inspected element">
              ${ICONS.star} <span id="commonSaveBtnText">Save</span>
            </button>
            <button class="xpath-btn-inspect xpath-btn-freeze" id="btnDockFreeze" title="Freeze DOM after 3s to inspect open dropdowns, popups & tooltips">
              ❄️ <span>Freeze (3s)</span>
            </button>
          </div>
        </div>

        <!-- Content Body -->
        <div class="xpath-dock-body" id="dockBody">
          <!-- Live XPath / CSS Evaluator -->
          <div class="xpath-tester-section">
            <div class="xpath-input-row">
              <span style="color: #64748b; display: flex; align-items: center;">${ICONS.search}</span>
              <input 
                type="text" 
                class="xpath-tester-input" 
                id="xpathInput" 
                placeholder="Test XPath (//button), CSS (.btn), or Playwright (page.getByRole)..." 
                spellcheck="false"
                autocomplete="off"
              />
              <button class="xpath-input-clear-btn" id="btnSearchClear" style="display: none;" title="Clear search">✕</button>
              <span class="xpath-eval-badge match-none" id="evalBadge" style="display:none;">0 matches</span>
              <div class="xpath-match-nav" id="matchNav" style="display:none;">
                <button class="xpath-btn-mini" id="btnPrevMatch" title="Previous match">${ICONS.arrowLeft}</button>
                <button class="xpath-btn-mini" id="btnNextMatch" title="Next match">${ICONS.arrowRight}</button>
              </div>
            </div>
          </div>

          <!-- Target Info & Best XPath (Default empty) -->
          <div id="inspectorContent">
            <div class="xpath-empty-state">
              <svg class="xpath-empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
                <line x1="8" y1="21" x2="16" y2="21"/>
                <line x1="12" y1="17" x2="12" y2="21"/>
              </svg>
              <p>Select any element on the page to automatically discover the best XPath, CSS selector, and test automation locator.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Tab Pane 2: Flow Recorder Pane -->
      <div id="recorderTabPane" class="xpath-recorder-view" style="display: none;">
        <div class="xpath-recorder-toolbar">
          <div class="xpath-recorder-status-row" style="display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap;">
              <span class="xpath-rec-live-badge idle" id="recToolbarLiveBadge">● IDLE</span>
              <button class="xpath-btn-inspect xpath-btn-record-assert" id="btnDockAddAssert" title="Pick element to insert dynamic wait (waitForHidden, loader gone) or assertion" style="background: rgba(234, 179, 8, 0.18); border: 1px solid rgba(234, 179, 8, 0.4); color: #fde047; padding: 2px 9px; font-size: 11px; font-weight: 600; border-radius: 5px; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;">
                👁️ Assert / Wait
              </button>
              <button class="xpath-btn-inspect xpath-btn-record-delay" id="btnDockAddDelay" title="Insert 2s fixed pause (waitForTimeout / Thread.sleep)" style="background: rgba(6, 182, 212, 0.15); border: 1px solid rgba(6, 182, 212, 0.35); color: #67e8f9; padding: 2px 8px; font-size: 11px; font-weight: 600; border-radius: 5px; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;">
                ⏱️ 2s Delay
              </button>
            </div>
            <span style="font-size: 11px; color: #94a3b8;" id="recToolbarStepCounter">0 steps recorded</span>
          </div>
          <div class="xpath-recorder-actions-row">
            <div style="display: flex; align-items: center; gap: 8px;">
              <select id="recorderFrameworkSelect" class="xpath-recorder-framework-select" title="Target Test Automation Framework">
                <option value="playwright">🎭 Playwright (JS/TS)</option>
                <option value="playwright-python">🐍 Playwright (Python)</option>
                <option value="playwright-java">☕ Playwright (Java)</option>
                <option value="selenium-java">☕ Selenium (Java)</option>
                <option value="selenium-python">🐍 Selenium (Python)</option>
                <option value="cypress">🌲 Cypress</option>
                <option value="robot">🤖 Robot Framework</option>
              </select>
            </div>
            <div class="xpath-recorder-btn-group">
              <button class="xpath-btn-export xpath-btn-export-script" id="btnExportFlowScript" title="Export complete runnable test script">
                ⚡ <span>Export Script</span>
              </button>
              <button class="xpath-btn-export" id="btnCopyFlowCode" title="Copy all action lines to clipboard">
                ${ICONS.copy} <span>Copy All</span>
              </button>
              <button class="xpath-btn-export" id="btnSaveFlowToLocators" title="Save these locators to Saved Locators collection">
                ${ICONS.star} <span>Save All</span>
              </button>
              <button class="xpath-btn-clear-saved" id="btnClearFlow" title="Clear all recorded steps">
                ${ICONS.trash} <span>Clear</span>
              </button>
            </div>
          </div>
        </div>
        <div class="xpath-recorder-timeline" id="recorderStepsTimeline">
          <!-- Populated by renderRecorderStepsList() -->
        </div>
      </div>

      <!-- Tab Pane 3: Saved Locators Pane -->
      <div id="savedTabPane" class="xpath-saved-view" style="display: none;">
        <div class="xpath-saved-toolbar">
          <div class="xpath-saved-search-row">
            ${ICONS.search}
            <input type="text" class="xpath-saved-search-input" id="savedSearchInput" placeholder="Search saved locators (tag, text, XPath, URL)..." autocomplete="off" spellcheck="false" />
          </div>
          <div class="xpath-saved-actions-bar">
            <div style="display: flex; align-items: center; gap: 8px;">
              <label class="xpath-delete-download-toggle" title="When enabled, saved locators will be automatically cleared right after you download the export file">
                <input type="checkbox" id="chkDeleteAfterDownload" />
                <span>Delete after download</span>
              </label>
              <select id="savedSortSelect" class="xpath-saved-sort-select" title="Locator Sequence Order">
                <option value="step-asc">Step Order (1st → Last)</option>
                <option value="newest-desc">Newest First (Last → 1st)</option>
              </select>
            </div>
            <div class="xpath-export-buttons-group">
              <button class="xpath-btn-export xpath-btn-export-script" id="btnExportFullScript" title="Copy / Export complete runnable Test Script">
                ⚡ <span>Script</span>
              </button>
              <button class="xpath-btn-export xpath-btn-export-json" id="btnExportJSON" title="Export saved locators as JSON file">
                ${ICONS.download} <span>JSON</span>
              </button>
              <button class="xpath-btn-export xpath-btn-export-csv" id="btnExportCSV" title="Export saved locators as CSV file">
                ${ICONS.download} <span>CSV</span>
              </button>
              <button class="xpath-btn-clear-saved" id="btnClearSaved" title="Clear all saved locators">
                ${ICONS.trash} <span>Clear</span>
              </button>
            </div>
          </div>
        </div>
        <div class="xpath-saved-list" id="savedLocatorsList">
          <!-- Populated by renderSavedLocatorsList() -->
        </div>
      </div>

      <!-- Resizer Handles -->
      <div class="xpath-resizer xpath-resizer-r" data-direction="r"></div>
      <div class="xpath-resizer xpath-resizer-b" data-direction="b"></div>
      <div class="xpath-resizer xpath-resizer-l" data-direction="l"></div>
      <div class="xpath-resizer xpath-resizer-t" data-direction="t"></div>
      <div class="xpath-resizer xpath-resizer-br" data-direction="br" title="Drag to resize">
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="rgba(255,255,255,0.4)" stroke-width="1.5">
          <line x1="8" y1="2" x2="2" y2="8" />
          <line x1="8" y1="5" x2="5" y2="8" />
          <line x1="8" y1="8" x2="8" y2="8" />
        </svg>
      </div>
      <div class="xpath-resizer xpath-resizer-bl" data-direction="bl"></div>
      <div class="xpath-resizer xpath-resizer-tr" data-direction="tr"></div>
      <div class="xpath-resizer xpath-resizer-tl" data-direction="tl"></div>
    `;
  }

  function openDock() {
    ensureInDOM();
    if (dockContainer) {
      dockContainer.style.display = 'flex';
      dockContainer.classList.remove('minimized');
    }
    if (launcherBtn) {
      launcherBtn.style.display = 'none';
    }
    updateRecorderBannerButtonState();
  }

  function closeDock() {
    stopInspect();
    if (dockContainer) {
      dockContainer.style.display = 'none';
    }
    if (launcherBtn) {
      launcherBtn.style.display = 'flex';
    }
    clearEvaluatorHighlights();
  }

  function switchDockTab(tabName) {
    activeDockTab = tabName || 'inspector';
    if (!shadowRoot) return;

    const tabBtnInspector = shadowRoot.getElementById('tabBtnInspector');
    const tabBtnRecorder = shadowRoot.getElementById('tabBtnRecorder');
    const tabBtnSaved = shadowRoot.getElementById('tabBtnSaved');
    const inspectorTabPane = shadowRoot.getElementById('inspectorTabPane');
    const recorderTabPane = shadowRoot.getElementById('recorderTabPane');
    const savedTabPane = shadowRoot.getElementById('savedTabPane');

    if (tabBtnInspector) tabBtnInspector.classList.toggle('active', activeDockTab === 'inspector');
    if (tabBtnRecorder) tabBtnRecorder.classList.toggle('active', activeDockTab === 'recorder');
    if (tabBtnSaved) tabBtnSaved.classList.toggle('active', activeDockTab === 'saved');

    if (inspectorTabPane) inspectorTabPane.style.display = activeDockTab === 'inspector' ? 'flex' : 'none';
    if (recorderTabPane) recorderTabPane.style.display = activeDockTab === 'recorder' ? 'flex' : 'none';
    if (savedTabPane) savedTabPane.style.display = activeDockTab === 'saved' ? 'flex' : 'none';

    if (activeDockTab === 'saved') {
      const savedInput = shadowRoot.getElementById('savedSearchInput');
      renderSavedLocatorsList(savedInput ? savedInput.value.trim() : '');
    } else if (activeDockTab === 'recorder') {
      renderRecorderStepsList();
    }
    updateRecorderBannerButtonState();
  }

  let lastToggleTimestamp = 0;
  function toggleDockAndInspect() {
    const now = Date.now();
    if (now - lastToggleTimestamp < 350) return;
    lastToggleTimestamp = now;

    initUI();
    if (dockContainer && dockContainer.style.display !== 'none') {
      if (isInspectMode) {
        stopInspect();
      } else {
        closeDock();
      }
    } else {
      openDock();
      startInspect();
    }
  }

  // Expose global controller helpers
  window.__SMART_XPATH_TOGGLE__ = toggleDockAndInspect;
  window.__SMART_XPATH_OPEN__ = function() {
    initUI();
    openDock();
    startInspect();
  };
  window.__SMART_XPATH_FREEZE__ = startFreezeCountdown;
  window.__SMART_XPATH_INSTANT_FREEZE__ = instantFreezeInspect;
  window.__SMART_XPATH_CLEANUP__ = function() {
    try { stopInspect(); } catch (e) {}
    try { removeFreezeHUD(); } catch (e) {}
    try { disableFreezeShield(); } catch (e) {}
    try {
      if (shadowHost && shadowHost.parentNode) {
        shadowHost.parentNode.removeChild(shadowHost);
      }
    } catch (e) {}
    try {
      if (highlightOverlay && highlightOverlay.parentNode) {
        highlightOverlay.parentNode.removeChild(highlightOverlay);
      }
    } catch (e) {}
    try {
      if (evalHighlightContainer && evalHighlightContainer.parentNode) {
        evalHighlightContainer.parentNode.removeChild(evalHighlightContainer);
      }
    } catch (e) {}
  };

  /**
   * Capture-phase Event Shield to block transient closing events (blur, focusout, mouseleave, outside mousedown)
   */
  function enableFreezeShield() {
    if (isFrozenMode) return;
    isFrozenMode = true;

    const transientEvents = [
      'blur',
      'focusout',
      'mouseleave',
      'mouseout',
      'pointerleave',
      'pointerout',
      'visibilitychange'
    ];

    transientEvents.forEach((evtName) => {
      const shieldHandler = (e) => {
        if (!isFrozenMode) return;
        e.stopImmediatePropagation();
        e.stopPropagation();
      };
      window.addEventListener(evtName, shieldHandler, { capture: true, passive: false });
      document.addEventListener(evtName, shieldHandler, { capture: true, passive: false });
      freezeShieldCleanups.push(() => {
        window.removeEventListener(evtName, shieldHandler, true);
        document.removeEventListener(evtName, shieldHandler, true);
      });
    });

    const blockDismissDown = (e) => {
      if (!isFrozenMode) return;
      const target = e.target;
      if (target === shadowHost || (shadowHost && shadowHost.contains(target))) return;
      if (freezeHudElement && (target === freezeHudElement || freezeHudElement.contains(target))) return;

      e.stopImmediatePropagation();
      e.stopPropagation();
    };
    window.addEventListener('mousedown', blockDismissDown, { capture: true, passive: false });
    window.addEventListener('pointerdown', blockDismissDown, { capture: true, passive: false });
    freezeShieldCleanups.push(() => {
      window.removeEventListener('mousedown', blockDismissDown, true);
      window.removeEventListener('pointerdown', blockDismissDown, true);
    });
  }

  function disableFreezeShield() {
    isFrozenMode = false;
    while (freezeShieldCleanups.length > 0) {
      const cleanup = freezeShieldCleanups.pop();
      try { cleanup(); } catch (e) {}
    }
  }

  function removeFreezeHUD() {
    if (freezeTimerInterval) {
      clearInterval(freezeTimerInterval);
      freezeTimerInterval = null;
    }
    if (freezeHudElement && freezeHudElement.parentElement) {
      freezeHudElement.remove();
    }
    freezeHudElement = null;
  }

  function cancelFreeze() {
    removeFreezeHUD();
    disableFreezeShield();
    stopInspect();
  }

  function showFreezeHUD(mode, secondsRemaining) {
    let hud = document.getElementById('__smart_xpath_freeze_hud__');
    if (!hud) {
      hud = document.createElement('div');
      hud.id = '__smart_xpath_freeze_hud__';
      (document.body || document.documentElement).appendChild(hud);
    }
    freezeHudElement = hud;

    if (mode === 'countdown') {
      hud.innerHTML = `
        <div style="position: fixed; top: 20px; left: 50%; transform: translateX(-50%); z-index: 2147483647; background: #0f172a; border: 1.5px solid #38bdf8; border-radius: 30px; padding: 8px 18px; color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px; font-weight: 500; display: flex; align-items: center; gap: 10px; box-shadow: 0 10px 30px rgba(0,0,0,0.6), 0 0 16px rgba(56, 189, 248, 0.4); user-select: none;">
          <span style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: #38bdf8; box-shadow: 0 0 8px #38bdf8;"></span>
          <span>⏱️ <strong>Open your dropdown now!</strong> Freezing in <strong style="color: #38bdf8; font-size: 15px;">${secondsRemaining}</strong>s...</span>
          <button id="__btn_cancel_freeze_hud__" style="background: rgba(255,255,255,0.12); border: 1px solid rgba(255,255,255,0.2); color: #94a3b8; border-radius: 6px; padding: 2px 8px; font-size: 11px; cursor: pointer; margin-left: 4px;">Cancel (Esc)</button>
        </div>
      `;
      const btnCancel = hud.querySelector('#__btn_cancel_freeze_hud__');
      if (btnCancel) {
        btnCancel.addEventListener('click', (e) => {
          e.stopPropagation();
          cancelFreeze();
        });
      }
    } else if (mode === 'frozen') {
      hud.innerHTML = `
        <div style="position: fixed; top: 20px; left: 50%; transform: translateX(-50%); z-index: 2147483647; background: #0b1329; border: 1.5px solid #60a5fa; border-radius: 30px; padding: 8px 18px; color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px; font-weight: 500; display: flex; align-items: center; gap: 10px; box-shadow: 0 10px 30px rgba(0,0,0,0.7), 0 0 20px rgba(96, 165, 250, 0.5); user-select: none;">
          <span style="font-size: 16px;">❄️</span>
          <span><strong>DOM Frozen!</strong> Click any dropdown item, option, or tooltip to inspect.</span>
          <button id="__btn_cancel_freeze_hud__" style="background: rgba(255,255,255,0.12); border: 1px solid rgba(255,255,255,0.2); color: #94a3b8; border-radius: 6px; padding: 2px 8px; font-size: 11px; cursor: pointer; margin-left: 4px;">Cancel (Esc)</button>
        </div>
      `;
      const btnCancel = hud.querySelector('#__btn_cancel_freeze_hud__');
      if (btnCancel) {
        btnCancel.addEventListener('click', (e) => {
          e.stopPropagation();
          cancelFreeze();
        });
      }
    }
  }

  function startFreezeCountdown(delaySeconds) {
    initUI();
    removeFreezeHUD();
    let remaining = typeof delaySeconds === 'number' && delaySeconds > 0 ? delaySeconds : 3;

    showFreezeHUD('countdown', remaining);

    freezeTimerInterval = setInterval(() => {
      remaining -= 1;
      if (remaining > 0) {
        showFreezeHUD('countdown', remaining);
      } else {
        clearInterval(freezeTimerInterval);
        freezeTimerInterval = null;
        // Lock DOM & Trigger Inspect
        showFreezeHUD('frozen', 0);
        enableFreezeShield();
        startInspect();
      }
    }, 1000);
  }

  function instantFreezeInspect() {
    initUI();
    removeFreezeHUD();
    showFreezeHUD('frozen', 0);
    enableFreezeShield();
    startInspect();
  }

  function toggleFreezeInspect() {
    if (isFrozenMode || freezeTimerInterval) {
      cancelFreeze();
    } else {
      instantFreezeInspect();
    }
  }

  /**
   * Set up dock & launcher event listeners
   */
  function setupDockEvents() {
    const header = shadowRoot.getElementById('dockHeader');
    const btnClose = shadowRoot.getElementById('btnClose');
    const btnMinimize = shadowRoot.getElementById('btnMinimize');
    const btnToggleInspect = shadowRoot.getElementById('btnToggleInspect');
    const xpathInput = shadowRoot.getElementById('xpathInput');
    const btnPrev = shadowRoot.getElementById('btnPrevMatch');
    const btnNext = shadowRoot.getElementById('btnNextMatch');

    // Floating Launcher Click
    if (launcherBtn) {
      launcherBtn.addEventListener('click', () => {
        openDock();
        startInspect();
      });
    }

    // Dragging (dynamic window listener attachment)
    let isDragging = false;
    let startX, startY, initialLeft, initialTop;

    function onDragMouseMove(e) {
      if (!isDragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      dockContainer.style.left = `${Math.max(10, Math.min(window.innerWidth - 300, initialLeft + dx))}px`;
      dockContainer.style.top = `${Math.max(10, Math.min(window.innerHeight - 80, initialTop + dy))}px`;
    }

    function onDragMouseUp() {
      if (isDragging) {
        isDragging = false;
        window.removeEventListener('mousemove', onDragMouseMove);
        window.removeEventListener('mouseup', onDragMouseUp);
      }
    }

    if (header) header.addEventListener('mousedown', (e) => {
      if (e.target.closest('button')) return;
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = dockContainer.getBoundingClientRect();
      initialLeft = rect.left;
      initialTop = rect.top;

      dockContainer.style.bottom = 'auto';
      dockContainer.style.right = 'auto';
      dockContainer.style.left = `${initialLeft}px`;
      dockContainer.style.top = `${initialTop}px`;
      e.preventDefault();

      window.addEventListener('mousemove', onDragMouseMove);
      window.addEventListener('mouseup', onDragMouseUp);
    });

    // Close
    if (btnClose) {
      btnClose.addEventListener('click', () => {
        closeDock();
      });
    }

    // Maximize / Restore Size
    const btnMaximize = shadowRoot.getElementById('btnMaximize');
    if (btnMaximize) {
      btnMaximize.addEventListener('click', () => {
        dockContainer.classList.toggle('maximized');
        const isMax = dockContainer.classList.contains('maximized');
        btnMaximize.title = isMax ? 'Restore Size' : 'Maximize Size';
        btnMaximize.innerHTML = isMax
          ? '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="4 14 10 14 10 20"/><polyline points="20 10 14 10 14 4"/></svg>'
          : '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/></svg>';
      });
    }

    // Minimize (if present)
    if (btnMinimize) {
      btnMinimize.addEventListener('click', () => {
        dockContainer.classList.toggle('minimized');
      });
    }

    // Mini-Bar Controller
    function applySnapMode(mode) {
      currentSnapMode = mode === 'mini' ? 'mini' : 'float';
      try { localStorage.setItem(STORAGE_KEY_SNAP_MODE, currentSnapMode); } catch (e) {}
      dockContainer.classList.remove('snapped-left', 'snapped-right', 'mini-bar');
      const sMini = shadowRoot.getElementById('btnMiniBar');
      if (sMini) sMini.classList.remove('active');
      if (currentSnapMode === 'mini') {
        dockContainer.classList.add('mini-bar');
        if (sMini) sMini.classList.add('active');
      }
    }

    const btnMiniBar = shadowRoot.getElementById('btnMiniBar');
    if (btnMiniBar) btnMiniBar.addEventListener('click', () => applySnapMode(currentSnapMode === 'mini' ? 'float' : 'mini'));
    const btnMiniCopy = shadowRoot.getElementById('btnMiniCopy');
    if (btnMiniCopy) {
      btnMiniCopy.addEventListener('click', () => {
        const code = shadowRoot.getElementById('miniCode') ? shadowRoot.getElementById('miniCode').textContent : '';
        if (code && code !== 'Pick element to inspect') copyToClipboard(code, btnMiniCopy, '✓');
      });
    }
    if (currentSnapMode === 'mini') applySnapMode('mini');

    // Restore saved dock size if available
    try {
      const savedSize = localStorage.getItem('__smart_xpath_dock_size__');
      if (savedSize) {
        const parsed = JSON.parse(savedSize);
        if (parsed.width && parsed.height) {
          dockContainer.style.width = Math.max(360, Math.min(window.innerWidth - 20, parsed.width)) + 'px';
          dockContainer.style.height = Math.max(260, Math.min(window.innerHeight - 20, parsed.height)) + 'px';
        }
      }
    } catch (e) {}

    // Resizing implementation for all 4 borders and 4 corners (dynamic window listeners)
    const resizers = shadowRoot.querySelectorAll('.xpath-resizer');
    let isResizing = false;
    let resizeDir = '';
    let startResizeX = 0, startResizeY = 0;
    let startW = 0, startH = 0;
    let startLeft = 0, startTop = 0;

    function onResizeMouseMove(e) {
      if (!isResizing) return;
      const dx = e.clientX - startResizeX;
      const dy = e.clientY - startResizeY;

      let newW = startW;
      let newH = startH;
      let newLeft = startLeft;
      let newTop = startTop;

      const minW = 360;
      const minH = 260;
      const maxW = window.innerWidth - 20;
      const maxH = window.innerHeight - 20;

      if (resizeDir.includes('r')) {
        newW = Math.max(minW, Math.min(maxW, startW + dx));
      }
      if (resizeDir.includes('b')) {
        newH = Math.max(minH, Math.min(maxH, startH + dy));
      }
      if (resizeDir.includes('l')) {
        const potentialW = startW - dx;
        if (potentialW >= minW && potentialW <= maxW) {
          newW = potentialW;
          newLeft = startLeft + dx;
        }
      }
      if (resizeDir.includes('t')) {
        const potentialH = startH - dy;
        if (potentialH >= minH && potentialH <= maxH) {
          newH = potentialH;
          newTop = startTop + dy;
        }
      }

      dockContainer.style.width = Math.round(newW) + 'px';
      dockContainer.style.height = Math.round(newH) + 'px';
      dockContainer.style.left = Math.round(newLeft) + 'px';
      dockContainer.style.top = Math.round(newTop) + 'px';
    }

    function onResizeMouseUp() {
      if (isResizing) {
        isResizing = false;
        window.removeEventListener('mousemove', onResizeMouseMove);
        window.removeEventListener('mouseup', onResizeMouseUp);
        try {
          const rect = dockContainer.getBoundingClientRect();
          localStorage.setItem('__smart_xpath_dock_size__', JSON.stringify({
            width: Math.round(rect.width),
            height: Math.round(rect.height)
          }));
        } catch (e) {}
      }
    }

    resizers.forEach((resizer) => {
      resizer.addEventListener('mousedown', (e) => {
        if (dockContainer.classList.contains('minimized')) return;
        isResizing = true;
        resizeDir = resizer.getAttribute('data-direction');
        startResizeX = e.clientX;
        startResizeY = e.clientY;

        const rect = dockContainer.getBoundingClientRect();
        startW = rect.width;
        startH = rect.height;
        startLeft = rect.left;
        startTop = rect.top;

        dockContainer.style.bottom = 'auto';
        dockContainer.style.right = 'auto';
        dockContainer.style.left = startLeft + 'px';
        dockContainer.style.top = startTop + 'px';

        dockContainer.classList.remove('maximized');
        e.preventDefault();
        e.stopPropagation();

        window.addEventListener('mousemove', onResizeMouseMove);
        window.addEventListener('mouseup', onResizeMouseUp);
      });
    });

    // Toggle Inspect Button
    if (btnToggleInspect) {
      btnToggleInspect.addEventListener('click', () => {
        if (isInspectMode) {
          stopInspect();
        } else {
          startInspect();
        }
      });
    }

    // Common Save Button in Banner
    const btnCommonSave = shadowRoot.getElementById('btnCommonSave');
    if (btnCommonSave) {
      btnCommonSave.addEventListener('click', () => {
        handleCommonSaveClick();
      });
    }

    // Freeze DOM Button (for transient dropdowns, menus, tooltips)
    const btnDockFreeze = shadowRoot.getElementById('btnDockFreeze');
    if (btnDockFreeze) {
      btnDockFreeze.addEventListener('click', () => {
        startFreezeCountdown(3);
      });
    }

    // Flow Record Button in Banner
    const btnDockRecord = shadowRoot.getElementById('btnDockRecord');
    if (btnDockRecord) {
      btnDockRecord.addEventListener('click', () => {
        toggleRecording();
      });
    }

    // Live XPath Tester Input with 120ms debounce
    let evalDebounceTimer = null;
    const btnSearchClear = shadowRoot.getElementById('btnSearchClear');
    if (btnSearchClear) {
      btnSearchClear.addEventListener('click', () => {
        if (xpathInput) xpathInput.value = '';
        btnSearchClear.style.display = 'none';
        evaluateCustomQuery('');
        updateCommonSaveButtonState();
      });
    }

    if (xpathInput) {
      xpathInput.addEventListener('input', () => {
        if (btnSearchClear) btnSearchClear.style.display = xpathInput.value.length > 0 ? 'flex' : 'none';
        clearTimeout(evalDebounceTimer);
        updateCommonSaveButtonState();
        evalDebounceTimer = setTimeout(() => {
          evaluateCustomQuery(xpathInput.value.trim());
        }, 120);
      });

      xpathInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          if (e.shiftKey) {
            cycleMatch(-1);
          } else {
            cycleMatch(1);
          }
        }
      });
    }

    if (btnPrev) btnPrev.addEventListener('click', () => cycleMatch(-1));
    if (btnNext) btnNext.addEventListener('click', () => cycleMatch(1));

    // Tab switching: Inspector vs Flow Recorder vs Saved Locators
    const tabBtnInspector = shadowRoot.getElementById('tabBtnInspector');
    const tabBtnRecorder = shadowRoot.getElementById('tabBtnRecorder');
    const tabBtnSaved = shadowRoot.getElementById('tabBtnSaved');

    if (tabBtnInspector) tabBtnInspector.addEventListener('click', () => switchDockTab('inspector'));
    if (tabBtnRecorder) tabBtnRecorder.addEventListener('click', () => switchDockTab('recorder'));
    if (tabBtnSaved) tabBtnSaved.addEventListener('click', () => switchDockTab('saved'));

    // Flow Recorder Controls
    const recorderFrameworkSelect = shadowRoot.getElementById('recorderFrameworkSelect');
    if (recorderFrameworkSelect) {
      recorderFrameworkSelect.value = currentFormat || 'playwright';
      recorderFrameworkSelect.addEventListener('change', () => {
        renderRecorderStepsList();
      });
    }

    const handleAssertTrigger = () => {
      if (!isRecordingMode) {
        startRecording();
      }
      if (isAssertPickingMode) {
        cancelAssertPicking();
      } else {
        startAssertPicking();
      }
    };

    const btnDockAddAssert = shadowRoot.getElementById('btnDockAddAssert');
    if (btnDockAddAssert) {
      btnDockAddAssert.addEventListener('click', handleAssertTrigger);
    }

    const btnDockAddDelay = shadowRoot.getElementById('btnDockAddDelay');
    if (btnDockAddDelay) {
      btnDockAddDelay.addEventListener('click', () => {
        if (!isRecordingMode) startRecording();
        insertFixedDelayStep(2000);
      });
    }

    const btnBannerAddAssert = shadowRoot.getElementById('btnBannerAddAssert');
    if (btnBannerAddAssert) {
      btnBannerAddAssert.addEventListener('click', handleAssertTrigger);
    }

    const btnExportFlowScript = shadowRoot.getElementById('btnExportFlowScript');
    if (btnExportFlowScript) btnExportFlowScript.addEventListener('click', exportFlowTestScript);

    const btnCopyFlowCode = shadowRoot.getElementById('btnCopyFlowCode');
    if (btnCopyFlowCode) btnCopyFlowCode.addEventListener('click', copyFlowFullCode);

    const btnSaveFlowToLocators = shadowRoot.getElementById('btnSaveFlowToLocators');
    if (btnSaveFlowToLocators) btnSaveFlowToLocators.addEventListener('click', saveFlowStepsToLocatorsCollection);

    const btnClearFlow = shadowRoot.getElementById('btnClearFlow');
    if (btnClearFlow) {
      btnClearFlow.addEventListener('click', () => {
        getRecordedFlowSteps((steps) => {
          if (!steps || steps.length === 0) return;
          if (confirm('Are you sure you want to clear all ' + steps.length + ' recorded flow steps?')) {
            setRecordedFlowSteps([], () => {
              renderRecorderStepsList();
              showSavedToast('Flow steps cleared');
            });
          }
        });
      });
    }

    // Saved Locators Controls
    const chkDel = shadowRoot.getElementById('chkDeleteAfterDownload');
    if (chkDel) {
      try {
        const savedPref = localStorage.getItem(STORAGE_KEY_DEL_AFTER);
        if (savedPref === 'true') chkDel.checked = true;
      } catch (e) {}
      chkDel.addEventListener('change', () => {
        try {
          localStorage.setItem(STORAGE_KEY_DEL_AFTER, String(chkDel.checked));
        } catch (e) {}
      });
    }

    const savedSearchInput = shadowRoot.getElementById('savedSearchInput');
    if (savedSearchInput) {
      savedSearchInput.addEventListener('input', () => {
        renderSavedLocatorsList(savedSearchInput.value.trim());
      });
    }

    const savedSortSelect = shadowRoot.getElementById('savedSortSelect');
    if (savedSortSelect) {
      savedSortSelect.addEventListener('change', () => {
        const sInput = shadowRoot.getElementById('savedSearchInput');
        renderSavedLocatorsList(sInput ? sInput.value.trim() : '');
      });
    }

    const btnExportFullScript = shadowRoot.getElementById('btnExportFullScript');
    if (btnExportFullScript) btnExportFullScript.addEventListener('click', exportSavedLocatorsScript);

    const btnExportJSON = shadowRoot.getElementById('btnExportJSON');
    if (btnExportJSON) btnExportJSON.addEventListener('click', exportSavedLocatorsJSON);

    const btnExportCSV = shadowRoot.getElementById('btnExportCSV');
    if (btnExportCSV) btnExportCSV.addEventListener('click', exportSavedLocatorsCSV);

    const btnClearSaved = shadowRoot.getElementById('btnClearSaved');
    if (btnClearSaved) {
      btnClearSaved.addEventListener('click', () => {
        getSavedLocators((list) => {
          if (!list || list.length === 0) return;
          if (confirm('Are you sure you want to clear all ' + list.length + ' saved locators?')) {
            setSavedLocators([], () => {
              renderSavedLocatorsList();
              updateSavedCountBadge();
              updateInspectorSaveButtonState();
              showSavedToast('All saved locators cleared');
            });
          }
        });
      });
    }

    // Initial badge & recorder button update
    updateSavedCountBadge();
    updateRecorderBannerButtonState();

    // Cross-tab reactive updates via chrome.storage.onChanged
    try {
      if (isExtensionValid() && chrome.storage && chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener((changes, areaName) => {
          try {
            if (areaName === 'local') {
              if (changes[STORAGE_KEY_SAVED]) {
                updateSavedCountBadge();
                if (activeDockTab === 'saved') {
                  const sInput = shadowRoot ? shadowRoot.getElementById('savedSearchInput') : null;
                  renderSavedLocatorsList(sInput ? sInput.value.trim() : '');
                }
                updateInspectorSaveButtonState();
              }
              if (changes[STORAGE_KEY_REC_STATE]) {
                updateRecorderBannerButtonState();
              }
              if (changes[STORAGE_KEY_FLOW_STEPS]) {
                getRecordedFlowSteps(() => {
                  updateRecorderCountBadge();
                  if (activeDockTab === 'recorder') {
                    renderRecorderStepsList();
                  }
                });
              }
            }
          } catch (listenerErr) {}
        });
      }
    } catch (e) {}
  }

  /**
   * Start element inspection
   */
  function startInspect() {
    ensureInDOM();
    isInspectMode = true;
    const btn = shadowRoot ? shadowRoot.getElementById('btnToggleInspect') : null;
    const label = shadowRoot ? shadowRoot.getElementById('inspectBtnLabel') : null;
    const dot = shadowRoot ? shadowRoot.getElementById('pulseDot') : null;
    const text = shadowRoot ? shadowRoot.getElementById('inspectStatusText') : null;

    if (btn) btn.classList.add('active');
    if (label) label.textContent = 'Cancel';
    if (dot) dot.style.display = 'block';
    if (text) text.textContent = 'Hover over any element and click to inspect';

    document.addEventListener('mouseover', onElementHover, true);
    document.addEventListener('click', onElementClick, true);
    document.addEventListener('keydown', onKeyDown, true);
  }

  /**
   * Stop element inspection
   */
  function stopInspect() {
    isInspectMode = false;
    isInspectFromDevTools = false;
    if (hoverRaf) {
      cancelAnimationFrame(hoverRaf);
      hoverRaf = null;
    }
    if (highlightOverlay) highlightOverlay.style.display = 'none';

    if (shadowRoot) {
      const btn = shadowRoot.getElementById('btnToggleInspect');
      const label = shadowRoot.getElementById('inspectBtnLabel');
      const dot = shadowRoot.getElementById('pulseDot');
      const text = shadowRoot.getElementById('inspectStatusText');

      if (btn) btn.classList.remove('active');
      if (label) label.textContent = 'Inspect';
      if (dot) dot.style.display = 'none';
      if (text) text.textContent = 'Click "Inspect" or press Alt+Shift+X to pick an element';
    }

    if (isFrozenMode) {
      disableFreezeShield();
      removeFreezeHUD();
    }

    document.removeEventListener('mouseover', onElementHover, true);
    document.removeEventListener('click', onElementClick, true);
    document.removeEventListener('keydown', onKeyDown, true);
  }

  function onKeyDown(e) {
    if (e.key === 'Escape') {
      if (isFrozenMode || freezeTimerInterval) {
        cancelFreeze();
      } else if (isInspectMode) {
        stopInspect();
      }
    }
  }

  /**
   * Hover over page elements (throttled via requestAnimationFrame)
   */
  let hoverRaf = null;
  function onElementHover(e) {
    if (!isInspectMode) return;
    let target = e.target;
    if (!target) return;
    if (target.nodeType !== 1) {
      target = target.parentElement;
    }
    if (!target || target.nodeType !== 1) return;

    if (target === shadowHost || (shadowHost && shadowHost.contains(target))) return;
    if (target === highlightOverlay || (highlightOverlay && highlightOverlay.contains(target))) return;
    if (freezeHudElement && (target === freezeHudElement || freezeHudElement.contains(target))) return;

    if (hoverRaf) cancelAnimationFrame(hoverRaf);
    hoverRaf = requestAnimationFrame(() => {
      renderHighlight(target);
    });
  }

  /**
   * Click to lock and inspect element
   */
  function onElementClick(e) {
    if (!isInspectMode) return;
    let target = e.target;
    if (!target) return;
    if (target.nodeType !== 1) {
      target = target.parentElement;
    }
    if (!target || target.nodeType !== 1) return;

    if (target === shadowHost || (shadowHost && shadowHost.contains(target))) return;
    if (target === highlightOverlay || (highlightOverlay && highlightOverlay.contains(target))) return;
    if (freezeHudElement && (target === freezeHudElement || freezeHudElement.contains(target))) return;

    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    try {
      inspectTarget(target);
    } catch (err) {
      console.error('XPath Finder inspectTarget error:', err);
    } finally {
      stopInspect();
      removeFreezeHUD();
      disableFreezeShield();
    }
  }

  /**
   * Highlight a hovered element with bounding rect
   */
  function renderHighlight(element) {
    if (!element || typeof element.getBoundingClientRect !== 'function') return;
    try {
      const rect = element.getBoundingClientRect();
      highlightOverlay.style.display = 'block';
      highlightOverlay.style.top = `${rect.top}px`;
      highlightOverlay.style.left = `${rect.left}px`;
      highlightOverlay.style.width = `${rect.width}px`;
      highlightOverlay.style.height = `${rect.height}px`;

      const tooltip = shadowRoot ? highlightOverlay.querySelector('#__smart_xpath_tooltip__') : null;
      if (tooltip) {
        let desc = getNodeShortDesc(element);
        desc += ` | ${Math.round(rect.width)}×${Math.round(rect.height)}`;
        tooltip.textContent = desc;

        if (rect.top < 30) {
          tooltip.style.top = 'auto';
          tooltip.style.bottom = '-26px';
        } else {
          tooltip.style.top = '-26px';
          tooltip.style.bottom = 'auto';
        }
      }
    } catch (e) {}
  }

  /**
   * Helper: Generate a short, readable CSS-style description for an element
   */
  function getNodeShortDesc(el) {
    if (!el || el.nodeType !== 1) return '';
    const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
    const tag = (engine && engine.safeGetTagName) ? engine.safeGetTagName(el) : (el.tagName ? String(el.tagName).toLowerCase() : '');
    const isSvg = engine && engine.isSVGElement ? engine.isSVGElement(el) : false;
    const idVal = (engine && engine.safeGetId) ? engine.safeGetId(el) : (typeof el.id === 'string' ? el.id : null);
    if (idVal && (!engine || !engine.isDynamicId(idVal))) {
      return tag + '#' + idVal;
    }
    if (isSvg) {
      const iconVal = (engine && engine.safeGetAttr) ? engine.safeGetAttr(el, 'data-icon') : (el.getAttribute ? el.getAttribute('data-icon') : null);
      if (iconVal) {
        return tag + '[data-icon="' + iconVal + '"]';
      }
    }
    const classStr = engine && engine.getElementClassString
      ? engine.getElementClassString(el)
      : (typeof el.className === 'string' ? el.className : '');
    if (classStr) {
      const firstCls = classStr.trim().split(/s+/)[0];
      if (firstCls && firstCls.length < 22) {
        return tag + '.' + firstCls;
      }
    }
    return tag;
  }

  /**
   * Helper: Get element ancestor hierarchy trail from root/body down to target
   */
  function getBreadcrumbTrail(element) {
    const trail = [];
    let curr = element;
    const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
    while (curr && curr !== document && curr.nodeType === 1 && trail.length < 30) {
      trail.unshift(curr);
      const curTag = (engine && engine.safeGetTagName) ? engine.safeGetTagName(curr) : (curr.tagName ? String(curr.tagName).toLowerCase() : '');
      if (curTag === 'body' || curTag === 'html') {
        break;
      }
      curr = (engine && engine.safeGetParent) ? engine.safeGetParent(curr) : curr.parentElement;
    }
    return trail;
  }

  /**
   * Safe XPath 1.0 attribute predicate generator
   */
  function formatXPathAttrPredicate(name, val) {
    const s = String(val || '');
    if (!s.includes("'")) {
      return "@" + name + "='" + s + "'";
    } else if (!s.includes('"')) {
      return '@' + name + '="' + s + '"';
    } else {
      const parts = s.split("'");
      const dq = String.fromCharCode(34) + "'" + String.fromCharCode(34);
      return "@" + name + "=concat('" + parts.join("', " + dq + ", '") + "')";
    }
  }

  /**
   * Safe XPath 1.0 text predicate generator
   */
  function formatXPathTextPredicate(text) {
    const cleanText = (text ? String(text) : '').replace(/s+/g, ' ').trim();
    if (!cleanText.includes("'")) {
      return "normalize-space()='" + cleanText + "'";
    } else if (!cleanText.includes('"')) {
      return 'normalize-space()="' + cleanText + '"';
    } else {
      const parts = cleanText.split("'");
      const dq = String.fromCharCode(34) + "'" + String.fromCharCode(34);
      return "normalize-space()=concat('" + parts.join("', " + dq + ", '") + "')";
    }
  }

  /**
   * Extract all relevant element attributes into toggleable matrix items
   */
  function extractElementAttributes(el) {
    if (!el || el.nodeType !== 1) return [];
    const items = [];
    const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
    const tag = (engine && engine.safeGetTagName) ? engine.safeGetTagName(el) : (el.tagName ? String(el.tagName).toLowerCase() : 'div');
    const isSvg = engine && engine.isSVGElement ? engine.isSVGElement(el) : false;

    // 1. Tag name
    items.push({
      category: 'tag',
      name: 'tag',
      value: tag,
      predicate: isSvg ? "local-name()='" + tag + "'" : '',
      isSvgTag: isSvg,
      checked: true,
      initialChecked: true,
      label: isSvg ? 'svg tag' : 'tag'
    });

    // 2. Element attributes
    try {
      const attrs = (el.attributes && typeof el.attributes.length === 'number') ? el.attributes : [];
      if (attrs) {
        for (let i = 0; i < attrs.length; i++) {
          const attr = attrs[i];
          if (!attr || !attr.name) continue;
          const name = String(attr.name).toLowerCase();
          const val = attr.value;
          if (val === null || val === undefined) continue;

          if (name === 'class') {
            const classes = (engine && engine.getElementClassList)
              ? engine.getElementClassList(el)
              : String(val).trim().split(/s+/).filter(Boolean);
            classes.forEach((c) => {
              const safeCls = String(c).replace(/['"\\]/g, '');
              items.push({
                category: 'class',
                name: 'class',
                value: c,
                predicate: "contains(concat(' ', normalize-space(@class), ' '), ' " + safeCls + " ')",
                checked: isSvg,
                initialChecked: isSvg,
                label: 'class'
              });
            });
          } else if (name === 'id') {
            const isDyn = (engine && engine.isDynamicId) ? engine.isDynamicId(val) : false;
            items.push({
              category: 'id',
              name: 'id',
              value: val,
              predicate: formatXPathAttrPredicate('id', val),
              checked: !isDyn,
              initialChecked: !isDyn,
              label: 'id'
            });
          } else {
            const isPrimary = (
              name === 'name' ||
              name === 'data-icon' ||
              name === 'data-name' ||
              name === 'data-testid' ||
              name === 'data-test' ||
              name === 'data-cy' ||
              name === 'data-qa' ||
              name === 'type' ||
              name === 'role' ||
              name === 'placeholder' ||
              name === 'aria-label' ||
              name === 'title'
            );
            items.push({
              category: 'attr',
              name: name,
              value: val,
              predicate: formatXPathAttrPredicate(name, val),
              checked: isPrimary,
              initialChecked: isPrimary,
              label: name
            });
          }
        }
      }
    } catch (e) {}

    // 3. Short text content if applicable (normalized whitespace across multi-line elements)
    const rawText = (engine && engine.safeGetText) ? engine.safeGetText(el) : ((typeof el.innerText === 'string' ? el.innerText : (typeof el.textContent === 'string' ? el.textContent : '')).trim());
    const cleanText = rawText.replace(/s+/g, ' ').trim();
    const childrenList = (engine && engine.safeGetChildren) ? engine.safeGetChildren(el) : (el.children || []);
    const childLen = childrenList.length;
    if (cleanText && cleanText.length >= 1 && cleanText.length <= 60 && childLen <= 4) {
      const cleanVal = cleanText.length > 30 ? cleanText.substring(0, 27) + '...' : cleanText;
      items.push({
        category: 'text',
        name: 'text()',
        value: cleanVal,
        predicate: formatXPathTextPredicate(cleanText),
        checked: false,
        initialChecked: false,
        label: 'text()'
      });
    }

    return items;
  }

  /**
   * Build complete serializable payload for DevTools Studio
   */
  function buildDevToolsPayload(element, existingAnalysis) {
    if (!element || element.nodeType !== 1) return null;
    const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
    let targetDoc = null;
    try {
      if (engine && typeof engine.safeGetOwnerDocument === 'function') {
        targetDoc = engine.safeGetOwnerDocument(element);
      } else if (element.ownerDocument) {
        targetDoc = element.ownerDocument;
      }
    } catch (e) {}
    if (!targetDoc && typeof document !== 'undefined') targetDoc = document;

    let analysis = existingAnalysis || null;
    if (!analysis && engine && typeof engine.analyzeElement === 'function') {
      try {
        analysis = engine.analyzeElement(element, targetDoc);
      } catch (e) {}
    }

    if (!analysis) {
      let fallbackTag = 'div';
      try {
        if (engine && typeof engine.safeGetTagName === 'function') {
          fallbackTag = engine.safeGetTagName(element) || 'div';
        } else if (element.tagName) {
          fallbackTag = element.tagName.toLowerCase();
        }
      } catch (tErr) {}
      const isSvg = (engine && typeof engine.isSVGElement === 'function') ? engine.isSVGElement(element) : false;
      const fallbackXP = isSvg ? "//*[local-name()='" + fallbackTag + "']" : ('//' + fallbackTag);
      analysis = {
        best: fallbackXP,
        bestType: isSvg ? 'svg-tag' : 'tag',
        bestLabel: isSvg ? ("SVG Namespace Tag (*[local-name()='" + fallbackTag + "'])") : ('Tag (<' + fallbackTag + '>)'),
        score: 30,
        alternatives: [{ xpath: fallbackXP, type: isSvg ? 'svg-tag' : 'tag', score: 30, label: isSvg ? ("SVG Namespace Tag (*[local-name()='" + fallbackTag + "'])") : ('Tag (<' + fallbackTag + '>)') }],
        cssSelector: fallbackTag,
        playwrightLocators: [],
        bestPlaywright: null,
        bestPlaywrightJava: null,
        bestId: null,
        relativeLocators: [],
        bestRelative: null,
        tagName: fallbackTag,
        isSvg: isSvg,
        elementInfo: { id: null, className: null, innerText: '', nodeName: fallbackTag }
      };
    }

    const matrix = extractElementAttributes(element);
    const trail = getBreadcrumbTrail(element);
    activeBreadcrumbElements = trail;
    const serializedTrail = trail.map((crumbEl, idx) => {
      let label = crumbEl.tagName.toLowerCase();
      if (crumbEl.id) label += '#' + crumbEl.id;
      else if (crumbEl.className && typeof crumbEl.className === 'string') {
        const firstCls = crumbEl.className.trim().split(/s+/)[0];
        if (firstCls) label += '.' + firstCls;
      }
      return { index: idx, label, tag: crumbEl.tagName.toLowerCase() };
    });

    return {
      analysis,
      matrix,
      breadcrumbs: serializedTrail
    };
  }

  /**
   * Analyze an element and update the dock UI
   */
  function inspectTarget(element) {
    if (!element || element.nodeType !== 1) return;
    let currentAnalysis = null;
    try {
      initUI();
      if (!isInspectFromDevTools) {
        openDock();
      }

      const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
      if (!engine || typeof engine.analyzeElement !== 'function') {
        console.warn('XPathEngine is not ready');
        return;
      }

      // Safe target document resolution
      let targetDoc = null;
      try {
        if (engine && typeof engine.safeGetOwnerDocument === 'function') {
          targetDoc = engine.safeGetOwnerDocument(element);
        } else if (element && element.ownerDocument) {
          targetDoc = element.ownerDocument;
        }
      } catch (docErr) {
        targetDoc = null;
      }
      if (!targetDoc && typeof document !== 'undefined') {
        targetDoc = document;
      }

      // Run Engine Analysis with 100% fail-safety
      try {
        currentAnalysis = engine.analyzeElement(element, targetDoc);
      } catch (e) {
        console.error('XPathEngine analysis error:', e && e.stack ? e.stack : e);
        currentAnalysis = null;
      }

      // Guaranteed infallible fallback if analysis was null or threw
      if (!currentAnalysis) {
        let fallbackTag = 'div';
        try {
          if (engine && typeof engine.safeGetTagName === 'function') {
            fallbackTag = engine.safeGetTagName(element) || 'div';
          } else if (element && typeof element.tagName === 'string') {
            fallbackTag = element.tagName.toLowerCase();
          }
        } catch (tErr) {
          fallbackTag = 'div';
        }

        const isSvg = (engine && typeof engine.isSVGElement === 'function') ? engine.isSVGElement(element) : false;
        const fallbackXP = isSvg ? "//*[local-name()='" + fallbackTag + "']" : ('//' + fallbackTag);
        const fallbackLabel = isSvg ? ("SVG Namespace Tag (*[local-name()='" + fallbackTag + "'])") : ('Tag (<' + fallbackTag + '>)');

        currentAnalysis = {
          best: fallbackXP,
          bestType: isSvg ? 'svg-tag' : 'tag',
          bestLabel: fallbackLabel,
          score: 30,
          alternatives: [{ xpath: fallbackXP, type: isSvg ? 'svg-tag' : 'tag', score: 30, label: fallbackLabel }],
          cssSelector: fallbackTag,
          playwrightLocators: [],
          bestPlaywright: null,
          bestPlaywrightJava: null,
          bestId: null,
          relativeLocators: [],
          bestRelative: null,
          tagName: fallbackTag,
          isSvg: isSvg,
          elementInfo: {
            id: null,
            className: null,
            innerText: '',
            nodeName: fallbackTag
          }
        };
      }

      // Pre-populate tester input with best XPath
      const xpathInput = shadowRoot ? shadowRoot.getElementById('xpathInput') : null;
      if (xpathInput) {
        xpathInput.value = currentAnalysis.best || '';
      }

      try {
        evaluateCustomQuery(currentAnalysis.best);
      } catch (evalErr) {
        console.warn('evaluateCustomQuery error:', evalErr);
      }

      // Render Inspector Content with DOM element reference for breadcrumbs
      try {
        if (!isInspectFromDevTools || (dockContainer && dockContainer.style.display !== 'none')) {
          renderAnalysisDetails(currentAnalysis, element);
        }
      } catch (renderErr) {
        console.error('renderAnalysisDetails error:', renderErr);
      }

      // Broadcast to DevTools Studio if open
      try {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
          const devPayload = buildDevToolsPayload(element, currentAnalysis);
          if (devPayload) {
            chrome.runtime.sendMessage({
              action: 'TESTPATH_ELEMENT_INSPECTED',
              data: devPayload
            }, () => {
              if (chrome.runtime.lastError) {}
            });
          }
        }
      } catch (broadcastErr) {}
    } catch (topErr) {
      console.error('inspectTarget error:', topErr);
    }
  }

  /**
   * Render analysis details card, breadcrumbs, & alternatives
   */
  function renderAnalysisDetails(data, element) {
    const container = shadowRoot.getElementById('inspectorContent');
    const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
    const fillVal = (data && data.fillValue && data.fillValue !== 'Enter value')
      ? data.fillValue
      : ((engine && typeof engine.getElementFillValue === 'function')
          ? engine.getElementFillValue(element)
          : (element && typeof element.value === 'string' && element.value.trim() ? element.value.trim() : 'Enter value'));
    const exactTextVal = (data && data.elementInfo && typeof data.elementInfo.innerText === 'string' && data.elementInfo.innerText.trim())
      ? data.elementInfo.innerText.trim()
      : fillVal;
    const formattedCode = engine
      ? engine.formatForFramework(data.best, currentFormat, data.bestPlaywright, data.bestPlaywrightJava, data.bestRelative, currentAction, fillVal, data.iframeInfo, exactTextVal)
      : data.best;

    // Build DOM Breadcrumbs Hierarchy
    const trail = element ? getBreadcrumbTrail(element) : [];
    activeBreadcrumbElements = trail;

    let breadcrumbsHTML = trail.map((el, i) => {
      const isCurrent = el === element;
      const desc = getNodeShortDesc(el);
      return '<button class="xpath-bc-btn ' + (isCurrent ? 'active' : '') + '" data-bc-idx="' + i + '" title="Inspect &lt;' + escapeHTML(desc) + '&gt;">' + escapeHTML(desc) + '</button>';
    }).join('<span class="xpath-bc-sep">›</span>');

    // Build Direct Children Quick-Jump
    const children = element ? (engine && typeof engine.safeGetChildren === 'function' ? engine.safeGetChildren(element).slice(0, 6) : Array.from(element.children || []).slice(0, 6)) : [];
    activeChildElements = children;
    let childrenHTML = '';
    if (children.length > 0) {
      const childPills = children.map((ch, i) => {
        const desc = getNodeShortDesc(ch);
        return '<button class="xpath-child-pill" data-ch-idx="' + i + '" title="Inspect child &lt;' + escapeHTML(desc) + '&gt;">' + escapeHTML(desc) + '</button>';
      }).join('');
      childrenHTML = '<div class="xpath-children-row"><span class="xpath-children-label">Children:</span>' + childPills + '</div>';
    }

    const breadcrumbsBarHTML = trail.length > 0 ? (
      '<div class="xpath-breadcrumbs-container">' +
        '<div class="xpath-breadcrumbs-header">' +
          '<span>DOM Breadcrumbs</span>' +
          '<span style="font-size: 9px; color: #64748b;">Hover to preview • Click to inspect</span>' +
        '</div>' +
        '<div class="xpath-breadcrumbs-track" id="breadcrumbsTrack">' +
          breadcrumbsHTML +
        '</div>' +
        childrenHTML +
      '</div>'
    ) : '';

    let alternativesHTML = '';
    data.alternatives.forEach((alt, idx) => {
      if (alt.xpath === data.best) return;
      alternativesHTML += `
        <div class="xpath-alt-item">
          <div class="xpath-alt-meta">
            <span class="xpath-alt-label">${escapeHTML(alt.label)}</span>
            <span class="xpath-alt-code" title="${escapeHTML(alt.xpath)}">${escapeHTML(alt.xpath)}</span>
          </div>
          <button class="xpath-btn-copy-small" data-copy="${escapeHTML(alt.xpath)}">Copy</button>
        </div>
      `;
    });

    if (data.cssSelector) {
      alternativesHTML += `
        <div class="xpath-alt-item">
          <div class="xpath-alt-meta">
            <span class="xpath-alt-label" style="color: #a5b4fc;">CSS Selector</span>
            <span class="xpath-alt-code" title="${escapeHTML(data.cssSelector)}">${escapeHTML(data.cssSelector)}</span>
          </div>
          <button class="xpath-btn-copy-small" data-copy="${escapeHTML(data.cssSelector)}">Copy</button>
        </div>
      `;
    }

    let playwrightCardHTML = '';
    if (data.playwrightLocators && data.playwrightLocators.length > 0) {
      const topPlaywright = data.playwrightLocators[0];
      let morePlaywrightHTML = '';
      if (data.playwrightLocators.length > 1) {
        morePlaywrightHTML = `
          <div class="xpath-playwright-more">
            ${data.playwrightLocators.slice(1).map((p) => `
              <div class="xpath-alt-item" style="background: rgba(17, 32, 25, 0.6); border-color: rgba(34, 197, 94, 0.15);">
                <div class="xpath-alt-meta">
                  <span class="xpath-alt-label" style="color: #4ade80;">${escapeHTML(p.label)}</span>
                  <span class="xpath-alt-code" title="${escapeHTML(p.code)}" style="color: #a7f3d0;">${escapeHTML(p.code)}</span>
                </div>
                <button class="xpath-btn-copy-small" data-copy="${escapeHTML(p.code)}">Copy</button>
              </div>
            `).join('')}
          </div>
        `;
      }

      playwrightCardHTML = `
        <!-- Playwright Modern Locators Card -->
        <div class="xpath-playwright-card">
          <div class="xpath-card-top">
            <span class="xpath-badge-playwright">
              ${ICONS.playwright} Playwright Modern Locator (Recommended)
            </span>
            <span class="xpath-badge-score" style="background: rgba(34, 197, 94, 0.2); color: #86efac; border-color: rgba(34, 197, 94, 0.4);">
              Score: ${topPlaywright.score}%
            </span>
          </div>
          <div class="xpath-code-display xpath-code-playwright" id="playwrightCodeDisplay">${escapeHTML(topPlaywright.code)}</div>
          <div class="xpath-actions-row">
            <span class="xpath-hint-text">User-facing &amp; auto-waiting</span>
            <div style="display: flex; gap: 6px;">
              <button class="xpath-btn-copy xpath-btn-copy-playwright" id="btnCopyPlaywright" data-copy="${escapeHTML(topPlaywright.code)}" title="Copy modern Playwright (JS/TS)">
                ${ICONS.copy} <span>Copy (JS/TS)</span>
              </button>
              <button class="xpath-btn-copy xpath-btn-copy-playwright" id="btnCopyPlaywrightJava" data-copy="${escapeHTML(topPlaywright.javaCode || topPlaywright.code)}" title="Copy modern Playwright (Java)">
                ${ICONS.copy} <span>Copy (Java)</span>
              </button>
            </div>
          </div>
          <!-- Playwright Quick Executable Actions -->
          <div class="xpath-playwright-actions-row">
            <span class="xpath-playwright-actions-label">Actions:</span>
            <button class="xpath-btn-action-mini" data-pw-action="click" title="Copy Click action: await ${escapeHTML(topPlaywright.code)}.click();">⚡ Click</button>
            <button class="xpath-btn-action-mini" data-pw-action="fill" title="Copy Fill action: await ${escapeHTML(topPlaywright.code)}.fill(&quot;${escapeHTML(fillVal)}&quot;);">✏️ Fill</button>
            <button class="xpath-btn-action-mini" data-pw-action="assertVisible" title="Copy Assert Visible action: await expect(${escapeHTML(topPlaywright.code)}).toBeVisible();">👁️ Assert</button>
            <button class="xpath-btn-action-mini" data-pw-action="waitFor" title="Copy Wait For action: await ${escapeHTML(topPlaywright.code)}.waitFor({ state: 'visible' });">⏳ Wait</button>
            <button class="xpath-btn-action-mini" data-pw-action="getText" title="Copy Get Text action: const text = await ${escapeHTML(topPlaywright.code)}.textContent();">📄 Text</button>
          </div>
          ${morePlaywrightHTML}
        </div>
      `;
    }

    let relativeCardHTML = '';
    if (data.relativeLocators && data.relativeLocators.length > 0) {
      const topRel = data.relativeLocators[0];
      let moreRelHTML = '';
      if (data.relativeLocators.length > 1) {
        moreRelHTML = `
          <div class="xpath-relative-more">
            ${data.relativeLocators.slice(1).map((r) => `
              <div class="xpath-alt-item" style="background: rgba(23, 18, 38, 0.7); border-color: rgba(168, 85, 247, 0.2);">
                <div class="xpath-alt-meta">
                  <span class="xpath-alt-label" style="color: #c084fc;">${escapeHTML(r.label)}</span>
                  <span class="xpath-alt-code" title="${escapeHTML(r.xpath)}" style="color: #e9d5ff;">${escapeHTML(r.xpath)}</span>
                </div>
                <button class="xpath-btn-copy-small" data-copy="${escapeHTML(r.xpath)}">Copy</button>
              </div>
            `).join('')}
          </div>
        `;
      }

      relativeCardHTML = `
        <!-- Relative XPath & Axes Generator Card (Collapsed Default) -->
        <div class="xpath-relative-card collapsed" id="relativeCard">
          <div class="xpath-relative-header" id="relativeHeader">
            <div class="xpath-card-top" style="margin-bottom: 0;">
              <span class="xpath-badge-relative">
                ${ICONS.relative} Relative &amp; Axes Locator
              </span>
              <span class="xpath-badge-score" style="background: rgba(168, 85, 247, 0.2); color: #d8b4fe; border-color: rgba(168, 85, 247, 0.4);">
                Score: ${topRel.score}%
              </span>
            </div>
            <span class="xpath-relative-toggle-icon">▼</span>
          </div>
          <div class="xpath-relative-body">
            <div class="xpath-code-display xpath-code-relative" id="relativeXPathDisplay">${escapeHTML(topRel.xpath)}</div>
            <div class="xpath-actions-row">
              <span class="xpath-hint-relative" title="${escapeHTML(topRel.label)}">${escapeHTML(topRel.label)}</span>
              <button class="xpath-btn-copy xpath-btn-copy-relative" id="btnCopyRelativeXPath" data-copy="${escapeHTML(topRel.xpath)}">
                ${ICONS.copy} <span>Copy Relative XPath</span>
              </button>
            </div>
            ${topRel.selenium4 ? `
              <div style="margin-top: 4px; padding-top: 6px; border-top: 1px dashed rgba(168, 85, 247, 0.25); display: flex; flex-direction: column; gap: 4px;">
                <div style="font-size: 10px; font-weight: 700; color: #d8b4fe;">Selenium 4 Relative Locator (Java)</div>
                <div class="xpath-code-display xpath-code-relative" id="relativeSelenium4Display" style="font-size: 11px;">${escapeHTML(topRel.selenium4)}</div>
                <div class="xpath-actions-row">
                  <span style="font-size: 10px; color: #c084fc; opacity: 0.85;">Spatial: toRightOf / toLeftOf / below</span>
                  <button class="xpath-btn-copy xpath-btn-copy-relative" id="btnCopySelenium4" data-copy="${escapeHTML(topRel.selenium4)}">
                    ${ICONS.copy} <span>Copy Selenium 4</span>
                  </button>
                </div>
              </div>
            ` : ''}
            ${moreRelHTML}
          </div>
        </div>
      `;
    }

    // Build Interactive Attribute Checkbox Matrix
    const matrixItems = element ? extractElementAttributes(element) : [];
    currentMatrixAttributes = matrixItems;

    let matrixGridHTML = '';
    matrixItems.forEach((item, idx) => {
      matrixGridHTML +=
        '<label class="xpath-matrix-chip" title="' + escapeHTML(item.predicate || item.value) + '">' +
          '<input type="checkbox" data-matrix-idx="' + idx + '" ' + (item.checked ? 'checked' : '') + '>' +
          '<span class="xpath-chip-tag type-' + item.category + '">' + escapeHTML(item.label) + '</span>' +
          '<span class="xpath-chip-val">' + escapeHTML(item.value) + '</span>' +
        '</label>';
    });

    const tagItem = matrixItems.find(it => it.category === 'tag');
    const isSvgElem = engine && engine.isSVGElement ? engine.isSVGElement(element) : false;
    const initialPredicates = [];
    matrixItems.forEach(it => {
      if (it.category !== 'tag' && it.checked) {
        initialPredicates.push(it.predicate);
      }
    });

    let initialCustomXPath = '';
    if (tagItem && tagItem.checked) {
      const tName = element ? element.tagName.toLowerCase() : 'svg';
      if (isSvgElem) {
        initialCustomXPath = initialPredicates.length > 0
          ? "//*[local-name()='" + tName + "' and " + initialPredicates.join(' and ') + "]"
          : "//*[local-name()='" + tName + "']";
      } else {
        initialCustomXPath = initialPredicates.length > 0
          ? '//' + tName + '[' + initialPredicates.join(' and ') + ']'
          : '//' + tName;
      }
    } else {
      initialCustomXPath = initialPredicates.length > 0
        ? '//*[' + initialPredicates.join(' and ') + ']'
        : '//*';
    }

    const matrixIconSVG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><path d="M9 4v16"/><path d="M15 4v16"/><path d="M4 9h18"/><path d="M4 15h18"/></svg>';

    let matrixCardHTML = '';
    if (matrixItems.length > 0) {
      matrixCardHTML =
        '<div class="xpath-matrix-card collapsed">' +
          '<div class="xpath-matrix-header" id="matrixHeader">' +
            '<div class="xpath-matrix-title">' +
              matrixIconSVG +
              '<span>Attribute Matrix (Custom XPath)</span>' +
              '<span class="xpath-matrix-count">' + matrixItems.length + ' attributes</span>' +
            '</div>' +
            '<span class="xpath-matrix-toggle-icon">▼</span>' +
          '</div>' +
          '<div class="xpath-matrix-body">' +
            '<div class="xpath-custom-preview">' +
              '<div class="xpath-custom-code" id="customXPathDisplay">' + escapeHTML(initialCustomXPath) + '</div>' +
              '<div class="xpath-custom-actions">' +
                '<div style="display: flex; align-items: center; gap: 6px;">' +
                  '<span class="xpath-eval-badge match-unique" id="customMatchBadge">Evaluating...</span>' +
                  '<button class="xpath-btn-small" id="btnMatrixReset" style="font-size: 10px; padding: 2px 7px;" title="Reset to suggested attributes">Reset</button>' +
                  '<button class="xpath-btn-small" id="btnMatrixClear" style="font-size: 10px; padding: 2px 7px;" title="Clear all attributes">Clear</button>' +
                '</div>' +
                '<button class="xpath-btn-copy xpath-btn-copy-small" id="btnCopyCustomXPath" data-copy="' + escapeHTML(initialCustomXPath) + '" style="background: #3b82f6; color: white;">' +
                  ICONS.copy + ' <span>Copy XPath</span>' +
                '</button>' +
              '</div>' +
            '</div>' +
            '<div class="xpath-matrix-grid">' +
              matrixGridHTML +
            '</div>' +
          '</div>' +
        '</div>';
    }

    const totalAltsCount = (data.alternatives ? data.alternatives.filter(a => a.xpath !== data.best).length : 0) + (data.cssSelector ? 1 : 0);
    let altDropdownHTML = '';
    if (totalAltsCount > 0) {
      altDropdownHTML = `
        <!-- Alternative Selectors Collapsible Dropdown (Default Closed) -->
        <div class="xpath-alt-dropdown-card collapsed" id="altDropdownCard">
          <div class="xpath-alt-dropdown-header" id="altDropdownHeader">
            <div class="xpath-alt-dropdown-title">
              ${ICONS.code}
              <span>Alternative Selectors</span>
              <span class="xpath-alt-count-badge">${totalAltsCount}</span>
            </div>
            <span class="xpath-alt-toggle-icon">▼</span>
          </div>
          <div class="xpath-alt-dropdown-body">
            <div class="xpath-alt-list">
              ${alternativesHTML}
            </div>
          </div>
        </div>
      `;
    }

    function getFrameworkDisplayName(fmt) {
      const map = {
        'raw': 'Plain XPath',
        'css': 'CSS Selector',
        'playwright': 'Playwright (Modern JS/TS)',
        'playwright-python': 'Playwright (Python)',
        'playwright-java': 'Playwright (Java)',
        'playwright-csharp': 'Playwright (C# .NET)',
        'selenium-java': 'Selenium (Java By.xpath)',
        'selenium-python': 'Selenium (Python By.XPATH)',
        'selenium-javascript': 'Selenium (JavaScript By.xpath)',
        'selenium-csharp': 'Selenium (C# By.XPath)',
        'selenium4-relative': 'Selenium 4 (RelativeLocator)',
        'cypress': 'Cypress (cy.xpath)',
        'robot': 'Robot Framework',
        'puppeteer': 'Puppeteer ($x)'
      };
      return map[fmt] || fmt;
    }

    function getFrameworkShortLabel(fmt) {
      const map = {
        'playwright': 'Playwright (JS) ▾',
        'playwright-python': 'Playwright (Py) ▾',
        'playwright-java': 'Playwright (Java) ▾',
        'playwright-csharp': 'Playwright (C#) ▾',
        'selenium-java': 'Selenium (Java) ▾',
        'selenium-python': 'Selenium (Py) ▾',
        'selenium-javascript': 'Selenium (JS) ▾',
        'selenium-csharp': 'Selenium (C#) ▾',
        'selenium4-relative': 'Selenium 4 ▾',
        'cypress': 'Cypress ▾',
        'robot': 'Robot ▾',
        'puppeteer': 'Puppeteer ▾'
      };
      return map[fmt] || (fmt + ' ▾');
    }

    function getAssertShortLabel(act) {
      switch (act) {
        case 'assertText': return '🔤 Text ▾';
        case 'assertChecked': return '☑️ Checked ▾';
        case 'assertEnabled': return '⚡ Enabled ▾';
        case 'assertVisible':
        default:
          return ['assertVisible', 'assertText', 'assertChecked', 'assertEnabled'].includes(act) ? '👁️ Visible ▾' : '👁️ Assert ▾';
      }
    }

    function getComputedActiveCode(fmt, act) {
      if (fmt === 'css') {
        const css = data.cssSelector || data.best;
        if (act === 'click') return 'await page.locator(\'' + css.replace(/'/g, "\\'") + '\').click();';
        if (act === 'fill') return 'await page.locator(\'' + css.replace(/'/g, "\\'") + '\').fill("' + fillVal.replace(/"/g, '\\"') + '");';
        if (act === 'assertVisible') return 'await expect(page.locator(\'' + css.replace(/'/g, "\\'") + '\')).toBeVisible();';
        if (act === 'assertText') return 'await expect(page.locator(\'' + css.replace(/'/g, "\\'") + '\')).toHaveText("' + (exactTextVal || fillVal).replace(/"/g, '\\"') + '");';
        if (act === 'assertChecked') return 'await expect(page.locator(\'' + css.replace(/'/g, "\\'") + '\')).toBeChecked();';
        if (act === 'assertEnabled') return 'await expect(page.locator(\'' + css.replace(/'/g, "\\'") + '\')).toBeEnabled();';
        if (act === 'waitFor') return 'await page.locator(\'' + css.replace(/'/g, "\\'") + '\').waitFor();';
        if (act === 'getText') return 'const text = await page.locator(\'' + css.replace(/'/g, "\\'") + '\').textContent();';
        return css;
      }
      return engine
        ? engine.formatForFramework(data.best, fmt, data.bestPlaywright, data.bestPlaywrightJava, data.bestRelative, act, fillVal, data.iframeInfo, exactTextVal)
        : data.best;
    }

    const isPwFormat = ['playwright', 'playwright-python', 'playwright-java', 'playwright-csharp'].includes(currentFormat);
    const isSelFormat = ['selenium-java', 'selenium-python', 'selenium-javascript', 'selenium-csharp', 'selenium4-relative'].includes(currentFormat);
    const isMoreFormat = ['cypress', 'robot', 'puppeteer'].includes(currentFormat);
    const isAssertAction = ['assertVisible', 'assertText', 'assertChecked', 'assertEnabled'].includes(currentAction);

    const heroCardHTML = `
      <!-- Unified Hero Locator Card -->
      <div class="xpath-hero-card">
        <div class="xpath-hero-header">
          <div class="xpath-hero-target-info">
            <span class="xpath-element-tag">&lt;${escapeHTML(data.tagName)}&gt;</span>
            ${data.iframeInfo && data.iframeInfo.isIframe ? `
              <span class="xpath-hero-iframe-badge" title="Element lives inside iframe: ${escapeHTML(data.iframeInfo.displayName || 'iframe')}">
                🖼️ ${escapeHTML(data.iframeInfo.displayName || 'In Frame')}
              </span>
            ` : ''}
            <span class="xpath-element-desc" title="${escapeHTML(data.elementInfo.innerText || '')}">
              ${escapeHTML(data.elementInfo.innerText || 'No direct text')}
            </span>
          </div>
          <span class="xpath-hero-score-badge">Score: ${data.score}%</span>
        </div>

        <!-- Segmented Framework & Language Dropdown Switcher -->
        <div class="xpath-framework-segmented" id="frameworkSegmented">
          <!-- 1. Plain XPath Direct Pill -->
          <button class="xpath-framework-pill ${currentFormat === 'raw' ? 'active is-xpath' : ''}" data-fmt="raw" type="button" title="Plain standard XPath">
            ${ICONS.crosshair} Plain XPath
          </button>

          <!-- 2. Playwright Multi-Language Dropdown -->
          <div class="xpath-dropdown-wrapper">
            <button class="xpath-framework-pill ${isPwFormat ? 'active is-playwright' : ''}" id="btnFrameworkPlaywright" type="button">
              ${ICONS.playwright} <span id="labelPlaywrightBtn">${isPwFormat ? getFrameworkShortLabel(currentFormat) : 'Playwright ▾'}</span>
            </button>
            <div class="xpath-dropdown-menu" id="dropdownPlaywright">
              <div class="xpath-dropdown-header">Playwright Languages</div>
              <button class="xpath-dropdown-item is-pw ${currentFormat === 'playwright' ? 'active' : ''}" data-fmt="playwright" type="button">
                <span>🟡 JavaScript / TypeScript</span>
                ${currentFormat === 'playwright' ? '<span class="opt-check">✓</span>' : ''}
              </button>
              <button class="xpath-dropdown-item is-pw ${currentFormat === 'playwright-python' ? 'active' : ''}" data-fmt="playwright-python" type="button">
                <span>🐍 Python</span>
                ${currentFormat === 'playwright-python' ? '<span class="opt-check">✓</span>' : ''}
              </button>
              <button class="xpath-dropdown-item is-pw ${currentFormat === 'playwright-java' ? 'active' : ''}" data-fmt="playwright-java" type="button">
                <span>☕ Java</span>
                ${currentFormat === 'playwright-java' ? '<span class="opt-check">✓</span>' : ''}
              </button>
              <button class="xpath-dropdown-item is-pw ${currentFormat === 'playwright-csharp' ? 'active' : ''}" data-fmt="playwright-csharp" type="button">
                <span>🔷 C# (.NET)</span>
                ${currentFormat === 'playwright-csharp' ? '<span class="opt-check">✓</span>' : ''}
              </button>
            </div>
          </div>

          <!-- 3. Selenium Multi-Language Dropdown -->
          <div class="xpath-dropdown-wrapper">
            <button class="xpath-framework-pill ${isSelFormat ? 'active is-selenium' : ''}" id="btnFrameworkSelenium" type="button">
              ⚡ <span id="labelSeleniumBtn">${isSelFormat ? getFrameworkShortLabel(currentFormat) : 'Selenium ▾'}</span>
            </button>
            <div class="xpath-dropdown-menu" id="dropdownSelenium">
              <div class="xpath-dropdown-header">Selenium Languages</div>
              <button class="xpath-dropdown-item is-sel ${currentFormat === 'selenium-java' ? 'active' : ''}" data-fmt="selenium-java" type="button">
                <span>☕ Java (By.xpath)</span>
                ${currentFormat === 'selenium-java' ? '<span class="opt-check">✓</span>' : ''}
              </button>
              <button class="xpath-dropdown-item is-sel ${currentFormat === 'selenium-python' ? 'active' : ''}" data-fmt="selenium-python" type="button">
                <span>🐍 Python (By.XPATH)</span>
                ${currentFormat === 'selenium-python' ? '<span class="opt-check">✓</span>' : ''}
              </button>
              <button class="xpath-dropdown-item is-sel ${currentFormat === 'selenium-javascript' ? 'active' : ''}" data-fmt="selenium-javascript" type="button">
                <span>🟡 JavaScript (By.xpath)</span>
                ${currentFormat === 'selenium-javascript' ? '<span class="opt-check">✓</span>' : ''}
              </button>
              <button class="xpath-dropdown-item is-sel ${currentFormat === 'selenium-csharp' ? 'active' : ''}" data-fmt="selenium-csharp" type="button">
                <span>🔷 C# (By.XPath)</span>
                ${currentFormat === 'selenium-csharp' ? '<span class="opt-check">✓</span>' : ''}
              </button>
              <button class="xpath-dropdown-item is-sel ${currentFormat === 'selenium4-relative' ? 'active' : ''}" data-fmt="selenium4-relative" type="button">
                <span>🟣 Selenium 4 Relative (Java)</span>
                ${currentFormat === 'selenium4-relative' ? '<span class="opt-check">✓</span>' : ''}
              </button>
            </div>
          </div>

          <!-- 4. CSS Direct Pill -->
          <button class="xpath-framework-pill ${currentFormat === 'css' ? 'active is-css' : ''}" data-fmt="css" type="button" title="CSS Selector">
            🌐 CSS
          </button>

          <!-- 5. More Frameworks Dropdown -->
          <div class="xpath-dropdown-wrapper">
            <button class="xpath-framework-pill ${isMoreFormat ? 'active' : ''}" id="btnFrameworkMore" type="button">
              <span id="labelMoreBtn">${isMoreFormat ? getFrameworkShortLabel(currentFormat) : 'More ▾'}</span>
            </button>
            <div class="xpath-dropdown-menu align-right" id="dropdownMore">
              <div class="xpath-dropdown-header">Other Frameworks</div>
              <button class="xpath-dropdown-item ${currentFormat === 'cypress' ? 'active' : ''}" data-fmt="cypress" type="button">
                <span>🌲 Cypress (cy.xpath)</span>
                ${currentFormat === 'cypress' ? '<span class="opt-check">✓</span>' : ''}
              </button>
              <button class="xpath-dropdown-item ${currentFormat === 'robot' ? 'active' : ''}" data-fmt="robot" type="button">
                <span>🤖 Robot Framework</span>
                ${currentFormat === 'robot' ? '<span class="opt-check">✓</span>' : ''}
              </button>
              <button class="xpath-dropdown-item ${currentFormat === 'puppeteer' ? 'active' : ''}" data-fmt="puppeteer" type="button">
                <span>🎭 Puppeteer ($x)</span>
                ${currentFormat === 'puppeteer' ? '<span class="opt-check">✓</span>' : ''}
              </button>
            </div>
          </div>
        </div>

        <!-- Unified Action Code Generator Toolbar -->
        <div class="xpath-action-toolbar" id="actionToolbar">
          <button class="xpath-action-btn ${currentAction === 'locator' ? 'active' : ''}" data-action="locator" type="button" title="Locator Only">🎯 Locator</button>
          <button class="xpath-action-btn ${currentAction === 'click' ? 'active' : ''}" data-action="click" type="button" title="Click Action">⚡ Click</button>
          <button class="xpath-action-btn ${currentAction === 'fill' ? 'active' : ''}" data-action="fill" type="button" title="Fill Action">✏️ Fill</button>
          
          <!-- Smart Assertion Suite Dropdown -->
          <div class="xpath-action-dropdown-wrapper">
            <button class="xpath-action-btn ${isAssertAction ? 'active' : ''}" id="btnActionAssert" type="button" title="Smart Assertions Suite (Click to choose assertion condition)">
              <span id="labelActionAssert">${getAssertShortLabel(currentAction)}</span>
            </button>
            <div class="xpath-action-dropdown-menu" id="dropdownAssert">
              <div class="xpath-dropdown-header">Smart Assertions</div>
              <button class="xpath-action-dropdown-item ${currentAction === 'assertVisible' ? 'active' : ''}" data-action="assertVisible" type="button">
                <span>👁️ Visible (toBeVisible)</span>
                ${currentAction === 'assertVisible' ? '<span class="opt-check">✓</span>' : ''}
              </button>
              <button class="xpath-action-dropdown-item ${currentAction === 'assertText' ? 'active' : ''}" data-action="assertText" type="button" title="Exact text assertion: ${escapeHTML(exactTextVal)}">
                <span>🔤 Exact Text (toHaveText)</span>
                ${currentAction === 'assertText' ? '<span class="opt-check">✓</span>' : ''}
              </button>
              <button class="xpath-action-dropdown-item ${currentAction === 'assertChecked' ? 'active' : ''}" data-action="assertChecked" type="button">
                <span>☑️ Checked (toBeChecked)</span>
                ${currentAction === 'assertChecked' ? '<span class="opt-check">✓</span>' : ''}
              </button>
              <button class="xpath-action-dropdown-item ${currentAction === 'assertEnabled' ? 'active' : ''}" data-action="assertEnabled" type="button">
                <span>⚡ Enabled (toBeEnabled)</span>
                ${currentAction === 'assertEnabled' ? '<span class="opt-check">✓</span>' : ''}
              </button>
            </div>
          </div>

          <button class="xpath-action-btn ${currentAction === 'waitFor' ? 'active' : ''}" data-action="waitFor" type="button" title="Wait For Action">⏳ Wait</button>
          <button class="xpath-action-btn ${currentAction === 'getText' ? 'active' : ''}" data-action="getText" type="button" title="Get Text Action">📄 Text</button>
        </div>

        <!-- Code Snippet Display -->
        <div class="xpath-hero-code-wrap">
          <div class="xpath-hero-code ${isPwFormat ? 'is-playwright' : (currentFormat === 'raw' ? 'is-xpath' : '')}" id="heroCodeDisplay">${escapeHTML(formattedCode)}</div>
          <div class="xpath-hero-code-footer">
            <span class="xpath-hero-framework-tag" id="heroFrameworkTag">${getFrameworkDisplayName(currentFormat)}</span>
            <button class="xpath-hero-btn-copy" id="btnCopyHero" title="Copy code snippet">
              ${ICONS.copy} <span>Copy Code</span>
            </button>
          </div>
        </div>
      </div>
    `;

    container.innerHTML = `
      ${breadcrumbsBarHTML}
      ${heroCardHTML}
      ${matrixCardHTML}
      ${relativeCardHTML}
      ${altDropdownHTML}
    `;

    // Update mini-bar in header
    const miniTag = shadowRoot.getElementById('miniTag');
    const miniCode = shadowRoot.getElementById('miniCode');
    if (miniTag) miniTag.textContent = `<${escapeHTML(data.tagName)}>`;
    if (miniCode) miniCode.textContent = formattedCode;

    // Unified Framework Selection Handler
    function selectFramework(fmt) {
      if (!fmt) return;
      currentFormat = fmt;
      try {
        localStorage.setItem(STORAGE_KEY_PREF_FRAMEWORK, fmt);
      } catch (e) {}
      try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ [STORAGE_KEY_PREF_FRAMEWORK]: fmt });
        }
      } catch (e) {}

      const allPills = shadowRoot.querySelectorAll('#frameworkSegmented .xpath-framework-pill');
      allPills.forEach((p) => p.classList.remove('active', 'is-playwright', 'is-selenium', 'is-xpath', 'is-css'));

      const isPw = ['playwright', 'playwright-python', 'playwright-java', 'playwright-csharp'].includes(fmt);
      const isSel = ['selenium-java', 'selenium-python', 'selenium-javascript', 'selenium-csharp', 'selenium4-relative'].includes(fmt);
      const isMore = ['cypress', 'robot', 'puppeteer'].includes(fmt);

      const btnPw = shadowRoot.getElementById('btnFrameworkPlaywright');
      const btnSel = shadowRoot.getElementById('btnFrameworkSelenium');
      const btnMore = shadowRoot.getElementById('btnFrameworkMore');
      const labelPw = shadowRoot.getElementById('labelPlaywrightBtn');
      const labelSel = shadowRoot.getElementById('labelSeleniumBtn');
      const labelMore = shadowRoot.getElementById('labelMoreBtn');

      if (labelPw) labelPw.textContent = isPw ? getFrameworkShortLabel(fmt) : 'Playwright ▾';
      if (labelSel) labelSel.textContent = isSel ? getFrameworkShortLabel(fmt) : 'Selenium ▾';
      if (labelMore) labelMore.textContent = isMore ? getFrameworkShortLabel(fmt) : 'More ▾';

      if (isPw && btnPw) btnPw.classList.add('active', 'is-playwright');
      if (isSel && btnSel) btnSel.classList.add('active', 'is-selenium');
      if (isMore && btnMore) btnMore.classList.add('active');

      if (fmt === 'raw') {
        const pRaw = shadowRoot.querySelector('#frameworkSegmented .xpath-framework-pill[data-fmt="raw"]');
        if (pRaw) pRaw.classList.add('active', 'is-xpath');
      } else if (fmt === 'css') {
        const pCss = shadowRoot.querySelector('#frameworkSegmented .xpath-framework-pill[data-fmt="css"]');
        if (pCss) pCss.classList.add('active', 'is-css');
      }

      // Update checkmarks in all dropdown menus
      const allItems = shadowRoot.querySelectorAll('#frameworkSegmented .xpath-dropdown-item');
      allItems.forEach((it) => {
        const f = it.getAttribute('data-fmt');
        const isActive = f === fmt;
        it.classList.toggle('active', isActive);
        let chk = it.querySelector('.opt-check');
        if (isActive) {
          if (!chk) {
            const span = document.createElement('span');
            span.className = 'opt-check';
            span.textContent = '✓';
            it.appendChild(span);
          }
        } else if (chk) {
          chk.remove();
        }
      });

      // Close all open menus
      closeAllFrameworkDropdowns();

      // Recalculate and update hero card display
      const newCode = getComputedActiveCode(currentFormat, currentAction);
      const codeEl = shadowRoot.getElementById('heroCodeDisplay');
      if (codeEl) {
        codeEl.textContent = newCode;
        codeEl.classList.remove('is-playwright', 'is-xpath');
        if (isPw) codeEl.classList.add('is-playwright');
        if (fmt === 'raw') codeEl.classList.add('is-xpath');
      }
      const tagEl = shadowRoot.getElementById('heroFrameworkTag');
      if (tagEl) tagEl.textContent = getFrameworkDisplayName(currentFormat);
      if (miniCode) miniCode.textContent = newCode;
      updateCommonSaveButtonState();
    }

    currentSelectFrameworkFn = selectFramework;

    function closeAllActionDropdowns() {
      const menus = shadowRoot.querySelectorAll('#actionToolbar .xpath-action-dropdown-menu');
      menus.forEach((m) => {
        m.classList.remove('open');
        m.style.display = 'none';
      });
    }

    function closeAllFrameworkDropdowns() {
      const menus = shadowRoot.querySelectorAll('#frameworkSegmented .xpath-dropdown-menu');
      menus.forEach((m) => {
        m.classList.remove('open');
        m.style.display = 'none';
      });
    }

    function setupDropdown(btnId, menuId) {
      const btn = shadowRoot.getElementById(btnId);
      const menu = shadowRoot.getElementById(menuId);
      if (btn && menu) {
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          const wasOpen = menu.classList.contains('open') || menu.style.display === 'flex';
          closeAllFrameworkDropdowns();
          closeAllActionDropdowns();
          if (!wasOpen) {
            menu.classList.add('open');
            menu.style.display = 'flex';
          }
        });
      }
    }

    setupDropdown('btnFrameworkPlaywright', 'dropdownPlaywright');
    setupDropdown('btnFrameworkSelenium', 'dropdownSelenium');
    setupDropdown('btnFrameworkMore', 'dropdownMore');

    // Smart Assertions Suite Dropdown Setup
    const btnAssert = shadowRoot.getElementById('btnActionAssert');
    const menuAssert = shadowRoot.getElementById('dropdownAssert');
    if (btnAssert && menuAssert) {
      btnAssert.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const wasOpen = menuAssert.classList.contains('open') || menuAssert.style.display === 'flex';
        closeAllFrameworkDropdowns();
        closeAllActionDropdowns();
        if (!wasOpen) {
          menuAssert.classList.add('open');
          menuAssert.style.display = 'flex';
        }
      });
    }

    const assertItems = shadowRoot.querySelectorAll('#dropdownAssert .xpath-action-dropdown-item');
    assertItems.forEach((item) => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const act = item.getAttribute('data-action') || 'assertVisible';
        currentAction = act;

        // Update active class on toolbar buttons
        const actionBtns = shadowRoot.querySelectorAll('#actionToolbar .xpath-action-btn');
        actionBtns.forEach((b) => b.classList.remove('active'));
        if (btnAssert) btnAssert.classList.add('active');

        // Update label on assert button
        const lbl = shadowRoot.getElementById('labelActionAssert');
        if (lbl) lbl.textContent = getAssertShortLabel(act);

        // Update checkmarks in assertion dropdown
        assertItems.forEach((ai) => {
          const isSelected = ai.getAttribute('data-action') === act;
          ai.classList.toggle('active', isSelected);
          let chk = ai.querySelector('.opt-check');
          if (isSelected) {
            if (!chk) {
              const sp = document.createElement('span');
              sp.className = 'opt-check';
              sp.textContent = '✓';
              ai.appendChild(sp);
            }
          } else if (chk) {
            chk.remove();
          }
        });

        closeAllActionDropdowns();

        const newCode = getComputedActiveCode(currentFormat, currentAction);
        const codeEl = shadowRoot.getElementById('heroCodeDisplay');
        if (codeEl) codeEl.textContent = newCode;
        if (miniCode) miniCode.textContent = newCode;
        copyToClipboard(newCode, btnAssert, 'Copied!');
        updateCommonSaveButtonState();
      });
    });

    const handleOutsideDropdownClick = (e) => {
      const path = (e.composedPath && typeof e.composedPath === 'function') ? e.composedPath() : [];
      const clickedInsideFramework = path.some((el) => el && el.classList && el.classList.contains('xpath-dropdown-wrapper'));
      if (!clickedInsideFramework) {
        closeAllFrameworkDropdowns();
      }
      const clickedInsideAction = path.some((el) => el && el.classList && el.classList.contains('xpath-action-dropdown-wrapper'));
      if (!clickedInsideAction) {
        closeAllActionDropdowns();
      }
    };
    shadowRoot.addEventListener('click', handleOutsideDropdownClick);
    window.addEventListener('click', handleOutsideDropdownClick);

    const directPills = shadowRoot.querySelectorAll('#frameworkSegmented .xpath-framework-pill[data-fmt]');
    directPills.forEach((p) => {
      p.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const fmt = p.getAttribute('data-fmt');
        if (fmt) {
          selectFramework(fmt);
        }
      });
    });

    const dropItems = shadowRoot.querySelectorAll('#frameworkSegmented .xpath-dropdown-item[data-fmt]');
    dropItems.forEach((it) => {
      it.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const fmt = it.getAttribute('data-fmt');
        if (fmt) {
          selectFramework(fmt);
        }
      });
    });

    // Unified Action Toolbar Direct Buttons
    const actionBtns = shadowRoot.querySelectorAll('#actionToolbar .xpath-action-btn[data-action]');
    actionBtns.forEach((abtn) => {
      abtn.addEventListener('click', () => {
        closeAllActionDropdowns();
        shadowRoot.querySelectorAll('#actionToolbar .xpath-action-btn').forEach((b) => b.classList.remove('active'));
        abtn.classList.add('active');
        currentAction = abtn.getAttribute('data-action');
        const newCode = getComputedActiveCode(currentFormat, currentAction);
        const codeEl = shadowRoot.getElementById('heroCodeDisplay');
        if (codeEl) codeEl.textContent = newCode;
        if (miniCode) miniCode.textContent = newCode;
        copyToClipboard(newCode, abtn, 'Copied!');
        updateCommonSaveButtonState();
      });
    });

    // Copy Hero Code button
    const btnCopyHero = shadowRoot.getElementById('btnCopyHero');
    if (btnCopyHero) {
      btnCopyHero.addEventListener('click', () => {
        const code = shadowRoot.getElementById('heroCodeDisplay').textContent;
        copyToClipboard(code, btnCopyHero, '✓ Copied!');
      });
    }

    const btnCopyRelativeXPath = shadowRoot.getElementById('btnCopyRelativeXPath');
    if (btnCopyRelativeXPath) {
      btnCopyRelativeXPath.addEventListener('click', () => {
        const text = btnCopyRelativeXPath.getAttribute('data-copy');
        copyToClipboard(text, btnCopyRelativeXPath, 'Copied!');
      });
    }

    const btnCopySelenium4 = shadowRoot.getElementById('btnCopySelenium4');
    if (btnCopySelenium4) {
      btnCopySelenium4.addEventListener('click', () => {
        const text = btnCopySelenium4.getAttribute('data-copy');
        copyToClipboard(text, btnCopySelenium4, 'Copied!');
      });
    }

    const btnSave = shadowRoot.getElementById('btnSaveLocator');
    const saveBtnText = shadowRoot.getElementById('saveLocatorBtnText');
    if (btnSave && data && data.best) {
      isLocatorSaved(data.best, (saved) => {
        if (saved) {
          btnSave.classList.add('is-saved');
          if (saveBtnText) saveBtnText.textContent = 'Saved!';
          btnSave.title = 'Saved! Click to remove';
        } else {
          btnSave.classList.remove('is-saved');
          if (saveBtnText) saveBtnText.textContent = 'Save';
          btnSave.title = 'Save this locator across tabs';
        }
      });

      btnSave.addEventListener('click', () => {
        toggleSaveCurrentLocator(data, element, btnSave, saveBtnText);
      });
    }

    const smallButtons = shadowRoot.querySelectorAll('.xpath-alt-item .xpath-btn-copy-small');
    smallButtons.forEach((btn) => {
      btn.addEventListener('click', () => {
        const text = btn.getAttribute('data-copy');
        if (text) {
          copyToClipboard(text, btn, 'Copied!');
        }
      });
    });

    // Toggle Collapse for Attribute Matrix
    const mHeader = shadowRoot.getElementById('matrixHeader');
    if (mHeader) {
      mHeader.addEventListener('click', () => {
        const card = mHeader.closest('.xpath-matrix-card');
        if (card) card.classList.toggle('collapsed');
      });
    }

    // Toggle Collapse for Relative & Axes Locator
    const relHeader = shadowRoot.getElementById('relativeHeader');
    if (relHeader) {
      relHeader.addEventListener('click', () => {
        const card = relHeader.closest('.xpath-relative-card');
        if (card) card.classList.toggle('collapsed');
      });
    }

    // Toggle Collapse for Alternative Selectors Dropdown
    const altHeader = shadowRoot.getElementById('altDropdownHeader');
    if (altHeader) {
      altHeader.addEventListener('click', () => {
        const card = altHeader.closest('.xpath-alt-dropdown-card');
        if (card) card.classList.toggle('collapsed');
      });
    }

    // Function to calculate custom XPath, update DOM, and evaluate
    function updateCustomXPathAndEvaluate() {
      if (!currentMatrixAttributes || currentMatrixAttributes.length === 0) return;
      const tItem = currentMatrixAttributes.find(it => it.category === 'tag');
      const tChecked = tItem ? tItem.checked : true;
      const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
      const isSvgElem = engine && engine.isSVGElement ? engine.isSVGElement(element) : false;
      const tName = element ? element.tagName.toLowerCase() : '*';

      const selPredicates = [];
      currentMatrixAttributes.forEach((item) => {
        if (item.category !== 'tag' && item.checked) {
          selPredicates.push(item.predicate);
        }
      });

      let customXPath = '';
      if (tChecked) {
        if (isSvgElem) {
          customXPath = selPredicates.length > 0
            ? "//*[local-name()='" + tName + "' and " + selPredicates.join(' and ') + "]"
            : "//*[local-name()='" + tName + "']";
        } else {
          customXPath = selPredicates.length > 0
            ? '//' + tName + '[' + selPredicates.join(' and ') + ']'
            : '//' + tName;
        }
      } else {
        customXPath = selPredicates.length > 0
          ? '//*[' + selPredicates.join(' and ') + ']'
          : '//*';
      }

      const codeEl = shadowRoot.getElementById('customXPathDisplay');
      if (codeEl) codeEl.textContent = customXPath;

      const btnCopyCustom = shadowRoot.getElementById('btnCopyCustomXPath');
      if (btnCopyCustom) btnCopyCustom.setAttribute('data-copy', customXPath);

      const badge = shadowRoot.getElementById('customMatchBadge');
      try {
        const targetDoc = (engine && engine.safeGetOwnerDocument) ? engine.safeGetOwnerDocument(element) : document;
        const matches = engine ? engine.queryXPath(customXPath, targetDoc) : [];
        if (badge) {
          badge.style.display = 'inline-block';
          if (matches.length === 1) {
            badge.className = 'xpath-eval-badge match-unique';
            badge.textContent = '1 match (Unique)';
          } else if (matches.length > 1) {
            badge.className = 'xpath-eval-badge match-multiple';
            badge.textContent = matches.length + ' matches';
          } else {
            badge.className = 'xpath-eval-badge match-none';
            badge.textContent = '0 matches';
          }
        }
        highlightEvaluatedElements(matches, 0);
      } catch (err) {
        if (badge) {
          badge.style.display = 'inline-block';
          badge.className = 'xpath-eval-badge match-none';
          badge.textContent = 'Syntax error';
        }
      }
    }

    // Bind matrix checkboxes
    const matrixCheckboxes = shadowRoot.querySelectorAll('.xpath-matrix-chip input[type="checkbox"]');
    matrixCheckboxes.forEach((cb) => {
      cb.addEventListener('change', () => {
        const idx = parseInt(cb.getAttribute('data-matrix-idx'), 10);
        if (currentMatrixAttributes[idx]) {
          currentMatrixAttributes[idx].checked = cb.checked;
        }
        updateCustomXPathAndEvaluate();
      });
    });

    // Reset button
    const btnMatrixReset = shadowRoot.getElementById('btnMatrixReset');
    if (btnMatrixReset) {
      btnMatrixReset.addEventListener('click', (e) => {
        e.stopPropagation();
        currentMatrixAttributes.forEach((item, idx) => {
          item.checked = item.initialChecked;
          const cb = shadowRoot.querySelector('.xpath-matrix-chip input[data-matrix-idx="' + idx + '"]');
          if (cb) cb.checked = item.initialChecked;
        });
        updateCustomXPathAndEvaluate();
      });
    }

    // Clear button
    const btnMatrixClear = shadowRoot.getElementById('btnMatrixClear');
    if (btnMatrixClear) {
      btnMatrixClear.addEventListener('click', (e) => {
        e.stopPropagation();
        currentMatrixAttributes.forEach((item, idx) => {
          const isTag = item.category === 'tag';
          item.checked = isTag;
          const cb = shadowRoot.querySelector('.xpath-matrix-chip input[data-matrix-idx="' + idx + '"]');
          if (cb) cb.checked = isTag;
        });
        updateCustomXPathAndEvaluate();
      });
    }

    // Copy custom XPath button
    const btnCopyCustom = shadowRoot.getElementById('btnCopyCustomXPath');
    if (btnCopyCustom) {
      btnCopyCustom.addEventListener('click', () => {
        const codeEl = shadowRoot.getElementById('customXPathDisplay');
        const text = btnCopyCustom.getAttribute('data-copy') || (codeEl ? codeEl.textContent : '');
        copyToClipboard(text, btnCopyCustom, 'Copied!');
      });
    }

    // Initial evaluation for the matrix custom XPath
    if (matrixItems.length > 0) {
      updateCustomXPathAndEvaluate();
    }

    // Breadcrumbs interactive buttons
    const bcButtons = shadowRoot.querySelectorAll('.xpath-bc-btn');
    bcButtons.forEach((btn) => {
      const idx = parseInt(btn.getAttribute('data-bc-idx'), 10);
      const targetEl = activeBreadcrumbElements[idx];
      if (!targetEl) return;

      btn.addEventListener('mouseenter', () => {
        renderHighlight(targetEl);
      });
      btn.addEventListener('mouseleave', () => {
        if (highlightOverlay) highlightOverlay.style.display = 'none';
      });
      btn.addEventListener('click', () => {
        if (highlightOverlay) highlightOverlay.style.display = 'none';
        inspectTarget(targetEl);
      });
    });

    // Children quick-jump interactive buttons
    const chButtons = shadowRoot.querySelectorAll('.xpath-child-pill');
    chButtons.forEach((btn) => {
      const idx = parseInt(btn.getAttribute('data-ch-idx'), 10);
      const targetEl = activeChildElements[idx];
      if (!targetEl) return;

      btn.addEventListener('mouseenter', () => {
        renderHighlight(targetEl);
      });
      btn.addEventListener('mouseleave', () => {
        if (highlightOverlay) highlightOverlay.style.display = 'none';
      });
      btn.addEventListener('click', () => {
        if (highlightOverlay) highlightOverlay.style.display = 'none';
        inspectTarget(targetEl);
      });
    });

    // Auto-scroll breadcrumbs track to active element
    setTimeout(() => {
      const track = shadowRoot.getElementById('breadcrumbsTrack');
      if (track) {
        track.scrollLeft = track.scrollWidth;
      }
    }, 10);

    // Update common save button state for newly inspected element
    updateCommonSaveButtonState();
  }

  /**
   * Live Evaluator: queries and highlights elements
   */
  function evaluateCustomQuery(query) {
    clearEvaluatorHighlights();
    const badge = shadowRoot ? shadowRoot.getElementById('evalBadge') : null;
    const nav = shadowRoot ? shadowRoot.getElementById('matchNav') : null;

    updateCommonSaveButtonState();

    if (!badge || !query) {
      if (badge) badge.style.display = 'none';
      if (nav) nav.style.display = 'none';
      return;
    }

    badge.style.display = 'inline-block';
    evaluatorMatches = [];
    currentMatchIndex = 0;

    const isPlaywright = /^(?:page\.)?getBy(Role|TestId|Label|Placeholder|Text|AltText|Title)\(/i.test(query);
    const isXPath = query.startsWith('/') || query.startsWith('(');

    const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
    try {
      if (isPlaywright) {
        evaluatorMatches = engine ? engine.queryPlaywright(query, document) : [];
      } else if (isXPath) {
        evaluatorMatches = engine ? engine.queryXPath(query, document) : [];
      } else {
        evaluatorMatches = engine ? engine.queryCSS(query, document) : [];
      }

      const count = evaluatorMatches.length;
      if (count === 1) {
        badge.className = 'xpath-eval-badge match-unique';
        badge.textContent = '1 match (Unique)';
        nav.style.display = 'none';
        highlightEvaluatedElements(evaluatorMatches, 0);
      } else if (count > 1) {
        badge.className = 'xpath-eval-badge match-multiple';
        badge.textContent = `${count} matches`;
        nav.style.display = 'flex';
        highlightEvaluatedElements(evaluatorMatches, 0);
      } else {
        badge.className = 'xpath-eval-badge match-none';
        badge.textContent = '0 matches';
        nav.style.display = 'none';
      }
    } catch (e) {
      badge.className = 'xpath-eval-badge match-none';
      badge.textContent = 'Invalid Syntax';
      nav.style.display = 'none';
    }
  }

  /**
   * Cycle through multiple matches in live evaluator
   */
  function cycleMatch(delta) {
    if (!evaluatorMatches.length) return;
    currentMatchIndex = (currentMatchIndex + delta + evaluatorMatches.length) % evaluatorMatches.length;
    const badge = shadowRoot.getElementById('evalBadge');
    badge.textContent = `${currentMatchIndex + 1} of ${evaluatorMatches.length} matches`;

    highlightEvaluatedElements(evaluatorMatches, currentMatchIndex);

    const activeEl = evaluatorMatches[currentMatchIndex];
    if (activeEl && typeof activeEl.scrollIntoView === 'function') {
      activeEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }

  /**
   * Draw highlights over matching elements (capped to first 80 to prevent lag on huge matching sets)
   */
  function highlightEvaluatedElements(matches, activeIdx) {
    if (!evalHighlightContainer) return;
    evalHighlightContainer.innerHTML = '';
    if (!matches || matches.length === 0) return;

    const MAX_HIGHLIGHTS = 80;
    const count = Math.min(matches.length, MAX_HIGHLIGHTS);

    for (let i = 0; i < count; i++) {
      const el = matches[i];
      if (!el || el.nodeType !== Node.ELEMENT_NODE) continue;
      const rect = el.getBoundingClientRect();
      const isActive = i === activeIdx;

      const box = document.createElement('div');
      box.style.cssText = `
        position: fixed;
        top: ${rect.top}px;
        left: ${rect.left}px;
        width: ${rect.width}px;
        height: ${rect.height}px;
        border: ${isActive ? '2px solid #3b82f6' : '1.5px dashed #94a3b8'};
        background: ${isActive ? 'rgba(59, 130, 246, 0.12)' : 'rgba(148, 163, 184, 0.06)'};
        pointer-events: none;
        z-index: 2147483639;
        border-radius: 3px;
        box-shadow: ${isActive ? '0 0 0 2px rgba(59, 130, 246, 0.2)' : 'none'};
      `;
      evalHighlightContainer.appendChild(box);
    }
  }

  function clearEvaluatorHighlights() {
    if (evalHighlightContainer) {
      evalHighlightContainer.innerHTML = '';
    }
  }

  /**
   * Helper: Copy to clipboard with visual feedback and execCommand fallback
   */
  function copyToClipboard(text, btnElement, successLabel) {
    if (!text || !btnElement) return;
    const doSuccess = () => {
      const originalHTML = btnElement.innerHTML;
      btnElement.classList.add('copied');
      btnElement.innerHTML = `${ICONS.check} <span>${successLabel}</span>`;
      setTimeout(() => {
        btnElement.classList.remove('copied');
        btnElement.innerHTML = originalHTML;
      }, 1500);
    };

    function execCopyFallback() {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.position = 'fixed';
        ta.style.top = '0';
        ta.style.left = '0';
        ta.style.opacity = '0';
        ta.style.pointerEvents = 'none';
        ta.style.zIndex = '-1';
        (document.body || document.documentElement).appendChild(ta);
        ta.focus();
        ta.select();
        ta.setSelectionRange(0, 999999);
        document.execCommand('copy');
        ta.remove();
        doSuccess();
      } catch (err) {
        console.warn('Fallback copy error:', err);
      }
    }

    if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      navigator.clipboard.writeText(text)
        .then(doSuccess)
        .catch(() => {
          execCopyFallback();
        });
    } else {
      execCopyFallback();
    }
  }

  function escapeHTML(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /**
   * Chrome Runtime Message Listener (if running as extension)
   */
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === 'TOGGLE_INSPECT') {
        if (message.fromDevTools) {
          if (isInspectMode) {
            stopInspect();
            sendResponse({ status: 'ok', isInspectMode: false });
            return;
          }
          isInspectFromDevTools = true;
          initUI();
          // Hide the launcher button and dock — DevTools inspection is headless on the page
          if (launcherBtn) launcherBtn.style.display = 'none';
          if (dockContainer) dockContainer.style.display = 'none';
          startInspect();
          sendResponse({ status: 'ok', isInspectMode: true });
          return;
        }
        isInspectFromDevTools = false;
        toggleDockAndInspect();
        sendResponse({ status: 'ok', isInspectMode });
      } else if (message.action === 'START_FREEZE_INSPECT') {
        if (message.fromDevTools) {
          isInspectFromDevTools = true;
        }
        startFreezeCountdown(message.delay || 3);
        sendResponse({ status: 'ok' });
      } else if (message.action === 'TOGGLE_FREEZE_INSPECT') {
        toggleFreezeInspect();
        sendResponse({ status: 'ok' });
      } else if (message.action === 'TOGGLE_PANEL') {
        if (dockContainer && dockContainer.style.display === 'none') {
          openDock();
        } else {
          closeDock();
        }
        sendResponse({ status: 'ok' });
      } else if (message.action === 'INSPECT_CONTEXT_ELEMENT') {
        if (window.__LAST_CONTEXT_ELEMENT__) {
          inspectTarget(window.__LAST_CONTEXT_ELEMENT__);
        }
        sendResponse({ status: 'ok' });
      } else if (message.action === 'SET_PREF_FRAMEWORK') {
        if (message.framework) {
          applyFrameworkChange(message.framework);
        }
        sendResponse({ status: 'ok', framework: currentFormat });
      } else if (message.action === 'TOGGLE_RECORD') {
        if (message.fromDevTools) isRecordFromDevTools = true;
        toggleRecording();
        sendResponse({ status: 'ok', isRecording: isRecordingMode });
      } else if (message.action === 'START_RECORD') {
        if (message.fromDevTools) isRecordFromDevTools = true;
        startRecording();
        sendResponse({ status: 'ok', isRecording: true });
      } else if (message.action === 'STOP_RECORD') {
        if (message.fromDevTools) isRecordFromDevTools = true;
        stopRecording();
        sendResponse({ status: 'ok', isRecording: false });
      } else if (message.action === 'GET_RECORD_STATE') {
        sendResponse({ status: 'ok', isRecording: isRecordingMode, isPaused: isRecordingPaused, steps: recordedFlowSteps });
      } else if (message.action === 'TOGGLE_RECORD_PAUSE') {
        if (isRecordingPaused) resumeRecording();
        else pauseRecording();
        sendResponse({ status: 'ok', isPaused: isRecordingPaused });
      } else if (message.action === 'CLEAR_RECORD_STEPS') {
        recordedFlowSteps = [];
        try { sessionStorage.removeItem(STORAGE_KEY_FLOW_STEPS); } catch (e) {}
        if (isExtensionValid()) {
          try {
            chrome.storage.local.set({ [STORAGE_KEY_FLOW_STEPS]: [] });
          } catch (e) {}
        }
        updateRecorderCountBadge();
        updateRecordingHUD();
        sendResponse({ status: 'ok' });
      } else if (message.action === 'ANALYZE_DEVTOOLS_ELEMENT') {
        let el = null;
        if (message.marker) {
          try {
            el = document.querySelector('[data-testpath-active="' + message.marker + '"]');
            if (el) el.removeAttribute('data-testpath-active');
          } catch (e) {}
        }
        if (!el && window.__LAST_CONTEXT_ELEMENT__) el = window.__LAST_CONTEXT_ELEMENT__;
        if (!el) el = document.activeElement;
        if (el && el !== document.body && el !== document.documentElement) {
          const payload = buildDevToolsPayload(el);
          try { renderHighlight(el); } catch (e) {}
          sendResponse({ success: true, data: payload });
        } else {
          sendResponse({ success: false, error: 'Element not found' });
        }
      } else if (message.action === 'DEVTOOLS_EVALUATE_QUERY') {
        const query = message.query;
        const reqIdx = message.matchIndex || 0;
        clearEvaluatorHighlights();
        evaluatorMatches = [];
        const isPlaywright = /^(?:page\.)?getBy(Role|TestId|Label|Placeholder|Text|AltText|Title)\(/i.test(query);
        const isXPath = query.startsWith('/') || query.startsWith('(');
        const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
        try {
          if (isPlaywright) {
            evaluatorMatches = engine ? engine.queryPlaywright(query, document) : [];
          } else if (isXPath) {
            evaluatorMatches = engine ? engine.queryXPath(query, document) : [];
          } else {
            evaluatorMatches = engine ? engine.queryCSS(query, document) : [];
          }
        } catch (e) {
          evaluatorMatches = [];
        }
        if (evaluatorMatches.length > 0) {
          const safeIdx = ((reqIdx % evaluatorMatches.length) + evaluatorMatches.length) % evaluatorMatches.length;
          currentMatchIndex = safeIdx;
          highlightEvaluatedElements(evaluatorMatches, safeIdx);
          const activeEl = evaluatorMatches[safeIdx];
          if (activeEl && typeof activeEl.scrollIntoView === 'function') {
            try { activeEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) {}
          }
          sendResponse({
            success: true,
            total: evaluatorMatches.length,
            index: safeIdx,
            tag: activeEl.tagName ? activeEl.tagName.toLowerCase() : 'element',
            text: (activeEl.innerText || activeEl.textContent || '').trim().slice(0, 100)
          });
        } else {
          removeHighlight();
          sendResponse({ success: true, total: 0, index: -1, tag: '', text: '' });
        }
      } else if (message.action === 'DEVTOOLS_EVALUATE_CUSTOM_XPATH') {
        const engine = XPathEngineRef || (typeof window !== 'undefined' ? window.XPathEngine : null);
        let matches = [];
        try {
          matches = engine ? engine.queryXPath(message.xpath, document) : [];
        } catch (e) {}
        if (matches.length > 0) {
          highlightEvaluatedElements(matches, 0);
        } else {
          removeHighlight();
        }
        sendResponse({ success: true, count: matches.length });
      } else if (message.action === 'DEVTOOLS_HIGHLIGHT_BREADCRUMB') {
        if (activeBreadcrumbElements && activeBreadcrumbElements[message.index]) {
          try { renderHighlight(activeBreadcrumbElements[message.index]); } catch (e) {}
        }
        sendResponse({ status: 'ok' });
      } else if (message.action === 'DEVTOOLS_SELECT_BREADCRUMB') {
        if (activeBreadcrumbElements && activeBreadcrumbElements[message.index]) {
          const el = activeBreadcrumbElements[message.index];
          const payload = buildDevToolsPayload(el);
          try { renderHighlight(el); } catch (e) {}
          sendResponse({ success: true, data: payload });
        } else {
          sendResponse({ success: false, error: 'Breadcrumb not found' });
        }
      } else if (message.action === 'DEVTOOLS_SELECT_CURRENT_MATCH') {
        if (evaluatorMatches && evaluatorMatches[message.index]) {
          const el = evaluatorMatches[message.index];
          const payload = buildDevToolsPayload(el);
          try { renderHighlight(el); } catch (e) {}
          sendResponse({ success: true, data: payload });
        } else {
          sendResponse({ success: false, error: 'Match not found' });
        }
      } else if (message.action === 'DEVTOOLS_CLEAR_HIGHLIGHT') {
        try { removeHighlight(); } catch (e) {}
        try { clearEvaluatorHighlights(); } catch (e) {}
        sendResponse({ status: 'ok' });
      }
      return true;
    });
  }

  // Track context menu clicked element
  window.addEventListener(
    'contextmenu',
    (e) => {
      window.__LAST_CONTEXT_ELEMENT__ = e.target;
    },
    true
  );

  // Keyboard shortcuts: Alt + Shift + X (Inspect), Alt + Shift + F (Freeze), Alt + Shift + R (Record Flow)
  window.addEventListener(
    'keydown',
    (e) => {
      if (e.key === 'Escape' && isAssertPickingMode) {
        e.preventDefault();
        cancelAssertPicking();
        showSavedToast('Assertion picking cancelled');
        return;
      }
      if (e.altKey && e.shiftKey && (e.key === 'X' || e.key === 'x')) {
        e.preventDefault();
        e.stopPropagation();
        toggleDockAndInspect();
      } else if (e.altKey && e.shiftKey && (e.key === 'F' || e.key === 'f')) {
        e.preventDefault();
        e.stopPropagation();
        toggleFreezeInspect();
      } else if (e.altKey && e.shiftKey && (e.key === 'R' || e.key === 'r')) {
        e.preventDefault();
        e.stopPropagation();
        toggleRecording();
      }
    },
    true
  );

  // Re-check DOM presence reactively via MutationObserver for SPAs that wipe body
  try {
    if (typeof MutationObserver !== 'undefined' && document.body) {
      const domObserver = new MutationObserver(() => {
        if (shadowHost && !document.contains(shadowHost)) {
          ensureInDOM();
        }
      });
      domObserver.observe(document.body, { childList: true });
    }
  } catch (obsErr) {}

  // Initialize UI once document is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      initUI();
      checkAutoResumeRecording();
    });
  } else {
    initUI();
    checkAutoResumeRecording();
  }

  function checkAutoResumeRecording() {
    try {
      if (isExtensionValid()) {
        chrome.storage.local.get([STORAGE_KEY_REC_STATE, STORAGE_KEY_FLOW_STEPS], (res) => {
          if (chrome.runtime && chrome.runtime.lastError) return;
          if (res && res[STORAGE_KEY_REC_STATE] && res[STORAGE_KEY_REC_STATE].isRecording) {
            recordedFlowSteps = Array.isArray(res[STORAGE_KEY_FLOW_STEPS]) ? res[STORAGE_KEY_FLOW_STEPS] : [];
            setTimeout(() => {
              startRecording(true);
              if (res[STORAGE_KEY_REC_STATE].isPaused) {
                pauseRecording();
              }
            }, 300);
          }
        });
      }
    } catch (e) {}
  }
})();
