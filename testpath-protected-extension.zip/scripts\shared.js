/**
 * TestPath - Shared Extension Utilities
 * Unified module for Background Service Worker, Popup, DevTools Studio, and Automation Scripts
 */
(function (root) {
  'use strict';

  // Check if URL is an internal browser page where extensions cannot run
  function isRestrictedUrl(url) {
    if (!url || typeof url !== 'string') return false;
    return (
      url.startsWith('chrome://') ||
      url.startsWith('chrome-extension://') ||
      url.startsWith('edge://') ||
      url.startsWith('about:') ||
      url.startsWith('view-source:') ||
      url.startsWith('https://chrome.google.com/webstore')
    );
  }

  // Safe HTML escaper (mitigates XSS when rendering user or DOM text into HTML)
  function escapeHTML(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // Safe UTF-8 to Base64 encoder without deprecated unescape()
  function utf8ToBase64(str) {
    str = String(str || '');
    try {
      if (typeof TextEncoder !== 'undefined') {
        const bytes = new TextEncoder().encode(str);
        let binary = '';
        const len = bytes.length;
        for (let i = 0; i < len; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        return btoa(binary);
      }
    } catch (e) {
      // Fallback
    }
    try {
      return btoa(unescape(encodeURIComponent(str)));
    } catch (e) {
      return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function (_, p1) {
        return String.fromCharCode(parseInt(p1, 16));
      }));
    }
  }

  // Parse timestamps safely (epoch ms, ISO string, Date object)
  function parseTimestamp(ts) {
    if (!ts) return 0;
    if (typeof ts === 'number') return ts;
    const parsed = new Date(ts).getTime();
    return isNaN(parsed) ? 0 : parsed;
  }

  // Framework file extension mapping
  const FRAMEWORK_EXT_MAP = {
    'playwright': 'saved_locators.spec.js',
    'playwright-python': 'test_saved_locators.py',
    'playwright-java': 'SavedLocatorsTest.java',
    'playwright-csharp': 'SavedLocatorsTest.cs',
    'selenium-java': 'SavedLocatorsTest.java',
    'selenium-python': 'test_saved_locators.py',
    'selenium-javascript': 'saved_locators.js',
    'selenium-csharp': 'SavedLocatorsTest.cs',
    'cypress': 'saved_locators.cy.js',
    'robot': 'saved_locators.robot',
    'puppeteer': 'saved_locators.spec.js'
  };

  /**
   * Generates a fully runnable test script in the selected framework
   */
  function buildRunnableTestScript(steps, framework, pageUrl) {
    if (!steps || steps.length === 0) {
      return '// No steps to export yet.';
    }

    var esc = function (s) { return String(s || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"'); };
    var escS = function (s) { return String(s || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'"); };

    // Resolve target page URL dynamically from current page or step metadata
    var targetUrl = (pageUrl && typeof pageUrl === 'string' && pageUrl.startsWith('http'))
      ? pageUrl.trim()
      : null;

    if (!targetUrl && steps && steps.length > 0) {
      for (var k = 0; k < steps.length; k++) {
        var stepUrl = steps[k].pageUrl || steps[k].url;
        if (stepUrl && typeof stepUrl === 'string' && stepUrl.startsWith('http')) {
          targetUrl = stepUrl.trim();
          break;
        }
      }
    }

    if (!targetUrl && typeof window !== 'undefined' && window.location && typeof window.location.href === 'string' && window.location.href.startsWith('http')) {
      targetUrl = window.location.href.trim();
    }

    if (!targetUrl) {
      targetUrl = 'https://your-app-url.com';
    }

    var urlEsc = esc(targetUrl);
    var urlEscS = escS(targetUrl);

    function getLoc(s, fw) {
      if (fw === 'playwright-python') {
        var l = s.bestPlaywright
          ? s.bestPlaywright.replace(/page\.getByRole/g, 'page.get_by_role').replace(/page\.getByTestId/g, 'page.get_by_test_id').replace(/page\.getByText/g, 'page.get_by_text').replace(/page\.getByPlaceholder/g, 'page.get_by_placeholder').replace(/page\.getByLabel/g, 'page.get_by_label')
          : ('page.locator("' + esc(s.bestXPath || s.cssSelector || '//button') + '")');
        return l;
      }
      if (fw === 'playwright-java') {
        return s.bestPlaywrightJava || ('page.locator("' + esc(s.bestXPath || s.cssSelector || '//button') + '")');
      }
      return s.bestPlaywright || ("page.locator('" + escS(s.bestXPath || s.cssSelector || '//button') + "')");
    }
    function cmt(s, i, pad) {
      return pad + '// Step ' + (i + 1) + ': ' + (s.action || 'click').toUpperCase() + ' <' + (s.tagName || s.tag || 'element') + '>' + (s.target ? (' - "' + s.target.slice(0, 40) + '"') : '') + '\n';
    }
    var xp = function (s) { return esc(s.bestXPath || s.cssSelector || '//button'); };
    var xpS = function (s) { return escS(s.bestXPath || s.cssSelector || '//button'); };

    var isRecorded = steps.some(function (s) { return !!s.timestamp; });
    var testTitle = isRecorded ? 'Recorded Flow Test' : 'Saved Locators Flow';
    var className = isRecorded ? 'RecordedFlowTest' : 'SavedLocatorsTest';
    var fnName = isRecorded ? 'test_recorded_flow' : 'test_saved_locators_flow';

    if (!framework || framework === 'playwright' || framework === 'raw') {
      var o = "import { test, expect } from '@playwright/test';\n\ntest('" + testTitle + "', async ({ page }) => {\n  await page.goto('" + urlEscS + "');\n\n";
      steps.forEach(function (s, i) {
        var a = (s.action || 'click').toLowerCase(), l = getLoc(s, 'playwright'); o += cmt(s, i, '  ');
        if (a === 'click') o += '  await ' + l + '.click();\n';
        else if (a === 'fill') o += "  await " + l + ".fill('" + escS(s.value || 'Enter text') + "');\n";
        else if (a === 'assertvisible') o += '  await expect(' + l + ').toBeVisible();\n';
        else if (a === 'asserttext') o += "  await expect(" + l + ").toHaveText('" + escS(s.target || '') + "');\n";
        else if (a === 'assertchecked') o += '  await expect(' + l + ').toBeChecked();\n';
        else if (a === 'assertenabled') o += '  await expect(' + l + ').toBeEnabled();\n';
        else if (a === 'waitfor') o += "  await " + l + ".waitFor({ state: 'visible' });\n";
        else if (a === 'gettext') o += '  const text' + (i + 1) + ' = await ' + l + '.textContent();\n';
        else o += '  await ' + l + '.click();\n';
        o += '\n';
      });
      return o + '});\n';
    }

    if (framework === 'playwright-python') {
      var o = 'import pytest\nfrom playwright.sync_api import Page, expect\n\n\ndef ' + fnName + '(page: Page):\n    page.goto("' + urlEsc + '")\n\n';
      steps.forEach(function (s, i) {
        var a = (s.action || 'click').toLowerCase(), l = getLoc(s, 'playwright-python'); o += cmt(s, i, '    ');
        if (a === 'click') o += '    ' + l + '.click()\n';
        else if (a === 'fill') o += '    ' + l + '.fill("' + esc(s.value || 'Enter text') + '")\n';
        else if (a === 'assertvisible') o += '    expect(' + l + ').to_be_visible()\n';
        else if (a === 'asserttext') o += '    expect(' + l + ').to_have_text("' + esc(s.target || '') + '")\n';
        else if (a === 'waitfor') o += '    ' + l + '.wait_for(state="visible")\n';
        else if (a === 'gettext') o += '    text_' + (i + 1) + ' = ' + l + '.text_content()\n';
        else o += '    ' + l + '.click()\n';
        o += '\n';
      });
      return o;
    }

    if (framework === 'playwright-java') {
      var o = 'package com.example.tests;\n\nimport com.microsoft.playwright.*;\nimport org.junit.jupiter.api.*;\nimport static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;\n\npublic class ' + className + ' {\n\n    static Playwright playwright;\n    static Browser browser;\n    BrowserContext context;\n    Page page;\n\n    @BeforeAll\n    static void launchBrowser() {\n        playwright = Playwright.create();\n        browser = playwright.chromium().launch();\n    }\n\n    @AfterAll\n    static void closeBrowser() {\n        playwright.close();\n    }\n\n    @BeforeEach\n    void createContextAndPage() {\n        context = browser.newContext();\n        page = context.newPage();\n        page.navigate("' + urlEsc + '");\n    }\n\n    @AfterEach\n    void closeContext() {\n        context.close();\n    }\n\n    @Test\n    void ' + fnName + '() {\n';
      steps.forEach(function (s, i) {
        var a = (s.action || 'click').toLowerCase(), l = getLoc(s, 'playwright-java'); o += cmt(s, i, '        ');
        if (a === 'click') o += '        ' + l + '.click();\n';
        else if (a === 'fill') o += '        ' + l + '.fill("' + esc(s.value || 'Enter text') + '");\n';
        else if (a === 'assertvisible') o += '        assertThat(' + l + ').isVisible();\n';
        else if (a === 'asserttext') o += '        assertThat(' + l + ').hasText("' + esc(s.target || '') + '");\n';
        else if (a === 'assertchecked') o += '        assertThat(' + l + ').isChecked();\n';
        else if (a === 'assertenabled') o += '        assertThat(' + l + ').isEnabled();\n';
        else if (a === 'waitfor') o += '        ' + l + '.waitFor();\n';
        else if (a === 'gettext') o += '        String text' + (i + 1) + ' = ' + l + '.textContent();\n';
        else o += '        ' + l + '.click();\n';
        o += '\n';
      });
      return o + '    }\n}\n';
    }

    if (framework === 'playwright-csharp') {
      var o = 'using Microsoft.Playwright;\nusing NUnit.Framework;\nusing System.Threading.Tasks;\n\nnamespace TestPathTests;\n\n[Parallelizable(ParallelScope.Self)]\n[TestFixture]\npublic class ' + className + ' : PageTest\n{\n    [Test]\n    public async Task ' + (isRecorded ? 'RecordedFlowTest' : 'SavedLocatorsFlowTest') + '()\n    {\n        await Page.GotoAsync("' + urlEsc + '");\n\n';
      steps.forEach(function (s, i) {
        var a = (s.action || 'click').toLowerCase(), x = xp(s); o += cmt(s, i, '        ');
        if (a === 'click') o += '        await Page.Locator("' + x + '").ClickAsync();\n';
        else if (a === 'fill') o += '        await Page.Locator("' + x + '").FillAsync("' + esc(s.value || 'Enter text') + '");\n';
        else if (a === 'waitfor') o += '        await Page.Locator("' + x + '").WaitForAsync();\n';
        else o += '        await Page.Locator("' + x + '").ClickAsync();\n';
        o += '\n';
      });
      return o + '    }\n}\n';
    }

    if (framework === 'selenium-java') {
      var o = 'package com.example.tests;\n\nimport org.openqa.selenium.By;\nimport org.openqa.selenium.WebDriver;\nimport org.openqa.selenium.chrome.ChromeDriver;\nimport org.openqa.selenium.support.ui.ExpectedConditions;\nimport org.openqa.selenium.support.ui.WebDriverWait;\nimport org.junit.jupiter.api.*;\nimport java.time.Duration;\nimport static org.junit.jupiter.api.Assertions.*;\n\npublic class ' + className + ' {\n\n    WebDriver driver;\n    WebDriverWait wait;\n\n    @BeforeEach\n    void setUp() {\n        driver = new ChromeDriver();\n        wait = new WebDriverWait(driver, Duration.ofSeconds(10));\n        driver.get("' + urlEsc + '");\n    }\n\n    @AfterEach\n    void tearDown() {\n        if (driver != null) driver.quit();\n    }\n\n    @Test\n    void ' + fnName + '() {\n';
      steps.forEach(function (s, i) {
        var a = (s.action || 'click').toLowerCase(), x = xp(s); o += cmt(s, i, '        ');
        if (a === 'click') o += '        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("' + x + '"))).click();\n';
        else if (a === 'fill') o += '        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("' + x + '"))).sendKeys("' + esc(s.value || 'Enter text') + '");\n';
        else if (a === 'assertvisible') o += '        assertTrue(driver.findElement(By.xpath("' + x + '")).isDisplayed());\n';
        else if (a === 'asserttext') o += '        assertEquals("' + esc(s.target || '') + '", driver.findElement(By.xpath("' + x + '")).getText());\n';
        else if (a === 'waitfor') o += '        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("' + x + '")));\n';
        else if (a === 'gettext') o += '        String text' + (i + 1) + ' = driver.findElement(By.xpath("' + x + '")).getText();\n';
        else o += '        driver.findElement(By.xpath("' + x + '")).click();\n';
        o += '\n';
      });
      return o + '    }\n}\n';
    }

    if (framework === 'selenium-python') {
      var o = 'import pytest\nfrom selenium import webdriver\nfrom selenium.webdriver.common.by import By\nfrom selenium.webdriver.support.ui import WebDriverWait\nfrom selenium.webdriver.support import expected_conditions as EC\n\n\n@pytest.fixture\ndef driver():\n    d = webdriver.Chrome()\n    d.get("' + urlEsc + '")\n    yield d\n    d.quit()\n\n\ndef ' + fnName + '(driver):\n    wait = WebDriverWait(driver, 10)\n\n';
      steps.forEach(function (s, i) {
        var a = (s.action || 'click').toLowerCase(), x = xp(s); o += cmt(s, i, '    ');
        if (a === 'click') o += '    wait.until(EC.element_to_be_clickable((By.XPATH, "' + x + '"))).click()\n';
        else if (a === 'fill') o += '    wait.until(EC.visibility_of_element_located((By.XPATH, "' + x + '"))).send_keys("' + esc(s.value || 'Enter text') + '")\n';
        else if (a === 'assertvisible') o += '    assert driver.find_element(By.XPATH, "' + x + '").is_displayed()\n';
        else if (a === 'asserttext') o += '    assert driver.find_element(By.XPATH, "' + x + '").text == "' + esc(s.target || '') + '"\n';
        else if (a === 'waitfor') o += '    wait.until(EC.visibility_of_element_located((By.XPATH, "' + x + '")))\n';
        else if (a === 'gettext') o += '    text_' + (i + 1) + ' = driver.find_element(By.XPATH, "' + x + '").text\n';
        else o += '    driver.find_element(By.XPATH, "' + x + '").click()\n';
        o += '\n';
      });
      return o;
    }

    if (framework === 'selenium-javascript') {
      var o = "const { Builder, By, Key, until } = require('selenium-webdriver');\n\n(async function " + fnName + "() {\n  const driver = await new Builder().forBrowser('chrome').build();\n  try {\n    await driver.get('" + urlEscS + "');\n\n";
      steps.forEach(function (s, i) {
        var a = (s.action || 'click').toLowerCase(), x = xp(s); o += cmt(s, i, '    ');
        if (a === 'click') o += '    await driver.findElement(By.xpath("' + x + '")).click();\n';
        else if (a === 'fill') o += '    await driver.findElement(By.xpath("' + x + '")).sendKeys("' + esc(s.value || 'Enter text') + '");\n';
        else if (a === 'waitfor') o += '    await driver.wait(until.elementLocated(By.xpath("' + x + '")), 10000);\n';
        else o += '    await driver.findElement(By.xpath("' + x + '")).click();\n';
        o += '\n';
      });
      return o + '  } finally {\n    await driver.quit();\n  }\n})();\n';
    }

    if (framework === 'selenium-csharp') {
      var o = 'using OpenQA.Selenium;\nusing OpenQA.Selenium.Chrome;\nusing OpenQA.Selenium.Support.UI;\nusing NUnit.Framework;\nusing System;\n\nnamespace TestPathTests;\n\n[TestFixture]\npublic class ' + className + '\n{\n    private IWebDriver driver;\n    private WebDriverWait wait;\n\n    [SetUp]\n    public void SetUp()\n    {\n        driver = new ChromeDriver();\n        wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));\n        driver.Navigate().GoToUrl("' + urlEsc + '");\n    }\n\n    [TearDown]\n    public void TearDown()\n    {\n        driver?.Quit();\n    }\n\n    [Test]\n    public void ' + (isRecorded ? 'RecordedFlowTest' : 'SavedLocatorsFlowTest') + '()\n    {\n';
      steps.forEach(function (s, i) {
        var a = (s.action || 'click').toLowerCase(), x = xp(s); o += cmt(s, i, '        ');
        if (a === 'click') o += '        wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("' + x + '"))).Click();\n';
        else if (a === 'fill') o += '        wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("' + x + '"))).SendKeys("' + esc(s.value || 'Enter text') + '");\n';
        else if (a === 'waitfor') o += '        wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("' + x + '")));\n';
        else o += '        driver.FindElement(By.XPath("' + x + '")).Click();\n';
        o += '\n';
      });
      return o + '    }\n}\n';
    }

    if (framework === 'cypress') {
      var o = "describe('" + testTitle + "', () => {\n  before(() => {\n    cy.visit('" + urlEscS + "');\n  });\n\n  it('executes all test flow actions', () => {\n";
      steps.forEach(function (s, i) {
        var a = (s.action || 'click').toLowerCase(), x = xpS(s); o += cmt(s, i, '    ');
        if (a === 'click') o += "    cy.xpath('" + x + "').click();\n";
        else if (a === 'fill') o += "    cy.xpath('" + x + "').type('" + escS(s.value || 'Enter text') + "');\n";
        else if (a === 'assertvisible') o += "    cy.xpath('" + x + "').should('be.visible');\n";
        else if (a === 'asserttext') o += "    cy.xpath('" + x + "').should('have.text', '" + escS(s.target || '') + "');\n";
        else if (a === 'waitfor') o += "    cy.xpath('" + x + "').should('exist');\n";
        else if (a === 'gettext') o += "    cy.xpath('" + x + "').invoke('text').then((t) => { cy.log(t); });\n";
        else o += "    cy.xpath('" + x + "').click();\n";
        o += '\n';
      });
      return o + '  });\n});\n';
    }

    if (framework === 'robot') {
      var o = '*** Settings ***\nLibrary    Browser\n\n*** Test Cases ***\n' + testTitle + '\n    New Page    ' + targetUrl + '\n\n';
      steps.forEach(function (s, i) {
        var a = (s.action || 'click').toLowerCase(), x = s.bestXPath || s.cssSelector || '//button'; o += '    # Step ' + (i + 1) + ': ' + a.toUpperCase() + ' <' + (s.tagName || 'element') + '>\n';
        if (a === 'click') o += '    Click    xpath=' + x + '\n';
        else if (a === 'fill') o += '    Fill Text    xpath=' + x + '    ' + (s.value || 'Enter text') + '\n';
        else if (a === 'assertvisible') o += '    Get Element    xpath=' + x + '\n';
        else if (a === 'waitfor') o += '    Wait For Elements State    xpath=' + x + '    visible\n';
        else o += '    Click    xpath=' + x + '\n';
        o += '\n';
      });
      return o;
    }

    if (framework === 'puppeteer') {
      var o = "const puppeteer = require('puppeteer');\n\n(async () => {\n  const browser = await puppeteer.launch({ headless: false });\n  const page = await browser.newPage();\n  await page.goto('" + urlEscS + "');\n\n";
      steps.forEach(function (s, i) {
        var a = (s.action || 'click').toLowerCase(), x = xpS(s); o += cmt(s, i, '  ');
        if (a === 'fill') o += "  const [el" + (i + 1) + "] = await page.$x('" + x + "');\n  if(el" + (i + 1) + ") await el" + (i + 1) + ".type('" + escS(s.value || 'Enter text') + "');\n";
        else if (a === 'waitfor') o += "  await page.waitForXPath('" + x + "');\n";
        else o += "  const [el" + (i + 1) + "] = await page.$x('" + x + "');\n  if(el" + (i + 1) + ") await el" + (i + 1) + ".click();\n";
        o += '\n';
      });
      return o + '  await browser.close();\n})();\n';
    }

    var o = '// ' + testTitle + ' Export - TestPath\n\n';
    steps.forEach(function (s, i) { o += '// Step ' + (i + 1) + ': ' + (s.action || 'locator').toUpperCase() + ' - <' + (s.tagName || s.tag || 'element') + '>\n' + (s.bestXPath || s.cssSelector || '//button') + '\n\n'; });
    return o;
  }

  const TestPathShared = {
    isRestrictedUrl: isRestrictedUrl,
    escapeHTML: escapeHTML,
    utf8ToBase64: utf8ToBase64,
    parseTimestamp: parseTimestamp,
    FRAMEWORK_EXT_MAP: FRAMEWORK_EXT_MAP,
    buildRunnableTestScript: buildRunnableTestScript
  };

  root.TestPathShared = TestPathShared;
  root.isRestrictedUrl = isRestrictedUrl;
  root.escapeHTML = escapeHTML;
  root.escapeHTMLPopup = escapeHTML;
  root.utf8ToBase64 = utf8ToBase64;
  root.parseTimestamp = parseTimestamp;
  root.FRAMEWORK_EXT_MAP = FRAMEWORK_EXT_MAP;
  root.buildRunnableTestScript = buildRunnableTestScript;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = TestPathShared;
  }
})(typeof globalThis !== 'undefined' ? globalThis : (typeof window !== 'undefined' ? window : this));
