/**
 * Smart XPath Finder - Background Service Worker (Manifest V3)
 */

try {
  importScripts('scripts/shared.js');
} catch (e) {
  console.warn('Failed to import scripts/shared.js:', e);
}

// Fallback isRestrictedUrl if shared.js was not loaded
function isRestrictedUrl(url) {
  if (typeof globalThis.TestPathShared !== 'undefined' && typeof globalThis.TestPathShared.isRestrictedUrl === 'function') {
    return globalThis.TestPathShared.isRestrictedUrl(url);
  }
  if (!url || typeof url !== 'string') return false;
  return (
    url.startsWith('chrome://') ||
    url.startsWith('chrome-extension://') ||
    url.startsWith('edge://') ||
    url.startsWith('about:') ||
    url.startsWith('view-source:') ||
    url.startsWith('https://chrome.google.com/webstore')
  );
}

// Safe UTF-8 to Base64 encoder fallback
function toBase64(str) {
  if (typeof globalThis.utf8ToBase64 === 'function') {
    return globalThis.utf8ToBase64(str);
  }
  try {
    return btoa(unescape(encodeURIComponent(str || '')));
  } catch (e) {
    return '';
  }
}

chrome.runtime.onInstalled.addListener(() => {
  // Create Context Menu item
  chrome.contextMenus.create({
    id: 'smart-xpath-inspect',
    title: 'Inspect Best XPath',
    contexts: ['all']
  });
});

// Handle Context Menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'smart-xpath-inspect') {
    let targetTab = tab;

    // If tab is missing or has invalid ID, query current active tab
    if (!targetTab || typeof targetTab.id !== 'number' || targetTab.id < 0) {
      try {
        const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
        targetTab = activeTab;
      } catch (e) {
        return;
      }
    }

    if (!targetTab || typeof targetTab.id !== 'number' || targetTab.id < 0) {
      return;
    }

    if (isRestrictedUrl(targetTab.url)) {
      console.warn('Cannot inspect internal browser page:', targetTab.url);
      return;
    }

    try {
      chrome.tabs.sendMessage(targetTab.id, { action: 'INSPECT_CONTEXT_ELEMENT' }, (response) => {
        if (chrome.runtime.lastError) {
          // If content script was not yet injected on this page, inject and retry
          injectScriptsAndSend(targetTab.id, { action: 'INSPECT_CONTEXT_ELEMENT' });
        }
      });
    } catch (err) {
      injectScriptsAndSend(targetTab.id, { action: 'INSPECT_CONTEXT_ELEMENT' });
    }
  }
});

// Map command hotkeys to content-script actions
const COMMAND_ACTIONS = {
  'toggle-inspect': 'TOGGLE_INSPECT',
  'freeze-inspect': 'TOGGLE_FREEZE_INSPECT',
  'toggle-record': 'TOGGLE_RECORD'
};

// Handle extension commands / hotkeys
chrome.commands.onCommand.addListener(async (command) => {
  const action = COMMAND_ACTIONS[command];
  if (!action) return;

  try {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) {
      const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      tab = tabs[0];
    }
    if (!tab || typeof tab.id !== 'number' || tab.id < 0) return;
    if (isRestrictedUrl(tab.url)) return;

    chrome.tabs.sendMessage(tab.id, { action }, () => {
      if (chrome.runtime.lastError) {
        injectScriptsAndSend(tab.id, { action });
      }
    });
  } catch (err) {
    console.warn('Command error:', err);
  }
});

/**
 * Fallback injector if tab hasn't loaded content script yet
 */
async function injectScriptsAndSend(tabId, message) {
  if (typeof tabId !== 'number' || tabId < 0) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['scripts/contentScript.js']
    });
    setTimeout(() => {
      chrome.tabs.sendMessage(tabId, message, () => {
        if (chrome.runtime.lastError) {
          // suppress silent cleanup error
        }
      });
    }, 150);
  } catch (err) {
    // Restricted or closed tab
  }
}

// Active requested downloads tracking with auto TTL cleanup (prevents memory leak)
const pendingDownloadsByUrl = new Map();
const pendingDownloadsById = new Map();

function trackPendingDownload(map, key, filename, ttlMs = 60000) {
  if (!key || !filename) return;
  map.set(key, filename);
  setTimeout(() => {
    map.delete(key);
  }, ttlMs);
}

// Handle file downloads requested by content scripts, popup, or panel
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.action === 'DOWNLOAD_FILE') {
    const { content, filename, mimeType } = message;
    if (chrome.downloads && typeof chrome.downloads.download === 'function') {
      try {
        const base64 = toBase64(content || '');
        const mime = mimeType || 'application/octet-stream';
        const dataUrl = `data:${mime};charset=utf-8;base64,${base64}`;

        if (filename) {
          trackPendingDownload(pendingDownloadsByUrl, dataUrl, filename);
        }

        chrome.downloads.download({
          url: dataUrl,
          filename: filename,
          saveAs: false,
          conflictAction: 'uniquify'
        }, (downloadId) => {
          if (chrome.runtime.lastError) {
            console.warn('Background download error:', chrome.runtime.lastError.message);
            if (filename) pendingDownloadsByUrl.delete(dataUrl);
            sendResponse({ success: false, error: chrome.runtime.lastError.message });
          } else {
            if (downloadId && filename) {
              trackPendingDownload(pendingDownloadsById, downloadId, filename);
            }
            sendResponse({ success: true, downloadId });
          }
        });
      } catch (err) {
        console.warn('Data URL encoding error:', err);
        sendResponse({ success: false, error: err.message });
      }
      return true; // Keep message channel open for async response
    }
  }
});

// Enforce exact requested file extension (.java, .py, .spec.js, .cs, .robot, etc.) and prevent Chrome from appending or substituting .txt
if (chrome.downloads && chrome.downloads.onDeterminingFilename) {
  chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
    try {
      let desired = null;
      if (item.id && pendingDownloadsById.has(item.id)) {
        desired = pendingDownloadsById.get(item.id);
        pendingDownloadsById.delete(item.id);
      } else if (item.url && pendingDownloadsByUrl.has(item.url)) {
        desired = pendingDownloadsByUrl.get(item.url);
        pendingDownloadsByUrl.delete(item.url);
      }

      let chosenFilename = desired || item.filename || '';

      // Strip unwanted .txt that Chrome automatically appends to automation scripts
      // e.g. "SavedLocatorsTest.java.txt" -> "SavedLocatorsTest.java"
      chosenFilename = chosenFilename.replace(/\.(java|py|cs|robot|spec\.js|cy\.js|js|json|csv)\.txt$/i, '.$1');

      // If Chrome replaced the extension entirely with .txt (e.g. "SavedLocatorsTest.txt" when original was "SavedLocatorsTest.java")
      if (desired && !desired.endsWith('.txt') && chosenFilename.endsWith('.txt')) {
        chosenFilename = desired;
      }

      // If no desired was recorded but filename is a known script name without extension:
      if (!desired && chosenFilename.endsWith('.txt')) {
        if (/Test\.txt$/i.test(chosenFilename)) {
          chosenFilename = chosenFilename.replace(/\.txt$/i, '.java');
        } else if (/test_.*\.txt$/i.test(chosenFilename) || /_flow\.txt$/i.test(chosenFilename)) {
          chosenFilename = chosenFilename.replace(/\.txt$/i, '.py');
        }
      }

      if (chosenFilename) {
        suggest({ filename: chosenFilename, conflictAction: 'uniquify' });
        return true;
      }
    } catch (e) {
      console.warn('onDeterminingFilename error:', e);
    }
    suggest({ filename: item.filename, conflictAction: 'uniquify' });
    return true;
  });
}
